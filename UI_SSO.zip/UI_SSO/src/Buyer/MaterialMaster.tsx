import React, { useEffect, useState } from 'react';
import { useRolePermissions } from '../UseRolePermission';

const MaterialMaster = () => {
  const { permissions: allRolesPermissions, loading } = useRolePermissions();
  const [userRole, setUserRole] = useState<string | null>(null);
  const [userPermissions, setUserPermissions] = useState<any>(null);

  useEffect(() => {
    const userData = localStorage.getItem("userData");
    if (userData) {
      const parsedUser = JSON.parse(userData);
      console.log('parsedUser',parsedUser);
      setUserRole(parsedUser.role);
    }
  }, []);

  useEffect(() => {
    if (userRole && allRolesPermissions.length > 0) {
      console.log("User role from localStorage:", userRole);
      console.log("All roles from backend:", allRolesPermissions.map(p => p.role));
      
      const matchedRole = allRolesPermissions.find(
        (r: any) => r.role.toLowerCase() === userRole.toLowerCase()
      );
      if (matchedRole) {
        setUserPermissions(matchedRole.permissions);
      } else {
        console.warn("No matching role found.");
      }
    }
  }, [userRole, allRolesPermissions]);
  

  if (loading) return <p>Loading...</p>;
  if (!userRole || !userPermissions) return <p>No permissions found for your role.</p>;

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Tasks for Role: {userRole}</h2>
      <div className="module-grid">
        {Object.entries(userPermissions).map(([module, tasks]) => (
          <div key={module} className="module-card border p-4 rounded shadow mb-4">
            <h3 className="module-title font-semibold text-lg mb-2">{module}</h3>
            <ul className="task-list space-y-2">
              {(tasks as string[]).map(task => (
                <li  key={task}>{task}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </div>
  );
};

export default MaterialMaster;
