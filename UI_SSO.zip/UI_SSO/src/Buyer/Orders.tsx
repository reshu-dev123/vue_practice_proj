import React, { useEffect, useState } from "react";
import axios from "axios";
import "./Request.css"; 
import { Link } from "react-router-dom";


interface PrListItem {
  po_id: string;
  po_type: string;
  po_ref: string;
  description: string;
  site_location: string;
  client_name: string;
  po_creation_date: string;
  delivery_date: string;
  buyer_name: string;
  status: string;
}

const Order: React.FC = () => {
  const [orderData, setOrderData] = useState<PrListItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      let token = localStorage.getItem("authToken");
      try {
        const response = await axios.get<{ PurchaseOrder: PrListItem[] }>(
          "http://192.168.203.122:5000/po-list",
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setOrderData(response.data.PurchaseOrder);
        setLoading(false);
      } catch (err) {
        setError("Failed to fetch orderData");
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div className="user-details">
      <div className="main-table-heading">
        <h3 className="table-title">Recent Purchase Requisitions</h3>
      </div>
    <table className="styled-table-req">
        <thead>
          <tr>
            <th>PO ID</th>
            <th>Type</th>
            <th>Reference</th>
            <th>Description</th>
            <th>Site Location</th>
            <th>Client Name</th>
            <th>Creation Date</th>
            <th>Delivery Date</th>
            <th>Buyer Name</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {orderData.map((item) => (
            <tr key={item.po_id}>
              <td>
              <Link to={`/purchase-request`} className="pr-link">
                  {item.po_id}
              </Link>
              </td>
              <td>{item.po_type}</td>
              <td>{item.po_ref}</td>
              <td>{item.description}</td>
              <td>{item.site_location}</td>
              <td>{item.client_name}</td>
              <td>{item.po_creation_date}</td>
              <td>{item.delivery_date}</td>
              <td>{item.buyer_name}</td>
              <td>
              <span
                 className={`status-badge ${
                  (item.status || "unknown").toLowerCase().replace(" ", "-")
                }`}
              >
                {item.status || "Unknown"}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Order;