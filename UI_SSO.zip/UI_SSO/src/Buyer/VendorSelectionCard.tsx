import React from 'react';
import './VendorSelectionCard.css';


type Props = {
  vendors: Record<string,any>[];
  onSubmit: () => void;
  onRemoveVendor: (vendorId: string) => void;
};

const VendorSelectionCard: React.FC<Props> = ({ vendors, onSubmit, onRemoveVendor }) => {
  return (
    <>
    <div className="vendor-selection-container">
        <div className='disp-flex'>
        {vendors.map((vendor) => (
            <div key={vendor.vendor_id} className="vendor-card">
            <div className="vendor-header">
                <button onClick={() => onRemoveVendor(vendor.vendor_id)} className="remove-btn">×</button>
            </div>
            <h3 className="vendor-name">{vendor.vendor_name}</h3>
            {/* <div className="vendor-location">{vendor.address}</div> */}
            <div className="vendor-info">
                <span className="vendor-rating">
                {'★'.repeat(vendor.vendor_rating)} 
                {'☆'.repeat(5 - vendor.vendor_rating)}
                </span>
                {/* <div>📦 Open Orders: {vendor.open_orders_count}</div>
                <div>📧 Email: {vendor.email || 'Not Available'}</div>
                <div>📞 Contact: {vendor.contact}</div>  */}
            </div>
            </div>
        ))} 
        </div>
        <div className="">
            <button onClick={onSubmit} className="submit-btn">Submit</button>
        </div>
    </div>
   </>
  );
};

export default VendorSelectionCard;