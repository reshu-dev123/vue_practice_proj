import React, { useState, useEffect } from "react";
import { io, Socket } from "socket.io-client";
import PurchaseRequest from "./PurchaseRequest";
import DealAssist from "../DealAssist/DealAssist";
import "./Request.css";

const PRWindow = () => {
  const [dividerPosition, setDividerPosition] = useState(60); // Initial width percentage for PurchaseRequest
  const [data, setData] = useState<Record<string,any> | null>(null);
  const [socket, setSocket] = useState<Socket | null>(null);

  // Establish WebSocket connection on component mount
  useEffect(() => {
    const newSocket = io("http://localhost:5000"); // Replace with your backend WebSocket URL
    

    // Subscribe to PR updates if data is available
    if (data?.pr_id) {
      setSocket(newSocket);
      newSocket.emit("subscribeToPR", data.pr_id);

      // Listen for PR updates
    newSocket.on("prUpdate", (updateData) => {
      console.log("Received PR update:", updateData);
      setData((prevData) => ({
        ...prevData,
        ...updateData,
      }));
    });

    }

    
    // Cleanup on component unmount
    return () => {
      newSocket.disconnect();
    };
  }, [data?.pr_id]);

  const handleMouseDown = (e: React.MouseEvent) => {
    const startX = e.clientX;

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const deltaX = moveEvent.clientX - startX;
      const newDividerPosition = Math.min(
        Math.max(dividerPosition + (deltaX / window.innerWidth) * 100, 0), // Allow dividerPosition to reach 0%
        100 // Allow dividerPosition to reach 100%
      );
      setDividerPosition(newDividerPosition);
    };

    const handleMouseUp = () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };

    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);
  };

  return (
    <div className="pr-window">
      <div
        className="purchase-request"
        style={{ width: `${dividerPosition}%` }}
      >
        <PurchaseRequest setData={setData} />
      </div>
      <div className="divider" onMouseDown={handleMouseDown}>
        <span className="material-symbols-outlined">drag_indicator</span>
      </div>
      {dividerPosition < 100 && ( // Only render DealAssist if dividerPosition is less than 100%
        <div
          className="deal-assist"
          style={{ width: `${100 - dividerPosition}%` }}
        >
          <DealAssist data={data} />
        </div>
      )}
    </div>
  );
};

export default PRWindow;