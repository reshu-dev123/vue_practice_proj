import React, { useEffect, useState } from "react";
import axios from "axios";
import "./Request.css";

interface VendorItem {
  vendor_id: number;
  company_id: number;
  vendor_name: string;
  contact_person_id: number | null;
  address_id: string | null;
  phone: string | null;
  email: string | null;
  created_at: string;
  open_orders_count: number | null;
  open_orders_cost: string | null;
  buyer_notes: string | null;
  vendor_rating: number | null;
  status: string | null;
  user_comments: string | null;
  previous_comments: string | null;
  reject_notes: string | null;
  address: string | null;
}

const Vendor: React.FC = () => {
  const [data, setData] = useState<VendorItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      const token = localStorage.getItem("authToken");
      if (!token) {
        setError("Authentication token is missing");
        setLoading(false);
        return;
      }
      try {
        const baseURL = process.env.REACT_APP_API_BASE_URL;
        const response = await axios.get<{ VendorList: VendorItem[] }>(
           `${baseURL}/vendor-list`,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setData(response.data.VendorList);
        setLoading(false);
      } catch (err) {
        setError("Failed to fetch data");
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const handleRemove = (vendorId: string) => {
    console.log('Remove vendor:', vendorId);
  };

  const handleSubmit = () => {
    console.log('Submit selected vendors');
  };

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <>
    
    <div className="user-details">
      <div className="main-table-heading">
        <h3 className="table-title">Vendor List</h3>
      </div>
      <table className="styled-table-req">
      <thead>
        <tr>
          <th>Vendor ID</th>
          <th>Vendor Name</th>
          <th>Email</th>
          <th>Address</th>
          <th>Created At</th>
          <th>Open Orders Count</th>
          <th>Open Orders Cost</th>
          <th>Vendor Rating</th>
          <th>Status</th>
        </tr>
    </thead>
        <tbody>
          {data.map((vendor) => (
             <tr key={vendor.vendor_id}>
             <td>{vendor.vendor_id}</td>
             <td>{vendor.vendor_name || "N/A"}</td>
             <td>{vendor.email || "N/A"}</td>
             <td>{vendor.address || "N/A"}</td>
             <td>{new Date(vendor.created_at).toLocaleDateString()}</td>
             <td>{vendor.open_orders_count !== null ? vendor.open_orders_count : "N/A"}</td>
             <td>{vendor.open_orders_cost !== null ? `$${vendor.open_orders_cost}` : "N/A"}</td>
             <td>{vendor.vendor_rating !== null ? vendor.vendor_rating.toFixed(1) : "N/A"}</td>
             <td>
               <span
                 className={`status-badge ${
                   (vendor.status || "unknown").toLowerCase().replace(" ", "-")
                 }`}
               >
                 {vendor.status || "Unknown"}
               </span>
             </td>
           </tr>
          ))}
        </tbody>
      </table>
    </div>
    </>
  );
};

export default Vendor;