import React, { useEffect, useState } from "react";
import axios from "axios";
import "./Request.css"; 
import { Link } from "react-router-dom";
import editIcon from "../assets/edit_icon.png";


interface PrListItem {
  pr_id: string;
  pr_type: string;
  pr_ref: string;
  description: string;
  site_location: string;
  client_name: string;
  pr_creation_date: string;
  delivery_date: string;
  buyer_name: string;
  status: string;
}

const Request: React.FC = () => {
  const [data, setData] = useState<PrListItem[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [editingBuyer, setEditingBuyer] = useState<string | null>(null); // Track which PR ID is being edited
  let token = localStorage.getItem("authToken");
  const baseURL = process.env.REACT_APP_API_BASE_URL;

  const handleBuyerChange = async (prId: string, newBuyer: string) => {
    try {
     
      await axios.put(
        `${baseURL}/update-pr`,
        { pr_id: prId, buyer_name: newBuyer },
        {
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
          },
        }
      );

      // Update the buyer_name in the local state
      setData((prevData) =>
        prevData.map((item) =>
          item.pr_id === prId ? { ...item, buyer_name: newBuyer } : item
        )
      );
      // Close the dropdown after updating
      setEditingBuyer(null);
    } catch (err) {
      console.error("Failed to update buyer name", err);
    }
  };
  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get<{ PurchaseRequest: PrListItem[] }>(
          `${baseURL}/pr-list`,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setData(response.data.PurchaseRequest);
        setLoading(false);
      } catch (err) {
        setError("Failed to fetch data");
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div className="user-details">
      <div className="main-table-heading">
        <h3 className="table-title">Recent Purchase Requisitions</h3>
      </div>
    <table className="styled-table-req">
        <thead>
          <tr>
            <th>PR ID</th>
            <th>Type</th>
            <th>Reference</th>
            <th>Description</th>
            <th>Site Location</th>
            <th>Client Name</th>
            <th>Creation Date</th>
            <th>Delivery Date</th>
            <th>Buyer Name</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item) => (
            <tr key={item.pr_id}>
              <td>
              <Link to={`/purchase-request/${item.pr_id}`} className="pr-link">
                  {item.pr_id}
              </Link>
              </td>
              <td>{item.pr_type}</td>
              <td>{item.pr_ref}</td>
              <td>{item.description}</td>
              <td>{item.site_location}</td>
              <td>{item.client_name}</td>
              <td>{item.pr_creation_date}</td>
              <td>{item.delivery_date}</td>
              <td >
                {item.status === "new" ? (
                   <>
                   {editingBuyer === item.pr_id ? (
                     <select
                       value={item.buyer_name || ""}
                       onChange={(e) =>
                         handleBuyerChange(item.pr_id, e.target.value)
                       }
                       onBlur={() => setEditingBuyer(null)} // Close dropdown on blur
                     >
                       <option value="">Select Buyer</option>
                       <option value="Pratap ">Pratap</option>
                       <option value="Subba Raju">Subba Raju</option>
                       <option value="Gowtham">Gowtham</option>
                       <option value="Pavan">Pavan</option>
                       <option value="Srinivas">Srinivas </option>
                     </select>
                   ) : (
                     <div className="disp-flex">
                       {item.buyer_name || "Not Assigned"}
                       <img src={editIcon}
                         className="action-icon"
                         onClick={() => setEditingBuyer(item.pr_id)} // Open dropdown on click
                       />
                     </div>
                   )}
                  </>
                ) : (
                  item.buyer_name
                )}
              </td>
              <td>
              <span
                  className={`status-badge ${
                    (item.status || "unknown").toLowerCase().replace(" ", "-")
                  }`}
                >
                  {item.status || "Unknown"}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default Request;