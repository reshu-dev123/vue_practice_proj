import React, { useEffect, useState } from "react";
import axios from "axios";
import "./Request.css"; 


interface materials {
  material_id: number;
  code: string;
  material_name: string;
  uom: string;
  category: string;
  quality_notes: string | null;
  good_brands: string | null;
  company_id: number;
  created_at: string;
}

const MaterialList: React.FC = () => {
  const [materialData, setMaterialListData] = useState<materials[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      let token = localStorage.getItem("authToken");
      try {  
        const baseURL = process.env.REACT_APP_API_BASE_URL;
        const response = await axios.get<{ materialsList: materials[] }>(
          `${baseURL}/material-list`,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${token}`,
            },
          }
        );
        setMaterialListData(response.data.materialsList);
        setLoading(false);
      } catch (err) {
        setError("Failed to fetch materialData");
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div>{error}</div>;
  }

  return (
    <div className="user-details">
      <div className="main-table-heading">
        <h3 className="table-title">Materials</h3>
      </div>
    <table className="styled-table-req">
        <thead>
          <tr>
            <th>Material ID</th>
            <th>Code</th>
            <th>Material Name</th>
            <th>Unit of Measurement</th>
            <th>Category</th>
            <th>Quality Notes</th>
            <th>Good Brands</th>
            <th>Company ID</th>
            <th>Created At</th>
          </tr>
        </thead>
        <tbody>
        {materialData.map((item) => (
          <tr key={item.material_id}>
            <td>{item.material_id}</td>
            <td>{item.code}</td>
            <td>{item.material_name}</td>
            <td>{item.uom}</td>
            <td>{item.category}</td>
            <td>{item.quality_notes || "N/A"}</td>
            <td>{item.good_brands || "N/A"}</td>
            <td>{item.company_id}</td>
            <td>{new Date(item.created_at).toLocaleDateString()}</td>
          </tr>
       ))}
        </tbody>
      </table>
    </div>
  );
};

export default MaterialList;