import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import "./PurchaseRequest.css";
import CurrencyFormatter from "../utils/CurrencyFormatter";

const PurchaseRequest = ({ setData }: Record<string, any>) => {
  const { pr_id } = useParams<{ pr_id: string }>();
  const [prDataJson, setPrData] = useState<Record<string, any>>();
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [quoteCount, setQuoteCount] = useState<number>(0);
  let token = localStorage.getItem("authToken");

  useEffect(() => {
    const fetchData = async () => {
      console.log('iddd', pr_id)
      try {
        const baseURL = process.env.REACT_APP_API_BASE_URL;
        const response = await axios.get(
          `${baseURL}/pr-data/${pr_id}`,
          {
            headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${token}`,
            },
          }
        );
        console.log("Response:", response);
        setData(response.data.PurchaseRequestData.pr_data);
        setPrData(response.data.PurchaseRequestData.pr_data);
        setQuoteCount(response.data.PurchaseRequestData.pr_data.quotes? response.data.PurchaseRequestData.pr_data.quotes.length:0);
        // console.log(response.data.PurchaseRequestData.pr_data);
        setLoading(false);
      } 
      catch (err) {
        setError("Failed to fetch data");
        setLoading(false);
      }
    };

    fetchData();
  }, [pr_id]);

  if (loading)
    return <div>Loading...</div>;


  if (error) 
    return <div>{error}</div>;

  if (!prDataJson) 
    return <div>No data available</div>;


  return (
    <>
      <div className="purchase-request-header">
        <div className="header">    
            <div className="opr-vendor-details">
              {/* <div className="opr-vendor-info">
                <p className="opr-pr-id">{prDataJson.pr_ref}</p>
                <p className="status-badge">{prDataJson.status}</p>
              </div> */}
              <div className="opr-vendor-info">
                <p className="opr-vendor-title">PR No.</p>
                <p className="opr-pr-id">{prDataJson.pr_ref}</p>
              </div>
              <div className="opr-vendor-info">
                <p className="opr-vendor-title">Client/Location</p>
                <p className="opr-vendor-value">{prDataJson.client_name} / {prDataJson.site_location}</p>
              </div>
              <div className="opr-vendor-info">
                <p className="opr-vendor-title">Status</p>
                <p className="status-badge">{prDataJson.status}</p>
              </div>
              <div className="opr-vendor-info">
                <p className="opr-vendor-title">Pr Type</p>
                <p className="opr-vendor-value">{prDataJson.pr_type}</p>
              </div>
              <div className="opr-vendor-info">
                <p className="opr-vendor-title">Delivery Date</p>
                <p className="opr-vendor-value">{prDataJson.delivery_date}</p>
              </div>
              <div className="opr-vendor-info">
                <p className="opr-vendor-title">Next Action</p>
                <p className="opr-vendor-value">{prDataJson.next_action}</p>
              </div>
              {/* <div className="opr-vendor-info">
                <p className="opr-vendor-title">P1 Vendor</p>
             {quoteCount>0 && prDataJson.quotes.map((quote:Record<string,any>) => (
                <p className="opr-vendor-value" key={`${quote.quote_no}-vendor`} >
                  {quote.vendor_name}
                </p>
              ))}             
              </div> */}
            </div>
          

          {/* <div>
            <span>Client/Location</span>
            <p>{data.client_name} / {data.site_location}</p>
          </div>

          <div>
            <span>Delivery Date</span>
            <p>{data.delivary_date}</p>
          </div> */}
        </div>
      <div style={{padding:"16px"}}>
      <div className="purchase-request-container">
        <div className="main-table-heading">
          <h3 className="">Comparative Report</h3>
        </div>

  <div className="table-container">
    <table className="styled-table">
              <thead>
                <tr>
          {/* Fixed Columns */}
          <th className="opr-table-text-center" style={{ width: '10%' }} rowSpan={3}>S.No</th>
          <th style={{ width: '30%' }} rowSpan={3}>Material Description</th>
          <th className="opr-table-text-center" rowSpan={3}>Total Qty</th>
          {/* Scrollable Columns */}
          { quoteCount>0 && prDataJson.quotes.map((quote:Record<string,any>) => (
  <th key={`${quote.quote_no}-vendor`} colSpan={2}>
    <div className="opr-vendor-cell-details">
      <div className="opr-vendor-cell-content">
        <div className="opr-vendor-info">
          <div className="opr-vendor-name">{quote.vendor_name}</div>
          <div className="opr-vendor-location">{prDataJson.site_location}</div>
        </div>
        <div className="opr-vendor-cell-actions">
          <button className="ask-ai">Ask AI</button>
          <a href="#" className="show-more">Show more</a>
        </div>
      </div>
    </div>
  </th>
))}
         
      </tr>
        <tr>
        { quoteCount>0 && prDataJson.quotes.map((quote:Record<string,any>) => (
            <>
            <th className="opr-table-text-center" style={{fontWeight:"500"}} key={quote.quote_no} colSpan={2}>
            Quote #{quote.quote_no}
          </th>
                    </>
          ))}
        </tr>
        <tr>
        {/* Subheaders for each quote */}
                  { quoteCount>0 && prDataJson.quotes.map((quote:Record<string,any>) => (
          <React.Fragment key= {quote.quote_no}>
            <th className="opr-table-text-center" key={`${quote.quote_no}-rate`}>Unit Cost</th>
            <th className="opr-table-text-center" key={`${quote.quote_no}-total`}>Total Amount</th>
          </React.Fragment>
                  ))}
                </tr>
              </thead>
              <tbody>
        {/* Material List Section */}
        <tr>
          <td colSpan={3 + quoteCount * 2} className="section-header">
            MATERIAL LIST
          </td>
        </tr>
                { prDataJson.materials.map((material:Record<string,any>, index:number) => (
                  <tr key={index}>
            {/* Fixed Columns */}
            <td className="opr-table-text-center" >{index + 1}</td>
            <td >{material.material_name}</td>
            <td className="opr-table-text-center">{material.quantity}</td>
            {/* Scrollable Columns */}
               

            {quoteCount>0 && prDataJson.quotes.map((quote:Record<string,any>) => (
    <>
            <td className="opr-table-text-center" key={`${quote.quote_no}-rate`}>
            <CurrencyFormatter value={quote.item_list[index]?.unit_cost} />
            </td>
            <td className="opr-table-text-center" key={`${quote.quote_no}-total`}>
              <CurrencyFormatter value={quote.item_list[index]?.total_cost} />
            </td>
            </>
  )
)}
                  </tr>
                )) }

        {/* Cost Summary Section */}
        <tr>
          <td colSpan={3 + quoteCount * 2} className="section-header">
            COST SUMMARY
          </td>
                  </tr>
                  <tr>
          <td colSpan={3} >Base Cost</td>
                    {quoteCount>0 && prDataJson.quotes.map((quote:Record<string,any>) => (
            <td className="opr-table-text-center" key={`${quote.quote_no}-interest`} colSpan={2}>
                        <CurrencyFormatter value={quote.summary.total_cost} />
                      </td>
                    ))}
                  </tr>
                  <tr>
          <td colSpan={3} >GST</td>
                    {quoteCount>0 && prDataJson.quotes.map((quote:Record<string,any>) => (
            <td className="opr-table-text-center" key={`${quote.quote_no}-basic-value`} colSpan={2}>
                        <CurrencyFormatter value={quote.summary.taxes_total} />
                      </td>
                    ))}
                  </tr>
                  <tr>
          <td colSpan={3} >Shipping</td>
                    {quoteCount>0 && prDataJson.quotes.map((quote:Record<string,any>) => (
           <td className="opr-table-text-center" key={`${quote.quote_no}-shipping`} colSpan={2}>
           <CurrencyFormatter value={quote.summary.shipping_cost} />
                      </td>
                    ))}
                  </tr>
                  <tr>
          <td colSpan={3} >Grand Total</td>
                    {quoteCount>0 && prDataJson.quotes.map((quote:Record<string,any>) => (
            <td className="opr-table-text-center" key={`${quote.quote_no}-grand-total`} colSpan={2}>
                        <CurrencyFormatter value={quote.summary.grand_total} />
                      </td>
                    ))}
                  </tr>

        {/* Terms & Conditions Section */}
        <tr>
          <td colSpan={3 + quoteCount * 2} className="section-header">
             TERMS & CONDITIONS
          </td>
                </tr>
                <tr>
          <td colSpan={3} >Payment Terms</td>
                  {quoteCount>0 && prDataJson.quotes.map((quote:Record<string,any>) => (
            <td className="opr-table-text-center" key={`${quote.quote_no}-price-basis`} colSpan={2}>
             {quote.terms.payment_terms}
            </td>
                  ))}
                </tr>
                <tr>
          <td colSpan={3} >Delivery Time</td>
                  {quoteCount>0 && prDataJson.quotes.map((quote:Record<string,any>) => (
            <td className="opr-table-text-center" key={`${quote.quote_no}-delivery-time`} colSpan={2}>
              {quote.terms.delivery_time}
            </td>
                  ))}
                </tr>
                <tr>
          <td colSpan={3} >Warranty</td>
                  {quoteCount>0 && prDataJson.quotes.map((quote:Record<string,any>) => (
            <td className="opr-table-text-center" key={`${quote.quote_no}-warranty`} colSpan={2}>
              {quote.terms.warranty}
            </td>
                  ))}
                </tr>
              </tbody>
            </table>
          </div>
      </div>
      </div>
      </div>
    </>

  );
};

export default PurchaseRequest;