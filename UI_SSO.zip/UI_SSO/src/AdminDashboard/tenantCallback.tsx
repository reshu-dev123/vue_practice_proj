import React, { useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';

const TenantCallback = () => {
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const code = params.get('code');
    const state = params.get('state');
    const storedState = sessionStorage.getItem('oauth_state');

    if (state !== storedState) {
      alert('Invalid state: possible CSRF detected!');
      return;
    }

    if (code) {
      console.log('Authorization code:', code);
      localStorage.setItem('auth_code_MSgRAPHAPI', code); 

      // 🚧 Send `code` to backend to exchange for access token
      // OR handle token exchange here if doing it client-side
    }

  
  }, [location]);

  return <div>Processing OAuth callback...</div>;
};

export default TenantCallback;
