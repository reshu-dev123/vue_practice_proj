import React from 'react'

const AdminSamplePage = () => {
  return (
    <div>AdminSamplePage</div>
    
  )
}

export default AdminSamplePage