import React from 'react'
import MailConsentButton from './MailConsentButton'

const AdminDashboardLogin = () => {
  return (
    <>
    <MailConsentButton/>
    </>
    
  )
}

export default AdminDashboardLogin