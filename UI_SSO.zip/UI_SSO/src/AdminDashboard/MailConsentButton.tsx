import React from 'react';

const MailConsentButton: React.FC = () => {
  const handleConsent = () => {
    const clientId = 'eb825014-be1a-4f86-b628-cd6e08bd31e7'; 
    const redirectUri = encodeURIComponent('http://localhost:3000/tenantcallback'); 
    const scope = encodeURIComponent('https://graph.microsoft.com/Mail.Read https://graph.microsoft.com/Mail.Send offline_access');

    const authUrl = `https://login.microsoftonline.com/common/oauth2/v2.0/authorize?` +
      `client_id=${clientId}` +
      `&response_type=code` +
      `&redirect_uri=${redirectUri}` +
      `&scope=${scope}` +
      `&response_mode=query` +
      `&prompt=consent`;

    window.location.href = authUrl;
  };

  return (
    <button
      className="modal-button"
      onClick={handleConsent}
    >
      Connect Office 365 Mailbox
    </button>
  );
};

export default MailConsentButton;
