import React from 'react'

const CompanySetup = () => {
  return (
    <div>CompanySetup</div>
  )
}

export default CompanySetup