import React from 'react'

const OrderApproval = () => {
  return (
    <div>OrderApproval</div>
  )
}

export default OrderApproval