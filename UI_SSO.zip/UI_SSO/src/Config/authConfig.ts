const authConfig = {
    clientId: "eb825014-be1a-4f86-b628-cd6e08bd31e7", 
    redirectUri: "http://localhost:3000/tenantcallback",
    scopes: [
      "https://graph.microsoft.com/Mail.Read",
      "https://graph.microsoft.com/Mail.Send",
      "offline_access",
    ],
    state: "1234", 
    authority: "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
  };
  
  export default authConfig;
  