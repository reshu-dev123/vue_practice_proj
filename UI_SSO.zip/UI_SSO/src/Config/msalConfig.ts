import { PublicClientApplication } from "@azure/msal-browser";
  

const msalConfig = {
  auth: {
    clientId: "9ccef28a-cfde-42f5-b1f1-feae19a8baf7",  
    authority: "https://login.microsoftonline.com/common",
    redirectUri: "http://localhost:3000/auth/callback", 
  }
};
export const authConfig = {
  clientId: "eb825014-be1a-4f86-b628-cd6e08bd31e7", // Replace with your Azure App's Client ID
  redirectUri: "http://localhost:3000/tenantcallback",
  scopes: [
    "openid", "profile", "email",
    "https://graph.microsoft.com/Mail.Read",
    "https://graph.microsoft.com/Mail.Send",
    "offline_access",
  ],
  state: "1234", // Optional, can be dynamic or generated
  authority: "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
};

export const msalInstance = new PublicClientApplication(msalConfig);

export const GOOGLE_CLIENT_ID = "348876178633-qsbrilf0q2nk8b5u559rd53n78hl50p9.apps.googleusercontent.com";
