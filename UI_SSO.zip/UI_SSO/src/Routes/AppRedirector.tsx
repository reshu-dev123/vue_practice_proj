import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import axios from 'axios'; // Import axios

const AppRedirector = () => {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true); // Added loading state

  useEffect(() => {
    const fetchUser = async () => {
      try {
        // Replace fetch with axios.get
        const res = await axios.get('http://192.168.203.122:5000/company/ibaseit');
        const data = res.data;

        if (data.status === 'success' && data.user) {
          const user = data.user;

          // Extract necessary user/company info
          const companyId = user.id;
          const logoFileName = user.logo.split('/').pop(); // Extracts "ibaseit.png"
          const companyName = user.company_name;

          // Construct the redirect URL
          const redirectUrl = `/company/${companyId}/${encodeURIComponent(logoFileName)}/${encodeURIComponent(companyName)}`;
          
          // Redirect the user
          navigate(redirectUrl);
        } else {
          // Handle failure to fetch or missing data
          navigate('/error'); // Redirect to an error page or display a message
        }
      } catch (err) {
        console.error("Failed to fetch user:", err);
        navigate('/error'); // Redirect to an error page on failure
      } finally {
        setLoading(false); // Stop loading state
      }
    };

    fetchUser();
  }, [navigate]);

  // Display a loading state while redirecting
  if (loading) return <div>Loading...</div>;

  return null;
};

export default AppRedirector;
