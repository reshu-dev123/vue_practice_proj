import { Routes, Route, Navigate } from 'react-router-dom';
import Dashboard from '../Dashboard';
import UserDetails from '../UserDetails.tsx/UserDetails';
import ModulePermissions from '../ModulePermissions.tsx/ModulePermissions';
import MaterialMaster from '../Buyer/MaterialMaster';
import { UserFormData } from '../types/User';
import OrderApproval from '../Admin/OrderApproval';
import CompanySetup from '../Admin/CompanySetup';
import RequestManagement from '../Admin/RequestManagement';
import AdminSamplePage from '../AdminDashboard/AdminSamplePage';
import AdminDashboardLogin from '../AdminDashboard/AdminDashboardLogin';
import TenantCallback from '../AdminDashboard/tenantCallback';
import Request from '../Buyer/Request';
import Vendors from '../Buyer/Vendors';
import Orders from '../Buyer/Orders';
import PurchaseRequest from '../Buyer/PurchaseRequest';
import PRWindow from '../Buyer/PRWindow';
import MaterialList from '../Buyer/MaterialList';
interface Props {
  userData: UserFormData | null;
  setIsOpenPrfl: React.Dispatch<React.SetStateAction<boolean>>;
}

const AppRoutes: React.FC<Props> = ({ userData, setIsOpenPrfl }) => {
  const role = userData?.role || 'Guest';

  const roleRoutes: {
    [key: string]: {
      path: string;
      element: JSX.Element;
    }[];
  } = {
    superAdmin: [
      { path: '/dashboard', element: <Dashboard userData={userData} /> },
      { path: '/user-management', element: <UserDetails setIsOpenPrfl={setIsOpenPrfl} /> },
      { path: '/module-access', element: <ModulePermissions userData={userData} /> },
      { path: '/material-master', element: <MaterialMaster/> },
      {path: '/order-approval', element: <OrderApproval/>},
      {path: '/request-management', element: <RequestManagement/>},
      {path: '/company-setup', element: <CompanySetup/>},
      {path:"/admin-dashboard-login",element: <AdminDashboardLogin />},
      { path: '/requests', element: <Request  /> },
      { path: '/purchase-request/:pr_id', element: <PRWindow/> },
      { path: '/orders', element: <Orders  /> },
      { path: '/vendors', element: <Vendors  /> },
      { path: '/material-list', element: <MaterialList/> },
      {path:"/tenantCallback", element:<TenantCallback/> }
    ],
    Buyer: [
      { path: '/dashboard', element: <Dashboard userData={userData} /> },
      { path: '/requests', element: <Request  /> },
      { path: '/purchase-request/:pr_id', element: <PRWindow/> },
      { path: '/orders', element: <Orders  /> },
      { path: '/vendors', element: <Vendors  /> },
      { path: '/material-list', element: <MaterialList/> },
      {path:"/tenantCallback", element:<TenantCallback/> }
      // { path: '/material-master', element: <MaterialMaster/> },
    ],
    Admin:[
      { path: '/dashboard', element: <Dashboard userData={userData} /> },
      {path: '/order-approval', element: <OrderApproval/>},
      {path: '/request-management', element: <RequestManagement/>},
      {path: '/company-setup', element: <CompanySetup/>},
    ]
  };

  const userRoutes = roleRoutes[role] || [];

  return (
    <Routes>
      <Route
        path="/"
        element={
          userRoutes.length > 0 ? (
            <Navigate to={userRoutes[0].path} replace />
          ) : (
            <p>Unauthorized</p>
          )
        }
      />

      {userRoutes.map(({ path, element }) => (
        <Route key={path} path={path} element={element} />
      ))}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

export default AppRoutes;
