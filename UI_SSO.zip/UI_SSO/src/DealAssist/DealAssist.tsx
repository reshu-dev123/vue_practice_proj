import React, { useState, useRef,useEffect } from "react";
import axios from "axios";
import ReactMarkdown from "react-markdown";
import { useParams } from "react-router-dom";
import './DealAssist.css';
import VendorSelectionCard from "../Buyer/VendorSelectionCard";
interface ChatPayload {
  pr_id: number;
  prompt: string;
  threadId?: string;
}

interface BuyerChat{
  msgBy: string;
  msgData: string;
  msgTime: string;
  msgType: string;
}

const DealAssist: React.FC<{ data: Record<string, any> | null }> = ({ data }: { data: Record<string, any> | null }) => {
  console.log("Received data in DealAssist:", data);
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<BuyerChat[]>([]);
  const [chatMsg, setChatMsg] = useState("");
  const [error, setError] = useState("");
  const threadIdRef = useRef(null); 
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const [vendorData, setVendorData] = useState<Record<string,any>[]>([]); 
  const [visibleVendors, setVisibleVendors] = useState<Record<string,any>[]>([]); 
const [vendorIndex, setVendorIndex] = useState(3); 
  const baseURL = process.env.REACT_APP_API_BASE_URL;


  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [messages]);

  

  useEffect(() => {
    if (data?.buyer_chat && data.buyer_chat.length > 0) {
      // Filter messages where msgType equals "system"
      const initialMessages = data.buyer_chat.filter(
        (message:BuyerChat) => message.msgBy !== "system"
      );

      setMessages(initialMessages);
    }
  }, [data]);

  useEffect(() => {
    const fetchVendorData = async () => {
      if (!data?.vendors || data.vendors.length === 0)
        return;
      try {
        setLoading(true);
        const baseURL = process.env.REACT_APP_API_BASE_URL;
  
        if (data?.vendors && data.vendors.length > 0) {
          const vendorIds = data.vendors.map((v:Record<string,any>) => v.vendor_id);
  
          const responses = await Promise.all(
            vendorIds.map((id:number) =>
              axios.get(`${baseURL}/vendor/${id}`)
            )
          );
  
          const vendors = responses.map((res) => res.data.vendor);
          setVendorData(vendors); // set all fetched vendors
          console.log(vendorData, "vendorData");
        }
  
        setLoading(false);
      } catch (error) {
        console.error("Error fetching vendor data:", error);
        setError("Failed to fetch vendor data.");
        setLoading(false);
      }
    };
  
    fetchVendorData();
  }, [data?.vendors]);
  
  useEffect(() => {
    if (vendorData.length > 0) {
      setVisibleVendors(vendorData.slice(0, 3));
      setVendorIndex(3);
    }
  }, [vendorData]);
  
  const handleVendorSubmit = () => {
    console.log("Vendor selection submitted");
  };

  const handleVendorRemove = (vendorId: string) => {
    setVisibleVendors((prev) => {
      const updated = prev.filter((v) => v.vendor_id !== vendorId);
  
      // Add next vendor from vendorData if available
      if (vendorIndex < vendorData.length) {
        updated.push(vendorData[vendorIndex]);
        setVendorIndex(vendorIndex + 1);
      }
  
      return updated;
    });
  };
  
  

  const submitChat = async () => {
    if (chatMsg?.trim()) {
      setMessages((prev) => [
        ...prev, 
        { 
        msgBy: "user",
         msgData: chatMsg, 
         msgType: "text",
         msgTime: new Date().toISOString() }]);
      setChatMsg("");

      try {
        
        const payload: ChatPayload = {
          pr_id: data?.pr_id,
          prompt: chatMsg,
        };

        if (threadIdRef.current) {
          payload.threadId = threadIdRef.current;
        }

        const response = await axios.post(
          `${baseURL}/ai/ask`,
          payload
        );

        const botReply = response?.data?.chat_activity?.message;
        const newThreadId = response?.data?.threadId;

        if (newThreadId) {
          threadIdRef.current = newThreadId;
        }

        setMessages((prev) => [
          ...prev,response?.data?.chat_activity]);
        
      } catch (err) {
        console.error("Error:", err);
        setError("An error occurred while processing the request.");
      } finally {
        setLoading(false);
      }
    }
  };
  if (loading) {
    return <div>Loading...</div>;
  }

  if (error) {
    return <div style={{ color: "red" }}>{error}</div>;
  }

  return (
    <div className="" style={{ height: "calc(100vh - 122px)" }}>
      <div className="voice-chatbot">
        <h2>ChatBot</h2>
        <div
          ref={chatContainerRef}
          style={{
            padding: "16px",
            overflowY: "auto",
            flexGrow: 1,
            display: "flex",
            flexDirection: "column",
          }}
        >
          
          {messages.map((message, index) => (
  <div
    className={`message-row ${message.msgBy === "ai" ? "align-left" : "align-right"}`}
    key={index} >
    <div className={`chat-bubble ${message.msgType} ${message.msgBy}`}>
      <div className="sender-label">
        {message.msgBy === "ai" && "AI"}
        {message.msgBy === "user" && "You"}
        {!(["ai", "user", "vendor", "buyer"].includes(message.msgBy))}
      </div>
      <ReactMarkdown>{message.msgData}</ReactMarkdown>
      {message.msgType === "vendor selection" && (
        <VendorSelectionCard
        vendors={visibleVendors}
        onSubmit={handleVendorSubmit}
        onRemoveVendor={handleVendorRemove}
        />
        
      )}
    </div>
    </div>
  
))}


        {loading && (
              <div className="">
                <div className="qts-message-typing">
                  <div className="qts-typing-dot"></div>
                  <div className="qts-typing-dot"></div>
                  <div className="qts-typing-dot"></div>
                </div>
              </div>
            )}
          
        {error && (
          <p style={{ color: "red", textAlign: "center" }}>{error}</p>
        )}
        </div>
        <div className="">
          <div className="modal-footer">
            <div className="input-group message-input">
              <input
                type="text"
                value={chatMsg}
                className="form-control"
                placeholder="Write a message..."
                aria-label="Message"
                onKeyDown={(e) => e.key === "Enter" && submitChat()}
                onChange={(e) => setChatMsg(e.target.value)}
              />
              <button className="send-btn" onClick={submitChat}>
                <span className="material-symbols-outlined">send</span>
              </button>
            </div>
          </div>
        </div>

</div>
</div>
  );
}
export default DealAssist;
