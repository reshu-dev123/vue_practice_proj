import React, { useState, useEffect } from "react";
import editIcon from "../assets/edit_icon.png";
import deleteIcon from "../assets/delete_icon.png";
import axios from "axios";
import UserForm from '../CreateUser'; 
import ConfirmationPopup from '../ConfirmationPopup';
import { useToast } from "../ToastContext";
import { UserFormData } from '../types/User';


interface UserDetailProps {
  setIsOpenPrfl: React.Dispatch<React.SetStateAction<boolean>>;
}


const UserDetails:React.FC<UserDetailProps> = ({setIsOpenPrfl}) => {
  const [users, setUsers] = useState<UserFormData[]>([]);
  const [isaddPopupOpen, setIsaddPopupOpen] = useState(false);
  const [iseditPopupOpen, setIseditPopupOpen] = useState(false);
  const [formData, setFormData] = useState<UserFormData>({
    id: "",
    firstname: "",
    lastname: "",
    email: "",
    address:"",
    mobile: "",
    role: "",
  });
  const [isDeletePopupOpen, setIsDeletePopupOpen] = useState(false); 
  const [userToDelete, setUserToDelete] = useState<UserFormData | null>(null); 
  const {showToast } = useToast();
  useEffect(() => {
    fetchUsers();
  }, []);
 const fetchUsers = async () => {
  let token = localStorage.getItem("authToken");
  try {
    const response = await axios.get("http://192.168.203.122:5000/get-users", {
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
      },
    });
    
    const users = response.data.users;  
    if (Array.isArray(users)) {
      setUsers(users);  
    } else {
      console.error("Users data is not an array:", users);
    }
  } catch (error) {
    console.error("Error fetching users:", error);
    showToast("Failed to fetch users. Please try again.",'error');
  }
};
const handleEditClick = async (user: UserFormData) => {
  console.log('user',user)
  try {
      setFormData(user);
      console.log("formdata",user)
      setIseditPopupOpen(true);
      setIsOpenPrfl(false);
  } catch (error) {
    console.error("Error fetching user:", error);
    showToast("Failed to fetch user details. Please try again.",'error');
  }
};
const deleteUser = async (user: UserFormData) => {
  let token = localStorage.getItem("authToken");
  try {
    const response = await axios.delete(`http://192.168.203.122:5000/delete-userProfile/${user.id}`, {
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${token}`,
      },
    });
    console.log("User Data",response);
    if (response.status === 200) {
      showToast(`User ${user.firstname} ${user.lastname} deleted successfully!`,'success')
    

      fetchUsers();
    } else {
      showToast("Failed to delete user. Please try again.",'error')
    }
  } catch (error) {
    console.error("Error deleting user:", error);
    showToast("Failed to delete user. Please try again.",'error')
  }
    setIsDeletePopupOpen(false);  
};

const handleDeleteClick = (user: UserFormData) => {
  setUserToDelete(user);
  setIsDeletePopupOpen(true);
  setIsOpenPrfl(false);
};


  const handleAddClick = () => {
    setIsaddPopupOpen(true);
    setIsOpenPrfl(false);
  };

  const cancelPopup = () => {
    setIseditPopupOpen(false);
    setIsaddPopupOpen(false);
    setIsDeletePopupOpen(false); 
  };

  return (
    <> 
      <div className="user-details">
          <div className="main-table-heading">
            <h2>User Details</h2>
            <button type="button" className="modal-button" onClick={handleAddClick}>
          Invite User
          </button> 
          </div>  
        <table className="user-table">
          <thead>
            <tr>
              <th>First Name</th>
              <th>Last Name</th>
              <th>Email</th>
              <th>Mobile</th>
              <th>Role</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {users.map((user) => (
              <tr key={user.id}>
                <td>{user.firstname}</td>
                <td>{user.lastname}</td>
                <td>{user.email}</td>
                <td>{user.mobile}</td>
                <td>{user.role}</td>
                <td>
                  <img src={editIcon} alt="Edit" className="action-icon" onClick={() => handleEditClick(user)} />
                  <img src={deleteIcon} alt="Delete" className="action-icon" onClick={() => handleDeleteClick(user)} />
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {iseditPopupOpen && (
          <UserForm setSubmittedData={fetchUsers} newUser={[formData]} mode="edit" cancelPopup={cancelPopup} />
        )}
        
        {isaddPopupOpen && (
          <UserForm setSubmittedData={fetchUsers} newUser={[formData]} mode="add" cancelPopup={cancelPopup} />
        )}

        {isDeletePopupOpen && userToDelete && (
          <>
          <ConfirmationPopup
            message={`Are you sure you want to delete ${userToDelete.firstname} ${userToDelete.lastname}?`}
            onConfirm={() => deleteUser(userToDelete)}
            onCancel={cancelPopup}
          />
          </>
        )}
      </div>
    </>
  );
};

export default UserDetails;
