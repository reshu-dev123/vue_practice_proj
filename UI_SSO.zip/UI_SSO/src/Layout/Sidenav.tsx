import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import { UserFormData } from '../types/User';
import ChevronDown from '../ChevronDown';
import DashboardIcon from '../assets/images/dashboard-icon.png';
import ComparativeIcon from '../assets/images/comparative-icon.png';
import OrdersIcon from '../assets/images/orders-icon.png';
interface SidenavProps {
    isOpen: boolean;
    toggleSidebar: () => void;
    onLogout:() => void;
    userData: UserFormData | null;
  }
const Sidenav : React.FC<SidenavProps> = ({ isOpen, toggleSidebar,onLogout,userData }) => {
  const userRole = userData?.role ?? null;
  const [openMenus, setOpenMenus] = useState({
    Modules: false,
    Settings: false,
  });
 const toggleMenu = (menu: 'Modules' | 'Settings') => {
    setOpenMenus((prev) => ({
      ...prev,
      [menu]: !prev[menu],
    }));
  };
    const sidebarStyle: React.CSSProperties = {
    // width: isOpen ? '200px' : '0',
    top: '74px',
    bottom: '0',
    backgroundColor: '#ffffff',
    borderRight: '1px solid #EDEDED',
    color: '#fff',
    // overflowX: 'hidden',
    transition: '0.1s',
    position: 'fixed',
    // position: 'relative',
    // height: 'calc(100vh - 80px)',
    // overflow: 'visible',
  };
 
  const menuClose = () => {
    if (window.innerWidth <= 600 ) {
      toggleSidebar();
}
  }
  const commonLinks = (
    <li className="nav-item">
      <NavLink onClick={menuClose} to="/dashboard" className={({ isActive }) => (isActive ? "active" : "")}>
      {/* <img src={DashboardIcon} alt="Dashboard icon" /> Dashboard */}
      <span className="material-symbols-outlined">grid_view</span><p className='m-0'>Dashboard</p>
      </NavLink>
    </li>
  );
  const renderLinksByRole = () => {
    switch (userRole) {
      case 'superAdmin':
        return (
          <>
            <li className="nav-item">
              <NavLink onClick={menuClose} to="/user-management" className={({ isActive }) => (isActive ? 'active' : '')}>
                User Management
              </NavLink>
            </li>
            {/* <li className="nav-item"
              onClick={()=>toggleMenu("Modules")}
              style={{
                background: 'none',
                border: 'none',
                color: '#000',
                padding: '10px 16px',
                textAlign: 'left',
                width: '100%',
                cursor: 'pointer',
                fontSize: '16px',
                fontWeight:' 500',
                marginBottom: '1px'
              }}
            > Modules
           <ChevronDown isOpen={openMenus.Modules}/>
            </li>
            {openMenus.Modules && (
              <ul style={{ paddingLeft: '16px'}}>
                <li className="nav-item">
                  <NavLink onClick={menuClose} to="/material-master" className={({ isActive }) => (isActive ? 'active' : '')}>
                    Material Master
                  </NavLink>
               </li>
                <li className="nav-item">
                  <NavLink onClick={menuClose} to="/order-approval" className={({ isActive }) => (isActive ? 'active' : '')}>
                  Order Approval
                  </NavLink>
                </li>
                <li className="nav-item">
                <NavLink onClick={menuClose} to="/request-management" className={({ isActive }) => (isActive ? 'active' : '')}>
                Request Management
                </NavLink>
              </li> 
              <li className="nav-item">
                  <NavLink onClick={menuClose} to="/company-setup" className={({ isActive }) => (isActive ? 'active' : '')}>
                  Company Setup
                  </NavLink>
              </li>
              </ul>
            )}
            <li className="nav-item"
              onClick={()=>toggleMenu("Settings")}
              style={{
                background: 'none',
                border: 'none',
                color: '#000',
                padding: '10px 16px',
                textAlign: 'left',
                width: '100%',
                cursor: 'pointer',
                fontSize: '16px',
                fontWeight:' 500',
                marginBottom: '1px'
              }}
            > Settings
           <ChevronDown isOpen={openMenus.Settings}/>
            </li>
            {openMenus.Settings && (
              <ul style={{ paddingLeft: '16px'}}>
                <li className="nav-item">
                  <NavLink onClick={menuClose} to="/module-access" className={({ isActive }) => (isActive ? 'active' : '')}>
                    Module Access
                  </NavLink>
                </li>
              </ul>
            )} */}
          </>
        );
      case 'Buyer':
        return (
          <>
          <li className="nav-item">
            <NavLink onClick={menuClose} to="/requests" className={({ isActive }) => (isActive ? 'active' : '')}>
              {/* <img src={ComparativeIcon} alt="Comparative icon" /> Requests */}
              <span className="material-symbols-outlined">two_pager</span><p className='m-0'>Requests</p>
            </NavLink>
           
          </li>
          <li className="nav-item">
            <NavLink onClick={menuClose} to="/orders" className={({ isActive }) => (isActive ? 'active' : '')}>
              {/* <img src={OrdersIcon} alt="Orders icon" /> Orders */}
              <span className="material-symbols-outlined">box</span><p className='m-0'>Orders</p>
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink onClick={menuClose} to="/vendors" className={({ isActive }) => (isActive ? 'active' : '')}>
            <span className="material-symbols-outlined">shopping_cart</span><p className='m-0'>Vendors</p>
            </NavLink>
          </li>
          <li className="nav-item">
            <NavLink onClick={menuClose} to="/material-list" className={({ isActive }) => (isActive ? 'active' : '')}>
            <span className="material-symbols-outlined">inventory_2</span><p className='m-0'>Materials</p>
            </NavLink>
          </li>
          </>
        );
      case 'Admin':
          return (
            <>
                <li className="nav-item">
                  <NavLink onClick={menuClose} to="/order-approval" className={({ isActive }) => (isActive ? 'active' : '')}>
                  Order Approval
                  </NavLink>
                </li>
                <li className="nav-item">
                <NavLink onClick={menuClose} to="/request-management" className={({ isActive }) => (isActive ? 'active' : '')}>
                Request Management
                </NavLink>
              </li> 
              <li className="nav-item">
                  <NavLink onClick={menuClose} to="/company-setup" className={({ isActive }) => (isActive ? 'active' : '')}>
                  Company Setup
                  </NavLink>
                </li>
          </>
          );
      case 'manager':
        return (
          <li className="nav-item">
            <NavLink onClick={menuClose} to="/approvals" className={({ isActive }) => (isActive ? 'active' : '')}>
              Approvals
            </NavLink>
          </li>
        );
      default:
        return null;
    }
  };
  return (
    <div  className = {isOpen ? 'sidenac-sec open' : 'sidenac-sec close'} style={sidebarStyle}>
      <div className='toggle-btn opr-sidenav-toggle' onClick={toggleSidebar}>
        <span className="material-symbols-outlined">chevron_right</span>
      </div>
      <ul className="nav d-block">
      {commonLinks}
      {renderLinksByRole()}
    </ul>
    </div>
  );
};

export default Sidenav;
