export interface UserFormData {
    id: string;
    firstname: string;
    lastname: string;
    mobile: string;
    address: string;
    email: string;
    role: string;
  }

export  interface Role {
    id: string;
    rolename: string;
  }
  