import React, { useState } from "react";
import { useMsal } from "@azure/msal-react";
import axios from "axios";
import Powermech from "../assets/images/power-mech-logo-1.png";
import { GoogleLogin } from "@react-oauth/google";

interface LoginButtonProps {
  setUser: (user: any) => void;
  setIsAuthenticated: React.Dispatch<React.SetStateAction<boolean>>;
  setIsOpenPrfl?: React.Dispatch<React.SetStateAction<boolean>>;
  onLoginSuccess?: () => void;
}
const sendTokenToBackend = async (
  token: string,
  loginType: "google" | "microsoft",
  setUser: (user: any) => void,
  setIsAuthenticated: React.Dispatch<React.SetStateAction<boolean>>,
  setIsOpenPrfl?: React.Dispatch<React.SetStateAction<boolean>>,
  onLoginSuccess?: () => void,

) => {
  try {
    const response = await axios.post(
      "http://192.168.203.122:5000/login",
      {
        access_token: token,
        loginType: loginType,
      },
      {
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
      }
    );

    if (response.data.user) {
      setUser(response.data.user);
      setIsAuthenticated(true);
      localStorage.setItem("userData", JSON.stringify(response.data.user));
      onLoginSuccess?.();
    }
    setIsOpenPrfl?.(false);
  } catch (error: any) {
    console.error("Error sending token to backend:", error.response?.data || error.message);
  }
};

const LoginButton: React.FC<LoginButtonProps> = ({ setUser, setIsAuthenticated, setIsOpenPrfl,onLoginSuccess}) => {
  const { instance } = useMsal();

  const handleMicrosoftLogin = async () => {
    try {
      const response = await instance.loginPopup({
        scopes: ["openid", "profile", "email"],
      });

      if (response?.accessToken) {
        localStorage.setItem("authToken", response.accessToken);
        localStorage.setItem("loginType", "microsoft");
        await sendTokenToBackend(response.accessToken, "microsoft", setUser, setIsAuthenticated, setIsOpenPrfl,onLoginSuccess);
      } else {
        console.error("No access token received.");
      }
    } catch (error) {
      console.error("Microsoft Login failed:", error);
    }
  };

  return (
    <div className="card" style={{ height: "100vh", width: "100%" }}>
        <div className="LoginBg"></div>
        <div style={{ margin: "auto" }}>
        <div style={{ marginBottom: "30px" }}>
          <img src={Powermech} alt="logo" />
        </div>
        <div className="Login-card">
          <h1>Login to your account</h1>
          <p style={{ color: "gray" }}>Welcome back, please log in to continue</p>

          <button className="login-btn" onClick={handleMicrosoftLogin}>Sign in with Microsoft</button>

          {/* Google Login Button */}
          <div style={{ marginTop: "20px" }}>
            <GoogleLogin
              onSuccess={(credentialResponse) => {
                const token = credentialResponse.credential;
                if (token) {
                  localStorage.setItem("authToken", token);
                  localStorage.setItem("loginType", "google");
                  sendTokenToBackend(token, "google", setUser, setIsAuthenticated, setIsOpenPrfl,onLoginSuccess);
                }
              }}
              onError={() => console.error("Google Login Failed")}
            />
          </div>
        </div>
      </div>
    </div>
  );
};

export default LoginButton;
