import React from "react";

interface CurrencyFormatterProps {
    value: number | null | undefined;
}

const CurrencyFormatter: React.FC<CurrencyFormatterProps> = ({ value }) => {
    if (value == null) {
        return <span>-</span>; 
      }
  const formattedValue = new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: 0, 
  }).format(value);

  return <span>{formattedValue}</span>;
};

export default CurrencyFormatter;