import authConfig from "../Config/authConfig";

export const buildAuthUrl = (): string => {
  const { clientId, redirectUri, scopes, state, authority } = authConfig;

  const queryParams = new URLSearchParams({
    client_id: clientId,
    response_type: "code",
    redirect_uri: redirectUri,
    scope: scopes.join(" "),
    state: state,
    prompt: "consent",
  });

  return `${authority}?${queryParams.toString()}`;
};
