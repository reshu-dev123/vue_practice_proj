import React from "react";
import "./StatusCount.css";

const StatusCount: React.FC = () => {
  return (
    <>
    <div className="status-card">
        <h3 className="status-card-header">Purchase Request Pipeline</h3>
      </div>
      <div className="progress pr-pipeline">
        <div
          className="progress-bar pr-pipeline-status pr-status-buyer-assigned"
          role="progressbar"
          aria-label="Segment one"
          style={{ width: "15%" }}
          aria-valuenow={15}
          aria-valuemin={0}
          aria-valuemax={100}
        ></div>
        <div
          className="progress-bar pr-pipeline-status pr-status-buyer-review"
          role="progressbar"
          aria-label="Segment two"
          style={{ width: "30%" }}
          aria-valuenow={30}
          aria-valuemin={0}
          aria-valuemax={100}
        ></div>
        <div
          className="progress-bar pr-pipeline-status pr-status-rfq-sent"
          role="progressbar"
          aria-label="Segment three"
          style={{ width: "20%" }}
          aria-valuenow={20}
          aria-valuemin={0}
          aria-valuemax={100}
        ></div>
        <div
          className="progress-bar pr-pipeline-status pr-status-quotes-received"
          role="progressbar"
          aria-label="Segment four"
          style={{ width: "30%" }}
          aria-valuenow={20}
          aria-valuemin={0}
          aria-valuemax={100}
        ></div>
        <div
          className="progress-bar pr-pipeline-status pr-status-negotiation"
          role="progressbar"
          aria-label="Segment five"
          style={{ width: "15%" }}
          aria-valuenow={20}
          aria-valuemin={0}
          aria-valuemax={100}
        ></div>
        <div
          className="progress-bar pr-pipeline-status pr-status-auction"
          role="progressbar"
          aria-label="Segment six"
          style={{ width: "10%" }}
          aria-valuenow={20}
          aria-valuemin={0}
          aria-valuemax={100}
        ></div>
        <div
          className="progress-bar pr-pipeline-status pr-status-pending-approval"
          role="progressbar"
          aria-label="Segment seven"
          style={{ width: "20%" }}
          aria-valuenow={20}
          aria-valuemin={0}
          aria-valuemax={100}
        ></div>
      </div>

      <div style={{ display: "flex", gap: "20px" }}>
        <div className="pr-status-info">
          <div className="d-flex justify-content-center" style={{ width: "100%" }}>
            <span className="pr-status-buyer-assigned"></span>
          </div>
          <h2>Buyer Assigned</h2>
          <p>10</p>
        </div>

        <div className="pr-status-info">
          <div className="d-flex justify-content-center" style={{ width: "100%" }}>
            <span className="pr-status-buyer-review"></span>
          </div>
          <h2>Buyer Review</h2>
          <p>10</p>
        </div>

        <div className="pr-status-info">
          <div className="d-flex justify-content-center" style={{ width: "100%" }}>
            <span className="pr-status-rfq-sent"></span>
          </div>
          <h2>RFQ Sent</h2>
          <p>10</p>
        </div>

        <div className="pr-status-info">
          <div className="d-flex justify-content-center" style={{ width: "100%" }}>
            <span className="pr-status-quotes-received"></span>
          </div>
          <h2>Quotes Received</h2>
          <p>10</p>
        </div>

        <div className="pr-status-info">
          <div className="d-flex justify-content-center" style={{ width: "100%" }}>
            <span className="pr-status-negotiation"></span>
          </div>
          <h2>In Negotiation</h2>
          <p>10</p>
        </div>

        <div className="pr-status-info">
          <div className="d-flex justify-content-center" style={{ width: "100%" }}>
            <span className="pr-status-auction"></span>
          </div>
          <h2>Auction</h2>
          <p>10</p>
        </div>

        <div className="pr-status-info">
          <div className="d-flex justify-content-center" style={{ width: "100%" }}>
            <span className="pr-status-pending-approval"></span>
          </div>
          <h2>Pending Approval</h2>
          <p>10</p>
        </div>
      </div>
      </>
  );
};

export default StatusCount;