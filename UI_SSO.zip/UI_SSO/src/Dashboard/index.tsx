import React from "react";
import { UserFormData } from "../types/User";
import Request from "../Buyer/Request";
import DashboardCards from "./DashboardCards";
import ShoppingCartIcon from "@mui/icons-material/ShoppingCartOutlined";
import PendingActionsIcon from "@mui/icons-material/PendingActionsOutlined";
import Inventory2Icon from "@mui/icons-material/Inventory2Outlined";
import AccessTimeIcon from "@mui/icons-material/AccessTimeOutlined";
import StatusCount from "./StatusCount";


interface DashboardProps {
  userData: UserFormData | null;
}

const Dashboard: React.FC<DashboardProps> = ({ userData }) => {
  if (!userData) {
    return <div>No user data available</div>;
  }

  const cardsData = [
    {
      title: "Total Open PRs",
      value: 23,
      change: "+4% from last month",
      icon: <ShoppingCartIcon/>, 
    },
    {
      title: "Pending Approvals",
      value: 7,
      change: "-2% from last month",
      icon: <PendingActionsIcon />,
    },
    {
      title: "Active Orders",
      value: 12,
      change: "Same as last month",
      icon: <Inventory2Icon />,
    },
    {
      title: "Avg. Processing Time",
      value: "3.2 days",
      change: "-0.5 days from last month",
      icon: <AccessTimeIcon />,
    },
  ];

  return (
    <div>
      <h4>Dashboard</h4>
      <DashboardCards cardsData={cardsData} />
      <StatusCount/>
      <Request />
    </div>
  );
};

export default Dashboard;