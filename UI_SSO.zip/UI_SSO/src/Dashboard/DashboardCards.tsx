import React from "react";


interface CardData {
  title: string;
  value: string | number;
  change: string;
  // icon: string; 
  icon: JSX.Element
}

interface DashboardCardsProps {
  cardsData: CardData[];
}

const DashboardCards: React.FC<DashboardCardsProps> = ({ cardsData }) => {
  return (
    <div className="dashboard-cards">
      {cardsData.map((card, index) => (
        <div className="dsh-card" key={index}>
          {/* <div className="dsh-card-icon">{card.icon}</div> */}
          <div className="dsh-card-content">
            <div className="d-flex align-items-center justify-content-between">
            <h5 className="dsh-card-title">{card.title}</h5>
            <div className="material-symbols-outlined dsh-card-icon">{card.icon}</div>
            </div>
            <p className="dsh-card-value">{card.value}</p>
            <p className="dsh-card-change">{card.change}</p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default DashboardCards;