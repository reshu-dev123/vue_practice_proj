import React from 'react';
import './ConfirmationPopup.css'; 

interface ConfirmationPopupProps {
  message: string;
  onConfirm: () => void;
  onCancel: () => void;
}

const ConfirmationPopup: React.FC<ConfirmationPopupProps> = ({ message, onConfirm, onCancel }) => {
  return (
    <div className="confirmation-popup">
      <div className="popup-content">
        <p className='fnt-small'>{message}</p>
        <div className='cnf-footer-field'>
          <button type="button" onClick={onConfirm} className='modal-button btn-right'>Delete</button>
          <button type="button" onClick={onCancel} className='modal-button-transp'>Cancel</button>
        </div>
      </div>
    </div>
  );
};

export default ConfirmationPopup;
