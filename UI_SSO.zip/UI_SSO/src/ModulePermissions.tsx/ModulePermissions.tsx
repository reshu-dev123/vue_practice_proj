import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useToast } from "../ToastContext";
import { UserFormData } from '../types/User';

interface Task {
  taskId: string;
  taskName: string;
  taskDesc: string;
}

interface Module {
  moduleId: string;
  moduleName: string;
  tasks: Task[];
}

interface ModulePermProps {
  userData: UserFormData | null;
}

interface RolePermission {
  role: string;
  permissions: {
    [moduleName: string]: string[];
  };
}

const ModulePermissions: React.FC<ModulePermProps> = ({ userData }) => {
  const [allModules, setAllModules] = useState<Module[]>([]);
  const [filteredModules, setFilteredModules] = useState<Module[]>([]);
  const [rolePermissions, setRolePermissions] = useState<RolePermission[]>([]);
  const [selectedRole, setSelectedRole] = useState<string>(userData?.role || '');
  const [editablePermissions, setEditablePermissions] = useState<{ [moduleName: string]: string[] }>({});
  const [loading, setLoading] = useState(true);
  const { showToast } = useToast();

  useEffect(() => {
    fetchModulePermissions();
  }, []);

  const fetchModulePermissions = async () => {
    const token = localStorage.getItem("authToken");

    try {
      const response = await axios.get(`http://192.168.203.122:5000/powermech/permissions/${123}`, {
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
      });

      const { modules, rolePermissions } = response.data;

      setAllModules(modules);
      setRolePermissions(rolePermissions);
      const initialRole = userData?.role || rolePermissions[0]?.role || '';
      setSelectedRole(initialRole);
      filterModulesByRole(initialRole, modules, rolePermissions);

      const getRoleData = (role: string): RolePermission | undefined => {
        return rolePermissions.find((rp: RolePermission) => rp.role === role);
      };
      const roleData = getRoleData(initialRole);
        setEditablePermissions(roleData?.permissions || {});
      
    } catch (error) {
      console.error("Error fetching modulePermission", error);
      showToast("Failed to fetch modulePermission. Please try again.", 'error');
    } finally {
      setLoading(false);
    }
  };

  const filterModulesByRole = (role: string,modules: Module[],rolePermissionsList: RolePermission[] ) => {
    const currentRolePerm = rolePermissionsList.find((rp) => rp.role === role);
    if (!currentRolePerm) {
      showToast(`No permissions found for role: ${role}`, 'error');
      return;
    }

    const filtered = modules
      .map((mod) => {
        const allowedTaskNames = currentRolePerm.permissions[mod.moduleName];
        if (!allowedTaskNames) return null;

        const filteredTasks = mod.tasks.filter(task =>
          allowedTaskNames.includes(task.taskName)
        );

        return filteredTasks.length > 0 ? { ...mod, tasks: filteredTasks } : null;
      })
      .filter(Boolean) as Module[];

    setFilteredModules(filtered);
  };

  const handleRoleChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const role = e.target.value;
    setSelectedRole(role);
    filterModulesByRole(role, allModules, rolePermissions);
    const getRolePermission = (role: string): RolePermission | undefined => {
      return rolePermissions.find((rp: RolePermission) => rp.role === role);
    };
    const selected = getRolePermission(role);
    setEditablePermissions(selected?.permissions || {});
  };

  const handleCheckboxChange = (moduleName: string, taskName: string) => {
    setEditablePermissions(prev => {
      const currentTasks = prev[moduleName] || [];
      const updatedTasks = currentTasks.includes(taskName)
        ? currentTasks.filter(t => t !== taskName)
        : [...currentTasks, taskName];

      return {
        ...prev,
        [moduleName]: updatedTasks
      };
    });
  };

  const handleSave = async () => {
    let token = localStorage.getItem("authToken");
    const payload={
      role: selectedRole,
      permissions: editablePermissions
    }
    console.log("Updated permissions for role:", selectedRole,'editablePermissions' ,editablePermissions);
    // localStorage.setItem('editablePermissions', JSON.stringify(editablePermissions));
    showToast(`Permissions saved for role: ${selectedRole}`, "success");
    let savedRolePermissions = await axios.post(`http://192.168.203.122:5000/update-role-permissions`, payload, { 
          headers: { 
            "Content-Type": "application/json",
             "Authorization": `Bearer ${token}`
             },
    });
    console.log("savedRolePermissions",savedRolePermissions.data)
  };

  if (loading) return <p>Loading...</p>;

  return (
    <>
      <h2 className="text-2xl font-bold mb-4">Module Permissions</h2>

      <div className="mb-4">
        <label htmlFor="role" className="block font-medium mb-1">Select Role:</label>
        <select
          id="role"
          name="role"
          value={selectedRole}
          onChange={handleRoleChange}
          className="border p-2 rounded w-full max-w-xs"
        >
          <option value="" disabled>Select a role</option>
          {rolePermissions.map((rp) => (
            <option key={rp.role} value={rp.role}>
              {rp.role}
            </option>
          ))}
        </select>
      </div>

      <div className="module-grid">
        {filteredModules.map((module, index) => (
          <div key={index} className="module-card border p-4 rounded shadow mb-4">
            <h3 className="module-title font-semibold text-lg mb-2">{module.moduleName}</h3>
            <ul className="task-list space-y-2">
              {module.tasks.map((task) => (
                <li key={task.taskId} className="flex items-center space-x-2">
                  <input
                    type="checkbox"
                    id={`${module.moduleName}-${task.taskName}`}
                    checked={editablePermissions[module.moduleName]?.includes(task.taskName) || false}
                    onChange={() => handleCheckboxChange(module.moduleName, task.taskName)}
                  />
                  <label htmlFor={`${module.moduleName}-${task.taskName}`}>
                    {task.taskName}
                  </label>
                </li>
              ))}
            </ul>
          </div>
       
        ))}
      </div>
      <button
           onClick={handleSave}
           className="modal-button btn-right"
         >
           Save Permissions
         </button>
    </>
  );
};

export default ModulePermissions;
