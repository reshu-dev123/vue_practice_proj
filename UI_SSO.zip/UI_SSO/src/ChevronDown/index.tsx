import React from 'react';
import arrowIcon from '../assets/images/down_arrow.png'; 

interface ChevronDownProps {
  isOpen?: boolean;
}

const ChevronDown: React.FC<ChevronDownProps> = ({ isOpen = false }) => {
  const style: React.CSSProperties = {
    width: '20px',
    height:'20px',
    marginLeft: '8px',
    transition: 'transform 0.2s ease-in-out',
    transform: isOpen ? 'rotate(180deg)' : 'rotate(0deg)',
  };

  return <img src={arrowIcon} alt="Toggle" style={style} />;
};

export default ChevronDown;
