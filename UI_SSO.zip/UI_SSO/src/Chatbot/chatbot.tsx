import React, { useState, ChangeEvent, KeyboardEvent } from 'react';
import axios from 'axios';
import chatbot from '../assets/images/chatbot.png';

type Message = {
  from: 'user' | 'bot';
  text: string;
};

const Chatbot: React.FC = () => {
  const [open, setOpen] = useState<boolean>(false);
  const [messages, setMessages] = useState<Message[]>([
    { from: 'bot', text: 'How can I help you today?I am here to assist you with procurement-related tasks.' },
  ]);
  const [input, setInput] = useState<string>('');

  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const handleSend = async () => {
    if (!input.trim()) return;

    const userMessage: Message = { from: 'user', text: input };
    setMessages(prev => [...prev, userMessage]);

    try {
      const res = await axios.post('http://192.168.203.122:5000/api/chat', {
        provider: 'openai',
        prompt: input,
      });

      const botReply: string = res.data?.response || "Sorry, I didn't get that.";
      const botMessage: Message = { from: 'bot', text: botReply };
      setMessages(prev => [...prev, botMessage]);
    } catch (error) {
      console.error('Axios error:', error);
      setMessages(prev => [...prev, { from: 'bot', text: 'Something went wrong.' }]);
    }

    setInput('');
  };

  const handleInputChange = (e: ChangeEvent<HTMLInputElement>) => {
    setInput(e.target.value);
  };

  const handleKeyPress = (e: KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Enter') {
      handleSend();
    }
  };

  return (
    <>
      <div className="chatbot-icon-container">
        <img
          src={chatbot}
          alt="Chatbot"
          className="chatbot-icon"
          onClick={handleOpen}
        />
      </div>

      {open && (
        <div className="chatbot-overlay">
          <div className="chatbot-window">
            <div className="chatbot-header">
              <h2>Chatbot</h2>
              <button onClick={handleClose} className="chatbot-close-btn">&times;</button>
            </div>
            <div className="chatbot-body">
              {messages.map((msg, idx) => (
                <div
                  key={idx}
                  className={`chatbot-message ${msg.from === 'user' ? 'user' : 'bot'}`}
                >
                  {msg.text}
                </div>
              ))}
            </div>
            <div className="chatbot-input" style={{display:'flex'}}>
              <input
                type="text"
                placeholder="Type your message..."
                value={input}
                onChange={handleInputChange}
                onKeyPress={handleKeyPress}
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              />
              <button className="send-btn" onClick={handleSend}>
              <span className="material-symbols-outlined">send</span>
            </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default Chatbot;
