import React, { useState } from 'react';
import UserForm from '../CreateUser'; 
import UserProfileIcon from '../assets/images/user-profile.png'
import UserPrflEditIcon from '../assets/images/profile-edit.png'
import UserMobileIcon from '../assets/images/user-mobile.png'
import UserEmailIcon from '../assets/images/user-email.png'
import UserRoleICON from '../assets/images/user-role.png'
import AdminDashboardIcon from '../assets/images/admin-dashboard.png'
import Logout from '../assets/images/Logout.png'
import { UserFormData } from '../types/User'
import { useNavigate } from 'react-router-dom';


interface ProfileCardProps {
  userData: { id:string,firstname: string; role: string; email: string ;mobile: string;lastname: string;address: string};
  onLogout: () => void;
}

const ProfileCard: React.FC<ProfileCardProps> = ({ userData, onLogout }) => {
  const [isUserEditPrflOpen, setisUserEditPrflOpen] = useState(false); 
  const [formData, setFormData] = useState<UserFormData>({
    id: userData.id, 
    firstname: userData.firstname ,
    lastname: userData.lastname , 
    email: userData.email ,
    mobile: userData.mobile , 
    address: userData.address,
    role: userData.role ,
  });
  const navigate = useNavigate();

  const handleManageAccountClick = (userData: UserFormData) => {
    setFormData(userData);
    setisUserEditPrflOpen(true); 
  };

  const cancelUserForm = () => {
    setisUserEditPrflOpen(false); 
  };

  return (
    <div className="profile-card">
      <div className="profile-header">
      <p className="user-name">
            <img src={UserProfileIcon} alt='UserProfileIcon' className="profile-icon"/>
            {userData.firstname} {userData.lastname}
      </p>
      <div className="profile-info">
          <p className="user-detail">
            <img src={UserEmailIcon} alt="Email Icon" className="icon" /> 
            {userData.email}
          </p>
          <p className="user-detail">
            <img src={UserMobileIcon} alt="Phone Icon" className="icon" /> 
            {userData.mobile}
          </p>
          {/* <p className="user-detail">
            <img src={UserMobileIcon} alt="Phone Icon" className="icon" /> 
            {userData.address}
          </p> */}
          <p className="user-detail">
            <img src={UserRoleICON} alt="Role Icon" className="icon" /> 
            {userData.role}
          </p>
          <p className="user-detail" onClick={() => window.open('/admin-dashboard-login','_blank')}>
            <img src={AdminDashboardIcon} alt="Admin Icon" className="icon isActive" />
            <span>Admin Dashboard</span>
          </p>
          <p className="user-detail">
            <img onClick={()=>handleManageAccountClick(userData)} src={UserPrflEditIcon} alt="Role Icon" className="icon isActive" /> 
            <span>Edit Profile</span>
          </p>

          <p className="user-detail">
            <img  onClick={onLogout} src={Logout} alt="Role Icon" className="icon isActive" /> 
            <span>Log out</span>
          </p>
     </div>
     </div>
      {isUserEditPrflOpen && (
        <UserForm
          setSubmittedData={() => setFormData} 
          newUser={[formData]} 
          mode="manage" 
          cancelPopup={cancelUserForm} />
      )}
    </div>
  );
};

export default ProfileCard;
