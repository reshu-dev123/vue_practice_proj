import React, { createContext, useContext } from 'react';
import { toast } from 'react-toastify';

const ToastContext = createContext();

export const useToast = () => {
  return useContext(ToastContext);
};

export const ToastProvider = ({ children }) => {
  const showToast = (message, type = 'success') => {
    if (type === 'success') {
      toast.success(message, {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
      });
    } else if (type === 'error') {
      toast.error(message, {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: false,
      });
    } else if (type === 'info') {
      toast.info(message, {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
      });
    } else if (type === 'warning') {
      toast.warning(message, {
        position: "top-center",
        autoClose: 3000,
        hideProgressBar: true,
      });
    }
  };

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
    </ToastContext.Provider>
  );
};
