// export const API_ENDPOINTS = {
//   URL: "https://chatbot.ibaseit.com/api/",
// };
// export const API_ENDPOINTS = {
//   URL: "https://ai.ibaseit.com/api/",
// };

export const API_ENDPOINTS = {
  URL: "http://localhost:5050/",
};
  