// useRolePermissions.ts
import { useEffect, useState } from "react";
import axios from "axios";

interface RolePermission {
    role: string;
    permissions: {
      [moduleName: string]: string[];
    };
  }

export const useRolePermissions = () => {
  const [permissions, setPermissions] = useState<RolePermission[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetch = async () => {
      const token = localStorage.getItem("authToken");
      const res = await axios.get("http://192.168.203.122:5000/powermech/permissions/123", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      setPermissions(res.data.rolePermissions);
      setLoading(false);
    };
    fetch();
  }, []);

  return { permissions, loading };
};
