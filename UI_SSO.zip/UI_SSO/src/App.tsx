import React, { useState, useEffect, useRef} from "react";
import {  useLocation } from "react-router-dom";
import { useMsal } from "@azure/msal-react";
import Sidenav from "./Layout/Sidenav";
import LoginButton from "./Login";
import './App.css'
import ProfileCard from "./ProfileCard";
import { ToastContainer } from "react-toastify";
import AppRoutes from "./Routes/AppRoutes";
import { UserFormData , Role} from "./types/User";
import UserIcon from "./assets/images/user-icon.png";
import NotificationIcon from "./assets/images/notification-icon.png";
import FilterIcon from "./assets/images/filter-icon.png";
 

const App: React.FC= () => {
  const { instance } = useMsal();
  const [isOpen, setIsOpen] = useState<boolean>(true);
  const [isOpenprfl,setIsOpenPrfl] = useState<boolean>(false);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const sidenavRef = useRef<HTMLDivElement>(null);
  const [userData, setUser] = useState<UserFormData | null>(null);
  const layoutExcludedRoutes = [
    "/admin-dashboard-login",
    "/admin-sample-page"
  ];
  
  const location = useLocation();
  const isLayoutVisible = !layoutExcludedRoutes.includes(location.pathname);
  
  useEffect(() => {
    const storedUserData = JSON.parse(localStorage.getItem("userData") || 'null');
    if (storedUserData) {
      setUser(storedUserData);
      setIsAuthenticated(true);
    }
  }, []);

  useEffect(() => {
    setIsOpenPrfl(false); 
  }, [location]);


  const handleLogout = () => {
    const loginType = localStorage.getItem("loginType");
    if (loginType === "microsoft"){
      instance.logoutPopup().then(()=>{
        setIsAuthenticated(false);
        localStorage.clear() 
    }).catch((err)=>{
       console.error("Microsoft logout error:", err);
    });
    }else if (loginType === "google") {
      const logoutWindow = window.open(
        "https://accounts.google.com/AccountChooser?logout",
       
      );
        setIsAuthenticated(false);
        localStorage.clear();
         if (logoutWindow) {
          logoutWindow.close(); 
        } 
    } else {
      console.warn("Unknown loginType during logout");
      setIsAuthenticated(false);
      localStorage.clear();
    }
     
  };

  const toggleProfileCard = () => {
    setIsOpenPrfl(!isOpenprfl);
  };


  const toggleSidebar = () => {
    setIsOpen(!isOpen);
  };

  const outsideMenu = () => {
    if (window.innerWidth <= 600) {
      setIsOpen(true);
    }
  };

  const sidebarStyle: React.CSSProperties = {
    marginLeft: isOpen ? "200px" : "52px",
    transition: "0.3s",
  };

  if (!isAuthenticated) {
    return (     
        <LoginButton 
        setUser={setUser} 
        setIsAuthenticated={setIsAuthenticated} 
        setIsOpenPrfl={setIsOpenPrfl}
        />
    );
  }

  return (
    <div>
    {isLayoutVisible && (
      <header>
        <div className="header-sec">
          <div className="align-items-center d-flex justify-content-between">
            <span style={{ width: "200px" }}>
              <img src="/images/oprete-logo.png" alt="Logo" className="header-sec-img" />
            </span>
            {/* <button className="toggle-btn btn" onClick={toggleSidebar}>
              <span></span>
              <span></span>
              <span></span>
            </button> */}

            <form className="d-flex" role="search">
                {/* <input className="form-control me-2 opr-search" type="search" placeholder="Search" aria-label="Search"/> */}
                <div className="opr-search-field">
                <input type="text" className="opr-search" placeholder="Search" />
                <div className="icon-group">
                  <div className="opr-search-divider"></div>
                  <img src={FilterIcon} alt="Filter icon" />
                </div>
                </div>
            </form>
  
            {userData && (
              <>
                <div className="user-info">
                  {/* <img className="opr-notification-icon" src={NotificationIcon} alt="Notification icon" /> */}
                  <span className="material-symbols-outlined">notifications</span>
                  <span style={{ margin: "0px 10px 0px 16px" }}>
                    {userData.firstname + ' ' + userData.lastname} ({userData.role})
                  </span>
                  {/* <span className="isActive">&#9662;</span> */}
                  <span onClick={toggleProfileCard} className="opr-user-icon"><img src={UserIcon} alt="User iocn" /></span>
                </div>
                {isOpenprfl && (
                  <ProfileCard userData={userData} onLogout={handleLogout} />
                )}
              </>
            )}
          </div>
        </div>
      </header>
    )}
  
    <div>
      {!isOpen && window.innerWidth <= 600 && isLayoutVisible && (
        <div
          ref={sidenavRef}
          onClick={outsideMenu}
          style={{
            position: "fixed",
            zIndex: 999,
            background: "rgba(0,0,0,0.2)",
            top: "62px",
            bottom: "0",
            left: "0",
            right: "0",
          }}
        />
      )}
  
      {isLayoutVisible && (
        <Sidenav
          isOpen={isOpen}
          toggleSidebar={toggleSidebar}
          onLogout={handleLogout}
          userData={userData}
        />
      )}
  
      <div className={isLayoutVisible ? "main-layout" : ""} style={isLayoutVisible ? sidebarStyle : {}}>
        <ToastContainer />
        <AppRoutes userData={userData} setIsOpenPrfl={setIsOpenPrfl} />
      </div>
    </div>
  </div>
  
  );
};

export default App;
