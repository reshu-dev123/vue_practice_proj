import { useState, useEffect } from "react";
import axios from "axios";
import { useParams } from "react-router-dom";
import { toast, ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";  
import { useToast } from "../ToastContext";
import { UserFormData,Role} from '../types/User';




interface UserFormProps {
  setSubmittedData: React.Dispatch<React.SetStateAction<UserFormData[]>>;
  newUser: UserFormData[];
  mode:"add" | "edit" |"manage";
  cancelPopup:()=> void;

}

const UserForm = ({ setSubmittedData,newUser,mode,cancelPopup}: UserFormProps) => {
  const [roles, setRoles] = useState<Role[]>([]);
  const [formErrors, setFormErrors] = useState({
    firstname: "",
    lastname: "",
    email: "",
    mobile: "",
    role: "",
  });
  const [formData, setFormData] = useState<UserFormData>({
    id:"",
    firstname: "",
    lastname: "",
    email: "",
    mobile: "", 
    address:"",
    role: "",
  });

  const {showToast } = useToast();


  useEffect(() => {
    const fetchRoles = async () => {
      try {
        const response = await axios.get("http://192.168.203.122:5000/get-roles");     
        setRoles(response.data.roles);
        console.log("Roles:", response.data.roles);
      } catch (error) {
        console.error("Error fetching roles:", error);
        setRoles([]);
      }
    };

    fetchRoles();
  }, []);

   useEffect(() => {
    if (mode === "edit" || mode === "manage" && newUser.length > 0) {
      setFormData(newUser[0]); 
    }
  }, [mode]);

  const validateFields = () => {
    const errors: any = {};
  
    if (!validateName(formData.firstname)) {
      errors.firstname = "First name is required.";
    }
  
    if (!validateName(formData.lastname)) {
      errors.lastname = "Last name is required.";
    }
  
    if (!validateEmail(formData.email)) {
      errors.email = "Please enter a valid Microsoft email address (e.g., @outlook.com, @hotmail.com, @microsoft.com)";
    }
  
    if (!validateMobile(formData.mobile)) {
      errors.mobile = "Mobile number must be 10 digits.";
    }
  
    if (!formData.role.trim()) {
      errors.role = "Role is required.";
    }
  
    setFormErrors(errors);
    return Object.keys(errors).length === 0; 
  };
  
  const validateName = (name: string) => {
    return name.trim() !== "";
  };
  const validateEmail = (email: string) => {
    const microsoftEmailRegex = /^[a-zA-Z0-9._%+-]+@(ibaseit\.com|outlook\.com|hotmail\.com|microsoft\.com)$/;
    return microsoftEmailRegex.test(email);
  };
  const validateMobile = (mobile: string) => {
    return /^\d{10}$/.test(mobile);
  };
 

  const handleCancel = ()=>{
    setFormErrors({
      firstname: "",
      lastname: "",
      email: "",
      mobile: "",
      role: "", 
    });
    cancelPopup();
  }
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    const cleanedValue = name === "mobile" ? value.replace(/\D/g, "") : value;
    setFormData((prevData) => ({
      ...prevData,
      [name]: cleanedValue,
    }));
      if (name === "mobile") {
      if (cleanedValue.length === 10) {
        setFormErrors((prevErrors) => ({
          ...prevErrors,
          mobile: "",
        }));
      } else {
        setFormErrors((prevErrors) => ({
          ...prevErrors,
          mobile: "",
        }));
      }
    }
  };
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const isValid = validateFields();
  if (!isValid) {
    return; 
  }
    let token = localStorage.getItem("authToken"); 
    const payload = {
      firstname: formData.firstname,
      lastname: formData.lastname,
      mobile: Number(formData.mobile),
      email: formData.email,
      role: formData.role,
    };
    
    try {
      const response = await axios.post("http://192.168.203.122:5000/invited_user", payload, {
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
      });
  
      console.log("User Data:", response);
      setSubmittedData((prevData) => [...prevData, response.data.userData]);  
      setFormData({
        id: "",
        firstname: "",
        lastname: "",
        email: "",
        address: "",
        mobile: "",
        role: "",
      });
      setFormErrors({
        firstname: "",
        lastname: "",
        email: "",
        mobile: "",
        role: "",
      });
     showToast("User successfully created!",'success')
      cancelPopup();

    } catch (error) {
      console.error("Error creating user:", error);
      showToast('Failed to create user. Please try again.','error')  
      cancelPopup();

     }
  };
  

  const handleSaveEdit = async () => {
    const isValid = validateFields();
  if (!isValid) {
    return; 
  }
    let token = localStorage.getItem("authToken");
    const payload = {
      // id:formData.id,
      firstname: formData.firstname,
      lastname: formData.lastname,
      mobile: Number(formData.mobile),
      email: formData.email,
      role: formData.role,
    };

    try {
      const response = await axios.post(`http://192.168.203.122:5000/update-userProfile/${formData.id}`, payload, {
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
      });
      console.log("User Data updated:", response);
      setSubmittedData((prevData) =>{
       return  prevData.map((user) =>
          user.id === formData.id ? {... user, ...response.data.userData } : user
        )
    });
    showToast('User successfully updated!','success')
        cancelPopup();

  
    } catch (error) {
      console.error("Error updating user:", error);
      showToast('Failed to create user. Please try again.','error')
        cancelPopup();
     }
  };


  return (
    <>

  <div className="modal-popup">
  <div className="modal-popup-content">
    {mode === "add" && <h4 className="modal-hdr">Add User</h4> }   
    {mode === "edit" && <h4 className="modal-hdr">Edit User</h4>} 
    {mode === "manage" && <h4 className="modal-hdr">Manage Account</h4>} 
     <form onSubmit={handleSubmit} className="padding-p1 form-scroll">
        <div className="form-group">
            <div>
              <label>First Name</label>
              <input type="text" name="firstname" value={formData.firstname} onChange={handleChange} required />
              {formErrors.firstname && <p className="error-text">{formErrors.firstname}</p>}   
            </div>
            <div>
            <label>Last Name</label>
              <input type="text" name="lastname" value={formData.lastname} onChange={handleChange} required />
              {formErrors.lastname && <p className="error-text">{formErrors.lastname}</p>}
            </div>
        </div>
        <div className="form-group">
          <label>Email</label>
          <input type="email" name="email" value={formData.email} onChange={handleChange} disabled={mode === "manage"} required />
          {formErrors.email && <p className="error-text">{formErrors.email}</p>}
        </div>
        {mode === 'manage' && (
          <div className="form-group">
            <label>Address</label>
            <input
              type="text"
              name="address"
              value={formData.address}
              onChange={handleChange}
            />
          </div>
        )}
        <div className="form-group">
          <div>
              <label>Mobile</label> 
              <input type="tel" name="mobile" value={formData.mobile} onChange={handleChange} required />
              {formErrors.mobile && <p className="error-text">{formErrors.mobile}</p>}
          </div>
          <div>
              <label htmlFor="role">Role</label>
              <select id="role" name="role" value={formData.role} onChange={handleChange} disabled={mode === "manage"} required>
                <option value="" disabled>
                  Select a role
                </option>
                {roles.map((role) => (
                  <option key={role.id} value={role.rolename}>
                    {role.rolename}
                  </option>
                ))}
              </select>
              {formErrors.role && <p className="error-text">{formErrors.role}</p>}
          </div>
        </div>

      </form>
      <footer className="footer-field">
      <button type="button" className="modal-button-transp" onClick={handleCancel}>cancel</button>
          {mode === "add" && (
        <button type="submit" onClick={handleSubmit} className="modal-button">
          Add
        </button>
      )}

      {(mode === "edit" || mode === "manage") && (
        <button type="button" className="modal-button btn-right" onClick={handleSaveEdit}>
          Save
        </button>
      )}      
    </footer>
  </div>
  </div>
    </>
  );
};

export default UserForm;
