module.exports = {
  devServer: {
    proxy: {
      "/ovsi": {
        target: process.env.VUE_APP_BACKEND_HOST,
        ws: false,
        secure: false,
        changeOrigin: true,
      },
    },
  },
};
