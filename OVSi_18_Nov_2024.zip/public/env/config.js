const config = (() => {
    return {
        "VUE_APP_GRAPHQL_API": "https://l5vm6nb5jrc2ff3a2zquor4pya.appsync-api.us-east-2.amazonaws.com/graphql",
        "VUE_APP_GRAPHQL_API_KEY": "da2-jtikwymngvef3oufdnxmeugk74",
        "VUE_APP_GET_FLIGHTS_API": "https://services.dev.ctl.aws.ual.com/ovsi/1.0/api/flight/getflights",
        "VUE_APP_GET_FLIGHTS_REPORTS_API": "https://services.dev.ctl.aws.ual.com/ovsi/1.0/api/report/getflightreport",
        "VUE_APP_ADD_VOLUNTEER": "https://services.dev.ctl.aws.ual.com/ovsi/1.0/api/passenger/addvolunteer",
        "VUE_APP_REMOVE_VOLUNTEER": "https://services.dev.ctl.aws.ual.com/ovsi/1.0/api/passenger/removevolunteer",
        "VUE_APP_DEACTIVE_FLIGHT": "https://services.dev.ctl.aws.ual.com/ovsi/1.0/api/flight/deactivateflight",
        "VUE_APP_GET_COMMENT": "https://services.dev.ctl.aws.ual.com/ovsi/1.0/api/flightcomment/getflightcomments",
        "VUE_APP_GET_FLIGHT_HISTORY": "https://services.dev.ctl.aws.ual.com/ovsi/1.0/api/report/getflighthistory",
        "VUE_APP_FINALIZE_FLIGHT": "https://services.dev.ctl.aws.ual.com/ovsi/1.0/api/flight/finalizeflight",
        "VUE_APP_ADD_COMMENT": "https://services.dev.ctl.aws.ual.com/ovsi/1.0/api/flightcomment/addflightcomment",
        "VUE_APP_GET_PASSENGERS": "https://services.dev.ctl.aws.ual.com/ovsi/1.0/api/passenger/getpassengers",
        "VUE_APP_INITIATE_FLIGHT": "https://services.dev.ctl.aws.ual.com/ovsi/1.0/api/flight/initiateflight",
        "VUE_APP_UPDATE_COMMENT": "https://services.dev.ctl.aws.ual.com/ovsi/1.0/api/flightcomment/updateflightcomment",
        "VUE_APP_GET_FLIGHT_API": "https://services.dev.ctl.aws.ual.com/ovsi/1.0/api/flight/getflight",
        "VUE_APP_GET_CONFIGURATION_API": "https://services.dev.ctl.aws.ual.com/ovsi/1.0/ovsi/1.0/api/configuration/getconfiguration",
        "VUE_APP_ADD_CONFIGURATION_API":"https://services.dev.ctl.aws.ual.com/ovsi/1.0/ovsi/1.0/api/configuration/addconfiguration",
        "VUE_APP_DELETE_CONFIGURATION_API":"https://services.dev.ctl.aws.ual.com/ovsi/1.0/ovsi/1.0/api/configuration/deleteconfiguration"
    };
})();