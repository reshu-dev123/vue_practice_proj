<template>
  <template  v-if="isLoggedIn">
  <UAHeader v-once />
  <div class="u-row main-body">
    <UANav v-if="getMenuItems" @openExportModalPopup="showExportModalPopup"/>
    <!--Azh Dynamically load the component from the API-->
    <!-- Menu -->
    <div class="u-menu u-col" :class="[menuSize,'main-body align-menu-top']" v-if="showOrHideMainMenus">
     <div class="u-row">
      <div class="u-col l11 m11 s11 u-menuItem ">
      <h3 class="u-text-white">Menu</h3>
        </div>
             </div>
      <template v-for=" (menuItem , key) in getMainMenuItems" :key="key">
      <UAMenuList :menuItem="menuItem" :subMenuItems="menuItem.id =='flight_Management'?getSubMenuItems(menuItem.id): []" :cssClass="'u-menuItem '"
        :imgPath="getImageUrl(menuItem.image)" :showIcon="true" :index="key"/>
      </template>
    </div>
    <div class="content u-rest" id="mainContentDiv" @scroll="onScroll">
      <UAAlertMessage v-once @scrollTop="scrollToTop" />
      <UAModalMessage v-if="showModalMessage"></UAModalMessage>
      <UASpinerModal v-if="isGeneratingPDF || isGeneratingExcel" />
      <component :is="processStep" ref="uaChldLayoutCom">
      </component>
    </div>
  </div>
 </template>
  <template v-else>
  <h2 class="u-padding u-center">Authenticating ...</h2>
 </template>
</template>

<script>
import UAAlertMessage from "@/components/UAAlertMessage.vue"
import UAHeader from "@/components/UAHeader.vue"
import UAOVSIDefaultLayout from "@/layouts/UAOVSIDefaultLayout.vue"
import UAModalMessage from "@/components/UAModalMessage.vue"
import UASpinerModal from "../components/UASpinerModal.vue";
import UAMenuList from "@/components/UAMenuList.vue";
import { mapState, mapActions, mapGetters,mapMutations } from "vuex";
import UANav from "../components/UANav.vue";
import UAButton from "../components/UAButton.vue";
import UAModal from "../components/UAModal.vue";
export default {
  name: "Landing",
  data(){
    return {
      showExportOptionModalPopup : false
    }
  },
  computed: {
    ...mapState({
      isGeneratingPDF: (state) => state.ovsiDefaultModule.isGeneratingPDF,
      isGeneratingExcel: (state) => state.ovsiDefaultModule.isGeneratingExcel,
      showOrHideMainMenus: (state) => state.menuModule.showOrHideMainMenus,
      isLoggedIn: (state)=> state.userModule.isLoggedIn,
      exportToExcelConfig: (state) => state.ovsiDefaultModule.exportToExcelConfig,
      isShow: (state) => state.ovsiDefaultModule.isShow,
      isScrollDown: (state) => state.ovsiDefaultModule.isScrollDown,
      selectedMenuId: state=>state.menuModule.selectedMenuId,
      menuSize(state) {
        return state.menuModule.toggleMenu ? 'u-menuSizeExp' : 'u-menuSize'
      },
      processStep(state) {
        return state.processStep;
      },
      showModalMessage: (state) => state.messageModal.showModalMessage,
    }),
    ...mapGetters(["getMenuItems", "getSubMenuItems", "getImageUrl", "getUserName", "getMainMenuItems"]),
  },
  methods: {
    ...mapMutations(["setshowOrHideMainMenus",'toggleMenu','setisScrollDown',"setIsShow"]),
    ...mapActions(["setProcessStep"]),
    scrollToTop(){
      var elem = document.getElementById('mainContentDiv');
      elem.scrollTop = 0;
    },
    onScroll(e){
      if(this.selectedMenuId != 'flight_Management'){return;} // enable only for flight_mgmt
        let isScollDown = e.target.scrollTop > 0;
        if(isScollDown == this.isScrollDown)
        return;
        isScollDown && this.setIsShow(true)
        this.setisScrollDown(isScollDown);
    },
    ClosePopup(){
      this.showExportOptionModalPopup = false;
    },
    showExportModalPopup(exportTypes){
      //this.showExportOptionModalPopup = true;
      this.$refs.uaChldLayoutCom.callChildExportFunc(exportTypes);
    }
      },
  components: {
    UAAlertMessage,
    UAHeader,
    UAOVSIDefaultLayout,
    UAMenuList,
    UAModalMessage,
    UASpinerModal,
    UANav,
    UAButton,
    UAModal
  }
};
</script>
<style scoped>
  .align-menu-top {
    top:7vh;
    position: absolute;
    z-index: 999;
  }
</style>
