<template>
  <div :class="isExpand ? 'u-modal u-m-expand' : 'u-row'" >
    <div :class="isExpand ? 'u-modal-content u-mc-expand' : 'u-row'">
       <div v-if="mainHeader" class="u-row-padding  u-border-5 u-of-x u-white">
        <div class="u-col l12 m12 s12 u-padding-top-7">
            <label class="u-msmall  u-fnt-bld">
              {{ mainHeader }}</label>
        </div>
      </div>
      <div v-if="isShowFilterSection"
         :class="['u-row u-margin-small u-border-bottom u-mar-btm-0', entityDisplayDetails.Layouts[0]?.filtersClass]" 
      >   
        <div class="u-col"  > 
          <UAOVSISearchFilters 
            :rtfFilters="getOVSIFilters"
            @resetDefaultData="resetData"
            :key="getOVSIFilters"
            @openMultiSelectPopup="openMultiSelectPopup"
            ref="searchFilterCom"
          />
        </div>
      </div>
         <div
        class="u-row u-margin-small u-bg-1 u-border-4 u-round-large u-margin-top-0"
        v-if="!isNavigatiingToSameCom  && !showMultiSelectPop"
      >
        <component
        v-if="innerLayout"
          :is="innerLayout"
          ref="uaFunctionalCom"    
        >
        </component>
      </div>
      <div
        class="u-row u-margin-small u-bg-1 u-border-4 u-round-large u-margin-top-0"
        v-if="!isNavigatiingToSameCom && showMultiSelectPop"
      >
        <UAMultiSelect2  
          :isMultiSelectPop="isMultiSelectPopup" 
          :filterField="multiSelectFieldInfo"
          :modelValue="filterFieldModalData"
          @setMultiselectModalValue="setMultiselectModalValue"
        >
        </UAMultiSelect2>
      </div>
    </div>
  </div>
</template>
<script>
import { mapState, mapGetters, mapMutations } from "vuex";
import UAOVSISearchFilters from "@/components/UAOVSISearchFilters.vue";
import UAButton from "@/components/UAButton.vue";
import UASpinerModal from "../components/UASpinerModal.vue";
import UAOversale from "../components/UAOversale.vue";
import UAFlightManagement from '@/components/UAFlightManagement.vue';
import UAOSLReport from '@/components/UAOSLReport.vue';
import UAHistory from '../components/UAHistory.vue';
import UAOSLVolunteerLists from "@/components/UAOSLVolunteerLists.vue";
import UAMultiSelect2 from "@/components/UAMultiSelect2.vue";
import UAOSLFlowTable from "@/components/UAOSLFlowTable.vue";
import UAOSLChannels from "@/components/UAOSLChannels.vue";
import UAOSLFlowMultiTabs from '@/components/UAOSLFlowMultiTabs.vue';
import UADowngradeIDBH from "@/components/UADowngradeIDBH.vue";
import UAUserManagement from '@/components/UAUserManagement.vue';
export default {
  name: "UAOVSIDefaultLayout",
  components: {
    UAOVSISearchFilters,
    UAButton,
    UASpinerModal,
    UAOversale,
    UAFlightManagement,
    UAOSLReport,
    UAHistory,
    UAOSLVolunteerLists,
    UAMultiSelect2,
    UAOSLFlowTable,
    UAOSLChannels,
    UAOSLFlowMultiTabs,
    UADowngradeIDBH,
    UAUserManagement
  },
  data() {
    return {
      isInnerTableEditable: false,
      isMultiSelectPopup : false,
      multiSelectFieldInfo:{},
      filterFieldModalData:{}
    };
  },
  computed: {
    ...mapState({
      searchOVSIData: (state) => state.ovsiDefaultModule.searchOVSIData,
      innerLayout: (state) => state.ovsiDefaultModule.innerLayout,
      isExpand: (state) => state.ovsiDefaultModule.isExpand,
      searchOVSIData: (state) => state.ovsiDefaultModule.searchOVSIData,
      showSerachFilter: (state) => state.ovsiDefaultModule.showSerachFilter,
      mainHeader: (state) => state.ovsiDefaultModule.mainHeader,
      isNavigateToInnerOtherView: (state) => state.ovsiDefaultModule.isNavigateToInnerOtherView,
      isNavigatiingToSameCom: (state) => state.ovsiDefaultModule.isNavigatiingToSameCom,
      filterConfig: state => state.ovsiDefaultModule.filterConfig,
      showMultiSelectPop: (state) => state.ovsiDefaultModule.showMultiSelectPop,
      entityDisplayDetails: state => state.ovsiDefaultModule.entityDisplayDetails,
      isShowFilterSection(){
        return  (this.showSerachFilter  && this.showSerachFilter.length > 0 
          && (!this.isNavigateToInnerOtherView 
          || (this.isNavigateToInnerOtherView && this.filterConfig && this.filterConfig.showSerachFilterOnNavigation)));
      }
    }),
    ...mapGetters(["getOVSIFilters", "getOVSIEntityId"]),
  },
  methods: {
    ...mapMutations(["setShowInlineTable",
      "setSelectedDataId",,]),
    callChildExportFunc(exportTypes){
      this.$refs.uaFunctionalCom.exportTOExcleFileFunc(exportTypes);
    },
    openMultiSelectPopup({showpopup,modalData}, filterField){
      this.isMultiSelectPopup = showpopup;
      this.multiSelectFieldInfo = filterField;
      this.filterFieldModalData = modalData;
    },
    setMultiselectModalValue(modalVal, dataObjForAll, filterObj){
      this.filterFieldModalData = modalVal;
      this.$refs.searchFilterCom.setMultiSelectModal(modalVal, dataObjForAll, filterObj);
      this.isMultiSelectPopup = false;
    },
    async resetData(isSearchClicked) {
      try{
        if(this.innerLayout=='UAOversale'){
          await this.$refs.uaFunctionalCom.handleSearchClickOrReste();
         }
      }catch(er){}
      try{
        if(!this.isNavigateToInnerOtherView && isSearchClicked)
         await this.$refs.uaFunctionalCom.fetchInitialLoadingData();  //To load inline table header data the data on click of search button
      } catch(err){}      
    },
  },
};
</script>
<style lang="scss">
.expand-close {
  filter: brightness(0) saturate(100%) invert(65%) sepia(61%) saturate(4080%)
    hue-rotate(190deg) brightness(84%) contrast(87%);
}
</style>