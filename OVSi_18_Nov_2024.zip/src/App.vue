<template>
  <div id="content">
  </div>
  <router-view v-if="isloginHandled"/>
</template>
<script>
import { mapActions } from "vuex";
import { getOamInfo } from './services/auth';
export default {
  name: 'App',
  data(){
    return {
      isloginHandled: false
    }
  },
  created() {
    console.log("OVSi V1.0.184 - eQE v0.1.0");
    window.addEventListener('loginHandler',(e)=>this.handleLogin(e))
    
  },
  beforeUnmount(){
    window.removeEventListener('loginHandler',(e)=>this.handleLogin(e))
  },
  methods: {
    ...mapActions([ "getMenuDetails", "getApplicationInfoDetails",
      "getRedirectUrl", "fetchAuthsAndSetCurrentRole",
      "fetchStationData"
    ]),
    handleLogin(e){
      let userInfo= getOamInfo();
      this.getApplicationInfoDetails({id:'applicationInfoDetails',userInfo})
      this.getRedirectUrl()
      this.getMenuDetails();
      this.isloginHandled=true;
    }
  }
}
</script>
<style lang="scss"></style>
