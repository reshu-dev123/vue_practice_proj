import { createApp } from "vue";
import App from "./App.vue";
import "./registerServiceWorker";
import router from "./router";
import store from "./store";
import './assets/css/OVSi.css';
import { oam } from "./services/auth";
// import { datadogRum } from '@datadog/browser-rum';
// import { getEnv } from "./helpers/utilities";
// datadogRum.init({
//     applicationId: getEnv('VUE_APP_AId'),
//     clientToken: getEnv('VUE_APP_Ctn'),
//     site: getEnv('VUE_APP_Ste'),
//     service: getEnv('VUE_APP_Svc'),
//     env: getEnv('VUE_APP_env'),
//     // Specify a version number to identify the deployed version of your application in Datadog
//     // version: '1.0.0', 
//     sessionSampleRate: 100,
//     sessionReplaySampleRate: 20,
//     trackUserInteractions: true,
//     trackResources: true,
//     trackLongTasks: true,
//     defaultPrivacyLevel: 'mask-user-input',
//  });
// datadogRum.startSessionReplayRecording();
createApp(App).use(store).use(router).mount("#app");
// appRef.config.warnHandler = (er,insta,info)=>{
//     console.error('er',er,' instance ',insta,'info: ',info)
// }

//setTimeout(loadApp,1000*1)
//loadApp()
oam();