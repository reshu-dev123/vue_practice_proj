export default {
  state: {
    alertType: "",
    alertMessages: '',
    modalAlertType: '',
    modalAlertMessages: '',
  },
  mutations: {
    clearAlertMessages(state) {
      state.alertType = "";
      state.alertMessages = [];
      state.modalAlertType = "";
      state.modalAlertMessages = [];
    },
    //Azh - set the alert messages from component/view
    setAlertMessages(state, alertObj) {
      state.alertType = alertObj.alertType;
      state.alertMessages = alertObj.alertMessages;
    },
    clearModalAlertMessages(state) {
      state.alertType = "";
      state.modalAlertMessages = [];
    },
    //Azh - set the alert messages from component/view
    setModalAlertMessages(state, alertObj) {
      state.modalAlertType = alertObj.alertType;
      state.modalAlertMessages = alertObj.alertMessages;
    },
    setAlertErrorMessageInfo(state, errInfoObj) {
      state.alertMessage.modalAlertType = errInfoObj.errorType;
      state.alertMessage.alertMessages = [errInfoObj.text];
    },
  },
  actions: {
    clearAlertMessages({ commit }) {
      // commit the data to mutation are synchronous
      commit("clearAlertMessages");
    },
    setAlertMessages({ commit }) {
      // commit the data to mutation are synchronous
      commit("clearAlertMessages");
    },
    handleErroMessageForAuth({ commit }, errInfoObj){
      commit('clearAlertMessages');
      if(errInfoObj.modalErr){
        commit('setModalAlertMessages',errInfoObj);
      }else{
        commit('setAlertMessages',errInfoObj);
      }
    },
    raiseServerError({ commit, rootState }, {er,isModalEr}) {
      let response = er.response;
      if (er?.message == "Network Error" || response?.status > 499) {
        let msg = {
          alertType:
            rootState.ovsiDefaultModule.applicationInfoDetails.errorMessageList
              .SERVER_ERROR.errorType,
          alertMessages: [
            rootState.ovsiDefaultModule.applicationInfoDetails.errorMessageList
              .SERVER_ERROR.text,
          ],
        };
        isModalEr?commit("setModalAlertMessages", msg):commit("setAlertMessages", msg);
      }
    },
    handleError({ commit, rootState },er){
      let response = er.response;
      let msg = {};
      if (response?.data?.messages) {
          let msgArray = response.data?.messages?.map(m => m.message);
          msg = { alertType: "warning", alertMessages: msgArray }
          
      } else {
        msg = {
          alertType: rootState.ovsiDefaultModule.applicationInfoDetails.errorMessageList.SERVER_ERROR.errorType,
          alertMessages: [rootState.ovsiDefaultModule.applicationInfoDetails.errorMessageList.SERVER_ERROR.text]
      }
      }
      commit('setAlertMessages',msg)
    }
  },
};
