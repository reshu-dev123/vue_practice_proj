import { getEntityDisplayDetails} from '../../services/rtfDefault.api'

export default {
  state: {
    exportToExcelConfig: {},
  },
  mutations: {
    resetEntityDetails(state){
    },
    setExportToExcelConfig(state, data){
        state.exportToExcelConfig = data;
    }
  },
  getters: {
  },
  actions: {
    getExportDetails({ commit,dispatch },id) {
        getEntityDisplayDetails(id)
        .then(async(response) => {
          if (response.status === 200) {
            let payload= await dispatch('getPayLoad',response)
            commit("setExportToExcelConfig", payload);
          } else {
            this.state.alertMessage.alertType = "warning";
            this.state.alertMessage.alertMessages = ["No Menu Data Found."];
          }
        })
        .catch((error) => {
          console.error(error)
          this.state.alertMessage.alertType = "error";
          this.state.alertMessage.alertMessages = ["Error: Unable to process request. Contact Administrator."];
          dispatch("unAuthorizedHandler", error);
        });
    },
   async backTopreviousAction({ commit,dispatch,getters,state }){
      
    }
  },
};
