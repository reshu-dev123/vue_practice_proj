import { getEntityDisplayDetails, getOVSIData ,getOVSiLocalData} from '../../services/rtfDefault.api'
import { getJPathvalue, getPatternMatching, getDateTimePart ,createHash, validateInputPattern, getbuttonColorClass } from '../../helpers/utilities'
import { getFlights ,getFlightReport,getFlightHistory,getFlight} from '../../services/flightService';
import {  getPassengers, getDowngradeList} from '../../services/passengerService';
import {getConfiguration} from '../../services/configurationService';
import {getoverviewbycity} from '../../services/oversaleService';


export default {
  state: {
    entityDisplayDetails: [],
    entityDisplayDetailsSubItems: [],
    applicationInfoDetails: {},
    searchOVSIData: [],    
    screenLayout: '',
    layout: '',
    showSerachFilter: [],
    addFilterItem: {},
    addFilterItemSetOnSrch:{},
    addEditItems: [],
    displayHeader: '',
    displayHeader1:'',
    filterSubmitButtonText:"",
    resetSearchVisible:'',
    showFilters: false,
    isExpand: false,
    innerLayout: '',
    isLoading: false,
    isInlineLoading: false,
    loadingMessage: '',
    actionId: "",
    action: "",
    isGeneratingExcel: false,
    generatingExcelMsg: '',
    isSelectedAllHubs: false, // used for oversale overview screen to track wheather selected all hubs or not
    chartConfig: {},
    searchfilters:[],
    tableDetails:[],
    addTableFields:[],
    modalButtons:[],
    apiResponse: {},
    cardsConfig:[],
    hideMainMenu: false,
    isNavigateToInnerOtherView:false,
    mainViewId: '',
    prevNavigateViews: [],
    isNavigatedEvent: false,
    selectedInputValues:{},
    selectedRecord: {},
    addCustomerComments: [],
    filterInputData:{},
    filterConfig: false,//TO show search filters after navigation from main screen
    commentsFooterFields: {},
    pagination: {
      prevToken: '',
      tokens: []
    },
    showMultiSelectPop: false,
    currRouteDDetails: '',
    editTableFields:[],
    editConfigTableFields:[],
    standardTblFlds:[],
    currentPage:1,
    isMoreDataLoading:false,
    isHeaderSrchClicked:false,
    headerFilterData:{},
    partitionKeyID:"",
    isViewDetails:false,
    prevOptions:{"type":"All","cabin":"All","compensation":"All","compensation_1":"All", "pass_class":"All"},
    showExportOptions:false,
    isScrollDown: false,
    isShow: true,
    intiateFlightPop:false,
    disableExport:false,
    currentSelTabIndex:0,
    stationData: {}, // used for stationpopup oversale screen
    applyFilterClicked:false
  },
  mutations: {
    getEntityDisplayDetails(state, entityDisplayDetails) {
      state.apiResponse={};
      state.entityDisplayDetails = entityDisplayDetails;
      state.screenLayout = state.entityDisplayDetails.ScreenLayout;
      state.layout = state.entityDisplayDetails.Layout;
      state.filterConfig = state.entityDisplayDetails.Layouts[0].filterConfig;
      state.showSerachFilter = state.entityDisplayDetails.Layouts[0].filters;
      
      if (!state.isNavigateToInnerOtherView) {        
        state.mainViewId = entityDisplayDetails.id;
      }
      state.innerLayout = state.entityDisplayDetails.Layouts[0].InnerLayout.name;
      state.displayHeader = state.entityDisplayDetails.Layouts[0].InnerLayout.displayHeader;
      state.filterSubmitButtonText = state.entityDisplayDetails.Layouts[0].filterSubmitButtonText;
      state.displayHeader1 = state.entityDisplayDetails.Layouts[0]?.InfoPop?.displayHeader1;
      state.innerFields1 = state.entityDisplayDetails.Layouts[0]?.InfoPop?.Fields;
      state.resetSearchVisible = state.entityDisplayDetails.Layouts[0].hasOwnProperty("resetSearchVisible") ?
          state.entityDisplayDetails.Layouts[0]?.resetSearchVisible : true
      state.action = state.entityDisplayDetails.action;
      state.actionId = state.entityDisplayDetails.actionId;
      state.addtionalexportToExcelConfig = state.entityDisplayDetails.Layouts[0].addtionalexportToExcelConfig ;
      state.chartConfig=state.entityDisplayDetails.Layouts[0].chartConfig;
      state.searchfilters = state.entityDisplayDetails.Layouts[0].searchfilters;
      state.tableDetails = state.entityDisplayDetails.Layouts[0].tableDetails;
      state.addTableFields = state.entityDisplayDetails.Layouts[0].addTableFields;
      state.modalButtons = state.entityDisplayDetails.Layouts[0].modalButtons;
      state.cardsConfig = state.entityDisplayDetails.Layouts[0]?.sections?.cardsConfig;
      state.addCustomerComments=state.entityDisplayDetails.Layouts[0]?.addCustomerComments;
      state.tabs = state.entityDisplayDetails.Layouts[0].InnerLayout.tabs;
      state.subtabs = state.entityDisplayDetails.Layouts[0].InnerLayout.subtabs;
      state.editTableFields = state.entityDisplayDetails.Layouts[0].editTableFields;
      state.commentsFooterFields = state.entityDisplayDetails.Layouts[0].commentsFooterFields;
      state.editConfigTableFields = state.entityDisplayDetails.Layouts[0].editConfigTableFields;
      state.standardTblFlds = state.entityDisplayDetails.Layouts[0].standardTblFlds;
      state.partitionKeyID = state.entityDisplayDetails.partitionKeyID;
      state.showExportOptions = state.entityDisplayDetails.Layouts[0].showExportOptions;
    },
    resetEntityDetails(state) {
      state.entityDisplayDetails = []
      state.screenLayout = "";
      state.layout = "";
      state.innerLayout = "";
      state.searchOVSIData = [];
      state.InnerRTFHeader = [];
      state.showSerachFilter = [];
      state.displayHeader = '';
      state.displayHeader1 = '';
      state.filterSubmitButtonText="";
      state.resetSearchVisible='';
      state.addFilterItem = {};
      state.addFilterItemSetOnSrch={};
      state.isLoading = false;
      state.isInlineLoading= false;
      state.loadingMessage='';
      state.isGeneratingExcel = false;
      state.generatingExcelMsg = '';
      state.isSelectedAllHubs=false;
      state.chartConfig={};
      state.searchfilters = [];
      state.tableDetails=[];
      state.addTableFields=[];
      state.modalHeader={};
      state.modalButtons=[];
      state.apiResponse={};
      state.cardsConfig=[];
      state.hideMainMenu=false;
      state.isNavigateToInnerOtherView= false;
      state.mainViewId='';
      state.prevNavigateViews = [];
      state.isNavigatedEvent= false;
      state.selectedInputValues={};
      state.addCustomerComments= [];
      state.editTableFields=[];
      state.filterInputData={};
      state.commentsFooterFields={};
      state.filterConfig={};
      state.pagination= {
        tokens: [],
        prevToken: ''
      },
      state.showMultiSelectPop= false;
      state.editConfigTableFields=[];
      state.currRouteDDetails = '';
      state.standardTblFlds = [];
      state.currentPage=1;
      state.isMoreDataLoading=false;
      if(!state.isHeaderSrchClicked){
        state.headerFilterData = {}
      };
      state.partitionKeyID = "";
      state.isViewDetails = false;
      state.showExportOptions = false;
      state.isShow=true;
      state.isScrollDown=false;
      state.intiateFlightPop=false;
      state.disableExport=false;
      state.currentSelTabIndex = 0;
    },
    setApplyFilterClicked(state, flag){
      state.applyFilterClicked = flag;
    },
    setCurrentSelTabIndex(state, index){
      state.currentSelTabIndex = index;
    },
    setStationData(state,data){
      state.stationData=data;
      state.stationData.stations = data.stations.sort((a,b)=>a.localeCompare(b));
      
    },
    setDisableExport(state,flag){
      state.disableExport = flag;
    },
    setIntiateFlightPop(state,flag){
      state.intiateFlightPop = flag;
    },
    setIsViewDetails(state,flag){
      state.isViewDetails = flag;
    },
    setisScrollDown(state,flag){
      state.isScrollDown = flag;
    },
    setIsShow(state,flag){
      state.isShow = flag;
    },
    setheaderFilterData(state, fltData){
      state.headerFilterData = fltData;
    },
    setIsHeaderSrchClicked(state,flag){
      state.isHeaderSrchClicked = flag;
    },
    setIsMoreDataLoading(state,flag){
      state.isMoreDataLoading = flag;
    },
    setCurrentPage(state,currentPage){
      state.currentPage=currentPage
    },
    setCurrRouteDDetails(state, routInfo){
      state.currRouteDDetails = routInfo;
    },
    setShowMultiSelectPop(state, flag){
      state.showMultiSelectPop = flag;
    },
    setPaginationToken(state,token){
      state.pagination.tokens.push(token);
    },
    setPaginationTokens(state,tokens){
      state.pagination.tokens=tokens;
    },
    setPaginationPrevToken(state,token){
      state.pagination.prevToken=token;
    },
    resetPagination(state){
      state.pagination= {
        tokens: [],
        prevToken: ''
      }
    },
    setFilterInputData(state, obj) {
      state.filterInputData = obj;
    },
    setSelectedInputValues(state, obj) {
      state.selectedInputValues = obj;
    },
    setIsNavigatedEvent(state, speed) {
      state.isNavigatedEvent = speed;
    },
    setIsNavigateToInnerOtherView(state, flag) {
      state.isNavigateToInnerOtherView = flag;
    },
    setPrevNavigateViews(state, viewID) {
      state.prevNavigateViews.push(viewID);
    },
    deletePrevNavigateViews(state) {
      state.prevNavigateViews.pop();
    },
    resetPrevNavigateViews(state) {
      state.prevNavigateViews = [];
    },
    updatePrevNavigateViews(state,{entityId,searchParams}) {
      state.prevNavigateViews.forEach(item=>{
        if(item.id == entityId)
          item.searchFilterInputParams=searchParams;
      })
    },
    setHideMainMenu(state, flg) {
      state.hideMainMenu = flg;
    },
    setSelectedAllHubs(state,flag){
      state.isSelectedAllHubs=flag;
    },
    setApplicationInfoDetails(state, appData) {
      state.applicationInfoDetails = appData;
    },
    resetShowSerachFilter(state, filterObj) {
      state.showSerachFilter = filterObj;
    },
    setaddFilterItem(state, filterIteam) {
      state.addFilterItem = filterIteam;
    },
    setAddFilterItemSetOnSrch(state, filterIteam){
      state.addFilterItemSetOnSrch = filterIteam;
    },
    resetaddFilterItem(state) {
      state.addFilterItem = {};
    },

    reSetSearchOVSIData(state) {
      state.searchOVSIData = [];
    },

    setSearchOVSIData(state, filterData) {
      state.searchOVSIData = filterData;
    },
    setError(state, filterData) {
      if (filterData.length == 0) {
        this.state.alertMessage.alertType = "warning";
        this.state.alertMessage.alertMessages = ["Warning: No Records Found!."];
      }
    },
    getAddEditItems(state, selectedRTFItems) {
      state.addEditItems = selectedRTFItems;
    },
    toggleViewMode(state) {
      state.isExpand = !state.isExpand;
    },
    setSuccessMsg(state, filterData) {
      this.state.alertMessage.alertType = "success";
      this.state.alertMessage.alertMessages = ["Info Section Updated Successfully !"];
    },
    setshowSerachFilter(state, filterData) {
      this.state.showFilters = filterData;
    },
    setInvalidDateError(state, errorMessage) {
      if (errorMessage.length > 0) {
        this.state.alertMessage.alertType = "warning";
        this.state.alertMessage.alertMessages = ["Warning: " + errorMessage];
      }
    },
    setIsGeneratingExcel(state, flag) {
      state.isGeneratingExcel = flag;
    },
    setGeneratingExcelMsg(state, msg) {
      state.generatingExcelMsg = msg;
    },
    setIsLoading(state, flag) {
      state.isLoading = flag;
    },
    setIsInlineLoading(state, {flag,msg}) {
      state.isInlineLoading = flag;
      flag?state.loadingMessage=msg:state.loadingMessage='';
    },
    setApiResponse(state,data){
      state.apiResponse=data;
    },
    setSelectedRecord(state,data){
     state.selectedRecord = data;
    },
    setPrevOptions(state, obj){
      state.prevOptions = obj;
    },
  },
  getters: {
    getOVSIFilters: (state) => {
        if (Object.keys(state.entityDisplayDetails).length > 0) {
          return (state.entityDisplayDetails.Layouts.find((item) => item.name === state.layout)).filters;
        }
    },
    getPreviousNavigationData: (state) => {
      if (state.prevNavigateViews.length > 1) {
        return state.prevNavigateViews[state.prevNavigateViews.length - 2];
      } else {
        return {};
      }
    },
    getOVSIEntityId: (state) => {
      if (Object.keys(state.entityDisplayDetails).length > 0) {
        return (state.entityDisplayDetails.Layouts[0].id);
      }
    },
    getOVSIFields: (state) => {
      if (Object.keys(state.entityDisplayDetails).length > 0) {
        return (state.entityDisplayDetails.Layouts[0].InnerLayout.Fields?.sort((a, b) => a.sequence - b.sequence));
      }
    },

    getCaptionHeaders: (state) => {
      if (Object.keys(state.entityDisplayDetails).length > 0) {
        return (state.entityDisplayDetails.Layouts[0].InnerLayout.CaptionHeaders?.sort((a, b) => a.sequence - b.sequence));
      }
    },

    getJPathValue: (state) => (jPath, jObject) => {
      return getJPathvalue(jPath, jObject);
    },
    getPatternMatching: (state) => (event, dataType) => {
      return getPatternMatching(event, dataType, state.applicationInfoDetails.inputPatterns);
    },
    validateKeyPressInput: (state) => (event, dataType) => {
      return validateInputPattern(event, dataType, state.applicationInfoDetails.keyPressInputPatterns);
    },
    getOvslStatusColor: (state)=>(oversaleStatus)=>{
      return getbuttonColorClass(oversaleStatus,state.applicationInfoDetails.oversaleStatusMapper)
    },
    getATRformatDate:(state)=> (date,format) =>{
      return `${date.getUTCFullYear()}-${date.getUTCMonth() < 9 ? '0' +( date.getUTCMonth() + 1 ): date.getUTCMonth() + 1}-${date.getUTCDate() < 10 ? '0' + date.getUTCDate() : date.getUTCDate()}`
    },
    getATRformatDateUTC:(state)=> (date,format) =>{
      return `${date.getUTCFullYear()}-${date.getUTCMonth() < 9 ? '0' +( date.getUTCMonth() + 1 ): date.getUTCMonth() + 1}-${date.getUTCDate() < 10 ? '0' + date.getUTCDate() : date.getUTCDate()}`
    },
    getPrevOptions: (state) =>{
      return JSON.parse(JSON.stringify(state.prevOptions));
    },
  },
  actions: {
    navigateMenuAction({ commit,dispatch,getters,state },obj){
      let {menu} = obj || {menu:getters.getMenuItems[0]};
        commit('setSelectedMenuId',menu.id);
        dispatch('getEntityDisplayDetailsAction',menu.id).then(()=>{
             if(state.screenLayout != ""){
                dispatch('setProcessStep',state.screenLayout)
             }else{
                dispatch('setProcessStep',menu.id)
             }
        })
    },
    async getEntityDisplayDetailsAction({ commit,dispatch }, id) {
      
      return await getEntityDisplayDetails(id)
        .then(async(response) => {
          if (response.status === 200 ) {
            let payload= await dispatch('getPayLoad',response);
            commit("getEntityDisplayDetails", payload);
          } else {
            this.state.alertMessage.alertType = "warning";
            this.state.alertMessage.alertMessages = ["!Warning: No Records Exists. - " + id];
          }
        })
        .catch((error) => {
          console.error(error);
          dispatch('unAuthorizedHandler',error)
          this.state.alertMessage.alertType = "warning";
          this.state.alertMessage.alertMessages = ["!Warning: No Records Exists. - " + id];
        });
    },

    async getApplicationInfoDetails({ commit,dispatch }, {id,userInfo}) {
      return await getEntityDisplayDetails(id)
        .then(async(response) => {
          if (response.status === 200) {
            let payload= await dispatch('getPayLoad',response);
            commit("setApplicationInfoDetails", payload);
            commit('setChannel',payload.channel);
            dispatch('fetchAuthsAndSetCurrentRole',userInfo);
          }
        })
        .catch((error) => {
          console.error(error);
          dispatch('unAuthorizedHandler',error)
        });
    },
    async getRTFDataLocal({ commit }, obj) {
      await getOVSiLocalData(obj)
        .then((response) => {     
          //if(response?.data?.data?.response!=null && response.status === 200 && !response?.data?.message ) {
          if(response.status === 200) {              
            commit("reSetSearchOVSIData");
            //let payload = JSON.parse(response.data.data.response.payload);
            let payload = response.data;
            let count = 1;
            if (payload.length > 0) {
              payload.forEach((rData) => {
                rData.id = count;
                rData.expandTable = true;
                rData.saveEnabled = false;
                rData.isShow = true;
                count++;
              });
              commit("setSearchOVSIData", payload)
              commit("setIsLoading", false);
            } else {
              this.state.alertMessage.alertType = "warning";
              this.state.alertMessage.alertMessages = ["Warning: No Records Found!"];
              commit("setIsLoading", false);
            }            
          } else {
            this.state.alertMessage.alertType = "warning";
            this.state.alertMessage.alertMessages = ["Unable To Find Record. Retry"];
              commit("setIsLoading", false);
          }
        })
        .catch((error) => {
          console.error('errr', error);
          this.state.alertMessage.alertType = "warning";
          this.state.alertMessage.alertMessages = ["Unable To Find Record. Retry"];
          commit("setIsLoading", false);
        });
      
    },
    async getOVSIData({ commit, dispatch, getters, state }, obj) {
     let authorize = await dispatch('authorizeModule',{operationId: obj.actionId,moduleId:getters.getOVSIEntityId,origin:obj.inputObject?.FlightOrigin});
     if(!authorize){
      console.log('REsult authorize: getOVSIData operationId', obj.actionId,authorize)
      commit("setIsLoading", false);
      return;
     }
     obj.cachePaths=getters.getCachePaths;
      switch(obj.actionId){
        case 'ua_get_flights':
          return dispatch('getFlights',obj);
        case 'ua_get_flight_report':
            return await dispatch('getFlightReport',obj);
        case 'ua_get_history':
          return dispatch('getFlightHistory',obj);
        case 'ua_get_VolList':
          return dispatch('getPassengers',obj);
        case 'ua_get_config':
          return dispatch('getConfiguration',obj)
        case 'ua_get_downgrade':
          return dispatch('getDowngradeList',obj);
        case 'ua_get_overview':
          return dispatch('getoverviewbycity',obj);
        default:
          console.log('default cse executed..')
         return  await getOVSIData(obj)
          .then(async (response) => {          
              if (response?.data?.data?.response != null && response.status === 200 && !response?.data?.errors) {
              commit("reSetSearchOVSIData");
              let payload = JSON.parse(response.data.data.response.payload);
              let count = 1;
              if (payload.length > 0) {
                payload.forEach((rData) => {
                  rData.id = count;
                  rData.expandTable = true;
                  rData.saveEnabled = false;
                  rData.isShow = true;
                  count++;
                });
                commit("setSearchOVSIData", payload)
              }
            }
            })
          .catch((error) => {
            if (!state.secondarysearchFilterMacro) {
              this.state.alertMessage.alertType = "warning";
              this.state.alertMessage.alertMessages = [this.state.ovsiDefaultModule.applicationInfoDetails.errorMessageList.SERVER_ERROR.text];
            }
  
          }).finally(()=>commit('setIsLoading', false));
         
      }

    },
   async getFlights({commit ,state,getters},obj){
    let uiFilters = state.showSerachFilter.filter(filter=>filter.useIn == 'ui');
    let copyObj= JSON.parse(JSON.stringify(obj));
    uiFilters.forEach(uf=>{
     delete copyObj.inputObject[uf.attributes.id];
    })
    if(!copyObj.inputObject.page){
      commit("setIsLoading", true);
    }
    return await  getFlights(copyObj)
      .then(response=>{
        if(response.status == 200 ){
          commit('setApiResponse',response.data);
          let flights = response.data.flights;
          if(!flights){
            commit('setAlertMessages',{ alertType: "warning",alertMessages: [response.data.messages[0].message]})
            commit('setSearchOVSIData',[]);
            return;
          }
          let uiObj= {},timeObj={};
          let uiFilters = state.showSerachFilter.filter(filter=>filter.useIn == 'ui');
          uiFilters.forEach(uf=> {
            if(uf.attributes.id == "startTime" || uf.attributes.id =="endTime"){
              state.addFilterItem[uf.attributes.id] ? timeObj[uf.attributes.id] = state.addFilterItem[uf.attributes.id]:'';
            } else {
              state.addFilterItem[uf.attributes.id]?uiObj[uf.attributes.id] = state.addFilterItem[uf.attributes.id]:'';
            }
          });
          if(uiObj['isPbtOverCapacity'] == 'all'){
            const {isPbtOverCapacity, ...rest} = Object.assign({},uiObj);
            uiObj = rest;
          }
          if(uiObj['oversaleStatus'] == 'ALL'){
            const {oversaleStatus, ...rest} = Object.assign({},uiObj);
            uiObj = rest;
          }
         // actual data  filter
          flights= flights.filter(f=>{
             for (let [key,value] of Object.entries(uiObj) ){
                 if(f[key].toString().toLowerCase() != value.toString().toLowerCase()){
                  return false;
                 }
             }
             //Filter record as per start time and end time 
             if(Object.keys(timeObj).length > 0){
              let startDtFld = state.showSerachFilter.filter(filter=> {
                return filter.attributes.id == 'startTime' && filter.filterByTime
              });
              let endDtFld = state.showSerachFilter.filter(filter=> {
                return filter.attributes.id == 'endTime' && filter.filterByTime
              });
              
              if(!getters.getJPathValue(startDtFld[0].pathToCompare,f)){
                return false;
              }
              let deptDt = new Date(getDateTimePart(getters.getJPathValue(startDtFld[0].pathToCompare,f),"yyyy-mm-dd hh:mm")).getTime();//date to compare
              
              let startDatePart = getDateTimePart(getters.getJPathValue(startDtFld[0].pathToCompare,f), "yyyy-mm-dd");
              let endDatePart = getDateTimePart(getters.getJPathValue(endDtFld[0].pathToCompare,f), "yyyy-mm-dd");
              let startDtTime = ''; let endDtTime = '';
              if(timeObj['startTime']){
                let startTime = startDatePart + ' ' + (timeObj['startTime'] ? timeObj['startTime'] : '00:00');
                startDtTime = new Date(startTime).getTime();
              }
              if(timeObj['endTime']){
                let endTime = endDatePart + ' ' + (timeObj['endTime'] ? timeObj['endTime'] : '00:00');                
                endDtTime = new Date(endTime).getTime();
              }
              if(startDtTime && endDtTime){
                //compare start and date time with departure date if both time present
                return deptDt >= startDtTime && deptDt <= endDtTime;
              } else if(startDtTime && !endDtTime){
                return deptDt >= startDtTime;
              } else if(!startDtTime && endDtTime){
                return deptDt <= endDtTime;
              }
            }
             return true;
          });
          flights = flights.sort(function (a, b) { // Sort hierarchy:  By Departure Date, Departure time, and Flight Number
            let aDate =  new Date(getDateTimePart(getters.getJPathValue("flifo.estimatedDepartureTimeLocal",a), "yyyy-mm-dd"));
            let bDate = new Date(getDateTimePart(getters.getJPathValue("flifo.estimatedDepartureTimeLocal",b), "yyyy-mm-dd"));
          
            let aTime =  new Date(getters.getJPathValue("flifo.estimatedDepartureTimeLocal",a)).getTime();
            let bTime = new Date(getters.getJPathValue("flifo.estimatedDepartureTimeLocal",b)).getTime();
          
            let aFlight = getters.getJPathValue("flightNumber",a);
            let bFlight = getters.getJPathValue("flightNumber",b);
           
            // Compare first value then second
            return aDate- bDate || aTime - bTime || aFlight - bFlight;
          });
          if(!flights || flights.length==0){
            commit('setAlertMessages',{ alertType: "warning",alertMessages: [this.state.ovsiDefaultModule.applicationInfoDetails.errorMessageList.RECORD_NOT_FOUND.text]})
          }
          if(copyObj.inputObject.page){
            flights = [...state.searchOVSIData, ...flights]
          } 
          commit('setSearchOVSIData',flights);
        }
      })
      .catch(err=>{
        console.error(err);
        this.state.alertMessage.alertType = "error";
        this.state.alertMessage.alertMessages = ["Unable To Find Record. Retry"];
       })
      .finally(()=> commit("setIsLoading", false));
    },
    async getFlightReport({commit },obj){
      commit("setIsLoading", true);
      return await  getFlightReport(obj)
        .then(response=>{
          if(response.status == 200 ){
            commit('setApiResponse',response.data);
            commit('setSearchOVSIData',response.data);
          }
        })
        .catch(err=> {
          console.error(err);
          this.state.alertMessage.alertType = "error";
          this.state.alertMessage.alertMessages = ["Unable To Find Record. Retry"];
        })
        .finally(()=> commit("setIsLoading", false));
      },
     async getFlightHistory({commit, state, getters },obj){
      commit("setIsLoading", true);
      return await  getFlightHistory(obj)
        .then(response=>{
          if(response.status == 200 ){
            let i=1;
            response.data.flightHistory.forEach(fh=>{
              fh.__row=i;
              i++;
            })
            commit('setSearchOVSIData',response.data.flightHistory);
          }
        })
        .catch(err=> {
          console.error(err);
          this.state.alertMessage.alertType = "error";
          this.state.alertMessage.alertMessages = ["Unable To Find Record. Retry"];
        })
        .finally(()=> commit("setIsLoading", false));
      },
      async getPassengers({commit },obj){
        commit("setIsLoading", true);
        return await  getPassengers(obj)
          .then(response=>{
            if(response.status == 200 ){
              let i=1;
              response.data.passengers?.forEach(fh=>{
                fh.__row=i;
                i++;
              })
              commit('setSearchOVSIData',response.data);
            }
          })
          .catch(err=> {
            console.error(err);
            this.state.alertMessage.alertType = "error";
            this.state.alertMessage.alertMessages = ["Unable To Find Record. Retry"];
          })
          .finally(()=> commit("setIsLoading", false));
      },
      async getConfiguration({commit },obj){
        commit("setIsLoading", true);
        return await  getConfiguration(obj)
          .then(response=>{
            if(response.status == 200 ){
              commit('setApiResponse',response.data);
            }
          })
          .catch(err=> {
            console.error(err);
            this.state.alertMessage.alertType = "error";
            this.state.alertMessage.alertMessages = ["Unable To Find Record. Retry"];
          })
          .finally(()=> commit("setIsLoading", false));
        },
      updatePrevOptions({commit },obj){
          commit("setPrevOptions", obj);
      },
      async getDowngradeList({commit },obj){
        commit("setIsLoading", true);
        return await  getDowngradeList(obj)
          .then(response=>{
            if(response.status == 200 ){
              commit('setSearchOVSIData',response.data);
            }
          })
          .catch(err=> {
            console.error(err);
            this.state.alertMessage.alertType = "error";
            this.state.alertMessage.alertMessages = ["Unable To Find Record. Retry"];
          })
          .finally(()=> commit("setIsLoading", false));
      },
      async getoverviewbycity({commit,dispatch},obj){
        commit('setSearchOVSIData',[]);
        let key= obj.actionId+createHash(obj.inputObject,obj.cachePaths).toString();
        let data = await dispatch('getFromCache',key);
        if(data){
          commit('setApiResponse',data);
          commit('setSearchOVSIData',data);
          commit("setIsLoading", false);
          return;
        }
        commit("setIsLoading", true);
        return await  getoverviewbycity(obj)
          .then(response=>{
            if(response.status == 200 ){
              dispatch('addIntoCache',{key,data:response.data})
              commit('setApiResponse',response.data);
              commit('setSearchOVSIData',response.data);
            }
          })
          .catch(err=>{
            console.error(err);
            this.state.alertMessage.alertType = "error";
            this.state.alertMessage.alertMessages = ["Unable To Find Record. Retry"];
          })
          .finally(()=> commit("setIsLoading", false));
      },
       // set select record data from API for direct land
       async getFlight({commit},obj){
        commit("setIsLoading", true);
        return await getFlight(obj).then(res=>{
          if(res.status == 200 && res.data.flight ){
            commit('setSelectedRecord',res.data.flight);
          }
          else{
            commit('setAlertMessages',{ alertType: "warning",alertMessages: [res.data.messages[0].message]})
          }
          }).catch(er=>{
            console.error(er);
            commit('setAlertMessages',{ alertType: "warning",alertMessages: ['Unable To Find Record. Retry']})
          })
          .finally(()=> commit("setIsLoading", false));
      }
    },
};
