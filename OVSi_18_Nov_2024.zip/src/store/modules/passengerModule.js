import {  getPassengers,addVolunteer,removeVolunteer} from '../../services/passengerService';
export default {
  state: {
   
  },
  mutations: {},
  getters: {},
  actions: {
   async removeVolunteer({commit},obj){
       return removeVolunteer(obj)
   }
  }
};
