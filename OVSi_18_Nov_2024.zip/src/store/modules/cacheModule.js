let cache={}
export default {
  state: {
    //cache: {},
    cachePaths:[]
  },
  getters: {
    getFromCache: (state) => (key) => cache[key],
    getCachePaths: (state) => state.cachePaths||[],
  },
  mutations: {
    getEntityDisplayDetails(state, entityDisplayDetails){
      state.cachePaths=entityDisplayDetails.cachePaths;
    },
    resetEntityDetails(state){
      state.cachePaths={}
    },
    clearCache(state) {
      cache = {};
    },
    clearCacheForKey(state, key) {
      cache[key] = {};
    },
    addIntoCache(state, { key, data }) {
      cache[key] = data;
    },
  },
  actions: {
    addIntoCache({ commit }, { key, data }) {
      commit("addIntoCache", { key, data });
    },
    getFromCache({ commit },key) {
      let data = cache[key];
      if (data) {
        return data;
      } else {
        return false;
      }
    },
  },
};
