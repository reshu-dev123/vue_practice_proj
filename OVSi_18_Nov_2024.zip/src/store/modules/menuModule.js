import { getImageUrl } from '../../helpers/utilities'
import { getEntityDisplayDetails } from '../../services/rtfDefault.api';

export default {
  state: {
    toggleMenu: false,
    showMenuItems: false,
    menuDetails: [],
    selectedMenuId: '',
    showOrHideMainMenus: false,
    selectedMainMenuId:'',
    isRouteNavigationMenu: false,
  },
  mutations: {
    setIsRouteNavigationMenu(state, flag) {
      state.isRouteNavigationMenu = flag;
    },
    setselectedMainMenuId(state, id) {
      state.selectedMainMenuId = id;
    },
    setshowOrHideMainMenus(state) {
      state.showOrHideMainMenus = !state.showOrHideMainMenus;
    },
    setSelectedMenuId(state, id) {
      state.selectedMenuId = id;
    },
    toggleMenu(state) {
      state.toggleMenu = !state.toggleMenu;
      state.showMenuItems = state.toggleMenu;
    },
    toggleMenuItems(state) {
      state.showMenuItems = !state.showMenuItems;
      state.toggleMenu = state.showMenuItems;
    },
    getMenuDetails(state, menuDetails) {
      state.menuDetails = menuDetails;
    },
    resetEntityDetails(state){
      state.isRouteNavigationMenu=false;
      state.selectedMenuId = '';
      state.selectedMainMenuId = '';
    }
  },
  getters: {
    getCurrentActiveMenuId: (state,getters, rootState)=>(menuInfo, menuInd) =>{
      if(menuInfo.id == state.selectedMenuId){
        return true;
      } else if(menuInd == 0 && !state.selectedMenuId) {
        return true;
      } 
      return false;
    },
    getMainMenuItems: (state,getters, rootState) => {
      if (Object.keys(state.menuDetails).length > 0) {
          return state.menuDetails.filter(menu => menu.parent.toLowerCase() == 'rootnode' && !menu.isNavigationMenu);              
      }
    },
    getMenuItems: (state,getters, rootState) => {
      if (Object.keys(state.menuDetails).length > 0) {        
        let prevItems = rootState.ovsiDefaultModule.prevNavigateViews;
        let lastItem = prevItems.length > 0 ? rootState.ovsiDefaultModule.prevNavigateViews[prevItems.length-1] : '';
        let mainMenuInfo = state.menuDetails.filter(menu => menu.id== state.selectedMainMenuId.toLowerCase());
        mainMenuInfo = mainMenuInfo.length > 0 ? mainMenuInfo[0] : '';
       //checking if navigation link clicked and need to show nav item accordingly
        if((rootState.ovsiDefaultModule.isNavigatedEvent && lastItem.showNavMenus) || state.isRouteNavigationMenu ){
          return state.menuDetails.filter(menu => menu.isNavigationMenu );//TO Flightmanagement navigated sub menus report,history,volunteer
        } else if(mainMenuInfo.showSubNavItems && state.selectedMainMenuId){ //for configuration menus 
          return state.menuDetails.filter(menu => menu.parent.toLowerCase() == state.selectedMainMenuId.toLowerCase());
        } else { //main menu
          return state.menuDetails.filter(menu => menu.parent.toLowerCase() == 'rootnode' && !menu.isNavigationMenu); //get 
        }        
      }
    },
    getSubMenuItems: (state) => (parentId) => {
      if (Object.keys(state.menuDetails).length > 0) {
        return state.menuDetails.filter(menu => menu.parent.toLowerCase() == parentId.toLowerCase());
      }
    },
    getParent: (state) => (parentId) => {
      if (Object.keys(state.menuDetails).length > 0) {
        return state.menuDetails.filter(menu => menu.id.toLowerCase() == parentId.toLowerCase());
      }
    },
    getImageUrl: (state) => (imgPath) => {
      return getImageUrl(imgPath);
    },

  },
  actions: {
    toggleMenu({ commit }) {
      commit("toggleMenu");
    },
    toggleMenuItems({ commit }) {
      commit("toggleMenuItems");
    },
    getMenuDetails({ commit,dispatch }) {
      getEntityDisplayDetails('MenuConfig')
        .then(async(response) => {
          if (response.status === 200) {
            let payload = await dispatch('getPayLoad',response)
            commit("getMenuDetails", payload);
          } else {
            this.state.alertMessage.alertType = "warning";
            this.state.alertMessage.alertMessages = ["No Menu Data Found."];
          }
        })
        .catch((error) => {
          console.error(error)
          this.state.alertMessage.alertType = "error";
          this.state.alertMessage.alertMessages = ["Error: Unable to process request. Contact Administrator."];
        });
    },
   async backTopreviousAction({ commit,dispatch,getters,state }){
      commit('clearAlertMessages');
      commit('deletePrevNavigateViews');
      if(this.state.ovsiDefaultModule.prevNavigateViews.length == 1 && this.state.ovsiDefaultModule.prevNavigateViews[0].id == this.state.ovsiDefaultModule.mainViewId){
        commit('setIsNavigatedEvent',false);
      }
     await dispatch('getEntityDisplayDetailsAction',this.state.ovsiDefaultModule.prevNavigateViews[this.state.ovsiDefaultModule.prevNavigateViews.length - 1].id);
     commit('setSelectedMenuId',this.state.ovsiDefaultModule.prevNavigateViews[this.state.ovsiDefaultModule.prevNavigateViews.length - 1].id);
     if(this.state.ovsiDefaultModule.prevNavigateViews.length == 1 && this.state.ovsiDefaultModule.prevNavigateViews[0].id == this.state.ovsiDefaultModule.mainViewId){
      commit('setIsNavigateToInnerOtherView',false);
    }
    }
  },
};
