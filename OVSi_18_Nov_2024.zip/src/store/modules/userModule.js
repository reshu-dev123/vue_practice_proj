import { CO_CK_NM } from '../../services/auth';
import { getEntityDisplayDetails} from '../../services/rtfDefault.api';
import { checkIfOAMDown5xx, getRedirectURL,setCookie,updateData, userLogoutAppSync } from '../../services/user.api';
import { decodeData, getParameterByName ,sortByPrority} from "@/helpers/utilities";
export default {
  state: {
    isLoggedIn: false,
    isLoginFailed: false,
    roleInfoList: [],
    currentRoleInfo: {},
    tokenResponse: {},
    tokenTimer: "",
    keyPhrase: {},
    refreshCount: 0,
    channel: "InsightUI",
  },
  mutations: {
    setTokenResponse(state, data) {
      state.tokenResponse = data;
    },
    setIsLoggenIn(state, flag) {
      state.isLoggedIn = flag;
    },
    setChannel(state, chnl) {
      state.channel = chnl;
    },
    setRedirectURL(state, data) {
      state.keyPhrase = data;
    },
    logout(state) {
      state.isLoggedIn = false;
      state.tokenResponse = {};
    },
    setTimer(state, timer) {
      state.tokenTimer = timer;
    },
    setUserConfig(state, config) {
      state.userConfig = config;
    },
    loginFailed(state) {
      state.isLoginFailed = true;
    },
    updateLocalStation(state, stn) {
      state.tokenResponse.userinfo.Location = stn;
    },
    setRoleInfo(state, { payload, currentRole, currentAD }) {
      state.roleInfoList = payload;
      state.tokenResponse.ad = currentAD;
      state.tokenResponse.role = currentRole;
      state.currentRoleInfo = payload.filter(
        (roleI) => roleI.ad.toLowerCase() == currentAD.toLowerCase()
      )[0];
      if (!currentRole || !currentAD) {
        state.currentRoleInfo = payload.filter(
          (roleI) => roleI.ad.toLowerCase() == "not_found"
        )[0];
      }
    },
    updateUserInfo(state,userInfo){ // update the expiry
      if(userInfo && state.tokenResponse && state.tokenResponse.userinfo){
        let u_info = JSON.parse(userInfo);
        state.tokenResponse.userinfo.Groups= u_info.Groups;
        setCookie(CO_CK_NM, u_info.crr, u_info.rem_exp-60);
      }
    }
  },
  getters: {
    getUserName(state) {
      let userName = "NA";
      if (state.isLoggedIn) {
        userName = state.tokenResponse.userinfo.DisplayName;
      }
      return userName;
    },
    getLocalStation: (state) => state.tokenResponse.userinfo.Location,
    getAllHubs: (state, getters, rootState) =>
      rootState.ovsiDefaultModule.applicationInfoDetails.hubs.sort((a,b)=>a.localeCompare(b)),
    getViewActions: (state, getters, rootState) =>
      rootState.ovsiDefaultModule.applicationInfoDetails.rolesConfig.view || [],
    getEditActions: (state, getters, rootState) => {
      return (
        rootState.ovsiDefaultModule.applicationInfoDetails.rolesConfig.edit ||
        []
      );
    },
    getUserRole: (state) => state.currentRoleInfo.accessInfo?.role?.role || "",
    getCurrentAd: (state) => state.currentRoleInfo.accessInfo?.role?.ad || "",
    getEmployeeId(state) {
      let UserID = "NA";
      if (state.isLoggedIn) {
        UserID = state.tokenResponse.userinfo.UserID;
      }
      return UserID.toUpperCase();
    },
    getRoleByModule: (state) => (moduleName) => {
      try {
        return state.currentRoleInfo?.accessInfo[moduleName] || "";
      } catch (er) {
        console.error(er);
      }
    },
    getRedirectURL(state) {
      return getParameterByName("redirect_uri", state.keyPhrase.oam_url);
    },
    getUserStation(state) {
      return state.tokenResponse.userinfo.Location || "";
    },
    isSuperUser: (state) => state.currentRoleInfo.priority == 1,
    isFlightMgmtEnabled:(state)=>state.currentRoleInfo?.accessInfo?.flight_Management?.enabled,
  },
  actions: {
    userLogout({ commit, dispatch, getters, state }) {
      //let logoutURL = `${state.keyPhrase.logout_url}?id_token_hint=${state.tokenResponse.id_token}&redirect_uri=${getters.getRedirectURL}`;
      let crr = state.tokenResponse.uid || state.tokenResponse.userinfo.crr;
      userLogoutAppSync(crr)
        .then((response) => {
          if (
            response.status == 200 &&
            response.data.data.redirect_logout.payload
          ) {
            let data = JSON.parse(response.data.data.redirect_logout.payload);
            if (data.status == "User invalidated") {
              commit("logout");
              setCookie(CO_CK_NM, crr, -20);
              window.location.replace(state.keyPhrase.global_logout_page);
            }
          }
        })
        .catch((error) => {
          console.error(error);
        })
    },
    async getRedirectUrl({ commit }) {
      let urlInfo = getRedirectURL();
      commit("setRedirectURL", urlInfo);
    },
    async fetchAuthsAndSetCurrentRole(
      { commit, dispatch, state, rootState },
      userinfo
    ) {
      let groups = userinfo?.user_info?.Groups || [];
      let currentRole = "",
        currentAD = "";
      userinfo.user_info.UserID = userinfo.user_info.UserID;
      userinfo.user_info.DisplayName = 
        userinfo.user_info.DisplayName
      ;
      commit("setTokenResponse", {
        userinfo: userinfo.user_info,
        uid: userinfo.crr,
      });
      dispatch("fetchStationData");
      getEntityDisplayDetails("userAuth")
        .then(async(response) => {
          if (response.status === 200) {
            let payload= await dispatch('getPayLoad',response)
            let tmpPayload = payload
              .sort(sortByPrority)
              .filter((roleConfig) => {
                return groups
                  .toString()
                  .toLowerCase()
                  .includes(roleConfig.ad.toLowerCase());
              });
            let roleConfig = tmpPayload[0];
            currentRole = roleConfig.accessInfo.role.role;
            currentAD = roleConfig.accessInfo.role.ad;
            commit("setRoleInfo", {
              payload: payload.sort(sortByPrority),
              currentRole,
              currentAD,
            });
            dispatch("setMenuForCurrentRole");
            commit("setIsLoggenIn", true);
          } else {
            this.state.alertMessage.alertType = "warning";
            this.state.alertMessage.alertMessages = [
              "!Warning: No Records Exists. - " + "userAuth",
            ];
          }
        })
        .catch((error) => {
          debugger
          console.error(error);
          dispatch("unAuthorizedHandler", error);
          this.state.alertMessage.alertType = "warning";
          this.state.alertMessage.alertMessages = [
            "!Warning: No Records Exists. - " + "userAuth",
          ];
        });
    },
    async unAuthorizedHandler({state,commit }, er) {
      console.error('er',er)
      if (er && er?.response && (er.response?.status == 401)) {
          setCookie(CO_CK_NM, state.tokenResponse.userinfo.crr, -1);
          window.location.reload();
      }
      let isDown = checkIfOAMDown5xx(er);
        if (isDown) {
          commit("setAlertMessages", {
            alertType: "warning",
            alertMessages: ["OAM Service is Down!"],
          });
          setTimeout(()=>{
           setCookie(CO_CK_NM, '', -2);
           window.location.reload();
          },1000*4)
        } else {
          setCookie(CO_CK_NM, '', -2);
           window.location.reload();
        }
    },
    authorizeModule(
      { commit, dispatch, getters, state },
      { moduleId, operationId, isModalErr, origin }
    ) {
      //let errMsg = `Insufficient permissions module [${moduleId}] for opeartion [${operationId}]`;
      let errorObj = this.state.ovsiDefaultModule.applicationInfoDetails.errorMessageList['PERMISSION_DENIED']
      let errMsg = errorObj.text;
      if (!moduleId) {
        moduleId = getters.getOVSIEntityId;
      }
      let fltRoleInfo = getters.getRoleByModule("flight_Management");
      switch (moduleId) {
        case "overSaleOverView":
          return dispatch("oversaleRoleHandler", {
            errMsg,
            operationId,
            isModalErr,
            origin,
          });
        case "flight_Management":
          if (!fltRoleInfo.enabled) {
            commit("setAlertMessages", {
              alertType: "warning",
              alertMessages: [errMsg],
            });
            return false;
          }
          if (getters.getViewActions.includes(operationId)) return true; // for short time view enalbled for flt_mgmt
          return dispatch("reportRoleHandler", {
            errMsg,
            operationId,
            isModalErr,
            fltRoleInfo,
            origin,
          });
        case "report":
        case "history":
        case "volunteerLists":
        case "downgradeIDBHlists":
          if (!fltRoleInfo.enabled) {
            commit("setAlertMessages", {
              alertType: "warning",
              alertMessages: [errMsg],
            });
            return false;
          }
          return dispatch("reportRoleHandler", {
            errMsg,
            operationId,
            isModalErr,
            fltRoleInfo,
            origin,
          });
      }
      return false;
    },
    oversaleRoleHandler(context, data) {
      // oversale overview screen has only view screens
      const { commit, dispatch, getters, state, rootState } = context;
      const { errMsg, operationId, isModalErr, origin } = data;
      let filterObj = rootState.ovsiDefaultModule.selectedInputValues;
      let stations = filterObj.inputObject.stations;
      let stationLen = stations ? stations.length : 0;
      let ovsRole = getters.getRoleByModule("overSaleOverView");
      if (!ovsRole.enabled) {
        dispatch("handleErroMessageForAuth", {
          alertType: "warning",
          alertMessages: [errMsg],
          modalErr: isModalErr,
        });
        return false;
      }
      if (ovsRole.allStation) {
        return true;
      }
      if (stationLen == 1) {
        // if 1 station present check If belongs to local or hubs
        if (ovsRole.stations.includes("Local Stations")) {
          let isOriginLocal =
            stations[0].toLowerCase() == getters.getLocalStation.toLowerCase();
          if (isOriginLocal) return true;
        }
        if (ovsRole.stations.includes("Hubs")) {
          let isOriginHubs = getters.getAllHubs.includes(
            stations[0].toLowerCase()
          );
          if (isOriginHubs) return true;
        }
      }
      if (stationLen == getters.getAllHubs.length) {
        // IF only hubs
        if (ovsRole.stations.includes("Hubs")) {
          let origins = stations.map((st) => st.toLowerCase());
          origins.sort();
          let hubs = getters.getAllHubs.map((st) => st.toLowerCase());
          hubs.sort();
          if (origins.toString() == hubs.toString()) return true;
        }
      }
      if (stationLen == getters.getAllHubs.length + 1) {
        // IF  hubs and local
        if (ovsRole.stations.includes("Hubs")) {
          let hubsFromOrigin = stations
            .map((st) => st.toLowerCase())
            .filter((st) => st != getters.getLocalStation.toLowerCase());
          hubsFromOrigin.sort();
          let hubs = getters.getAllHubs.map((st) => st.toLowerCase());
          hubs.sort();
          if (
            hubsFromOrigin.toString() == hubs.toString() &&
            ovsRole.stations.includes("Local Stations")
          )
            return true;
        }
      }
      dispatch("handleErroMessageForAuth", {
        alertType: "warning",
        alertMessages: [errMsg],
        modalErr: isModalErr,
      });
      return false;
    },
    permissionHandler(
      { dispatch, getters },
      { errMsg, operationId, isModalErr, fltRoleInfo, configPath }
    ) {
      if (
        fltRoleInfo[configPath] == "View" &&
        getters.getViewActions.includes(operationId)
      )
        return true;
      if (fltRoleInfo[configPath] == "Edit") return true;
      dispatch("handleErroMessageForAuth", {
        alertType: "warning",
        alertMessages: [errMsg],
        modalErr: isModalErr,
      });
      return false; // for No access
    },
    reportRoleHandler(
      { dispatch, getters },
      { errMsg, operationId, isModalErr, fltRoleInfo, origin }
    ) {
      // check if its an local station
      let isOriginLocal =
        origin && origin.toLowerCase() == getters.getLocalStation.toLowerCase();
      if (isOriginLocal)
        return dispatch("permissionHandler", {
          errMsg,
          operationId,
          isModalErr,
          fltRoleInfo,
          configPath: "local",
        });
      let isOriginHubs =
        origin && getters.getAllHubs.includes(origin.toLowerCase());
      if (isOriginHubs)
        return dispatch("permissionHandler", {
          errMsg,
          operationId,
          isModalErr,
          fltRoleInfo,
          configPath: "hubs",
        });
      return dispatch("permissionHandler", {
        errMsg,
        operationId,
        isModalErr,
        fltRoleInfo,
        configPath: "all_stations",
      });
    },
    setMenuForCurrentRole({commit, dispatch, getters, state,rootState}){ // will hide/show admin panel based on current role
      let isAdminConfigEnbld  = state.currentRoleInfo.accessInfo.adminstration.enabled;
      let isSuperU = state.currentRoleInfo.priority==1;
      if(!isSuperU && !isAdminConfigEnbld){
        let menues = JSON.parse(JSON.stringify(rootState.menuModule.menuDetails));
        commit('getMenuDetails',menues.filter(m=>m.id!='admin')); // hide admin panel itself from the menu
      }
    },
    updateData({ commit, dispatch, getters, state }, obj) {
      let ad = obj.role.ad;
      let roles = state.roleInfoList;
      roles.forEach((role) => {
        if (role.ad.toLowerCase() == ad.toLowerCase()) {
          role.accessInfo = obj;
        }
      });
      //return;
      return updateData(roles,state.tokenResponse.uid)
        .then((res) => {
          if (res.status == 200 && res.data.data?.updateMetadata?.payload) {
            commit("setAlertMessages", {
              alertType: "success",
              alertMessages: ["Roles Config Updated successfully"],
            });
            commit('updateUserInfo',res.data.data.updateMetadata.user_info);
            if (ad.toLowerCase() == getters.getCurrentAd.toLowerCase())
              commit("setRoleInfo", {
                payload: roles,
                currentRole: obj.role.role,
                currentAD: ad,
              });
          } else {
            commit("setAlertMessages", {
              alertType: "warning",
              alertMessages: ["Roles Config Update Failed"],
            });
            dispatch("fetchAuthsAndSetCurrentRole");
          }
        })
        .catch((er) => {
          console.error(er);
          commit("setAlertMessages", {
            alertType: "error",
            alertMessages: ["Roles Config Update Failed"],
          });
          dispatch("unAuthorizedHandler", er);
        });
    },
    async mapLocalStation({ commit, dispatch, getters, state }, mapper) {
      let localStn = getters.getLocalStation;
      Object.keys(mapper).forEach((stn) => {
        let value = mapper[stn];
        if (value.toString().toLowerCase().includes(localStn.toLowerCase())) {
          localStn = stn;
        }
      });
      commit("updateLocalStation", localStn);
    },
    getPayLoad({commit, dispatch, getters, state},apiRes){
      // let payload= JSON.parse(apiRes.data.data.getMetadata.payload);// api json
      // commit('updateUserInfo',apiRes.data.data.getMetadata.user_info);
      // return payload.Payload
      return apiRes.data; // local json
    },
    async fetchStationData({ commit, dispatch, getters, state }) {
      let id = "stations";
      return await getEntityDisplayDetails(id)
        .then(async(response) => {
          if (response.status === 200) {
            let payload=  await dispatch('getPayLoad',response)
            let stations = [],
              stationNames = [],
              hubsData = [],
              hubFullNames = [];
            dispatch("mapLocalStation", payload.mapper);
            let hubs = getters.getAllHubs;
            payload.stations.forEach((obj, i) => {
              stations.push(obj.code);
              stationNames.push(obj.name);
              if (hubs.includes(obj.code.toLowerCase())) {
                hubsData.push(obj);
              }
            });
            hubs.forEach((hub) => {
              hubsData.forEach((obj) => {
                if (obj.code.toLowerCase() == hub.toLowerCase()) {
                  hubFullNames.push(obj.name);
                }
              });
            });
            commit("setStationData", { stations, stationNames, hubFullNames });
          } else {
            this.state.alertMessage.alertType = "warning";
            this.state.alertMessage.alertMessages = [
              "!Warning: No Records Exists. - " + id,
            ];
          }
        })
        .catch((error) => {
          console.error(error);
          this.state.alertMessage.alertType = "warning";
          this.state.alertMessage.alertMessages = [
            "!Warning: No Records Exists. - " + id,
          ];
          dispatch("unAuthorizedHandler", error);
        });
    },
  },
};
