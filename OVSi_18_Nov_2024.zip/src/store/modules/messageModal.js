export default {
  state: {
    modalType: "",
    title: "",
    modalMessages: '',
    showModalMessage:false
  },
  mutations: {
    clearModalMessages(state) {
      state.modalType = "";
      state.title = "";
      state.modalMessages = [];
      state.showModalMessage=false;
    },
    setshowModalMessage(state, flag){
      state.showModalMessage = flag
    },
    //Azh - set the alert messages from component/view
    setmodalMessages(state, alertObj) {
      state.showModalMessage = alertObj.showModalMessage;
      state.modalType = alertObj.modalType;
      state.title = alertObj.title;
      state.modalMessages = alertObj.modalMessages;
    },
  },
  actions: {
    clearModalMessages({ commit }) {
      // commit the data to mutation are synchronous
      commit("clearModalMessages");
    },
    setmodalMessages({ commit }) {
      // commit the data to mutation are synchronous
      commit("clearModalMessages");
    },
  },
};
