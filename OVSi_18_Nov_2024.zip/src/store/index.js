import { createStore } from "vuex";
import alertMessage from "./modules/alertMessage.js"
import menuModule from "./modules/menuModule.js"
import ovsiDefaultModule from "./modules/ovsiDefaultModule.js"
import exportModule from "./modules/exportModule.js"
import cacheModule from "./modules/cacheModule.js"
import userModule from "./modules/userModule.js";
import messageModal from "./modules/messageModal.js";
import passengerModule from "./modules/passengerModule.js";


export default createStore({
  state: {
    processStep: "UAOVSIDefaultLayout",
    prevProcessStep: "",
    action: "",
  },
  mutations: {
    setProcessStep(state, step) { 
      state.prevProcessStep = state.processStep;
      state.processStep = step;
    }
  },
  actions: {
    setProcessStep({ commit }, step) {
          if (step != "" && step != "/") {
            commit("setProcessStep", step);
          }
    }
  },
  modules: {
    alertMessage,
    menuModule,
    ovsiDefaultModule,    
    userModule,
    messageModal,
    passengerModule,
    exportModule,
    cacheModule
  },
});
