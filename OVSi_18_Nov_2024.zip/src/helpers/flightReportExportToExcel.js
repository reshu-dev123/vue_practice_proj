
  import { mapDateToOtherFormat, getJPathvalue, mergeRowsCells,  createRowsData,
    createHeadersCells, generateAndDownloadExcel, appendHeadersCells, appendRowsData } from './utilities';
  import { getFlightReport,getFlightHistory} from '../services/flightService';
  import { getDowngradeList, getPassengers} from '../services/passengerService';
  const ExcelJS = require('exceljs');

  const getReportHeader = (fields, selectedRecord) => {
    return fields.combineFields.map(f=>{
      return f.path?(f.formatDate? mapDateToOtherFormat(f, selectedRecord):getJPathvalue(f.path,selectedRecord)):f.concatePath.map(p=>getJPathvalue(p,selectedRecord)).join(f.concatePrefix ||'')
    }).join(fields.combineBy|| ' ');
  }

  const getReportFileName = (fields, selectedRecord, getCombineFieldsFileName) => {
    let flightInfo = fields.reportFileNameFields.combineFields.map(f=>{
      return f.path ? (f.formatDate? mapDateToOtherFormat(f, selectedRecord):getJPathvalue(f.path,selectedRecord))
      : f.concatePath.map(p=>getJPathvalue(p,selectedRecord)).join(f.concatePrefix ||'')
    }).join(fields.reportFileNameFields.combineBy || '_');
    if (getCombineFieldsFileName)
      return flightInfo;
    else
      return fields.reportFileName + '_' + flightInfo;
  }
  export const exportPageDataToExcelFile = async(exportScreenOptions, searchOVSIData, exportToExcelConfig, selectedRecord, applicationInfoDetails) => {
    let workbook = new ExcelJS.Workbook();
    let paramObj = {
      inputObject: {
        FlightOrigin: selectedRecord['flightOrigin'],
        FlightNumber: selectedRecord['flightNumber'],
        FlightDate: selectedRecord['flightDate'],
      }
    }
    let fileName ='';
    for(let page of exportScreenOptions.exportOption) {
    //exportScreenOptions.exportOption.forEach(async(page) => {
      let excelConfigInfo = exportToExcelConfig.pageWiseexcleConfigInfo[page].exportToExcelConfig;  
      paramObj.action = excelConfigInfo.actionId;  
      if(page == 'report'){
        let reportData;
        if(exportScreenOptions.currPageId != 'report') {
          let res = await getFlightReport(paramObj);
          reportData = res.data;
        } else {
          reportData = searchOVSIData; 
        }  
        exportFlightReportExcel(workbook, reportData, excelConfigInfo, exportToExcelConfig.commonDisplayHeaderFields, selectedRecord, applicationInfoDetails)
        fileName = getReportFileName(excelConfigInfo, selectedRecord);
      }
      if(page == 'history'){
        let historyData;
        if(exportScreenOptions.currPageId != 'history') {
          let res = await getFlightHistory(paramObj);
          res.data.flightHistory.forEach((fh, i) => fh.__row=i+1);
          historyData = res.data.flightHistory;
        } else {
          historyData = searchOVSIData; 
        }
        exportHistoryExcel(workbook, historyData, excelConfigInfo, exportToExcelConfig.commonDisplayHeaderFields, selectedRecord, applicationInfoDetails)
        fileName = getReportFileName(excelConfigInfo, selectedRecord);
      }
      if(page == 'volunteerLists') {
        let passengerData;
        if(exportScreenOptions.currPageId !=  'volunteerLists') {
          let inpObj = JSON.parse(JSON.stringify(paramObj));
          inpObj.inputObject.PassengerType = 'V'
          let res = await getPassengers(inpObj);
         // res.data.passengers.forEach((psnr,i) => psnr.__row=i+1);
          passengerData = res.data;
        } else {
          passengerData = searchOVSIData; 
        }
        exportVolunteerListsExcel(workbook, passengerData, excelConfigInfo, exportToExcelConfig.commonDisplayHeaderFields, selectedRecord, applicationInfoDetails)
        fileName = getReportFileName(excelConfigInfo, selectedRecord);
      }
      if(page == 'downgradeIDBHlists') {
        let downgradeIDBHlistData;
        if(exportScreenOptions.currPageId !=  'downgradeIDBHlists') {
          let res = await getDowngradeList(paramObj);
          downgradeIDBHlistData = res.data;
        } else {
          downgradeIDBHlistData = searchOVSIData; 
        }
        exportDowngradeIDBHlistDataExcel(workbook, downgradeIDBHlistData, excelConfigInfo, exportToExcelConfig.commonDisplayHeaderFields, selectedRecord, applicationInfoDetails)
        fileName = getReportFileName(excelConfigInfo, selectedRecord);
      }
    //});
    }
    if(exportScreenOptions.exportOption.length > 1) fileName = getReportFileName(exportToExcelConfig.commonExcleFileNameFields, selectedRecord,true);
    generateAndDownloadExcel(workbook, fileName);
  }
  export const addDataInExcleSheet = (worksheet, exportToExcelConfig, exportTblData, applicationInfoDetails, headerRowData, selectedRecord) => {
    //generate the required header details for the sheet
      exportToExcelConfig.excelRowDetails.forEach((excelFieldsObj)=> {
        if(excelFieldsObj.headerColumnsInfo){
          createHeadersCells(excelFieldsObj.headerColumnsInfo, worksheet, applicationInfoDetails, 
            excelFieldsObj.dynamicHeaderDatRequired ? excelFieldsObj.headerDataInfo : headerRowData);
        }	
        //generate the required rows with actual data for the sheet
        if(excelFieldsObj.rowInfo){
        if(excelFieldsObj.tabId == "Processed"){
          exportTblData.forEach(tblData=>{
            tblData.processedPassengers.forEach((psgnr) =>{
              psgnr.flightDestination = tblData.flightDestination;
              if(psgnr.passenger.volunteerStatus == 'I'){
                psgnr.volunteerStatusText = "InVol"
              } else if(psgnr.passenger.volunteerStatus == 'V'){
                psgnr.volunteerStatusText = "Vol"
              }
              let lastMainRowInfo = createRowsData(excelFieldsObj.rowInfo, worksheet, applicationInfoDetails, [psgnr]);		
              if(excelFieldsObj.rowInfo.appendDataInSameRows && psgnr.compensation && psgnr.compensation.issuances){
                let appendRowInfo =  excelFieldsObj.rowInfo.appendDataInSameRows;
                let totalIssuancesCount = 0;//TO CALCULATE THR TOTAL ROWS ADDED IN EXCE AGIANST MAIN RECORD
                    let psnrWiseROwInfo =  JSON.parse(JSON.stringify(lastMainRowInfo));                   
                    totalIssuancesCount = totalIssuancesCount + psgnr.compensation.issuances.length;
                    psgnr.compensation.issuances.forEach((issData, issuInd) => {
                      let issuRowsInfo = psnrWiseROwInfo;//5
                      let appendRowInfoObj = JSON.parse(JSON.stringify(appendRowInfo));
                      if( issuInd == 0) { 
                        //IF FIRST ITERATION OF SUB data(if bid options data found) RECORD IN MAIN ROW ELSE CREATE NEW ROW
                        let issuanceData = [{...issData}];
                        appendRowsData(appendRowInfoObj, worksheet, applicationInfoDetails, issuanceData, {}, issuRowsInfo);
                        psnrWiseROwInfo.rowInd = psnrWiseROwInfo.rowInd + 1;
                      } else {
                        let issuanceData = [{...issData}];
                        let mergeRowCellsInfo = { totolSubRowDataLength : psgnr.compensation.issuances.length, 
                          currSubRowInd : issuInd, 
                          isLastSubRow : (psgnr.compensation.issuances.length - 1 == issuInd)
                        }
                        createRowsData(appendRowInfoObj, worksheet, applicationInfoDetails, issuanceData, {}, mergeRowCellsInfo);
                      }                   
                    });
                  if(totalIssuancesCount > 1 ){//if more bid option found then merge main row data in eachcell/column
                    let mergeRowCellsInfo = { 
                      totolSubRowDataLength : totalIssuancesCount, 
                      currRowInd : lastMainRowInfo.rowInd
                    }
                    mergeRowsCells(excelFieldsObj.rowInfo, worksheet, applicationInfoDetails, mergeRowCellsInfo)
                  }                  
              }
            })
          })
        } else if(excelFieldsObj.tabId == "Upgrade/Downgrade") {
          exportTblData.forEach(tblData=>{
            let updnGradeList = tblData.processedPassengers.filter(psngr => psngr.passenger.deniedBoardingCode == 'A' || psngr.passenger.deniedBoardingCode == 'B')
            updnGradeList.forEach((psgnr) => {
              psgnr.flightDestination = tblData.flightDestination;
              if(psgnr.passenger.deniedBoardingCode == 'B'){
                psgnr.psngerType = "Downgrade"
              } else if(psgnr.passenger.deniedBoardingCode == 'A'){
                psgnr.psngerType = "Upgrade"
              }
              let lastMainRowInfo = createRowsData(excelFieldsObj.rowInfo, worksheet, applicationInfoDetails, [psgnr]);		
                if(excelFieldsObj.rowInfo.appendDataInSameRows && psgnr.compensation && psgnr.compensation.issuances){
                  let appendRowInfo =  excelFieldsObj.rowInfo.appendDataInSameRows;
                  let totalIssuancesCount = 0;//TO CALCULATE THR TOTAL ROWS ADDED IN EXCE AGIANST MAIN RECORD
                      let psnrWiseROwInfo =  JSON.parse(JSON.stringify(lastMainRowInfo));                   
                      totalIssuancesCount = totalIssuancesCount + psgnr.compensation.issuances.length;
                      psgnr.compensation.issuances.forEach((issData, issuInd) => {
                        let issuRowsInfo = psnrWiseROwInfo;//5
                        let appendRowInfoObj = JSON.parse(JSON.stringify(appendRowInfo));
                        if(issuInd == 0) { 
                          //IF FIRST ITERATION OF SUB data(if bid options data found) RECORD IN MAIN ROW ELSE CREATE NEW ROW
                          let issuanceData = [{...issData}];
                          appendRowsData(appendRowInfoObj, worksheet, applicationInfoDetails, issuanceData, {}, issuRowsInfo);
                          psnrWiseROwInfo.rowInd = psnrWiseROwInfo.rowInd + 1;
                        } else {
                          let issuanceData = [{...issData}];
                          let mergeRowCellsInfo = { totolSubRowDataLength : psgnr.compensation.issuances.length, 
                            currSubRowInd : issuInd, 
                            isLastSubRow : (psgnr.compensation.issuances.length - 1 == issuInd)
                          }
                          createRowsData(appendRowInfoObj, worksheet, applicationInfoDetails, issuanceData, {}, mergeRowCellsInfo);
                        }                   
                      });
                    if(totalIssuancesCount > 1 ){//if more bid option found then merge main row data in eachcell/column
                      let mergeRowCellsInfo = { 
                        totolSubRowDataLength : totalIssuancesCount, 
                        currRowInd : lastMainRowInfo.rowInd
                      }
                      mergeRowsCells(excelFieldsObj.rowInfo, worksheet, applicationInfoDetails, mergeRowCellsInfo)
                    }                  
                }
            })
          })
        } else{
          createRowsData(excelFieldsObj.rowInfo, worksheet, applicationInfoDetails, 
            (excelFieldsObj.dynamicTableDatRequired ? excelFieldsObj.rowDataInfo : exportTblData),
             selectedRecord );
        }
        }
      });   
  }
  const getCabinWiseDataForExcel = (cabins,searchOVSIData) => {
    let cabinData = {}
    let cabinWiseData = [];
    for (let i = 0; i < cabins.length; i++) {
      let filteredCabinData = searchOVSIData.cabinTotals.filter((item) => {
        return item.cabinCode == cabins[i];
      })
      cabinData[cabins[i]] = filteredCabinData.length > 0 ? filteredCabinData[0] : {};
    }
    cabinWiseData.push(cabinData);
    return cabinWiseData;
  }
  //GENERATE REPORT SCREEN DATA 
  export const exportFlightReportExcel = (workbook, searchOVSIData, exportToExcelConfig, commonHeaderFields, selectedRecord, applicationInfoDetails) => {
    let worksheet = workbook.addWorksheet(exportToExcelConfig.sheetName);
    let headerData = [{"concateFlightData" : getReportHeader(commonHeaderFields ,selectedRecord)}];
    exportToExcelConfig.excelRowDetails.forEach((excelFieldsObj)=> {
        if(excelFieldsObj.headerColumnsInfo && excelFieldsObj.dynamicHeaderDatRequired){
          excelFieldsObj.headerDataInfo = headerData;
        }	
        searchOVSIData.downgradeTotalCount = searchOVSIData.processedPassengers.filter(psngr => psngr.passenger.deniedBoardingCode == 'B').length;
        searchOVSIData.upgradeTotalCount = searchOVSIData.processedPassengers.filter(psngr => psngr.passenger.deniedBoardingCode == 'A').length;
      
        //generate the required rows with actual data for the sheet
        if(excelFieldsObj.rowInfo && excelFieldsObj.dynamicTableDatRequired) {
          if(excelFieldsObj.isCabinWiseData){
            excelFieldsObj.rowDataInfo = getCabinWiseDataForExcel(excelFieldsObj.cabins, searchOVSIData)
          } else if(excelFieldsObj.tabId == "Must ride") {
            let mustRideList = searchOVSIData.mustRidePassengers;
            mustRideList.forEach((psgnr) => {
              psgnr.flightDestination = searchOVSIData.flightDestination;
            })
            excelFieldsObj.rowDataInfo = mustRideList;
          }
        }
    });
    addDataInExcleSheet(worksheet, exportToExcelConfig, [searchOVSIData], applicationInfoDetails, headerData, selectedRecord)
    return workbook;
  }
  export const exportHistoryExcel = (workbook, searchOVSIData, exportToExcelConfig,commonHeaderFields, selectedRecord, applicationInfoDetails) => {
    let worksheet = workbook.addWorksheet(exportToExcelConfig.sheetName);
    let headerData = [{"concateFlightData" : getReportHeader(commonHeaderFields ,selectedRecord)}];
    let lastHeaderRowInfo = {};
    exportToExcelConfig.excelRowDetails.forEach((excelFieldsObj)=> {
      if(excelFieldsObj.headerColumnsInfo){
        lastHeaderRowInfo = createHeadersCells(excelFieldsObj.headerColumnsInfo, worksheet, applicationInfoDetails, headerData);
      }	
      //generate the required rows with actual data for the sheet
      if(excelFieldsObj.rowInfo) {
        let rowSeq = 0;
        searchOVSIData.forEach((tabData) => {
          rowSeq++;
          tabData.row = rowSeq;
          let mainExcelFieldsObj = JSON.parse(JSON.stringify(excelFieldsObj));
          mainExcelFieldsObj.rowInfo.rowValues.forEach(rwFieldsInfo =>{
            rwFieldsInfo.forEach((rwInfo) => {
              if(!(tabData.compensation && tabData.compensation.passengerOffers) && rwInfo.showOnlyIfBidDetailsFound) { //modifying the field info to make it blank value to show data only if bid details found
                if( rwInfo.combinepath)  rwInfo.combinepath = [];                   
                rwInfo.getTextFrom = 'text';
              }                              
            });
          });
          let lastMainRowInfo = createRowsData(mainExcelFieldsObj.rowInfo, worksheet, applicationInfoDetails, [tabData],selectedRecord);		
          if(mainExcelFieldsObj.rowInfo.appendDataInSameRows && tabData.compensation && tabData.compensation.passengerOffers){
            let appendRowInfo =  mainExcelFieldsObj.rowInfo.appendDataInSameRows;
            let totalBidOptionsCount = 0;//TO CALCULATE THR TOTAL ROWS ADDED IN EXCE AGIANST MAIN RECORD
              tabData.compensation.passengerOffers.forEach((psgnr, psnrInd) => {
                let alternateFlightDetails =  psgnr?.alternateSchedule?.alternateFlights ||[];
                let psnrWiseROwInfo =  JSON.parse(JSON.stringify(lastMainRowInfo));
                if(psnrInd == 0) {///APPEND THE FIRST PASSENGER OFFERS BID OPTIONS HEADER
                  appendHeadersCells(appendRowInfo.headerColumnsInfo, worksheet, applicationInfoDetails, [psgnr], lastHeaderRowInfo); 
                }                   
                totalBidOptionsCount = totalBidOptionsCount + psgnr.bidOptions.length;
                psgnr.bidOptions.forEach((bidOpt, ind) => {
                  let bidRowsInfo = psnrWiseROwInfo;
                  bidOpt.isAccepted ? bidOpt.active = 'YES' : bidOpt.active = 'NO';
                  bidOpt.processed = 'YES';
                  let appendRowInfoObj = JSON.parse(JSON.stringify(appendRowInfo));
                  if(ind == 0 && psnrInd == 0) { 
                    //IF FIRST ITERATION OF RECORD IN MAIN ROW  ELSE CREATE NEW ROW
                    let bidData = [{alternateFlightDetails : alternateFlightDetails[0], ...bidOpt}];
                    appendRowsData(appendRowInfoObj, worksheet, applicationInfoDetails, bidData, {}, bidRowsInfo);
                    psnrWiseROwInfo.rowInd = psnrWiseROwInfo.rowInd + 1;
                  } else {
                    let bidData = [{alternateFlightDetails : alternateFlightDetails[0],...bidOpt}];
                    let mergeRowCellsInfo = { 
                      totolSubRowDataLength : psgnr.bidOptions.length, 
                      currSubRowInd : ind, 
                      isLastSubRow : (psgnr.bidOptions.length - 1 == ind)
                    }
                    createRowsData(appendRowInfoObj, worksheet, applicationInfoDetails, bidData, {}, mergeRowCellsInfo);
                  }                     
                });
              });
              if(totalBidOptionsCount > 1 ){//if more bid option found then merge main row data in eachcell/column
                let mergeRowCellsInfo = { 
                  totolSubRowDataLength : totalBidOptionsCount, 
                  currRowInd : lastMainRowInfo.rowInd
                }
                mergeRowsCells(excelFieldsObj.rowInfo, worksheet, applicationInfoDetails, mergeRowCellsInfo)
              }
            }
        });	
      }
    });
  }
  export const exportVolunteerListsExcel = (workbook, searchOVSIData, exportToExcelConfig, commonHeaderFields, selectedRecord, applicationInfoDetails) => {
    let worksheet = workbook.addWorksheet(exportToExcelConfig.sheetName);
    let headerData = [{"concateFlightData" : getReportHeader(commonHeaderFields,selectedRecord)}];
    let lastHeaderRowInfo = {};
    exportToExcelConfig.excelRowDetails.forEach((excelFieldsObj)=> {
      if(excelFieldsObj.headerColumnsInfo){
        lastHeaderRowInfo = createHeadersCells(excelFieldsObj.headerColumnsInfo, worksheet, applicationInfoDetails, headerData);
      }	
      //generate the required rows with actual data for the sheet
      if(excelFieldsObj.rowInfo && searchOVSIData.passengers) {
        let rowSeq = 0;
        searchOVSIData.passengers.forEach((tabData) => {
          rowSeq++;
          tabData.row = rowSeq;
          //get the cabin name show it in excel
          let cabinName = exportToExcelConfig.tabs.filter((tb, ind) => {
            return tabData.passenger.volunteerStatus == 'V' 
              && tabData.passenger.currentCabinCode === tb.compareCabinCode;
          })[0].label;
          tabData.cabinName = cabinName;
          let lastMainRowInfo = createRowsData(excelFieldsObj.rowInfo, worksheet, applicationInfoDetails, [tabData]);		
          if(excelFieldsObj.rowInfo.appendDataInSameRows && tabData.compensation && tabData.compensation.passengerOffers){
            let appendRowInfo =  excelFieldsObj.rowInfo.appendDataInSameRows;
            let totalBidOptionsCount = 0;//TO CALCULATE THR TOTAL ROWS ADDED IN EXCE AGIANST MAIN RECORD
                tabData.compensation.passengerOffers.forEach((psgnr, psnrInd) => {
                let alternateFlightDetails =  psgnr?.alternateSchedule?.alternateFlights ||[];
                let psnrWiseROwInfo =  JSON.parse(JSON.stringify(lastMainRowInfo));
                if(psnrInd == 0) {//APPEND THE FIRST PASSENGER OFFERS BID OPTIONS HEADER
                  appendHeadersCells(appendRowInfo.headerColumnsInfo, worksheet, applicationInfoDetails, [psgnr], lastHeaderRowInfo); 
                }                   
                totalBidOptionsCount = totalBidOptionsCount + psgnr.bidOptions.length;
                psgnr.bidOptions.forEach((bidOpt, ind) => {
                  let bidRowsInfo = psnrWiseROwInfo;//5
                  bidOpt.isAccepted ? bidOpt.active = 'YES' : bidOpt.active = 'NO';
                  bidOpt.processed = 'YES';
                  let appendRowInfoObj = JSON.parse(JSON.stringify(appendRowInfo));
                  if(ind == 0 && psnrInd == 0) { 
                    //IF FIRST ITERATION OF SUB data(if bid options data found) RECORD IN MAIN ROW ELSE CREATE NEW ROW
                    let bidData = [{alternateFlightDetails : alternateFlightDetails[0], ...bidOpt}];
                    appendRowsData(appendRowInfoObj, worksheet, applicationInfoDetails, bidData, {}, bidRowsInfo);
                    psnrWiseROwInfo.rowInd = psnrWiseROwInfo.rowInd + 1;
                  } else {
                    let bidData = [{alternateFlightDetails :  alternateFlightDetails[0],...bidOpt}];
                    let mergeRowCellsInfo = { totolSubRowDataLength : psgnr.bidOptions.length, 
                      currSubRowInd : ind, 
                      isLastSubRow : (psgnr.bidOptions.length - 1 == ind)
                    }
                    createRowsData(appendRowInfoObj, worksheet, applicationInfoDetails, bidData, {}, mergeRowCellsInfo);
                  }                   
                });
              });
              if(totalBidOptionsCount > 1 ){//if more bid option found then merge main row data in eachcell/column
                let mergeRowCellsInfo = { 
                  totolSubRowDataLength : totalBidOptionsCount, 
                  currRowInd : lastMainRowInfo.rowInd
                }
                mergeRowsCells(excelFieldsObj.rowInfo, worksheet, applicationInfoDetails, mergeRowCellsInfo)
              }                  
            }
        });	
      }
    });
    return workbook;
  }
  const getFilteredCabinData = (cbnIndex,cabins,searchOVSIData) => {
    if(Object.keys(searchOVSIData).length == 0) return searchOVSIData;
    let filterData = searchOVSIData.downgradeList || [];
    let selectedCabinInfo = cabins.filter((cbn, ind) => {
      return ind == cbnIndex;
    });
    let cabinInfo = selectedCabinInfo[0];
    filterData = filterData.filter(psnrInfo => {
      return psnrInfo.currentCabin == cabinInfo.compareCabinCode;
    });
    filterData.forEach((item, ind) => {
      item.row = ind + 1;
    });
    return filterData;
  }

  export const exportDowngradeIDBHlistDataExcel = (workbook, searchOVSIData, exportToExcelConfig,commonHeaderFields, selectedRecord, applicationInfoDetails) => {
    let worksheet = workbook.addWorksheet(exportToExcelConfig.sheetName);
    let headerData = [{"concateFlightData" : getReportHeader(commonHeaderFields ,selectedRecord)}];
    let commonHeaderInfo = exportToExcelConfig.excelRowDetails[0];
    if(commonHeaderInfo.headerColumnsInfo){
        createHeadersCells(commonHeaderInfo.headerColumnsInfo, worksheet, applicationInfoDetails, headerData);
    }
    exportToExcelConfig.cabins.forEach((cbnInfo,cbnIdx) =>{
      let headercabinData = {};
      headercabinData["cabinName"] = cbnInfo.name;
      headercabinData["cabinHeader"] = cbnInfo.label;
      let cabinHeaderData = [headercabinData];
      let excelTblFldsInfo = exportToExcelConfig.excelRowDetails.slice(1);
      excelTblFldsInfo.forEach((excelFieldsObj)=> {
        if(excelFieldsObj.headerColumnsInfo){
          createHeadersCells(excelFieldsObj.headerColumnsInfo, worksheet, applicationInfoDetails, cabinHeaderData);
        }	
        //generate the required rows with actual data for the sheet
        if(excelFieldsObj.rowInfo) {
          let rowSeq = 0;            
          let cabinData = getFilteredCabinData(cbnIdx,exportToExcelConfig.cabins,searchOVSIData);
          cabinData.forEach(cbInfo => {
            rowSeq++;
            cbInfo.row = rowSeq;
          }) 
          
          createRowsData(excelFieldsObj.rowInfo, worksheet, applicationInfoDetails,cabinData);		
        }
      });
    })
    return workbook;
  }