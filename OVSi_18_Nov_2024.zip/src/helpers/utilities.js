const ExcelJS = require('exceljs');
import FileSaver from 'file-saver';
//Azh - Strictly use this with DRY 
export const getJPathvalue = (jPath, jObject) => {
	//Azh - This method is a helper method to iterate JSON tree and retrieve value - Nested
	const jPathKeys = jPath.split(".");
	switch (jPathKeys.length) {
		case 1:
			return jObject?.[jPathKeys[0]];
		case 2:
			return jObject?.[jPathKeys[0]]?.[jPathKeys[1]];
		case 3:
			return jObject?.[jPathKeys[0]]?.[jPathKeys[1]]?.[jPathKeys[2]];
		case 4:
			return jObject?.[jPathKeys[0]]?.[jPathKeys[1]]?.[jPathKeys[2]]?.[jPathKeys[3]];
		case 5:
			return jObject?.[jPathKeys[0]]?.[jPathKeys[1]]?.[jPathKeys[2]]?.[jPathKeys[3]]?.[jPathKeys[4]];
		default:
			return ""
	}
}

//Azh/Bha - To set up add record / item with empty values for all keys - [Structure] WIP
export const setAddEditItem = (addEditItem) => {
	return addEditItem;
}
//Azh - All image src has to be validated - else code will break
export const getImageUrl = (imgPath) => {
	try {
		return require("../assets/img/" + imgPath);
	}
	catch {
		return require(`../assets/img/default.png`);
	}
}
export const getPatternMatching = (e, selectedDataType, inputRegPattern) => {
	if (selectedDataType != undefined) {
		const splitedDataType = selectedDataType.split("_");
		switch (splitedDataType[0]) {

			case "number":
				let numRegex = new RegExp(inputRegPattern.number);
				if (splitedDataType.length > 1) {
					var length = splitedDataType[1];					
					if((e.target.value.length) <= length) {					
						if(numRegex.test(e.target.value))  {
							return true;
						}
					} else {
						return length;
					}
				} else {
					if (numRegex.test(e.target.value)) {
						return true;
					}
					else {
						return false;
					}
				}

			case "negNumber":
				//  - and integers
				let negNumRegex = new RegExp(inputRegPattern.negNumber);
				if (negNumRegex.test(e.target.value)) {
					return true;
				}
				else {
					return false;
				}

			case "alphaNumeric":
				let alphaNumRegex = new RegExp(inputRegPattern.alphaNumeric);
				if (splitedDataType.length > 1) {
					let length = splitedDataType[1];
					if ((e.target.value.length) <= length) {
						if (alphaNumRegex.test(e.target.value)) {
							return true;
						}
						break;
					} else {
						return length;
					}
				} else {
					if (alphaNumRegex.test(e.target.value)) {
						return true;
					}
					else {
						return false;
					}
				}

			case "char":
				let charRegex = new RegExp(inputRegPattern.char);//at least one character should present and space is optional
				if (splitedDataType.length > 1) {
					let length = splitedDataType[1];
					if (charRegex.test(e.target.value))	 {
						if ((e.target.value.length) <= length) {
							return true;
						}
						else{
							return length;
						}
					} else {
						return false;
					}
				} else {
					if (charRegex.test(e.target.value)) {
						return true;
					}
					else {
						return false;
					}
				}
			case "charOrSpace":
				let charSpaceRegex = new RegExp(inputRegPattern.charOrSpace);//at least one character should present and space is optional
				if (splitedDataType.length > 1) {
					let length = splitedDataType[1];
					if ((e.target.value.length) <= length) {
						if (charSpaceRegex.test(e.target.value)) {
							return true;
						}
						break;
					} else {
						return length;
					}
				} else {
					if (charSpaceRegex.test(e.target.value)) {
						return true;
					}
					else {
						return false;
					}
				}
			case "TimeHHMM": 
				//  - HH:MM format
				let hhmmRegex = new RegExp(inputRegPattern.TimeHHMM);
				if (hhmmRegex.test(e.target.value)) {
					return true;
				}
				else {
					return false;
				}
			case "AMTCURRCODE": 
				//  - HH:MM format
				//let validCurrCodes = ['USD', 'EUR']
				//let amtCurrency = /^[0-9]{1,5}(\s)?([A-Za-z]{3})?$/;
				let amtCurrency = new RegExp(inputRegPattern.AMTCURRCODE);//eg: 50 usd,20.56 usd takes both num and deci val and USD (num range-5 digit,deci precision-2)
				if (amtCurrency.test(e.target.value)) {
					// if(isNaN(e.target.value)){
					// 	let currCode = e.target.value.toString().substring(e.target.value.length - 3); //GET LAST 3 LETTERS
					// 	const includesValue = validCurrCodes.some(element => {
					// 		return element.toLowerCase() === currCode.toLowerCase();
					// 	  });
					// 	return includesValue;
					// }
					return true;
				}
				else {
					return false;
				}
			case "DeciNum":
				let decNumRegex = new RegExp(inputRegPattern.DeciNum);
				if (splitedDataType.length > 1) {
					var length = splitedDataType[1];
					if ((e.target.value.length) <= length) {
						if (decNumRegex.test(e.target.value)) {
							return true;
						}
						break;
					} else {
						return length;
					}
				} else {
					if (decNumRegex.test(e.target.value)) {
						return true;
					}
					else {
						return false;
					}
				}
			case "all":
				if (splitedDataType.length > 1) {
					var length = splitedDataType[1];
					if ((e.target.value.length) <= length) {
						return true;
					}
					else {
						return length;
					}

				} else {
					return true;
				}
			default:
		}   return "";
	}
}
export const validateInputPattern = (e, selectedDataType, inpRegPattern) => {
	if (selectedDataType != undefined) {
		const splitedDataType = selectedDataType.split("_");
		switch (splitedDataType[0]) {
			case "number":
				let numRegex = new RegExp(inpRegPattern.number);
				if (numRegex.test(e.target.value + String.fromCharCode(e.charCode))) {
					return true;
				}
				return false;
			case "negNumber":
				//  - and integers
				let negNumRegex = new RegExp(inpRegPattern.negNumber);
				if (negNumRegex.test(e.target.value + String.fromCharCode(e.charCode))) {
					return true;
				}
				return false;
			case "alphaNumeric":
				let alphaNumRegex = new RegExp(inpRegPattern.alphaNumeric);
				if (alphaNumRegex.test(e.target.value + String.fromCharCode(e.charCode))) {
					return true;
				}
				return false;
			case "char": //only characters
				let charRegex = new RegExp(inpRegPattern.char);
				if (charRegex.test(e.target.value + String.fromCharCode(e.charCode))) {
					return true;
				}
				return false;
			case "charOrSpace":				
				let charspaceRegex = new RegExp(inpRegPattern.charOrSpace);
				if (charspaceRegex.test(e.target.value + String.fromCharCode(e.charCode))) {
					return true;
				}
				return false;				
			case "TimeHHMM": //  - HH:MM format  
				let hhmmRegex = new RegExp(inpRegPattern.TimeHHMM);
				if (hhmmRegex.test(e.target.value + String.fromCharCode(e.charCode))) {
					return true;
				}
				return false;
			case "date": 
				let dtRegex = new RegExp(inpRegPattern.date);
				if (dtRegex.test(e.target.value + String.fromCharCode(e.charCode))) {
					return true;
				}
				return false;
			case "AMTCURRCODE": 
				let amtCurrency = new RegExp(inpRegPattern.AMTCURRCODE);//eg: 50 usd,20.56 usd takes both num and deci val and USD (num range-5 digit,deci precision-2)
				if (amtCurrency.test(e.target.value + String.fromCharCode(e.charCode))) {
					return true;
				}
				return false;
			case "DeciNum":		
				let deciNumRegex = new RegExp(inpRegPattern.DeciNum);		
				if (deciNumRegex.test(e.target.value + String.fromCharCode(e.charCode))) {
					return true;
				}
				return false;
			case "all":
				return true;
				
			default:
		}  return true; //if no case found
	}
	return true;
}
export const decodeData = (dataToDecode) =>atob(dataToDecode);
export const encodeData = (dataToEncode) => btoa(dataToEncode);

export const getErrorResponse = (errorDetails, errorMsg = []) => {
	let errMsg; let timeOutErrorFound = false,maxLimit=false;
	if (errorDetails.message.toString().toLowerCase().includes('timed out')) {
		errMsg = ["Request timed out. Please validate the data and try again."];
		timeOutErrorFound = true;
	} else if (errorDetails.toString().toLowerCase().includes('NoLambdaResponse')) {
		errMsg = ["Data size has exceeded maximum allowed limit, Please Retry with less data!"];
		maxLimit = true;
	} 
	else {
		errMsg = errorMsg.length > 0 ? errorMsg : ["Unable To Find Record. Please Retry"];
	}
	return { alertType: 'warning', alertMessages: errMsg, timeOutErrorFound,maxLimit }
}
export const validatInputParams = (tableFields,showIssuanceNo) => {
	let errFound = [];
	tableFields?.forEach((inHeader) => {
		if (inHeader?.isError) {
			let msg = ''
			if(showIssuanceNo){
				msg = `${showIssuanceNo.headerText} ${showIssuanceNo.headerPrefix||''} ${inHeader?.label || inHeader?.name} : ${inHeader.dislayError} `;
			} else{
				msg = `${inHeader?.label || inHeader?.name} : ${inHeader.dislayError} `;
			}
			errFound.push(msg);
			return;
		}
		inHeader?.subFields?.forEach((subField) => {
			if (subField.isError) {
				let msg = `${subField?.label || subField?.name} : ${subField.dislayError} `;
				errFound.push(msg);
				return;
			}
		});
	});
	return errFound.length == 0 ? false : errFound;
}
export const validatInputObjParams = (tableFields) => {
	let errFound = false;
	tableFields?.forEach((inHeader) => {
		if (inHeader && inHeader[1] == '' || inHeader[1] == undefined) {
			errFound = true;
			return;
		}
	});
	return errFound
}

export const getDateTimePart = (dateToFormat, format) => {
	try {
		let selectedDDMM = '';
		if (dateToFormat == '' || dateToFormat == undefined) {
			return selectedDDMM;
		} else {
			let datepart = dateToFormat.split("T");
			let mm = '', hh = '';
			let myDate = datepart[0].split("-")
			let mon = myDate[1];
			let dd = myDate[2];
			let yyyy = myDate[0];
			if (datepart.length > 1) {
				let timepart = datepart[1].split(":");
				hh = timepart[0];
				mm = timepart[1];
			}

			switch (format) {
				case 'mm-dd-yyyy':
					selectedDDMM = mon + "-" + dd + '-' + yyyy;
					break;
				case 'mm-dd hh:mm':
					selectedDDMM = mon + "-" + dd + ' ' + hh + ':' + mm;
					break;
				case 'yyyy-mm-dd':
					selectedDDMM = yyyy + "-" + mon + "-" + dd;
					break;
				case 'mm-dd-yyyy':
					selectedDDMM = mon + "-" + dd + "-" + yyyy;
					break;
				case 'yyyy-mm-dd hh:mm':
					selectedDDMM = yyyy + "-" + mon + "-" + dd + " " + hh + ":" + mm;
					break;
				case 'hh-mm':
					selectedDDMM = hh + ":" + mm;
					break;
				case 'yyyy':
					selectedDDMM = yyyy;
					break;
				case 'mon':
					selectedDDMM = mon;
					break;
				case 'dd':
					selectedDDMM = dd;
					break;
				case 'mm':
					selectedDDMM = mm;
					break;
				case 'hh':
					selectedDDMM = hh;
					break;
			}
			return selectedDDMM;
		}
	}
	catch {

	}
}

export const getDateDiff = (firstDate, secDate, diffFormat) => {
	switch (diffFormat) {
		case "d": return (firstDate - secDate) / (1000 * 60 * 60 * 24);
			break;
		case "h": return (firstDate - secDate) / (1000 * 60 * 60) % 24;
			break;
		case "m": return (firstDate.getTime() - secDate.getTime()) / (1000 * 60) % 60;
			break;
		case "s": return (firstDate.getTime() - secDate.getTime()) / (1000) % 60;
			break;
	}
	return firstDate - secDate;
}
export const mapDateToOtherFormat = (rField, data) => {
	let date = getFieldData(rField, data);
	if (date) {
	  // return  new Date(date).toLocaleString('en-US', {  month: 'short' });
	  const tokens = new Date(date).toLocaleDateString({}, rField.mapDateFormat).split(' ');
	  return `${tokens[1].toString().substring(0, 2)}-${tokens[0]}-${tokens[2]}`;

	}
	return "";
  }
  export const getFieldData = (field, data) => {
	if (field.inlineField == 'data' && field.formatDate) {
	  return getDateTimePart(getJPathvalue(field.path, data), field.dateFormat);
	}
  }

export const createGetInputObj = (getInputParams, fieldData) => {
	let inParamObj = {};
	try {
		getInputParams.forEach((eField) => {
			if (eField.id == 'par_username' || eField.id == 'username') {
				inParamObj[eField.id] = 'WB.OPFL'
			} else {
				if (fieldData.hasOwnProperty(eField.path)) {
					if(eField.formatDate){
						let currentValue = mapDateToOtherFormat(eField, fieldData);
						inParamObj[eField.id] = currentValue != undefined ? currentValue.trim() : currentValue;
					} else{
						let currentValue = getJPathvalue(eField.path, fieldData).toString();
						inParamObj[eField.id] = currentValue != undefined ? currentValue.trim() : currentValue;
					}
				} else if(eField.concate) {
					inParamObj[eField.id] = eField.concatePath.map(path=> getJPathvalue(path,fieldData)).join(eField.concatePrefix||'').toString();
				} else {
					inParamObj[eField.id] = eField.model;
				}
			}
		});

	} catch (err) {
		console.error('err :',err)
	}

	return inParamObj;
}

export const sleep = async (msec) => {
	return new Promise(resolve => setTimeout(resolve, msec));
}
export const getUniqueId = (userId) => {
	return `${userId}_${(new Date()).getTime()}`
}

export const getLoopMins = () => {
	const intervalLaps = [30, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20, 20];
	return intervalLaps;
}

//This method used to format(YYYY-MM-DD) for API date
export const getAPIFormattedDate = (date) => {
	if(date?.includes("/")){
		let strArr = date.split("/");
		if(strArr.length === 3) {
			let mon, day, year;
			mon = `${strArr[0]}`
			day = `${strArr[1]}`
			year = `${strArr[2]}`

			return year  + "-" + mon + "-" + day;
		}
	}else{
		return date; //without format
	}
}

//This method used to create zone specific date in different formats for datepicker and manully entering date text.
export const createLocalDate = (dateStr, monthFlg = true) => {
	let mon; let year; let mm; let month; let dd; 
	let dt = new Date();
	year = dt.getFullYear();
	mm = dt.getMonth() + 1;
	month = dt.getMonth();
	dd = dt.getDate();
	//get all respective t.imezone offset info
	let hrs = dt.getHours();
	let mins = dt.getMinutes();
	let secs = dt.getSeconds();
	let gmtOffsetInMins = dt.getTimezoneOffset();
	let gmtOffsetInHrs = gmtOffsetInMins / 60;
	if(dateStr?.includes("NaN")){
		dt = new Date();
		return dt;
	}else if(dateStr?.includes("-")){
		let arr = dateStr?.split('-');  
		year = arr[0]
		mon = arr[1];
		dd = arr[2];
		return new Date(Date.UTC(year, mon - 1 , dd, hrs + gmtOffsetInHrs, mins, secs));
	}else{
		let arr = dateStr?.split('/');  
		if(arr.length > 0){
			month = arr[0];
			dd = arr[1];
			year = arr[2];
		}
		if(monthFlg){ 
			//if flg is TRUE we should not minus one from the month, this case from date picker
			return new Date(Date.UTC(year, month, dd, hrs + gmtOffsetInHrs, mins, secs));
		}else{ 
			//this case from manually entering date text, so we should minus one from the month
			return new Date(Date.UTC(year, month - 1 , dd, hrs + gmtOffsetInHrs, mins, secs));
		}
  }
}

//To get default today's date based on zone specific 
export const getDefaultDate = (dateFlag = 'CURR_MON_DATE', dateFormat) => {
	let dt = new Date(); 
	let mon; let day; 
	let year = dt.getFullYear();
	let mm = dt.getMonth() + 1;
	let month = dt.getMonth();
	let dd = dt.getDate();
	let hrs = dt.getHours();
	let mins = dt.getMinutes();
	let secs = dt.getSeconds();
	let gmtOffsetInMins = dt.getTimezoneOffset();
	let gmtOffsetInHrs = gmtOffsetInMins / 60;
	let localDate = new Date(Date.UTC(year, month, dd, hrs + gmtOffsetInHrs, mins, secs));
	
	if(dateFlag == "CURR_MON_DATE") { //CURRENT/TODAY DATE		
		mon = ("0" + mm).slice(-2);
		day = ("0" + dd).slice(-2);
	} else if(dateFlag == "LESS_ONE_DAY_FROM_TODAY_DATE") { 
		//LESS ONE DAY FROM CURRENT/TODAY DATE (TODAY-1) EVEN IF MONTH AND YEAR CHANING 
		//EX.IF DATE IS 01-JAN-2023 THEN IT WILL BE 31-DEC-2022
		dd = dd -1;
		if(dd == 0) {
			mm = mm -1;
			if(mm == 0) {
				mm = 12;
				year = year -1;
			}
			//let newDt = new Date(year, mm, dd);
			dd = localDate.getDate();
		}
		day = ("0" + dd).slice(-2);
		mon = ("0" + mm).slice(-2);				
	} else if(dateFlag == "LESS_ONE_DAY_IN_CURR_MONTH_FROM_TODAY_DATE") { 
		//LESS ONE DAY FROM CURRENT/TODAY DATE (TODAY-1) FOR CURRENT MONTH ONLY  NO NEED TO CHANGE THE MONTH
		//IF DATE IS 1ST OF EVERY MONTH THEN WE NEED TO KEEP AS IT IS,NO NEED TO DO -1
		//EX.IF DATE IS 01-JAN-2023 THEN IT WILL BE 01-JAN-2023
		dd = dd > 1 ? dd - 1 : dd;
		day = ("0" + dd).slice(-2);
		mon = ("0" + mm).slice(-2);				
	} else if(dateFlag == "FIRST_DAY_OF_CURR_MON") { //FIRST DAY OF CURRENT MONTH
		mon = ("0" + mm).slice(-2);
		day = "01";
	} else if(dateFlag == "FIRST_DAY_OF_CURR_YEAR") { //FIRST DAY OF CURRENT YEAR
		mon = "01"; day = "01";
	}
	if(dateFormat == "MM-DD-YYYY"){		
		return [mon, day, year].join("-");
	} else {
		return [year, mon, day].join("-");		
	}	
}

const getTableDataForField = (fields, tableData, selectedRecord) => {
	let fieldData = "";
	if(fields.isAminities ){
	  let  ams = getJPathvalue(fields.path, tableData) || [];
	  let aminities = ams.filter(am=>am[fields.filterPath] == fields.filterValue) || [];
	  return aminities.length>0 ? combineFields(fields,aminities[0]) : fields.defaultValue;
	}
	if(fields.targetObj == 'selectedRecord'){
	  return getJPathvalue(fields.path, selectedRecord);
	}
	if (Object.keys(tableData).length > 0) {
	  fieldData = getJPathvalue(fields.path, tableData[fields.cabin]);
	  if(!fields.cabin){
	  	fieldData = getJPathvalue(fields.path, tableData);
	  }
	  if(fields.dataType && fields.dataType.toString() == "array"){
		fieldData = combineFields(fields,fieldData[0]);
	  }
	  if(fields.dataType && fields.dataType.toString() == "object"){
		fieldData = combineFields(fields,fieldData);
	  }
	  if(fields.dataType && fields.dataType.toString() == "nestiarray"){
		fieldData = combineFields(fields,(fieldData[0]?fieldData[0][fields.subpath][0]:{}));
	  }
	}
	if(fieldData === 0){
	  return fieldData;
	}
	if((!fieldData || !fieldData.toString().trim()) && fields && fields.defaultValue != (null || undefined) && (fields.defaultValue == 0 || fields.defaultValue.toString())){
		fieldData = fields.defaultValue.toString();
	}
	return fieldData;
  }
  //TO HANDLE MULTIPLE CURRENCIES
  const getMultipleCurrencyData =(field,data) =>{
    let currData={}
    data.filter(tblData=>{
      if(field.name=='ETC'){
        currData = tblData.flightTotals?.etcTotal.length>0 ? tblData.flightTotals?.etcTotal:field.defaultValue
      }
      if(field.name=='Drafts'){
        currData = tblData.flightTotals?.draftAmountTotal.length>0 ? tblData.flightTotals?.draftAmountTotal:field.defaultValue
      }
      if(field.name=='Amenities'){
        currData = tblData.flightTotals.amenitiesByCurrency.length>0 ? tblData.flightTotals.amenitiesByCurrency:field.defaultValue
      } 
      else{
        currData;
      }
    })
    return currData;
  }

  const combineFields = (field,item) =>{
	let FloatObj = {};
      let fieldValue ='';
      if(field.isFloatValue){
		if(field.isAminities){
			let aminObj = {};
			FloatObj["amountCompensated"] = aminObj;
			field.combinepath.forEach(path=>{
				if(path == field.combinepath[0]){
					let amnt = getJPathvalue(path,item) || field.defaultValue
					let amntValue = Number.isInteger(amnt) ? amnt : parseFloat(amnt).toFixed(2)
					aminObj["amount"] =  amntValue;
				} else {
					let currCode = getJPathvalue(path,item)
					aminObj["currencyCode"] =  currCode;
				}
			})
		} else{
			field.combinepath.forEach(path=>{
				if(path == field.combinepath[0]){
					let amnt = getJPathvalue(path,item) || field.defaultValue
					let amntValue = Number.isInteger(amnt) ? amnt : parseFloat(amnt).toFixed(2)
					FloatObj["amount"] =  amntValue;
				} else {
					let currCode = getJPathvalue(path,item)
					FloatObj["currencyCode"] =  currCode;
				}
			})
		}
         fieldValue = field.combinepath.map(path=>getJPathvalue(path,FloatObj)).join(field.combinePrefix||'').toString();
      } else{
         fieldValue = field.combinepath.map(path=>getJPathvalue(path,item)).join(field.combinePrefix||'').toString();
      }
      if(fieldValue.trim().length === 0){
       return field.defaultValue;
      }
      return fieldValue;
  }
  const concateFieldData = (field,item) =>{
		let combineStr = '';
		field.combineFields.forEach(fldItem => {
			if(fldItem.getTextFrom == 'data') {
				if(combineStr){
					if(fldItem.formatDate)
						combineStr = combineStr + (field.combinePrefix||'') + getDateTimePart(getJPathvalue(fldItem.path,item), fldItem.dateFormat);
					else {
						combineStr = combineStr + (field.combinePrefix||'') + getJPathvalue(fldItem.path,item);
					}
				} else {
					combineStr = getJPathvalue(fldItem.path,item);
				}			
			} else {
				if(combineStr){
					combineStr = combineStr + (field.combinePrefix||'') + fldItem.label;
				} else {
					combineStr = fldItem.label;
				}
			}
		});
		return combineStr;
	}
  const combineMultipleFields = (field,item) => {
	let combineFieldStr = [];
	field.combineFields.forEach((pItem) => {
		let combineStr = '';
		if(pItem.getTextFrom == 'data') {
			if(pItem.takeDataFromParentPath){
				let itemData = item[pItem.takeDataFromParentPath];//if nested path present
				if(!itemData) return;
				if(pItem.mapDateFormat)
					combineStr = mapDateToOtherFormat(pItem,itemData);
				else if(pItem.formatDate)
					combineStr = getDateTimePart(getJPathvalue(pItem.path,itemData), pItem.dateFormat);
				else  if(pItem.combinepath)
					combineStr = pItem.combinepath.map(path => getJPathvalue(path,itemData)).join(pItem.combinePrefix||'').toString();
				else 
					combineStr = getJPathvalue(pItem.path,itemData);
			} else {
				if(pItem.mapDateFormat) 
					combineStr = mapDateToOtherFormat(pItem,item);
				else if(pItem.formatDate)
					combineStr = getDateTimePart(getJPathvalue(pItem.path,item), pItem.dateFormat);
				else  if(pItem.combinepath)
					combineStr = pItem.combinepath.map(path => getJPathvalue(path,item)).join(pItem.combinePrefix||'').toString();
				else 
					combineStr = getJPathvalue(pItem.path,item);
			}
			
		} else {
			combineStr = pItem.label;
		}
		combineFieldStr.push(combineStr);							
	});
	return combineFieldStr.join(field.combineBy||'').toString();
  }
  export const createHeadersCells = (excelHeaderFieldInfo, worksheet, applicationInfoDetails, headerRowData={}) => {
	let lastRowInfo = {};
	excelHeaderFieldInfo.forEach((headerRowInfo) => {
		let headerarr = headerRowInfo.headerCellInfo.map(col => {
			if(col.getTextFrom == 'data') {
				return (headerRowData && headerRowData.length > 0) ? headerRowData[0][col.path] : "";
			} else if(col.getTextFrom == 'title') {
				return (headerRowData && headerRowData.length > 0) ?  col.text.replace("#myText",
				headerRowData[0][col.path] ):   "";
			}
			return col.text;
		});
		//Add Header Row
		let headerRow = worksheet.addRow(headerarr);
		let cellCount = 0;
		headerRowInfo.headerCellInfo.forEach(col => {   
			let startCell = cellCount+1;  
			if(col.mergeCellCount){
				let endCell = cellCount + col.mergeCellCount;   
				cellCount = endCell;
				worksheet.mergeCells(`'${headerRow.getCell(startCell).address} : ${headerRow.getCell(endCell).address}'`); //TO MERGE CELLS IN CURRENT ROW	  
			} else {
				cellCount++;
			}
			let mergedCell = headerRow.getCell(startCell);
			if(col.styles){
				if(col.styles.bgColorCode && col.styles.bgColorCode != ''){
					mergedCell.fill = {
					type: "pattern",
					pattern: "solid",
					fgColor: { argb: applicationInfoDetails.colorClassCodes[col.styles.bgColorCode] }
					};
				}
				if(col.styles.fontColorCode && col.styles.fontColorCode != ''){
					mergedCell.font = { color: { argb: applicationInfoDetails.colorClassCodes[col.styles.fontColorCode] } };
				}
			} 
			if(col.styles && col.styles.alignment && Object.keys(col.styles.alignment).length > 0){
				mergedCell.alignment = col.styles.alignment;
			} else {
				mergedCell.alignment = { "horizontal":'center'}
			}			
			mergedCell.font = { ...mergedCell.font, bold: true } //making header bold 			 		
			if(col.getTextFrom == 'data') {
				mergedCell.value = headerRowData.length > 0 ? headerRowData[0][col.path] : "";
			} else if(col.getTextFrom == 'title') {
				mergedCell.value =  col.text.replace("#myText",headerRowData[0][col.path]) ;
			  } else {
				mergedCell.value = col.text;
			}		
		});		
		lastRowInfo.rowInd =  headerRow.number;
		lastRowInfo.cellInd =  cellCount;
	  });
	return lastRowInfo;
}
export const appendHeadersCells = (excelHeaderFieldInfo, worksheet, applicationInfoDetails, headerRowData={}, lastTblHeaderInfo) => {
	let lastRowInfo = {};
	excelHeaderFieldInfo.forEach((headerRowInfo) => {
		let headerRow = worksheet.getRow(lastTblHeaderInfo.rowInd);
			//lastRowInd = row.number;
		let lastRowInd = 0;
		let lastCellInd = 0;
		let cellCount = lastTblHeaderInfo.cellInd;
		headerRowInfo.headerCellInfo.forEach(col => {   
			let startCell = cellCount+1;  
			if(col.mergeCellCount){
				let endCell = cellCount + col.mergeCellCount;   
				cellCount = endCell;
				worksheet.mergeCells(`'${headerRow.getCell(startCell).address} : ${headerRow.getCell(endCell).address}'`); //TO MERGE CELLS IN CURRENT ROW	  
			} else {
				cellCount++;
			}
			let mergedCell = headerRow.getCell(startCell);
			if(col.styles){
				if(col.styles.bgColorCode && col.styles.bgColorCode != ''){
					mergedCell.fill = {
					type: "pattern",
					pattern: "solid",
					fgColor: { argb: applicationInfoDetails.colorClassCodes[col.styles.bgColorCode] }
					};
				}
				if(col.styles.fontColorCode && col.styles.fontColorCode != ''){
					mergedCell.font = { color: { argb: applicationInfoDetails.colorClassCodes[col.styles.fontColorCode] } };
				}
			} 
			if(col.styles && col.styles.alignment && Object.keys(col.styles.alignment).length > 0){
				mergedCell.alignment = col.styles.alignment;
			} else {
				mergedCell.alignment = { "horizontal":'center'}
			}			
			mergedCell.font = { ...mergedCell.font, bold: true } //making header bold 	
			if(col.getTextFrom == 'data') {
				if(col.concateData){
					//TO CONCATE MULTIPLE PATH VALUES IN ONE COULMN
					let concateStr = concateFieldData(col, headerRowData[0])
					mergedCell.value = concateStr;
				} else {
					mergedCell.value = headerRowData.length > 0 ? getJPathvalue(col.path, headerRowData[0]) : "";
				}
				
			} else {
				mergedCell.value = col.text;
			}		
		});		
		lastRowInfo.rowInd =  headerRow.number;
		lastRowInfo.cellInd =  cellCount;
	  });
	return lastRowInfo;
}
export const createRowsData = (tblRowsPerSingleDataObj, worksheet, applicationInfoDetails, exportTblData, selectedRecord, mergeRowCellsInfo ) => {
		let tblRowsPerSingleDataFlds = tblRowsPerSingleDataObj.rowValues;
	let rowSeq = 0;
	let lastRowInfo = {};
	//Add Data and Conditional Formatting
	exportTblData.forEach((eRowData, indx) => {
		//TO RENDER THE MODAL SCREEN MULTIPLE TIMES DEPEND ON THE RECORD PRESENT ON MODAL DATA
		//IF IT IS 2 DATA ROW/OBJECT PRESENT THEN WE NEED TO SHOW 2 TIMES SAME SCREEN WITH DYNAMIC DATA
		if(tblRowsPerSingleDataObj.repeatSameDesignDataRowWise){
			//ADD HEADER ROW FOR EACH RECORD IN MODAL DATA IN CASE OF SINGLE MACRO DATA
			createHeadersCells(tblRowsPerSingleDataObj.headerColumnsInfo, worksheet, applicationInfoDetails, tblRowsPerSingleDataObj?.excelDataToShow );
		}
		let lastRowInd = 0;
		let lastCellInd = 0;
		tblRowsPerSingleDataFlds.forEach((rowFld) => {
			let rowValues = [];
			let rwFieldsInfo = JSON.parse(JSON.stringify(rowFld));
			if(tblRowsPerSingleDataObj.tableRowSStartCell){
				for(let i=1; i <= tblRowsPerSingleDataObj.tableRowSStartCell; i++){
					rowValues.push('');
				}		
			}
			rwFieldsInfo.forEach((rw, indx) => {				
				if(rw.getTextFrom == 'data'){
					if (rw.isTextColorRequired) {
						if (rw.path && eRowData[rw.path] > 0) {
							rw.styles = rw.styles;
						}
					}
					if (rw.dynamicTextPath) {
						//If data is present in Primary path then take primary path data 
						//otherwise take secondary path data and change color and path to show data
						if(!(eRowData[rw.path] && eRowData[rw.path].trim() != "")){
							if(rw.secondaryPath && eRowData[rw.secondaryPath.path] && eRowData[rw.secondaryPath.path] != ''){
							//if we need to change the text color depend on the multple path value
							rw.path = rw.secondaryPath.path;
							rw.styles = rw.secondaryPath.styles;
							}
						}
					} 
					if (rw.dynamicTextstyle) {
						//CHANGE TEXT COLOR IF DEPENDED OTHER DATA IS NOT EMPTY
						if(rw.dynamicTextStyleOtherField && eRowData[rw.dynamicTextStyleOtherField.path] && eRowData[rw.dynamicTextStyleOtherField.path].trim() != "") {
							rw.styles = rw.dynamicTextStyleOtherFieldPath.styles;
						} else if (rw.compareData) {
							//CHANGE TEXT COLOR IF DEPENDED OTHER DATA IS NOT SAME
							if(eRowData[rw.path] != eRowData[rw.secondaryPath.path]) {
								rw.styles = rw.secondaryPath.styles;
							}
						} 
					}	
					if(rw.concateData){
						//TO CONCATE MULTIPLE PATH VALUES IN ONE COULMN
						let concateStr = concateFieldData(rw, eRowData)
						rowValues.push(concateStr);
					} else if(rw.combineMultipleFields){
						//TO CONCATE MULTIPLE PATH VALUES IN ONE COULMN
						let concateStr = combineMultipleFields(rw,eRowData);
						rowValues.push(concateStr);
					} else {
						let currVal;
						if(rw.isMultipleCurrency){
							let multipleCurrencyData = getMultipleCurrencyData(rw.fields,[eRowData]);
							if(multipleCurrencyData && multipleCurrencyData.length>0){
								multipleCurrencyData.forEach((mulDt)=>{
									currVal = combineFields(rw.fields, mulDt);
									rowValues.push(currVal);
								})
							} else{
								currVal = rw.fields.defaultValue;
								rowValues.push(currVal);
							}
						} else{
							currVal = getTableDataForField(rw, eRowData, selectedRecord );
						}
						//currVal = currVal ? currVal.toString() : currVal;
						if(rw.formatDate) {
							if(rw.mapDateFormat)
								rowValues.push(mapDateToOtherFormat(rw,eRowData));
							else
								rowValues.push(getDateTimePart(currVal, rw.dateFormat));
						} else if(!rw.isMultipleCurrency) {
							rowValues.push(currVal);
						}					
					}
				} else if(rw.getTextFrom == 'label') {
					rowValues.push(rw.label);
				}         
			});
			let row = worksheet.addRow(rowValues);
			lastRowInd = row.number;
			let cellCount = tblRowsPerSingleDataObj.tableRowSStartCell ? tblRowsPerSingleDataObj.tableRowSStartCell : 0;

			rwFieldsInfo.forEach((rw, rwInd) => {			
				let startCell = cellCount+1;  
				let currCell = row.getCell(startCell);
				let cellValue = currCell.value;
				if(rw.mergeMultipleRowCells && (mergeRowCellsInfo && mergeRowCellsInfo.isLastSubRow)){
					//MERGE multiple row cells LIKE L5:L7
					cellCount++;
					let currCellInfo = row.getCell(startCell).address.split(/(\d+)/);
					let startMergeCellFromAddress = currCellInfo[0] + ((parseInt(currCellInfo[1]) - mergeRowCellsInfo.totolSubRowDataLength) + 1);
					worksheet.mergeCells(`'${startMergeCellFromAddress} : ${row.getCell(startCell).address}'`);		  
					//worksheet.mergeCells('L5:L7');		  
				} else if(rw.mergeCellCount){//merge multiple cell in single row
					let endCell = cellCount + rw.mergeCellCount;   
					cellCount = endCell;
					worksheet.mergeCells(`'${row.getCell(startCell).address} : ${row.getCell(endCell).address}'`);		  
				} else {
					cellCount++;
				}
				
				if(rw.styles && rw.styles.alignment && Object.keys(rw.styles.alignment).length > 0){
					currCell.alignment = rw.styles.alignment;
				} else {
					currCell.alignment = { horizontal:'center'} 
				}	
				if(tblRowsPerSingleDataObj.rowWiseBGColorRequired && (indx % 2) == 0 ){
					//CHANGE THE BG COLOR FOR CELL IN INTERCHANGE ROW
					currCell.fill = {
						type: "pattern",
						pattern: "solid",
						fgColor: { argb: applicationInfoDetails.colorClassCodes[tblRowsPerSingleDataObj.rowWiseBGColor] }
					};
				}	    
				if(rw.changeStyle){ //if only want change the text color                   
					if(rw.styles.fontColorCode && rw.styles.fontColorCode != ''){
						currCell.font = { color: { argb: applicationInfoDetails.colorClassCodes[rw.styles.fontColorCode] }};
					}
					if(rw.styles.fontBold && rw.styles.fontBold != ''){
						currCell.font = {...currCell.font, bold : rw.styles.fontBold};
					}
					if(rw.styles.bgColorCode && rw.styles.bgColorCode != ''){
						currCell.fill = {
							type: "pattern",
							pattern: "solid",
							fgColor: { argb: applicationInfoDetails.colorClassCodes[rw.styles.bgColorCode] }
						};
					}           
				}	
				currCell.value = cellValue;
				if(rw.hyperlinkButton && currCell.value && currCell.value.toString().trim() != ''){
					currCell.font = { ...currCell.font, underline: true } //making Underline Text for hyperlink button 	
				}				   
			});	
			lastCellInd = cellCount;
		}); 
		lastRowInfo.rowInd =  lastRowInd;
		lastRowInfo.cellInd =  lastCellInd;
		if(lastRowInd > 0 && tblRowsPerSingleDataObj.isBorderRequired){			
			worksheet.getRow(lastRowInd).eachCell({ includeEmpty: true },(cell, number) => {
				cell.border = { bottom: { style: "thin", color : {argb: '000000' }}};
			});
			if(tblRowsPerSingleDataObj.borderRow){
				let brdRow = worksheet.addRow([""]);
				worksheet.mergeCells(`'${brdRow.getCell(1).address} : ${brdRow.getCell(tblRowsPerSingleDataObj.borderRow.mergeCellCount).address}'`);	
			}
		}	        
	});
	return lastRowInfo;
}
export const mergeRowsCells = (tblRowsPerSingleDataObj, worksheet, applicationInfoDetails, mergeRowCellsInfo ) => {
	let tblRowsPerSingleDataFlds = tblRowsPerSingleDataObj.rowValues;
	//Add Data and Conditional Formatting
	let lastRowInd = 0;
	tblRowsPerSingleDataFlds.forEach((rowFld) => {
		let rwFieldsInfo = JSON.parse(JSON.stringify(rowFld));
		let row = worksheet.getRow(mergeRowCellsInfo.currRowInd);
		lastRowInd = row.number;
		let cellCount = tblRowsPerSingleDataObj.tableRowSStartCell ? tblRowsPerSingleDataObj.tableRowSStartCell : 0;

		rwFieldsInfo.forEach((rw) => {			
			let startCell = cellCount + 1;  
			let currCell = row.getCell(startCell);
			let cellValue = currCell.value;
			if(rw.mergeMultipleRowCells){
				//MERGE multiple row cells LIKE L5:L7
				cellCount++;
				let currCellInfo = row.getCell(startCell).address.split(/(\d+)/);
				let startMergeCellFromAddress = currCellInfo[0] + ((parseInt(currCellInfo[1]) + mergeRowCellsInfo.totolSubRowDataLength) - 1);
				worksheet.mergeCells(`'${startMergeCellFromAddress} : ${row.getCell(startCell).address}'`);		  
				//worksheet.mergeCells('L5:L7');		  
			} else if(rw.mergeCellCount){//merge multiple cell in single row
				let endCell = cellCount + rw.mergeCellCount;   
				cellCount = endCell;
				worksheet.mergeCells(`'${row.getCell(startCell).address} : ${row.getCell(endCell).address}'`);		  
			} else {
				cellCount++;
			}
			
			if(rw.styles && rw.styles.alignment && Object.keys(rw.styles.alignment).length > 0){
				currCell.alignment = rw.styles.alignment;
			} else {
				currCell.alignment = { horizontal:'center'} 
			}	
			if(tblRowsPerSingleDataObj.rowWiseBGColorRequired && (indx % 2) == 0 ){
				//CHANGE THE BG COLOR FOR CELL IN INTERCHANGE ROW
				currCell.fill = {
					type: "pattern",
					pattern: "solid",
					fgColor: { argb: applicationInfoDetails.colorClassCodes[tblRowsPerSingleDataObj.rowWiseBGColor] }
				};
			}	    
			if(rw.changeStyle){ //if only want change the text color                   
				if(rw.styles.fontColorCode && rw.styles.fontColorCode != ''){
					currCell.font = { color: { argb: applicationInfoDetails.colorClassCodes[rw.styles.fontColorCode] }};
				}
				if(rw.styles.fontBold && rw.styles.fontBold != ''){
					currCell.font = {...currCell.font, bold : rw.styles.fontBold};
				}
				if(rw.styles.bgColorCode && rw.styles.bgColorCode != ''){
					currCell.fill = {
						type: "pattern",
						pattern: "solid",
						fgColor: { argb: applicationInfoDetails.colorClassCodes[rw.styles.bgColorCode] }
					};
				}           
			}	
			currCell.value = cellValue;
			if(rw.hyperlinkButton && currCell.value && currCell.value.toString().trim() != ''){
				currCell.font = { ...currCell.font, underline: true } //making Underline Text for hyperlink button 	
			}				   
		});	
	}); 
	if(lastRowInd > 0 && tblRowsPerSingleDataObj.isBorderRequired){			
		worksheet.getRow(lastRowInd).eachCell({ includeEmpty: true },(cell, number) => {
			cell.border = { bottom: { style: "thin", color : {argb: '000000' }}};
		});
		if(tblRowsPerSingleDataObj.borderRow){
			let brdRow = worksheet.addRow([""]);
			worksheet.mergeCells(`'${brdRow.getCell(1).address} : ${brdRow.getCell(tblRowsPerSingleDataObj.borderRow.mergeCellCount).address}'`);	
		}
	}
}
export const appendRowsData = (tblRowsPerSingleDataObj, worksheet, applicationInfoDetails, exportTblData, selectedRecord, lastTblHeaderInfo ) => {
	let tblRowsPerSingleDataFlds = tblRowsPerSingleDataObj.rowValues;
	let rowSeq = 0;
	let lastRowInfo = {};
	let rowNum = 0;
	//Add Data and Conditional Formatting
	exportTblData.forEach((eRowData, indx) => {		
		let lastRowInd = 0;
		let lastCellInd = 0;
		rowNum = rowNum++;
		tblRowsPerSingleDataFlds.forEach((rowFld) => {
			let rowValues = [];
			let rwFieldsInfo = JSON.parse(JSON.stringify(rowFld));
			
			let row = worksheet.getRow(lastTblHeaderInfo.rowInd);
			lastRowInd = row.number;
			
			let cellCount = lastTblHeaderInfo.cellInd;
			rwFieldsInfo.forEach((rw) => {
				let startCell = cellCount+1;  
				if(rw.mergeCellCount){
					let endCell = cellCount + rw.mergeCellCount;   
					cellCount = endCell;
					worksheet.mergeCells(`'${row.getCell(startCell).address} : ${row.getCell(endCell).address}'`);		  
				} else {
					cellCount++;
				}
				let currCell = row.getCell(startCell);
				if(rw.styles && rw.styles.alignment && Object.keys(rw.styles.alignment).length > 0){
					currCell.alignment = rw.styles.alignment;
				} else {
					currCell.alignment = { horizontal:'center'} 
				}	
				if(tblRowsPerSingleDataObj.rowWiseBGColorRequired && (indx % 2) == 0 ){
					//CHANGE THE BG COLOR FOR CELL IN INTERCHANGE ROW
					currCell.fill = {
						type: "pattern",
						pattern: "solid",
						fgColor: { argb: applicationInfoDetails.colorClassCodes[tblRowsPerSingleDataObj.rowWiseBGColor] }
					};
				}	    
				if(rw.changeStyle){ //if only want change the text color                   
					if(rw.styles.fontColorCode && rw.styles.fontColorCode != ''){
						currCell.font = { color: { argb: applicationInfoDetails.colorClassCodes[rw.styles.fontColorCode] }};
					}
					if(rw.styles.fontBold && rw.styles.fontBold != ''){
						currCell.font = {...currCell.font, bold : rw.styles.fontBold};
					}
					if(rw.styles.bgColorCode && rw.styles.bgColorCode != ''){
						currCell.fill = {
							type: "pattern",
							pattern: "solid",
							fgColor: { argb: applicationInfoDetails.colorClassCodes[rw.styles.bgColorCode] }
						};
					}           
				}	
				// if(rw.showInFirstRow && rowNum > 1)	{ //show this field info only in first row
				// 	currCell.value = ""; 
				// 	return; 
				// }
				if(rw.concateData){
					//TO CONCATE MULTIPLE PATH VALUES IN ONE COULMN
					let concateStr = concateFieldData(rw, eRowData)
					currCell.value = concateStr;
				} else if(rw.combineMultipleFields){
					//TO CONCATE MULTIPLE PATH VALUES IN ONE COULMN
					let concateStr = combineMultipleFields(rw,eRowData);
					currCell.value =  concateStr;
				} else if(rw.rowSeq){
					currCell.value = ++rowSeq;
				} else if(rw.getTextFrom == 'data') {
					let currVal = getTableDataForField(rw, eRowData,  selectedRecord )
					if(rw.formatDate) {
						if(rw.mapDateFormat)
							currCell.value = rowValues.push(mapDateToOtherFormat(rw,eRowData));
						else
							currCell.value = getDateTimePart(currVal, rw.dateFormat)
					} else {
						currCell.value = currVal //? currVal.toString() : currVal;
					}
				} else {
					currCell.value = rw.label;
				}	
				if(rw.hyperlinkButton && currCell.value && currCell.value.toString().trim() != ''){
					currCell.font = { ...currCell.font, underline: true } //making Underline Text for hyperlink button 	
				}				   
			});	
			lastCellInd = cellCount;
		}); 
		lastRowInfo.rowInd =  lastRowInd;
		lastRowInfo.cellInd =  lastCellInd;
		if(lastRowInd > 0 && tblRowsPerSingleDataObj.isBorderRequired){			
			worksheet.getRow(lastRowInd).eachCell({ includeEmpty: true },(cell, number) => {
				cell.border = { bottom: { style: "thin", color : {argb: '000000' }}};
			});
			if(tblRowsPerSingleDataObj.borderRow){
				let brdRow = worksheet.addRow([""]);
				worksheet.mergeCells(`'${brdRow.getCell(1).address} : ${brdRow.getCell(tblRowsPerSingleDataObj.borderRow.mergeCellCount).address}'`);	
			}
		}	        
	});
	return lastRowInfo;
}
export const checkEmptyRow = (worksheet, rownum,cellInd) => {
	let row = worksheet.getRow(rownum);
	let isValuePresent = false;
	row.eachCell((cell, cellNUmber) => {
		if(cell.value) {
			isValuePresent  = true;
			return;
		} 
	});
	return isValuePresent;
}
export const generateAndDownloadExcel = async(workbook, reportFileName) => {
	await workbook.xlsx.writeBuffer().then((data) => {
		let blob = new Blob([data], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
		FileSaver.saveAs(blob, reportFileName + ".xlsx");
		//status = true;
	  });
	  return true;
  }
//seperated logic to export modal popup data to excel
  export const exportTOExcleModalFile = (exportToExcelConfig, applicationInfoDetails) => {
	//Create workbook and worksheet
	let workbook = new ExcelJS.Workbook();
	let worksheet = workbook.addWorksheet("Sheet1");
	//generate the required header details for the sheet
	exportToExcelConfig.excelReportFileData.forEach((excelFieldsObj)=> {
		if(excelFieldsObj.typeOfData == 'headerText'){
			//generate header data
			createHeadersCells(excelFieldsObj.headerColumnsInfo, worksheet, applicationInfoDetails, excelFieldsObj?.excelDataToShow );
		} else if(excelFieldsObj.typeOfData == 'tableData'){
			//generate the required rows with actual data for the sheet
			createRowsData(excelFieldsObj.rowInfo, worksheet, applicationInfoDetails, excelFieldsObj?.excelDataToShow);
		}
	});	
	
	//Generate Excel File with given name
	workbook.xlsx.writeBuffer().then((data) => {
	  let blob = new Blob([data], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
	  FileSaver.saveAs(blob, exportToExcelConfig.reportFileName + ".xlsx");
	});
  }
  export const getbuttonColorClass = (status,oversaleStatusMapper)=>{
	let maprObj = oversaleStatusMapper[status.toUpperCase()];
	if(maprObj && maprObj.color){
		return maprObj.color;
	}
	switch (status.toString().toUpperCase()) {
		case 'INPROGRESS':
		case 'IN PROGRESS':
			return 'volunteersAdded';
		case 'IN PROCESS':
		case 'INPROCESS':
			return 'volunteersProcessed';
		case 'FINALIZED': 
			return 'finalised';
		case 'STOPPED':
			return 'stopped';
		case 'ACTIVE':
            return 'Active';
		case 'INITIATED':
			  return 'initiated';
		case 'MODIFIED':
				return 'modified';
		case 'DELETED':
			return 'deleted';
		default:
			return oversaleStatusMapper['default'].color;
	}
  }

export const getAmtAndCurrencyCode = (amtCurrCode) => {
	let amtObj = {};
	if(amtCurrCode && isNaN(amtCurrCode)) {
		if(amtCurrCode.toString().indexOf(' ') !== -1){
			let splitAmt = amtCurrCode.split(' ');
			if(splitAmt.length == 2){//IF AMT AND CURR CODE IS PRESENT
				amtObj.amount = splitAmt[0];
				amtObj.currencyCode = splitAmt[1];
				return amtObj;
			}
			amtObj.amount = splitAmt[0]; //ONLY AMOUNT PRESENT
			return amtObj;
		} else {
			//SAMPLE Ex. 12 USD, 12USD, 12
			amtObj.currencyCode  = amtCurrCode.toString().substring(amtCurrCode.length - 3); //GET LAST 3 LETTERS
			amtObj.amount = amtCurrCode.toString().substring(0,amtCurrCode.length - 3); //GET LAST 3 LETTERS
			return amtObj;
		} 
	  
	} else {
		amtObj.amount = amtCurrCode; //ONLY AMOUNT PRESENT
		return amtObj
	}
}
export const  getParameterByName=(name, url )=>{
    name = name.replace(/[\[\]]/g, '\\$&');
    var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, ' '));
}
let currColor={}
export const getRandomColor = (curr)=>{
	if(!currColor[curr]){
		let color='#' + Math.random().toString(16).substr(-6);
		currColor[curr]=color;
		return color
	}
	return currColor[curr];
};
export const  copyToClipBoard = async (text)=>{
	try {
	  await navigator.clipboard.writeText(text);
	} catch (err) {
	  console.error('Failed to copy: ', err);
	}
};
export const getCombinedCabinValues = (cabins)=>{
	let cabinText = [0,0,0];
	if(cabins){
		cabins.forEach(cb=>{
			switch(cb.cabinCode){
				case 'J':
					cabinText[0]=cb.availableSeatCount;
					break;
				case 'O':
					cabinText[1]=cb.availableSeatCount;
					break;
				case 'Y':
					cabinText[2]=cb.availableSeatCount;
					break;
				default:
					break;
			}		
		});
	}
	return cabinText.join('/');
}
export const getEnv = (prop_key_name) => {
	//return config[prop_key_name] || process.env[prop_key_name];
	return  process.env[prop_key_name];
};

export const getSortedDataByField = (dataToSort, fieldToSortData) => {
	//-1 = [a,b] , 1 = [b,a], 0 no change
	let sortedData = dataToSort.sort(function (a, b) {
		let firstValue = getJPathvalue(fieldToSortData.path,a);
		let secValue = getJPathvalue(fieldToSortData.path,b);
		if(fieldToSortData.sortingOrder == "asc"){
			if(!firstValue && !secValue) return 0;
			if(!firstValue) return 1;
			if(!secValue) return -1;
		} else {
			if(!firstValue && !secValue) return 0;
			if(!firstValue) return -1;
			if(!secValue) return 1;
		}
		if(fieldToSortData.sortedDataType == "date"){
			firstValue =  new Date(getDateTimePart(firstValue, "yyyy-mm-dd"));
            secValue = new Date(getDateTimePart(secValue, "yyyy-mm-dd"));
		} else if (fieldToSortData.sortedDataType == "time"){
			firstValue =  new Date(getDateTimePart(firstValue, "yyyy-mm-dd hh:mm")).getTime();
            secValue = new Date(getDateTimePart(secValue, "yyyy-mm-dd hh:mm")).getTime();
		}
		if(fieldToSortData.sortingOrder == "asc"){
			if(fieldToSortData.sortedDataType == "string"){
				return firstValue.toString().toLowerCase().localeCompare(
					secValue.toString().toLowerCase());
			} else {
				return firstValue - secValue;
			}
		} else {
			if(fieldToSortData.sortedDataType == "string"){
				return secValue.toString().toLowerCase().localeCompare(
					firstValue.toString().toLowerCase())
			} else {
				return secValue - firstValue;
			}
		}		
	  });
	return sortedData;
}

export const validateDateWithDDMM = (dateTodValidate) => {
	let monthWith31Days = [1,3,5,7,8,10,12];
	let monthWith30Days = [4,6,9,11];
	if (dateTodValidate.includes("/")) {
		let dtPartArr = dateTodValidate.split("/");
		if (dtPartArr.length === 3) {
			let mon = parseInt(dtPartArr[0]);
			let day = parseInt(dtPartArr[1]);
			let year = parseInt(dtPartArr[2]);
			if(day == 0 || mon == 0 || mon > 12 || year == 0){
				return false;
			} else if(mon == 2){
				if(checkLeapYear(year)){
					return day <= 29;//leap year days validation
				} else {
					return day <= 28;
				}
			} else if(monthWith30Days.includes(mon) && day > 30){
				return false;
			} else if(monthWith31Days.includes(mon) && day > 31){
				return false;
			}
			return true;
		}
	}
}
// Function to check leap year
export const checkLeapYear = (year) => {
    //three conditions to find out the leap year
    if ((0 == year % 4) && (0 != year % 100) || (0 == year % 400)) {
        return true;
    } else {
        return false;
    }
}
export const sortByPrority = (el1,el2)=>{
	if (el1.priority < el2.priority) {
		return -1;
	  } else if (el1.priority > el2.priority) {
		return 1;
	  } else {
		return 0;
	  }
};
export const createHash = (obj,keys)=> keys.map(k=>obj[k]||'').toString();
export const getCommaSeperatedValue = (numbrToConvert) => {
	//CONVERT FORMAT NUMBER WITH COMMAS EX.1234567 -> 1,234,567
	if(numbrToConvert) return numbrToConvert.toLocaleString();
	return numbrToConvert;
}