import axios from "axios";
import {  getEnv,decodeData } from "../helpers/utilities";
const getUserInfoQuery= 'query MyQuery($action_type: String) {   get_user_info(action_type: $action_type) {     user_info   } }'
const userLogoutQuery='query MyQuery($action_type: String) {   redirect_logout(action_type: $action_type) {     payload   } }'
const saveMutaion= "mutation MyMutation($DocType: String!, $Id: String!, $Payload: AWSJSON) { updateMetadata(input: {DocType: $DocType, Id: $Id, Payload: $Payload}) { payload user_info } }"


const authClientInstance = axios.create({});

const url = getEnv('VUE_APP_GRAPHQL_API');

const generateToken = ({ code })=>{
  let data = { query:getUserInfoQuery, variables:{
    "action_type":"user_info"
  }};
  let headers = { "content-type": "application/json","is_first":true };
  headers['Authorization'] = 'cec:'+code;
   return authClientInstance.post(url, data, { headers }); // userInfo
}

const fetchInfoByUId = (uid)=>{
  let data = { query:getUserInfoQuery, variables:{
    "action_type":"user_info"
  }};
  let headers = { "content-type": "application/json" ,"is_valid":true};
  headers['Authorization'] = 'crr:'+uid;
   return authClientInstance.post(url, data, { headers }); // user info along with expryin time 
}
const userLogoutAppSync = (uid)=>{
  let data = { query:userLogoutQuery, variables:{
    //"action":co_rl_id,
    "action_type":"logout_user"
  }};
  let headers = { "content-type": "application/json","is_valid": 'false' };
  headers['Authorization'] = 'crr:'+uid;
   return authClientInstance.post(url, data, { headers }); 
}
const  setCookie =(cname, cvalue,exSec)=>{
  const d = new Date();
  d.setTime(d.getTime() + (exSec*1000));
  let expires = "expires="+ d.toUTCString();
  document.cookie = cname + "=" + cvalue + ";path=/" +";"+  expires;
}
const  getCookie=(cname)=>{
  let name = cname + "=";
  let decodedCookie = decodeURIComponent(document.cookie);
  let ca = decodedCookie.split(';');
  for(let i = 0; i <ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) == ' ') {
      c = c.substring(1);
    }
    if (c.indexOf(name) == 0) {
      return c.substring(name.length, c.length);
    }
  }
  return "";
}
const updateData = (apiObj,uid)=>{
  let data = { query:saveMutaion, variables:{
    "DocType":"EntityType","Id":"userAuth","Payload":JSON.stringify(apiObj)
  }};
  let headers = { "content-type": "application/json" ,"is_valid":true};
  headers['Authorization'] = 'crr:'+uid;
   return authClientInstance.post(url, data, { headers });
}

const getRedirectURL = ()=>{
 let oam_url = `${decodeData(getEnv('VUE_APP_ou'))}client_id=${decodeData(getEnv('VUE_APP_ocd'))}domain=${decodeData(getEnv('VUE_APP_oud'))}redirect_uri=${decodeData(getEnv('VUE_APP_ord'))}response_type=${decodeData(getEnv('VUE_APP_ort'))}scope=${decodeData(getEnv('VUE_APP_scope'))}code_challenge_method=${decodeData(getEnv('VUE_APP_occm'))}code_challenge=${decodeData(getEnv('VUE_APP_occ'))}`;
 let global_logout_page = `${decodeData(getEnv('VUE_APP_glp'))}`;
 return {oam_url,global_logout_page}
}
const checkIfOAMDown200 = (res)=>{ // If Appsync handle OAM down
  if (res.status == 200 && res.data?.errors) {
    let message =res.data.errors[0]?.message;
    message= JSON.parse(message);
    return message?.Code == 1003;
  }
}
const checkIfOAMDown5xx = (er)=>{ // If Lambda handle OAM down
  if (er && er.response?.status == 500 && er.response.data?.errors) {
    let message =response.data.errors[0]?.message;
    message= JSON.parse(message);
    return message?.Code == 1003;
  }
}
export {
  generateToken,
  setCookie,
  getCookie,
  fetchInfoByUId,
  updateData,
  userLogoutAppSync,
  getRedirectURL,
  checkIfOAMDown200,
  checkIfOAMDown5xx,
}