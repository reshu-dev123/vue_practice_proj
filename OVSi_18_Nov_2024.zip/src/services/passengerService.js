import { getEnv } from "../helpers/utilities";
import api from "./api";
const GET_PASSENGERS = getEnv('VUE_APP_GET_PASSENGERS');
const ADD_VOLUNTEER = getEnv('VUE_APP_ADD_VOLUNTEER');
const REMOVE_VOLUNTEER = getEnv('VUE_APP_REMOVE_VOLUNTEER');
const GET_COMMENT = getEnv('VUE_APP_GET_COMMENT');
const ADD_COMMENT = getEnv('VUE_APP_ADD_COMMENT');
const UPDATE_COMMENT = getEnv('VUE_APP_UPDATE_COMMENT');
const REMOVE_PROCESSED_PASSENGER =  getEnv('VUE_APP_REMOVE_PROCESSED_PASSENGER');
const REMOVE_MUSTRIDE = getEnv('VUE_APP_REMOVE_MUSTRIDE');
const ADD_PROCESS_PASSENGER = getEnv('VUE_APP_ADD_PROCESS_PASSENGER');
const ADD_MUSTRIDE = getEnv('VUE_APP_ADD_MUSTRIDE');
const GET_DOWNGRADE_LIST = getEnv('VUE_APP_GET_DOWNGRADE_LIST');
const getPassengers = (obj)=>{
    let {inputObject} = obj;
    let inputObject2= JSON.parse(JSON.stringify(inputObject)); 
    let queryParams = "";
  
    Object.keys(inputObject2).forEach(key=>{
      const value = inputObject2[key];
      queryParams+=`${key}=${value}&`;
    })
    
    queryParams = queryParams.substring(
    0,queryParams.length-1);
    return api.get(GET_PASSENGERS+`?${queryParams}`);
};
const getDowngradeList = (obj)=>{
  let {inputObject} = obj;
  let inputObject2= JSON.parse(JSON.stringify(inputObject)); 
  let queryParams = "";

  Object.keys(inputObject2).forEach(key=>{
    const value = inputObject2[key];
    queryParams+=`${key}=${value}&`;
  })
  
  queryParams = queryParams.substring(
  0,queryParams.length-1);
  return api.get(GET_DOWNGRADE_LIST+`?${queryParams}`);
};
const addVolunteer = (apiObj)=>{
  return api.post(ADD_VOLUNTEER,apiObj);
};
const removeVolunteer= (apiObj)=>{
 return api.post(REMOVE_VOLUNTEER,apiObj);
};
const getFlightComments= (apiObj)=>{
  return api.get(GET_COMMENT,apiObj);
 };
 const addflightcomment= (apiObj)=>api.post(ADD_COMMENT,apiObj);
 const getPassengerOffers= (apiObj)=>api.post(GET_PASSENGERS,apiObj);
 const updateflightcomment= (apiObj)=>api.post(UPDATE_COMMENT,apiObj);
 const removeprocessedpassenger= (apiObj)=>api.post(REMOVE_PROCESSED_PASSENGER,apiObj);
 const removemustride = (apiObj)=>api.post(REMOVE_MUSTRIDE,apiObj);
 const addProcessPassenger= (apiObj)=>api.post(ADD_PROCESS_PASSENGER,apiObj);
 const addMustride= (apiObj)=>api.post(ADD_MUSTRIDE,apiObj);

export {
    getPassengers,
    addVolunteer,
    removeVolunteer,
    getFlightComments,
    addflightcomment,
    getPassengerOffers,
    updateflightcomment,
    removeprocessedpassenger,
    removemustride,
    addProcessPassenger,
    addMustride,
    getDowngradeList
}