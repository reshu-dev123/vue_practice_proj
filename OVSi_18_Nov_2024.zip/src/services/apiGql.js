import axios from "axios";
import { getEnv } from "../helpers/utilities";

const GRAPHQL_API_AUTH_KEY = getEnv('VUE_APP_GRAPHQL_API_KEY');

const httpClientInstance = axios.create({
  headers: {
    "Content-Type": "application/json",
    //"x-api-key": GRAPHQL_API_AUTH_KEY
  },
});
let coRelHeader;
export const addCorelIdInHeaders=(uid)=>{
    coRelHeader= {
      "Content-Type": "application/json",
      "Authorization": 'crr:'+uid,
      "is_valid": true
    }
}
//Azh - Various App Sync http API calls.
const apiGql = {
  get(url, params) {
    return httpClientInstance.get(url, { params });
  },

  post(url, data) {
    return httpClientInstance.post(url, data, { headers:coRelHeader });
  },

  put(url, data, headers = { "content-type": "application/json" }) {
    return httpClientInstance.put(url, data, { headers });
  },

  delete(url) {
   return httpClientInstance.delete(url);
  },
  patch(url, data, config) {
    return httpClientInstance.patch(url, data, config);
  },
  all(urls, params) {
   let response = urls.map(url => httpClientInstance.get(url, params)); // Individual params should be passed
   return response;
  }

};

export default apiGql;