import api from './api.js';


//get call request
const getTimestamp = () => api.get(process.env.VUE_APP_tmeStmp_Path);

export{
    getTimestamp
}