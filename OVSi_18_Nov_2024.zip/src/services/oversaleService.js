import { getEnv } from "../helpers/utilities";
import api from "./api";

const GET_OVERVIEW_BY_CITY_API = getEnv('VUE_APP_GET_OVERVIEW_BY_CITY');
const GET_OVERVIEW_BY_COST_API = getEnv('VUE_APP_GET_OVERVIEW_BY_COST');
const GET_OVERVIEW_BY_DB_API = getEnv('VUE_APP_GET_OVERVIEW_BY_DB');

const getoverviewbycity =(obj)=>{
    let {inputObject} = obj;
     Object.keys(inputObject).forEach((key,index)=>{
      if( key !='showHubs' && !inputObject[key]){
        delete inputObject[key];
      }
     })
     return api.post(GET_OVERVIEW_BY_CITY_API,inputObject);
 };
 const getoverviewbycost =(obj)=>{
  let {inputObject} = obj;
   Object.keys(inputObject).forEach((key,index)=>{
     if(!inputObject[key]){
       delete inputObject[key];
     }
   })
   return api.post(GET_OVERVIEW_BY_COST_API,inputObject);
};
const getoverviewbydb =(obj)=>{
  let {inputObject} = obj;
   Object.keys(inputObject).forEach((key,index)=>{
     if(!inputObject[key]){
       delete inputObject[key];
     }
   })
   return api.post(GET_OVERVIEW_BY_DB_API,inputObject);
};

 export {
    getoverviewbycity,
    getoverviewbycost,
    getoverviewbydb
 }