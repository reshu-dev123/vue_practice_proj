import axios from "axios";

//Azh - This will create the client object to be used across app
const httpClientInstance = axios.create({
    headers: {
    "Content-Type": "application/json",
  },
});

//Azh - Various http API calls.
const api = {
  get(url, params) {
    return httpClientInstance.get(url, { params }); 
  },

  post(url, data, headers = { "content-type": "application/json" }) {
    return httpClientInstance.post(url, data, { headers });
  },

  put(url, data, headers = { "content-type": "application/json" }) {
    return httpClientInstance.put(url, data, { headers });
  },

  delete(url) {
   return httpClientInstance.delete(url);
  },
  patch(url, data, config) {
    return httpClientInstance.patch(url, data, config);
  },
  all(urls, params) {
   let response = urls.map(url => httpClientInstance.get(url, params)); // Individual params should be passed
   return response;
  }
};

export default api;
