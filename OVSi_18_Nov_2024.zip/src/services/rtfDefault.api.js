import { getEnv } from '../helpers/utilities.js';
import api from './api.js';
import apiGql from './apiGql.js';

const ENTITY = process.env.VUE_APP_Entity_Path;

const GRAPHQL_END_POINT = getEnv('VUE_APP_GRAPHQL_API');
const query = "query MyQuery($DocType: String!, $Id: String!) { getMetadata(DocType: $DocType,Id: $Id) { payload user_info}}";
const getEntityDisplayDetails = (id) => {
   let variables = { Id:id,DocType: "EntityType"}; 
  return api.get(ENTITY + id + ".json"); // local json
  return apiGql.post(GRAPHQL_END_POINT , ({query,variables}));// api call graph
};
const getOVSiLocalData = (object) => {
  return api.get(ENTITY + object.id + "Data.json");
};
 const  getOVSIData = async(object) => {
  //query = "query MyQuery($Action: String, $ActionID: String, $DBType: String, $Input: AWSJSON) { response:severlessApi(Action: $Action, ActionID: $ActionID, DBType: $DBType, Input: $Input) { payload StatusMessage DBType }}"
 let  query = "";

  let obj = JSON.stringify(object.inputObject);
  const variables = {
    "Action": object.action,
    "ActionID": object.actionId,
    "Input": obj,
    //"DBType":object.DBType
  }
  return await apiGql.post(GRAPHQL_END_POINT, { query, variables });
};
export {
  getEntityDisplayDetails,
  getOVSIData,
   getOVSiLocalData
}