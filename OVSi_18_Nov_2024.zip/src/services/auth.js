import {  encodeData } from "../helpers/utilities";
import { addCorelIdInHeaders } from "./apiGql";
import {
  fetchInfoByUId,
  getCookie,
  generateToken,
  setCookie,
  getRedirectURL,
  checkIfOAMDown200,
  checkIfOAMDown5xx,
} from "./user.api";

let oamInfo = {};
export const CO_CK_NM = "_coid_";
setCookie(CO_CK_NM,'e0a9ba30-1201-4',13800);
const  loadApp =(value)=>window.dispatchEvent(new CustomEvent('loginHandler', {  value  }));
const initateFreshlogin = ({ code }) => {
  generateToken({ code })
    .then((res) => {
      if (res.status == 200 && res.data.data.get_user_info.user_info) {
        let user_info = JSON.parse(res.data.data.get_user_info.user_info);
        oamInfo.user_info = user_info;
        addCorelIdInHeaders(user_info.crr);
        setCookie(CO_CK_NM, user_info.crr, user_info.rem_exp-60);
        loadApp(true);
      } else {
       let isDown = checkIfOAMDown200(res);
       if(isDown)
       alert('OAM service is Down!, Please retry  or contact your administrator.')
       else
        throw Error('Invalid code Found')
      }
    })
    .catch((er) => {
      if(er && er?.reponse?.status == 500){
        alert('OAM service is Down!, Please retry  or contact your administrator.')
      }
      redirectToAuth()
    });
};
const redirectToAuth = () => {
  let urlInfo = getRedirectURL();
  oamInfo = {
    oam_url: urlInfo.oam_url,
    // oam_url: 'https://signon-oqa.ual.com/oauth2/rest/authorize?client_id=OVERSALEINTELLIGENCE_ODEV_CID&domain=OVERSALEINTELLIGENCE_ODEV&redirect_uri=http://localhost:8080/oauth2/idpresponse&response_type=code&scope=openid&code_challenge_method=S256&code_challenge=jyJGW3s73cvrVW4w7tMBV_E7mZFrGWOkp9ODKcHM2Vc',
    global_logout_page: urlInfo.global_logout_page,
  };
  let isPathOrQueryPassed =
    window.location.origin.concat("/") != window.location.href;
  let redirect_uri_dev = isPathOrQueryPassed
    ? oamInfo.oam_url + `&state=${encodeData(window.location.href)}`
    : oamInfo.oam_url;
  window.location.replace(redirect_uri_dev);
};
export const oam = () => {
  let uParser = document.createElement('a');
      uParser.href = window.location.href
  if (window.location.search.toString().includes("code") && uParser.pathname == '/oauth2/idpresponse') {
    // redirected from OMA scen 1
    //Checking for the "code" in the PCKE flow of OAM OIDC flow for passing to the token API endpoint.
    const queryParams = new URLSearchParams(window.location.search);
    //parameters to be passed along with the token Endpoint.
    const authCode = queryParams.get("code");
    initateFreshlogin({ code: authCode });
    return;
  }
  let crr = getCookie(CO_CK_NM);
  if (!crr) {
    redirectToAuth();
  } // user hit direct domain scen 2
  else {
    let user_info = JSON.parse("{\"DisplayName\":\"Local User\",\"UserID\":\"v123456\",\"Groups\":[\"Local ual-oversaleinsight-qa-admin-dgg\"],\"Location\":\"HSC\",\"rem_exp\":12097,\"crr\":\"b1449c18-1e2c-4\"}");
          oamInfo.crr = crr;
          oamInfo.user_info = user_info;
          addCorelIdInHeaders(crr);
          loadApp(true);
    // fetchInfoByUId(crr)
    //   .then((res) => {
    //     // for existing session
    //     if (res.status == 200 && res.data.data.get_user_info.user_info) {
    //       let user_info = JSON.parse(res.data.data.get_user_info.user_info);
    //       oamInfo.crr = crr;
    //       oamInfo.user_info = user_info;
    //       addCorelIdInHeaders(crr);
    //       loadApp(true);
    //       if (user_info.rem_exp > 1) {
    //         setCookie(CO_CK_NM, crr, user_info.rem_exp-60);
    //       }
    //     } else {
    //       throw Error("Invalid Session Found");
    //     }
    //   })
    //   .catch((er) => {
    //     console.error(er);
    //     debugger
    //     let isDown = checkIfOAMDown5xx(er);
    //     if (isDown) {
    //       alert('OAM service is Down!, Please retry  or contact your administrator.')
    //     } else {
    //       setCookie(CO_CK_NM, crr, -2);
    //       redirectToAuth();
    //     }
    //  });
  }
};

export const getOamInfo = () => {
  let c = oamInfo;
  oamInfo={};
  return c;
};
