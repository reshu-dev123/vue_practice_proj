import api from "./api";
import { getEnv } from "../helpers/utilities";

const GET_CONFIGURATION_API = getEnv('VUE_APP_GET_CONFIGURATION_API');
const ADD_CONFIGURATION_API = getEnv('VUE_APP_ADD_CONFIGURATION_API');
const DELETE_CONFIGURATION_API = getEnv('VUE_APP_DELETE_CONFIGURATION_API');

const getConfiguration= (apiObj)=>{
  return api.get(GET_CONFIGURATION_API,apiObj);
 };
const addConfiguration= (apiObj)=>api.post(ADD_CONFIGURATION_API,apiObj);
const deleteConfiguration= (apiObj)=>api.post(DELETE_CONFIGURATION_API,apiObj);
export {
  getConfiguration,
  addConfiguration,
  deleteConfiguration,
}
