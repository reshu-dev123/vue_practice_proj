import { getEnv } from "../helpers/utilities";
import api from "./api";

const GET_FLIGHTS_API = getEnv('VUE_APP_GET_FLIGHTS_API');
const GET_FLIGHTS_REPORTS_API = getEnv('VUE_APP_GET_FLIGHTS_REPORTS_API');
const GET_FLIGHT_HISTORY = getEnv('VUE_APP_GET_FLIGHT_HISTORY');
const GET_FLIGHT_API = getEnv('VUE_APP_GET_FLIGHT_API');
const DEACTIVE_FLIGHT = getEnv('VUE_APP_DEACTIVE_FLIGHT');
const FINALIZE_FLIGHT = getEnv('VUE_APP_FINALIZE_FLIGHT');
const INITIATE_FLIGHT = getEnv('VUE_APP_INITIATE_FLIGHT');

const getFlights =(obj)=>{
   let {inputObject} = obj;
    Object.keys(inputObject).forEach((key,index)=>{
      if(!inputObject[key]){
        delete inputObject[key];
      }
    })
    return api.post(GET_FLIGHTS_API,inputObject);
};
const getFlightReport =(obj)=>{
  let {inputObject} = obj;
  let inputObject2= JSON.parse(JSON.stringify(inputObject)); 
  let queryParams = "";

  Object.keys(inputObject2).forEach(key=>{
    const value = inputObject2[key];
    queryParams+=`${key}=${value}&`;
  })
  
  queryParams = queryParams.substring(
  0,queryParams.length-1);
  return api.get(GET_FLIGHTS_REPORTS_API+`?${queryParams}`);
};
const getFlightHistory =(obj)=>{

  let {inputObject} = obj;
  let inputObject2= JSON.parse(JSON.stringify(inputObject)); 
   let queryParams = "";

   Object.keys(inputObject2).forEach(key=>{
     const value = inputObject2[key];
     queryParams+=`${key}=${value}&`;
   })
   
   queryParams = queryParams.substring(0,queryParams.length-1);
   return api.get(GET_FLIGHT_HISTORY+`?${queryParams}`);
};
const getFlight = (inputObject)=>{
  let inputObject2= JSON.parse(JSON.stringify(inputObject)); 
  let queryParams = "";

  Object.keys(inputObject2).forEach(key=>{
    const value = inputObject2[key];
    queryParams+=`${key}=${value}&`;
  })
  
  queryParams = queryParams.substring(
  0,queryParams.length-1);
  return api.get(GET_FLIGHT_API+`?${queryParams}`)
}
const deactiveFlight = (apiObj)=>{
 return api.post(DEACTIVE_FLIGHT,apiObj);
};
const finalizeFlight = (apiObj)=>{
  return api.post(FINALIZE_FLIGHT,apiObj);
 };
 const initiateFlight = apiObj=>api.post(INITIATE_FLIGHT,apiObj);
export {
    getFlights,
    getFlightReport,
    getFlightHistory,
    deactiveFlight,
    finalizeFlight,
    initiateFlight,
    getFlight
}