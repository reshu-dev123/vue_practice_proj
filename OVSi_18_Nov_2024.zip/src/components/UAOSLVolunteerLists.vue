<template>
  <div class="u-row" style="min-height: 84vh;">
    <div class="u-col l12 m12 s12">
  <div v-if="displayHeader" :class="['u-col l10 m10 s10',displayHeader.cssClass]">
    <label>{{getHeaders(displayHeader.header)}}</label>
    <h6>{{displayHeader.subHeader}}</h6>
  </div>
  </div>
  <div class="u-row u-padding">
 <UATab :tabFields="tabs" @selectedTab="handleSelectTab" :countArray="countArray" />
 <UAModalDisplay v-if="showModalPopup" @close="ClosePopup()"
    :modalTable="addTableFields[0].modalTemp"
    :tableData="modalData"
    :bidData="bidOptionData"
    :footerFields="modalButtons[0].closeButtons"
  />
   <!-- Add customer modal -->
   <UAModalDisplay v-if="addPopup" @close="ClosePopup()" :subHeader="getHeaders(displayHeader.header)"
      @add="addEditPassenger" :tableData="selectedPsngrData" :modalTable="addCustomerTableFields[0].modalTemp"
      @addNewFieldRow="addCustomerNewFieldRows"
      @deleteNewFieldRow="deleteCustomerNewFieldRows"
      @bindDependentValuesOnCHange="setDependentValuesOnCHange($event, addCustomerTableFields[0].modalTemp)"
      :footerFields="modalButtons[0].addButtons" />
 <div class="u-row" >
  <UATableDisplay 
    :cardRowCss="['u-white']"
    :tableData="getFilterData" 
    :tableFields="getOVSIFields"
    @setShowModalPopup="setShowModalPopup" 
    @addFieldsModalPopup="toggleAddPop"
    :disableActionBtn="getStatusValue()=='STOPPED'"
  /> 
  </div>
  </div>
  </div>
</template>

<script>
import { mapState,mapMutations,mapGetters,mapActions } from 'vuex';
import UATableDisplay from "./UATableDisplay.vue";
import UASearchKeyword from "./UASearchKeyword.vue";
import UAButton from "./UAButton.vue";
import UATab from "./UATab.vue";
import UAModalDisplay from "./UAModalDisplay.vue";
import {mapDateToOtherFormat, getAmtAndCurrencyCode, validatInputParams} from "@/helpers/utilities";
import {addProcessPassenger} from '../services/passengerService';

export default {
  name: "UAOSLVolunteerLists",
  data() {
      return {
          selectedTabIndex: 0,
          countArray:[],
          showModalPopup:false,
          modalData:[],
          bidOptionData:[],
          editModalDisplayTableFields:[],
          addCustomerTblFldsCopy:[],
          addPopup: false,
          selectedPsngrData: {},
      };
  },
  props: [],
  created(){
    this.reSetSearchOVSIData();
    this.getOVSIData({
             inputObject: {
               FlightOrigin:this.selectedRecord['flightOrigin'],
               FlightNumber:this.selectedRecord['flightNumber'],
               FlightDate:this.selectedRecord['flightDate'], 
               PassengerType: 'V'
             },
             actionId: this.actionId,
         }).finally(()=>{
          this.tabs.forEach(tabInfo=>{
            let filterData = (this.searchOVSIData && this.searchOVSIData.passengers) || [];
              filterData = filterData?.filter(psnrInfo => {
                return psnrInfo.passenger?.volunteerStatus == 'V' && psnrInfo.passenger.currentCabinCode == tabInfo.compareCabinCode;
              });
             this.countArray.push(filterData.length);
          })
         })
  },
  mounted(){
    this.addCustomerTblFldsCopy = JSON.parse(JSON.stringify(this.addCustomerTableFields));
  },
  components: {
    UATableDisplay,
    UASearchKeyword,
    UAButton,
    UATab,
    UAModalDisplay,
},
  computed: {
    ...mapState({
      displayHeader: (state)=>state.ovsiDefaultModule.displayHeader,
      searchfilters: (state) => state.ovsiDefaultModule.searchfilters,
      tableDetails: (state)=>state.ovsiDefaultModule.tableDetails,
      sections: (state)=>state.ovsiDefaultModule.entityDisplayDetails.Layouts[0].InnerLayout.sections,
      searchOVSIData: (state)=>state.ovsiDefaultModule.searchOVSIData,
      tabs: state => state.ovsiDefaultModule.tabs,
      prevNavigateViews: state => state.ovsiDefaultModule.prevNavigateViews,
      isNavigatedEvent: state => state.ovsiDefaultModule.isNavigatedEvent,
      actionId: (state) => state.ovsiDefaultModule.actionId,
      selectedRecord: state => state.ovsiDefaultModule.selectedRecord,
      isLoading: (state) => state.ovsiDefaultModule.isLoading,
      exportToExcelConfig: (state) => state.ovsiDefaultModule.exportToExcelConfig,
      addTableFields: (state) => state.ovsiDefaultModule.addTableFields,
      modalButtons: (state) => state.ovsiDefaultModule.modalButtons,
      addCustomerTableFields: (state) => state.ovsiDefaultModule.entityDisplayDetails.Layouts[0].InnerLayout.addCustomerTableFields,
      additionalFields: (state) => state.ovsiDefaultModule.entityDisplayDetails.Layouts[0].InnerLayout.additionalFields,
      statusField: (state) => state.ovsiDefaultModule.entityDisplayDetails.Layouts[0].InnerLayout.statusField,
      channel: (state) => state.userModule.channel,
      getFilterData(){
        if(Object.keys(this.searchOVSIData).length == 0) return this.searchOVSIData;
        let filterData = this.searchOVSIData && this.searchOVSIData.passengers || [];
        let selectedTadInfo = this.tabs.filter((tb, ind) => {
          return ind == this.selectedTabIndex;
        });
        let tabInfo = selectedTadInfo[0];
        filterData = filterData.filter(psnrInfo => {
          if( psnrInfo.passenger.volunteerStatus)
          return psnrInfo.passenger.volunteerStatus == 'V' && psnrInfo.passenger.currentCabinCode == tabInfo.compareCabinCode;
        });
        filterData.forEach((item, ind) => {
          item.__row = ind + 1;
        });
        return filterData;
      }
    }) ,
    ...mapGetters(["getOVSIFields", "getJPathValue", "getEmployeeId"]),
  },
methods:{
  ...mapActions(["getOVSIData","getEntityDisplayDetailsAction","authorizeModule","updatePrevOptions"]),
  ...mapMutations(["reSetSearchOVSIData","setSelectedMenuId","setAlertMessages","setModalAlertMessages","clearAlertMessages","setSelectedRecord"]),
    handleSelectTab(tab, tabIndex) {
      this.selectedTabIndex = tabIndex;
    },
    getHeaders(header){
      return  header.combineFields.map(f=>{
        return f.path?(f.formatDate? mapDateToOtherFormat(f, this.selectedRecord):this.getJPathValue(f.path,this.selectedRecord)):f.concatePath.map(p=>this.getJPathValue(p,this.selectedRecord)).join(f.concatePrefix ||'')
      }).join(header.combineBy|| ' ');
    },
    ClosePopup(){
      this.showModalPopup =false;
      this.addCustomerTableFields[0].modalTemp = JSON.parse(JSON.stringify(this.addCustomerTblFldsCopy[0].modalTemp || []));
      this.addPopup = false;
    },
    setShowModalPopup(currRowData){
      this.clearAlertMessages();
      this.editModalDisplayTableFields = JSON.parse(JSON.stringify(this.addTableFields));
      this.modalData = [currRowData];
      this.bidOptionData = currRowData.compensation.passengerOffers;
      this.showModalPopup = true;
    },
    getStatusValue() {
      let rField= this.statusField;
      let actualValue = this.getJPathValue(rField.path, this.selectedRecord) || this.getJPathValue(rField.overViewPath, this.selectedRecord);
      return actualValue.toUpperCase();
    },
    combineFields(field, item) {
      return field.combinepath
        .map((path) => this.getJPathValue(path, item))
        .join(field.combinePrefix || "")
        .toString();
    },
    setAmmentiesTotalValues(currModalInfo, tblDataInfo={}){
      let newRowData = [];   
      let tblMdlData = JSON.parse(JSON.stringify(tblDataInfo));
      if(tblMdlData.compensation && Object.keys(tblMdlData.compensation).length>0){ 
        currModalInfo.modalFields.forEach(modalData => {        
          let tblIssuanceData;
          if(modalData.fieldsToAddAssuance){
            if(modalData.bindModalFieldWithIteratbleData) {//IN CASE OF MULTIPLE ISSUANCE WE NEED TO SHOW MULTIPLE ISSUANCE ROW AS PER ISSUANCE RECORD LENGTH
              if(modalData.multiDataParentPathToIterateTblFilds){
                tblIssuanceData = this.getJPathValue(modalData.multiDataParentPathToIterateTblFilds,tblMdlData)
              }
            }
            let fieldWiseTotalCount = {};
            modalData[modalData.id].forEach((mdlFieldItem,mdlFldIndx) => {
              mdlFieldItem.tableFields.forEach(fieldItem => {
              let totalCount = 0;
                let tblData = {};
                if(Array.isArray(tblIssuanceData)){//IF MULTIPLE ISSUANCE FOUND - AS DATA IN ARRAY TYPE
                  tblData = tblIssuanceData[mdlFldIndx];
                } else {
                  tblData = JSON.parse(JSON.stringify(tblDataInfo));
                }
              if(tblData && Object.keys(tblData).length > 0 ){
                //totalCount = this.getJPathValue(fieldItem.path, tblData);
                if (fieldItem.isAminities && fieldItem.isEdit) {
                  let ams =
                    this.getJPathValue(fieldItem.path, tblData) || [];
                  let aminities =
                    ams.filter(
                      (am) => am[fieldItem.filterPath] == fieldItem.filterValue
                    ) || [];
                    let fieldValue  = 
                    aminities.length > 0
                      ? this.combineFields(fieldItem, aminities[0])
                      : fieldItem.defaultValue;
                      totalCount = parseFloat(fieldValue.split(' ')[0]);
                } else if(!fieldItem.isAminities &&
                    fieldItem.combinepath &&
                    fieldItem.combinepath.length > 0) {
                  totalCount = parseFloat(this.combineFields(fieldItem, tblData).split(' ')[0]);
                } else {
                  totalCount = this.getJPathValue(fieldItem.path, tblData);
                }
              } else {
                totalCount = fieldItem.model ? parseInt(fieldItem.model) : 0;
              }
                if(fieldWiseTotalCount.hasOwnProperty(fieldItem.id)){                
                  totalCount = fieldWiseTotalCount[fieldItem.id] + totalCount;
                  fieldWiseTotalCount[fieldItem.id]= totalCount;
                } else {
                  fieldWiseTotalCount[fieldItem.id]=totalCount;
              }
              //GET THE VALUES FROM NEW ROW ADDED FIELDS AND ADD IT IN TOTAL
              currModalInfo.addNewRowFields.forEach(addModalField => {           
                addModalField.tableFields.forEach(addFieldItem => {
                  if(addFieldItem.id == fieldItem.id){
                    totalCount = totalCount + (addFieldItem.model ? parseFloat(addFieldItem.model) : 0);
                  }                
                });
              });
              //SET THE TOTAL FOR ALL ROWS
              currModalInfo.modalFields.forEach(modalData => {  
                if(modalData.showTotalInfo){
                  modalData[modalData.id].forEach(mdlFieldItem => {
                      mdlFieldItem.tableFields.forEach(totalFieldItem => {
                        if(totalFieldItem.id == fieldItem.id){
                          totalFieldItem.model = Number.isInteger(totalCount) ? totalCount : parseFloat(totalCount).toFixed(2);
                        }
                      });
                    });
                  }                         
                });
              });
            });
          }                          
        });
      }
    },
   //ON CHNAGE IN FIELD GET/CALCULATE THE FILED WISE VALUE
    setDependentValuesOnCHange(inputFieldDetails, currModalInfo) {
      let totalCount = 0;
      try {
        if (inputFieldDetails.inputFieldInfo.currField.dependOnOtherSection
          && inputFieldDetails.inputFieldInfo.currField.dependOnOtherSection.length > 0) {
          currModalInfo.modalFields.forEach(modalData => {
            if(modalData[inputFieldDetails.inputFieldInfo.currField.currentSectionId]){
              modalData[inputFieldDetails.inputFieldInfo.currField.currentSectionId].forEach(modlRowFiledInfo => {
                modlRowFiledInfo.tableFields.forEach(fieldItem => {
                if (fieldItem.model && inputFieldDetails.inputFieldInfo.currField.id == fieldItem.id) {
                  if(inputFieldDetails.inputFieldInfo.currField.id == "miles"){
                    totalCount = totalCount + (fieldItem.model ? parseInt(fieldItem.model) : 0);
                  }else{
                    let amt = fieldItem.model.toString().trim();
                    let amtCode = getAmtAndCurrencyCode(amt);
                    totalCount = totalCount + (amtCode.amount ? parseFloat(amtCode.amount) : 0);
                  }
                }
                });
              });              
            }           
          });
            currModalInfo.addNewRowFields.forEach(addModalField =>{
              addModalField.tableFields.forEach(fieldItem => {
                if (fieldItem.model && inputFieldDetails.inputFieldInfo.currField.id == fieldItem.id) {
                  if(inputFieldDetails.inputFieldInfo.currField.id == "miles"){
                    totalCount = totalCount + (fieldItem.model ? parseInt(fieldItem.model) : 0);
                  }else{
                      let amt = fieldItem.model.toString().trim();
                      let amtCode = getAmtAndCurrencyCode(amt);
                      totalCount = totalCount + (amtCode.amount ? parseFloat(amtCode.amount) : 0);
                  }
                }
              });
            });
          //BIND THE TOTAL OF FIELD IN BELOW TOTAL FIELDS
          currModalInfo.modalFields.forEach(modalData => {            
            if(inputFieldDetails.inputFieldInfo.currField.dependOnOtherSection 
              && modalData[inputFieldDetails.inputFieldInfo.currField.dependOnOtherSection[0]]){
                modalData[inputFieldDetails.inputFieldInfo.currField.dependOnOtherSection[0]][0].tableFields.forEach(fieldItem => {
                  if (inputFieldDetails.inputFieldInfo.currField.dependOnOtherSectionField[0] == fieldItem.id) {
                    fieldItem.model =  Number.isInteger(totalCount) ? totalCount : parseFloat(totalCount).toFixed(2);
                  }
                });
            }            
          });
        }
      } catch (err) {
        console.error(err)
      }
    },
    getExistingIssuanceFlds(psngrData,mdlTblFlds,mdlTblCopyFlds){
      let issuaceDetails = mdlTblFlds.modalTemp.modalFields[1];
          let issuancLength = psngrData.compensation.issuances.length;
          if(issuancLength > 1){ 
            //AS METADATA OF ISSUANCE ARRAY CONTAINS ONE ISSUANCE FILEDS 
            //SO IF ISSUANCE GREATER THAN ONE THEN PUSH INTO SAME ISSUANCE FILEDS ARRAY WITH (TOTAL ISSUANCE LENGTH  MINUS ONE )TIMES
            psngrData.compensation.issuances.forEach((issuance, ind) =>{
              if((issuancLength-1) <= ind) return;
              let mdlFldsInfo = JSON.parse(JSON.stringify(mdlTblCopyFlds.modalTemp.modalFields[1][issuaceDetails.id][0] || []))
              //mdlFldsInfo.headers[0].deleteimg= true,
              issuaceDetails[issuaceDetails.id].push(mdlFldsInfo) 
            });
          }
          return issuaceDetails;
    },
    toggleAddPop(data,bindData) {
      if (this.getStatusValue() == 'STOPPED') { return; }
      this.clearAlertMessages();
      this.selectedPsngrData = [data];
      //TO ADD EXISTING MULTIPLE ISSUANCES
      if(data.compensation && Object.keys(data.compensation).length>0 && this.addCustomerTableFields[0].modalTemp.manipulateModalFieldASPerData){
        if(data.compensation.issuances && data.compensation.issuances.length >0){
          this.getExistingIssuanceFlds(data,this.addCustomerTableFields[0],this.addCustomerTblFldsCopy[0]);
        }
      }
      if(bindData){ //TO SET THE TOTAL VALUES
        this.setAmmentiesTotalValues(this.addCustomerTableFields[0].modalTemp, data);
      }
      this.addPopup = true
    },
    addCustomerNewFieldRows(){
       this.addCustomerTableFields[0].modalTemp
      .addNewRowFields.push(JSON.parse(JSON.stringify(this.additionalFields[0] || [])))
    },
    deleteCustomerNewFieldRows(indx, currmodalData,mode){
      if (mode =='add'){
      this.addCustomerTableFields[0].modalTemp
      .addNewRowFields = this.addCustomerTableFields[0].modalTemp
        .addNewRowFields.filter((item,ind) => currmodalData[currmodalData.id].length +ind +1  != indx);
        this.setAmmentiesTotalValues(this.addCustomerTableFields[0].modalTemp);
      }
    },
    addEditCustomerErrMSG(mdltblFields,errmessages){
      let errorMsgs = errmessages.map( errmsgobj => {
          let errmsg=errmsgobj.message;
          mdltblFields.modalFields.forEach(modal => {
            let modalTableFields = modal[modal.id][0];
            modalTableFields.tableFields.forEach(tblFld =>{
              if(tblFld.compareFieldNameInErrMSG && errmsg.includes(tblFld.compareFieldNameInErrMSG)) {
                errmsg= errmsg.replace(tblFld.compareFieldNameInErrMSG, tblFld.label);//REPLACE UI FIELD NAME IN API ERROR MESSAGE        
              }
            }); 
          });             
          return errmsg;
        });
        return errorMsgs;
    },
    addEditPassenger(mdlTemp,selMode) {
      this.clearAlertMessages();
      let errFound = [];
      let headerText= '';
      mdlTemp.modalFields.forEach(modal => {
        modal[modal.id].forEach((modalTblFlds,modalTblFldInd) => {
          if(modalTblFlds.headers[0]?.tableHeaderText){
            headerText=`${modalTblFlds.headers[0]?.tableHeaderText} ${modalTblFldInd+1}`
          }
        let err = validatInputParams(modalTblFlds.tableFields,headerText);
        if (err) {
          errFound = [...errFound, ...err];
        }
        })
      });
      if(mdlTemp.addNewRowFields && mdlTemp.addNewRowFields.length>0){
        headerText='';
        mdlTemp.addNewRowFields.forEach((addRowFlds,addRowInd) =>{
          if(addRowFlds.headers[0]?.tableHeaderText){
            headerText=`${addRowFlds.headers[0]?.tableHeaderText} ${addRowInd+2}`
          }
          let err = validatInputParams(addRowFlds.tableFields,headerText);
          if (err) {
            errFound = [...errFound, ...err];
          }
        })
      }
      if (errFound.length > 0) {
        let alertInfo = {
          alertType: "error",
          alertMessages: [...errFound],
        };
        this.setModalAlertMessages(alertInfo);
        return;
      }
      let uiObj = {};
      mdlTemp.modalFields.forEach(modal => {
        modal[modal.id].forEach(mf => {
          if(mf.showTotalInfo) return;
          let headers = mf.headers[0];
          if(!uiObj.hasOwnProperty(headers.tableRootPath)) uiObj[headers.tableRootPath] =[];
          let tempObj = {};
        if (headers.isAminities) { // header is under  aminities
            tempObj[headers.aminitiesRootPath] = [];
          mf.tableFields.forEach(f => {
            if (f.isAminities) { // field is under  aminities
              let aminObj = { amenityCode: f.filterValue, count: 100 }; aminObj[f.updtPath] = {};
              let amt = f.model.toString().trim();
              let amtCode = getAmtAndCurrencyCode(amt);
              f.combineStructure.forEach(stcr => {
                let value = '';
                if(stcr.target == 'model') {
                  value = amtCode[stcr.id] || stcr.defaultValue;
                } else {
                  value = stcr.defaultValue;
                }
                //let value = stcr.target == 'model' ? parseInt(f.model) : stcr.defaultValue;
                if (value) { aminObj[f.updtPath][stcr.id] = value }
              })
                tempObj[headers.aminitiesRootPath].push(aminObj);
            } else {
              if (f.updtPath) {
                if (f.combineStructure) {
                  let currObj = {};
                  let amt = f.model.toString().trim();
                  let amtCode = getAmtAndCurrencyCode(amt);
                  f.combineStructure.forEach(strctr => {
                    if(strctr.target == 'model') {
                      currObj[strctr.id] = amtCode[strctr.id] || strctr.defaultValue;
                    } else {
                      currObj[strctr.id] = strctr.defaultValue;
                    }
                    //currObj[strctr.id] = strctr.target == 'model' ? f.model : strctr.defaultValue;
                  })
                  headers.tableRootPath ? tempObj[f.updtPath] = currObj : uiObj[f.updtPath] = currObj;
                } else {
                  headers.tableRootPath ? tempObj[f.updtPath] = f.model || f.defaultValue : uiObj[f.updtPath] = f.model || f.defaultValue;
                }
              }
            }
          });
            uiObj[headers.tableRootPath].push(tempObj);
        }
        else {
          mf.tableFields.forEach(f => {
              f.updtPath ? uiObj[f.updtPath] = f.model || f.defaultValue : ''
          });
        }
      })
      })
      if(mdlTemp.addNewRowFields && mdlTemp.addNewRowFields.length>0){
        mdlTemp.addNewRowFields.forEach(addRowFlds =>{
          let headers = addRowFlds.headers[0];
          let newRowFldObj = {};
        if (headers.isAminities) { // header is under  aminities
          newRowFldObj[headers.aminitiesRootPath] = [];
          addRowFlds.tableFields.forEach(f => {
            if (f.isAminities) { // field is under  aminities
              let aminObj = { amenityCode: f.amenityCode, count: 100 }; aminObj[f.updtPath] = {};
              let amt = f.model?f.model.toString().trim():"";
              let amtCode = getAmtAndCurrencyCode(amt);
              f.combineStructure.forEach(stcr => {
                let value = '';
                if(stcr.target == 'model') {
                  value = amtCode[stcr.id] || stcr.defaultValue;
                } else {
                  value = stcr.defaultValue;
                }
                //let value = stcr.target == 'model' ? parseInt(f.model) : stcr.defaultValue;
                if (value) { aminObj[f.updtPath][stcr.id] = value }
              })
              newRowFldObj[headers.aminitiesRootPath].push(aminObj);
            } else {
              if (f.updtPath) {
                if (f.combineStructure) {
                  let currObj = {};
                  let amt = f.model?f.model.toString().trim():undefined;
                  let amtCode = getAmtAndCurrencyCode(amt);
                  f.combineStructure.forEach(strctr => {
                    if(strctr.target == 'model') {
                      currObj[strctr.id] = amtCode[strctr.id] || strctr.defaultValue;
                    } else {
                      currObj[strctr.id] = strctr.defaultValue;
                    }
                    //currObj[strctr.id] = strctr.target == 'model' ? f.model : strctr.defaultValue;
                  })
                  headers.tableRootPath ? newRowFldObj[f.updtPath] = currObj : uiObj[f.updtPath] = currObj;
                } else {
                  headers.tableRootPath ? newRowFldObj[f.updtPath] = f.model || f.defaultValue : uiObj[f.updtPath] = f.model || f.defaultValue ;
                }
              }
            }
          });
            }
            uiObj[headers.tableRootPath].push(newRowFldObj);
        })
      }
      uiObj["carrierCode"] = this.selectedRecord.carrierCode;
      uiObj["flightOrigin"] = this.selectedRecord['flightOrigin'];
      uiObj["flightNumber"] = this.selectedRecord['flightNumber'];
      uiObj["flightDate"] = this.selectedRecord['flightDate'];
      uiObj["employeeId"] = this.getEmployeeId;
      uiObj["station"] = this.selectedRecord['flightOrigin'];
      uiObj["channel"] = this.channel;
      uiObj["passengers"] = [];
      uiObj["passengers"].push({ passengerFirstName: uiObj.passengerFirstName, passengerLastName: uiObj.passengerLastName })
      delete uiObj.passengerFirstName;
      delete uiObj.passengerLastName;
      this.addPassenger(uiObj, selMode, mdlTemp)
    },
    async addPassenger(apiObj, operation, mdlTblFieldsInfo) {
      let isAuthorized = await this.authorizeModule({ operationId: 'addProcessPassenger', moduleId: 'report',isModalErr:true,origin:this.selectedRecord.flightOrigin })
      if (!isAuthorized) { return; }
      await addProcessPassenger(apiObj).then(async(res) => {
        if (res.status == 200) {
          if (res.data.isSuccessful) {
            this.setAlertMessages({
              alertType: "success",
              alertMessages: [`Passenger ${apiObj.passengers[0].passengerFirstName} ${apiObj.passengers[0].passengerLastName} ${operation} successfully`]
            })
            this.ClosePopup();
            if(this.getStatusValue() !='FINALIZED'){
              this.changeStatus('Volunteers Processed');
            }
            await this.navigateScreen();
          } else {
            let msgArray = this.addEditCustomerErrMSG(mdlTblFieldsInfo,res.data.messages);
            this.setModalAlertMessages({
              alertType: "warning",
              alertMessages: msgArray
            })
          }
        }
      }).catch(er => {
        let response = er.response;
        let msgArray = this.addEditCustomerErrMSG(mdlTblFieldsInfo,response.data.messages);
        this.setModalAlertMessages({
          alertType: "warning",
          alertMessages: msgArray
        })
      })
    },
    async navigateScreen(){ // navigating to report
      //update reportInlinefilter with default options when flight navigation with new flight data
      let isAuthorized = await this.authorizeModule({operationId: 'ua_get_flight_report',moduleId: 'report',origin: this.selectedRecord.flightOrigin})
      if(!isAuthorized){return; }
      this.setSelectedMenuId('report');
      let defaultOptions = {"type":"All","cabin":"All","compensation":"All","compensation_1": "All","pass_class":"All"};
      this.updatePrevOptions(defaultOptions);
      this.redirectToSpecificMenu('report');
    },
    async redirectToSpecificMenu(id){
      await this.getEntityDisplayDetailsAction(id).then(()=>{
        this.setSelectedMenuId(id);
      });
    },
    changeStatus(status) {
      let inObj = JSON.parse(JSON.stringify(this.selectedRecord || []));
      inObj['oversaleStatus'] = status;
      this.setSelectedRecord(inObj);
    },
}
};
</script>
<style scoped>
.u-margin-right-58 {
  margin-right: 58px;
}
</style>


