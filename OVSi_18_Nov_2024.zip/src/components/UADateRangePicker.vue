<template>
  <div class="datepicker u-row" id="datepicker" ref="dateRangeRef">

    <!-- Start of Display -->
    <div :class="['u-flex u-width-100', {'u-round u-border-err':this.err}]" tabindex="0">
      <div class="u-width-100">
        <label class="u-date-label"  :class="[isFloatLabel ? floatClass : cssLabel ? cssLabel : 'u-msmall']" :for="labelInfo" v-if="showLabel">
          {{ this.modelValue != "" ? this.labelInfo : !isFloatLabel ? this.labelInfo : this.placeholder }}
          <span class="u-small u-text-red" v-if="isMandatory && !isDisabled">*</span>
        </label>
        <input class="u-date-input" :class="['u-input u-border u-round u-datepicker-from-border u-padding-12', cssClass]"
          :value="getFormattedStartDate" @input="onStartTextInput($event, 'from')"  :disabled="isDisabled" id="startDate" @click="openFromDatePicker"
          autocomplete="off" :placeholder="dateFieldInfo?.datePlaceHolder || 'MM/DD/YYYY'" :maxlength="dateFieldInfo.attributes.maxlength"
          @mouseleave="prefixZeros($event, 'from','mouseleave')" @keypress="onKeyPressHandler($event)"
          @focus="onFocusHandler($event,'from','focus')"
          @keyup="keyUpHandler($event,'from','keyup')"
          @blur="prefixZeros($event, 'from','blur')"
          @paste="onPasteHandler($event)"/>
      </div>

      <div class="u-width-100">
        <input class="u-date-input"  :class="['u-input u-border-top u-border-bottom u-padding-12', cssClass]" :value="getFormattedEndDate "
          :disabled="isDisabled" autocomplete="off"  @input="onStartTextInput($event, 'to')" id="endDate" :placeholder="dateFieldInfo?.datePlaceHolder || 'MM/DD/YYYY'"
           @click="openToDatePicker" :maxlength="dateFieldInfo.attributes.maxlength"
           @mouseleave="prefixZeros($event, 'to','mouseleave')" @keypress="onKeyPressHandler($event)"
           @focus="onFocusHandler($event,'to','focus')"
           @keyup="keyUpHandler($event,'to','keyup')"
           @blur="prefixZeros($event, 'to','blur')"
           @paste="onPasteHandler($event)"/>
      </div>
      <!-- Date Icon -->
      <div class="u-border   u-round u-datepicker-to-border u-white" @mouseleave="mouseLeave()">
        <span class="spanDate u-pointer">
          <img src="../assets/img/calendar.png" alt="calendar icon" class="calendar-icon" @click="resetDate" />
        </span>
      </div>
    </div>
    <div class="u-tiny u-error" v-if="this.err">
      <svg width="14" height="14" fill="#D50032" viewBox="0 0 16 14" v-if="this.err">
        <path
          d="M8.982 1.566a1.13 1.13 0 0 0-1.96 0L.165 13.233c-.457.778.091 1.767.98 1.767h13.713c.889 0 1.438-.99.98-1.767L8.982 1.566zM8 5c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 5.995A.905.905 0 0 1 8 5zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z" />
      </svg>
      <span class="validPrefix">{{ this.$attrs?.validationPrefix }}</span>{{ this.err }}
    </div>
    <!-- Start of Main Pop Up  @blur="hideDatepicker" tabindex="1"  style="top: 135px;"-->
    <div id="mainPopup" v-if="showDatepicker" @mouseleave="mouseLeave()" @mouseover="mouseOver()" class="mainPopup" :class="[cssTclass,widthCssClass]">
       
      <!-- Start of Left panel -->
      <div class="datepicker-popup" 
        :class="[isYearPickerVisible ? 'hideDatepicker' : 'unhideDatepicker', cssFixedCal,]">
        <!-- header -->
        <div class="datepicker-header">
          <div class="u-col u-flex-center">
            <div class="u-col l2 m2 s2">
              <input type="button" @click="previousMonth('from')" id="button_prev_month" class="arrow" value="&lt;" />
            </div>
            <div class="u-col l12 m12 s12 u-center u-medium lf mf sf u-padding-top-1">
              <div class="u-col l12 m12 s12 u-flex-center u-display-space-evenly" style="" >
                  <label  >{{ getMonthName('from') }}
                  </label>
                  <label class="year-change" @click="yearPickerVisible()">{{ getSelectedYear() }}
                  </label>
              </div>
            </div>
            <div class="u-col l2 m2 s2 u-right-align">
              <input type="button" @click="nextMonth('from')" id="button_next_month" class="arrow" value="&gt;" />
            </div>
          </div>
          
        </div>
        
        <div class="picker">
          <div class="u-medium lf mf sf day-names">
            <span v-for="day in daysOfWeek" :key="day" class="dates">{{ day }}</span>
          </div>
          <div class="weekSpan">
            <span v-for="(week, index) in generateFromWeeks()" :tabindex="index" :key="index" class="u-medium lf mf sf days">
              <span v-for="day in week" :key="day.date" :id="getDateId(day.date)"
                :class="[getActiveDateRange(day),{'date-disabled': !isCurrentMonth(day.date), ' u-pointer-events-none': !isUnderDateLimits(day.date) }]"
                @click="selectDate(day.date, 'both')" class="date-cell"> {{ day.number }} </span>
            </span>
          </div>
        </div>
      </div>
     
    </div>
    <!-- END of DATEPICKER -->
    <!-- Start of Icon -->
    <div class="year-picker" @mouseleave="mouseLeave()" @mouseover="mouseOver()"  :class="[cssTclass, classcssFixedCal]" v-if="isYearPickerVisible">
      <div class="year-picker-popup">
        <div class="year-picker-header">
          <input type="button" @click="decrementYear" class="arrow" value="&lt;" />
          <span>{{ startYear }} - {{ endYear }}</span>
          <input type="button" @click="incrementYear" class="arrow" value="&gt;" />
        </div>
        <div class="year-picker-body">
          <span v-for="yearitem in yearList" :key="yearitem" >
            <span :id="yearitem"  :class="{ active: yearitem == selectedFromYear, 'current-year': isCurrentYear(yearitem) }" class="year-name"
            @click="selectYear(yearitem)">{{ yearitem }}
            </span>
          </span>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import { mapState, mapMutations, mapGetters } from "vuex";
import { getDefaultDate,createLocalDate,validateDateWithDDMM } from "@/helpers/utilities";
export default {
  name: "UADateRangePicker",
  data() {
    return {
      showDatepicker: false,
      fromDatePicker:false,
      toDatePicker: false,
      isYearPickerVisible: false,
      selectedFromDate: null,
      selectedFromYear: null,
      selectedFromMonth: null,
      selectedToDate: null,
      selectedToYear: null,
      selectedToMonth: null,
      yearList: [],
      startYear: new Date().getFullYear() - 9,
      endYear: new Date().getFullYear() + 10,
      daysOfWeek: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
      isStartDateValid: true,
      isEndDateValid: true,
      copyModelValue: { startDate: '', endDate: '' },
      enabledDates: [],
      err: "",
      mouseLeaveDetected: false,
      dateClickCount:0,
      yearClickCount:0,
      monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    };
  },
  props: ["modelValue", "startDate", "endDate", "id", "isDisabled", "labelInfo", "isFloatLabel", "isMandatory", "placeholder", "showLabel", "cssClass", "cssLabel", "isUppercase", "cssTclass", "cssFixedCal", "cssFixedTime", "onChangeFieldsToTrigger", "shrend", "dateFieldInfo", "design",'widthCssClass'],
  mounted() {
    this.setDefaultDateValues();
    this.generateYearList();
    this.copyModelValue = (this.startDate && this.endDate) ? { startDate: this.startDate, endDate: this.endDate } : {};
    this.enabledDates = this.dateLimits();  
    if (!this.$refs.dateRangeRef) return;
    document.addEventListener("click", (e) => this.handleClickEvent(e));
  },
  unmounted() {
    document.removeEventListener("click",  (e) => this.handleClickEvent(e));
  },
  watch: {
    startYear() {
      this.generateYearList();
    },
    endYear() {
      this.generateYearList();
    },
    selectedYear() {
      this.generateYearList();
    },
    
  },
  computed: {
    ...mapGetters(["getATRformatDateUTC", "getATRformatDate", "validateKeyPressInput"]),
    ...mapState({
      dateConfig: (state)=> state.ovsiDefaultModule?.applicationInfoDetails?.dateConfig,
      applicationInfoDetails: (state)=> state.ovsiDefaultModule?.applicationInfoDetails,
      getFormattedStartDate(){
        if(this.startDate && this.startDate.length == 10 && this.isStartDateValid){
          return this.getDatePart(createLocalDate(this.startDate), "dateString", this.dateConfig?.defaultShowDateFormat)
        } else if(this.startDate){
          return this.startDate;
        }
      },
      getFormattedEndDate() {
        if(this.endDate && this.endDate.length == 10 && this.isEndDateValid){
          return this.getDatePart(createLocalDate(this.endDate), "dateString", this.dateConfig?.defaultShowDateFormat)
        } else if(this.endDate){
          return this.endDate;
        }
      }
    }),
    floatClass() {
      return this.modelValue != "" ? "u-floatFly" : "u-float";
    },
  },
  methods: {
    ...mapMutations(["setCalendarDisabled"]),
    onPasteHandler(event){
      let pasteText = event.clipboardData.getData('text/plain');
      if(!this.validateInputText(pasteText) ){
        event.preventDefault();
      }
    },
    validateInputText(pasteText){
      if(this.dateFieldInfo && this.dateFieldInfo.attributes && this.dateFieldInfo.attributes.maxlength){
        if(pasteText.length > this.dateFieldInfo.attributes.maxlength) return false;
      }      
      if(this.dateFieldInfo.dataType && this.dateFieldInfo.dataType != '')  {
        let ptrnType = this.dateFieldInfo.dataType.split('_')[0];
        let dateRegex = new RegExp(this.applicationInfoDetails.keyPressInputPatterns[ptrnType]);
        if (!dateRegex.test(pasteText)) return false;
      } 
      return true;
    },
    getDateId(date){
      let m= this.monthNames[date.getMonth()].substring(0,3);
      let d= date.getDate();
      return `${m}${d}`;
    },
    setDateMonthYearValue(dtType, dt, isSetCurrYearMonthForEmptyDate=false, currDt){
      if(dtType == 'from'){
        this.selectedFromDate = dt ? dt : null;
        this.selectedFromMonth = dt ? dt.getMonth() : (isSetCurrYearMonthForEmptyDate ? currDt.getMonth() : null);
        this.selectedFromYear = dt ? dt.getFullYear() : (isSetCurrYearMonthForEmptyDate ? currDt.getFullYear() : null);
      } else {
        this.selectedToDate = dt ? dt : null;
        this.selectedToMonth = dt ? dt.getMonth() : (isSetCurrYearMonthForEmptyDate ? currDt.getMonth() : null);
        this.selectedToYear = dt ? dt.getFullYear(): (isSetCurrYearMonthForEmptyDate ? currDt.getFullYear() : null);
      }
    },
    setDefaultDateValues(){
      if(this.startDate.length > 0){
        let frmDt = this.getDatePart(createLocalDate(this.startDate));
        this.setDateMonthYearValue('from', frmDt);//IF DEFAULT DATE PRESENT THEN SET DEFAULT DATE 
      } else {
        let currFrmDt = this.getDatePart(createLocalDate(getDefaultDate()));
        this.setDateMonthYearValue('from', null, true, currFrmDt);//IF DEFAULT DATE NOT PRESENT THEN SET CURRENT MONTH AND YEAR
      }
      if(this.endDate.length > 0){
        let toDt = this.getDatePart(createLocalDate(this.endDate));
        this.setDateMonthYearValue('to', toDt);
      } else {
        let currToDt = this.getDatePart(createLocalDate(getDefaultDate()));
        this.setDateMonthYearValue('to', null, true, currToDt);
      }
    },
    onKeyPressHandler(event){
      if(!this.validateKeyPressInput(event,this.dateFieldInfo.dataType)){
        event.preventDefault();
      }
    },
    keyUpHandler(e,type){
      if(e.type == "keyup" && e.key == "Tab"){//IF FOCUS COMING FROM ON TAB CHANGE EVENT NOT ONCLICK EVENT
        if(type == 'to'){
          this.fromDatePicker = false;
          this.toDatePicker = true;
        } else if(type == 'from'){
          this.toDatePicker = false;
          this.fromDatePicker = true;
        } 
      } 
    },
    onFocusHandler(e,type, evntType) {
      this.mouseLeaveDetected = false;         
    },
    prefixZeros(e,type, evntType) {
        if(evntType == "mouseleave"){
          this.mouseLeaveDetected = true;
        }
        if(e.target.value.length == 0 || e.target.value.length == 10){
          return;
        }
        let str = e.target.value;
        let mon, day, yyyy, strArr, finalStr = str;
        if (str.includes("/")) {
          strArr = str.split("/");
          if (strArr.length === 3) {
            mon = `${strArr[0]}`
            day = `${strArr[1]}`
            yyyy = `${strArr[2]}`
             mon = mon != "0" ? ("0" + mon).slice(-2) : mon;
             day = day != "0" ? ("0" + day).slice(-2) : day;
             finalStr = `${mon}/${day}/${yyyy}`;
             let dtStr= `${type == "from" ? "startDate" : "endDate"}`;
             this.$emit(`update:${dtStr}`, finalStr);    
            if(this.validateDateFormat(finalStr, type)){
              if(type == 'from'){
                  this.setDateMonthYearValue('from', this.getDatePart(new Date(finalStr)));
                  if(!this.isEndDateValid) {
                    this.validateDateFormat(this.endDate, 'to');
                  }          
                  this.$emit("update:startDate", this.getDatePart(new Date(finalStr),"dateString"));       
                } else {
                  this.setDateMonthYearValue('to', this.getDatePart(new Date(finalStr)));
                  this.$emit("update:endDate", this.getDatePart(new Date(finalStr),"dateString")); 
                  if(!this.isStartDateValid) {
                    this.validateDateFormat(this.startDate, 'from');
                  }
                }
                //IF BOTH DATE FORMAT IS VALID THEN COMPARE THEN RANGE
                if(this.isStartDateValid && this.isEndDateValid) {
                  this.validateDateRange(this.selectedFromDate,this.selectedToDate); 
                }
                if(this.onChangeFieldsToTrigger != undefined && this.onChangeFieldsToTrigger.length >0){
                  this.$emit("callApiOnDateChange", this.getDatePart(new Date(finalStr),"dateString"));
               }
            }
          }
        }
      },
    onStartTextInput(e, type){
      let text = e.target.value;        
      if(text.length == 0){//when we clear the date set default current month and year
        let currDt = this.getDatePart(createLocalDate(getDefaultDate()));
        if(type == 'from'){
          this.selectedFromDate = null;
          this.selectedFromMonth = currDt ? currDt.getMonth(): null;
          this.selectedFromYear = currDt ? currDt.getFullYear() : null;
        } else {
          this.selectedToDate = null;
          this.selectedToMonth = currDt ? currDt.getMonth(): null;
          this.selectedToYear = currDt ? currDt.getFullYear() : null;
        }
        this.$emit(`update:${type == 'from' ? "startDate" : "endDate"}`, ''); 
        this.validateDateFormat(text, type);
        return;
      }
      let ln = parseInt(text.length);
      if( ln == 2 ){
        if(!text.includes("/")){
        this.$emit(`update:${type == 'from' ? "startDate" : "endDate"}`, e.inputType == "deleteContentBackward"? text:`${text}/`);       
        }
      }else if(ln == 5){
        if(!text.substring(4,5).includes("/") && text.lastIndexOf("/") <= 2){
          this.$emit(`update:${type == 'from' ? "startDate" : "endDate"}`, e.inputType == "deleteContentBackward"? text:`${text}/`);
        }
      }
      else {
        this.$emit(`update:${type == 'from' ? "startDate" : "endDate"}`, text); 
      }
      let isValid = this.validateDateFormat(text, type);
      if(isValid){  
        if(type == 'from'){
          this.setDateMonthYearValue('from', this.getDatePart(new Date(text)));
          if(!this.isEndDateValid) {
            this.validateDateFormat(this.endDate, 'to');
          }          
          this.$emit("update:startDate", this.getDatePart(new Date(text),"dateString"));       
        } else {
          this.setDateMonthYearValue('to', this.getDatePart(new Date(text)));
          this.$emit("update:endDate", this.getDatePart(new Date(text),"dateString")); 
          if(!this.isStartDateValid) {
            this.validateDateFormat(this.startDate, 'from');
          }
        }
        //IF BOTH DATE FORMAT IS VALID THEN COMPARE THEN RANGE
        if(this.isStartDateValid && this.isEndDateValid) {
          this.validateDateRange(this.selectedFromDate,this.selectedToDate); 
        }           
       } 
      
    },
    validateDateFormat(text, type){
      if(!this.isMandatory && text.length == 0 ){
         //IF BOTH DATES ARE EMPTY THEN DON'T SHOW ERROR MESSAGE WHEN DATE RANGE FIELD IS NOT MANDATORY FIELD
        type == 'from' ? this.isStartDateValid = true : this.isEndDateValid = true;
        if((type == 'from' && this.endDate.length == 0) || (type == 'to' && this.startDate.length == 0)){         
          this.err = '';
          if(this.dateFieldInfo) {
            this.dateFieldInfo.isError =  false;
            this.dateFieldInfo.dislayError = this.err
          }
        } 
        else if((type == 'from' && this.isEndDateValid == true) || (type == 'to' && this.isStartDateValid == true) ){
          //IF ANY ONE VALID DATE IS SELECTED AND ONE DATE IS EMPTY THEN RESET THE ERROR
          this.err = '';
          if(this.dateFieldInfo) {
            this.dateFieldInfo.isError =  false;
            this.dateFieldInfo.dislayError = this.err
          }
        } 
        return true;
      }
      if(text.length != 10){
        this.err = `Length of ${type == 'from' ? 'Start ' : 'End'} Date should be 10`;
        if(this.dateFieldInfo) {
          this.dateFieldInfo.isError =  true;
          this.dateFieldInfo.dislayError = this.err
        }
        type == 'from' ? this.isStartDateValid = false : this.isEndDateValid = false;
        return false;
      } 
      if(this.isValidDate(text)){
        type == 'from' ? this.isStartDateValid = true : this.isEndDateValid = true;
        this.err = '';
        if(this.dateFieldInfo) {
          this.dateFieldInfo.isError =  false;
          this.dateFieldInfo.dislayError = this.err
        }
        return true;       
      } else {
        this.err = `Invalid ${type == 'from' ? 'Start ' : 'End'} Date found `;
        if(this.dateFieldInfo) {
          this.dateFieldInfo.isError =  true;
          this.dateFieldInfo.dislayError = this.err
        }
        type == 'from' ? this.isStartDateValid = false : this.isEndDateValid = false;
        return false;
      }
    },
    isValidDate(str){
      let  regEx = new RegExp(this.dateConfig.defaultDatePattern); ///^\d{4}-\d{2}-\d{2}$/;
      if(!str.match(regEx)) 
       return false;
      let isvalid = validateDateWithDDMM(str);
      if(!isvalid) return false;//IF DAYS AND MONTH NOT PROPER THEN INVALIDATE THE DATE
      let dt = createLocalDate(str,false)//false for to consider the entered month number
      return dt.toString()  != 'Invalid Date';
    },
    getActiveDateRange(date){
      if(!date) return false;
      let dtToCompare = new Date(date.date);
      if(this.toDatePicker && (this.isEndDateValid && this.selectedToDate && (dtToCompare.toDateString() === this.selectedToDate.toDateString()))){
        return 'active';
      } else if (this.fromDatePicker && (this.isStartDateValid && this.selectedFromDate &&(dtToCompare.toDateString() === this.selectedFromDate.toDateString()))){
        return 'active';
      } else if((!this.toDatePicker && !this.fromDatePicker) && 
        (this.isStartDateValid && this.selectedFromDate &&(dtToCompare.toDateString() === this.selectedFromDate.toDateString()) 
        || (this.isEndDateValid && this.selectedToDate && (dtToCompare.toDateString() === this.selectedToDate.toDateString())))){
          return 'active';
      } else if((!this.toDatePicker && !this.fromDatePicker) && this.selectedFromDate && this.selectedToDate && dtToCompare >= this.selectedFromDate && dtToCompare <= this.selectedToDate){
        return 'in-range-active-class';
      }
    },
    resetDataRange(){
      this.err = "";
      this.isStartDateValid =true;
      this.isEndDateValid =true;
      setTimeout(() => {
        this.setDefaultDateValues();        
      }, 10)  
      this.showDatepicker = false;
      this.isYearPickerVisible = false;
      this.mouseLeaveDetected = false;
    },
    getDatePart(date, type = "date",formatDate){
      if(!date) {
        return;
      }
      else{
        let year = date.getFullYear();
        let month = date.getMonth();
        let dd = date.getDate();
        let datePart = createLocalDate(month+"/"+dd+"/"+year);
        year = datePart.getFullYear();
        month = datePart.getMonth();
        dd = datePart.getDate();
      if(type == "date"){
        return datePart;
      } else if(type == "dateString"){
        let mm = month+1;
        let mon = ("0" + mm).slice(-2);
		    let day = ("0" + dd).slice(-2);
        if(formatDate == "MM-DD-YYYY"){
          return  mon + "-" + day + "-" + year;
        } else if(formatDate == "MM/DD/YYYY"){
          return  mon + "/" + day + "/" + year;
        } else {
          return year  + "-" + mon + "-" + day;
        }        
      }   
     }   
    },
    dateLimits() {
      let limits = [];
      let currentDate = new Date();
      if (!this.dateFieldInfo?.disableFutureDateSelection) {
        currentDate.setDate(currentDate.getDate() + this.dateFieldInfo?.daysLimit);
      }
      let startDate = new Date();
      if (!this.dateFieldInfo?.disablePastDateSelection) {
        startDate.setDate(startDate.getDate() - (this.dateFieldInfo?.daysLimit - 1));
      }
      while (startDate <= currentDate) {
        limits.push({ date: new Date(startDate), number: startDate.getDate(), month: startDate.getMonth(), year: startDate.getFullYear() });
        startDate.setDate(startDate.getDate() + 1);
      }
      return limits;
    },
    generateFromWeeks() {
      let weeks = [];
      let currentWeek = [];
      let year = this.getSelectedYear();//this.selectedFromYear;
      let month = this.toDatePicker ? this.selectedToMonth : this.selectedFromMonth;//this.selectedFromMonth;
      let currentDate = new Date(year, month, 1);
      let startDate = new Date(currentDate);
      startDate.setDate(startDate.getDate() - currentDate.getDay());
      while (startDate.getMonth() === month || currentWeek.length < 7 || weeks.length < 5) {
        if (currentWeek.length > 0 && startDate.getDay() === 0) {
          weeks.push(currentWeek);
          currentWeek = [];
        }
        currentWeek.push({ date: new Date(startDate), number: startDate.getDate(), month: startDate.getMonth(), year: startDate.getFullYear() });
        startDate.setDate(startDate.getDate() + 1);
      }
      weeks.push(currentWeek);
      return weeks;
    },
    mouseOver(){
      this.mouseLeaveDetected = false;
    },
    mouseLeave(){
      this.showDatepicker ? this.mouseLeaveDetected = true : this.mouseLeaveDetected = false;
    },
    openFromDatePicker(event) {
      if(this.isStartDateValid && this.selectedFromDate){
        let fmtdt =this.getDatePart(new Date(this.selectedFromDate));
        this.selectedFromMonth = fmtdt.getMonth();
        this.selectedFromYear = fmtdt.getFullYear();
      }
      this.toDatePicker = false;
      this.fromDatePicker = !this.fromDatePicker;      
      this.showDatepicker = this.fromDatePicker;
      this.isYearPickerVisible = false;     
      //this.isYearPickerVisible = this.showDatepicker;
      
      document.removeEventListener("click",  (e) => this.handleClickEvent(e));      
      this.mouseLeaveDetected = false;
      document.getElementById('mainPopup') && document.getElementById('mainPopup').focus(); 
    },
    openToDatePicker(event) {    
      if(this.isEndDateValid && this.selectedToDate){
        let ftodt =this.getDatePart(new Date(this.selectedToDate));
        this.selectedToMonth = ftodt.getMonth();
        this.selectedToYear = ftodt.getFullYear();
      }
      this.fromDatePicker = false;
      this.toDatePicker = !this.toDatePicker;
      this.showDatepicker = this.toDatePicker;
      this.isYearPickerVisible = false;
      
      document.removeEventListener("click",  (e) => this.handleClickEvent(e));      
      this.mouseLeaveDetected = false;
      document.getElementById('mainPopup') && document.getElementById('mainPopup').focus(); 
    },
    resetDate(event) {    
      this.dateClickCount = 0;
      this.yearClickCount = 0;
      this.showDatepicker = !this.showDatepicker;
      this.isYearPickerVisible = false;
      this.toDatePicker = false;
      this.fromDatePicker = false
      document.removeEventListener("click",  (e) => this.handleClickEvent(e));      
      this.mouseLeaveDetected = false;
      document.getElementById('mainPopup') && document.getElementById('mainPopup').focus();
    },
    //end
    handleClickEvent(event) {
      if(this.mouseLeaveDetected && this.showDatepicker){
        //if (event.target !== this.$refs.dateRangeRef && event.composedPath().includes(this.$refs.dateRangeRef)) {
        if (this.$refs.dateRangeRef && !this.$refs.dateRangeRef.contains(event.target)) {
          this.showDatepicker = false;
          this.isYearPickerVisible = false;
          this.fromDatePicker = false;
          this.toDatePicker = false;
          this.mouseLeaveDetected = false;
        }
      }
    },
    isCurrentMonth(date) {
      return date.getMonth() === (this.toDatePicker ? this.selectedToMonth : this.selectedFromMonth);
    },
    isCurrentDate(date) {
      return (
        date.getDate() === new Date().getDate() &&
        date.getMonth() === new Date().getMonth() &&
        date.getFullYear() === new Date().getFullYear()
      );
    },
    isCurrentYear(yearname) {
      return new Date(yearname).getFullYear() === new Date().getFullYear();
    },
    selectYear(years) {
      // this.selectedYear = years;      
      if(this.toDatePicker){//INDIVIDUAL DATE SELECTION
        this.selectedToYear = years;
      } else if(this.fromDatePicker){
        this.selectedFromYear = years;
       } else {//WHEN WE OPEN FROM CALENDER ICON TO SELECT THE START AND END DATE ONE BY ONE
        this.yearClickCount +=1;
        if(this.yearClickCount == 1){
          this.selectedFromYear = years;
        } else if(this.yearClickCount == 2) {
          this.selectedFromYear = years;
        }
      }
      this.isYearPickerVisible = false;
      this.showDatepicker = true;
    },
    incrementYear() {
      this.startYear += 10;
      this.endYear += 10;
    },
    decrementYear() {
      this.startYear -= 10;
      this.endYear -= 10;
    },
    generateYearList() {
      let years = [];
      for (let year = this.startYear; year <= this.endYear; year++) {
        years.push(year.toString());
      }
      this.yearList = years;
    },
    yearPickerVisible() {
      //this.showDatepicker = false;
      this.isYearPickerVisible = !this.isYearPickerVisible;
    },
    validateDateRange(frmDt, toDt){
      // fromDT should not gt toDateIF BOTH DATES PRESENT
      if(!frmDt || !toDt) return;
      if (frmDt && toDt && (frmDt > toDt) && !(frmDt?.getDate() == toDt?.getDate() && frmDt?.getFullYear() == toDt?.getFullYear() && frmDt?.getMonth() == toDt?.getMonth())) {
        //this.isStartDateValid = false;
        this.err = "From date should be less than To date.";
        if(this.dateFieldInfo) {
          this.dateFieldInfo.isError =  true;
          this.dateFieldInfo.dislayError = this.err;
        } 
        return false;
      }
      else {
        //this.isStartDateValid = true;
        this.err = "";
        if(this.dateFieldInfo) {
          this.dateFieldInfo.isError =  false;
          this.dateFieldInfo.dislayError = "";
        }
        return true;
      }
    },
    selectBothDate(date, type) {
      //IF WE SELECT DATE THROUGH CALENDER ICON INSTEAD OF CLICKING ON INDIVIDUAL DATES
      let y = date ;//new Date(date);
      if(!this.selectedFromDate){
        this.setDateMonthYearValue('from', y);
        this.isStartDateValid = true;
        this.emitModels(y, 'from');
        if(this.selectedFromDate && this.selectedToDate){
          this.validateDateRange(this.selectedFromDate, this.selectedToDate); //to validate date range on selction of to date
        }
      } else if(!this.selectedToDate){
        this.isEndDateValid = true;
        this.setDateMonthYearValue('to', y);
        this.validateDateRange(this.selectedFromDate, this.selectedToDate); //to validate date range on selction of to date
        this.emitModels(y, 'to')
        this.showDatepicker = false;
      } else if(this.selectedFromDate && this.selectedToDate){
        if(this.dateClickCount == 1){
          this.setDateMonthYearValue('from', y);
          this.emitModels(y, 'from');
          this.isStartDateValid = true;
          if(this.isEndDateValid){
            this.validateDateRange(this.selectedFromDate, this.selectedToDate); //to validate date range on selction of to date
          }
        } else if(this.dateClickCount == 2) {
          this.setDateMonthYearValue('to', y);
          this.emitModels(y, 'to');
          this.isEndDateValid = true;
          this.hideDatepicker();
          if(this.isStartDateValid){
            this.validateDateRange(this.selectedFromDate, this.selectedToDate); //to validate date range on selction of to date
          } 
        }
      }
    },
    selectDate(date, type) {
      this.isYearPickerVisible = false;
      let y = date ;//new Date(date); //&& (type === '0' ||  type === '1')
      if(this.toDatePicker){
        this.setDateMonthYearValue('to', y);
        this.isEndDateValid = true;
        this.emitModels(y, 'to');
        this.hideDatepicker();
        this.toDatePicker = false;
        if(this.isStartDateValid){
          this.validateDateRange(this.selectedFromDate, this.selectedToDate); //to validate date range on selction of to date
        }        
      }else if(this.fromDatePicker){
        this.setDateMonthYearValue('from', y);
        this.isStartDateValid = true;
        this.emitModels(y, 'from')
        this.hideDatepicker();
        this.fromDatePicker = false;
        if(this.isEndDateValid){
          this.validateDateRange(this.selectedFromDate, this.selectedToDate); //to validate date range on selction of to date
        }
      }else{
        this.dateClickCount += 1; 
        this.selectBothDate(date,type);
      }
    
    },
    previousMonth() {
      if(this.toDatePicker){
        if (this.selectedToMonth === 0) {
          this.selectedToMonth = 11;
          this.selectedToYear -= 1;
        } else {
          this.selectedToMonth -= 1;
        }
      } else {
        if (this.selectedFromMonth === 0) {
          this.selectedFromMonth = 11;
          this.selectedFromYear -= 1;
        } else {
          this.selectedFromMonth -= 1;
        }
      }
    },
    nextMonth(type) {
      if(this.toDatePicker){
        if (this.selectedToMonth === 11) {
          this.selectedToMonth = 0;
          this.selectedToYear += 1;
        } else {
          this.selectedToMonth += 1;
        }
      } else {
        if (this.selectedFromMonth === 11) {
          this.selectedFromMonth = 0;
          this.selectedFromYear += 1;
        } else {
          this.selectedFromMonth += 1;
        }
      }
    },
    getMonthName(type) {
      return this.monthNames[this.toDatePicker ? this.selectedToMonth : this.selectedFromMonth];
    },
    getSelectedYear() {
      return this.toDatePicker ? this.selectedToYear : this.selectedFromYear;
    },
    getYear(date) {
      return new Date(date).getFullYear();
    },
    hideDatepicker() {
      this.showDatepicker = false;
    },
    isUnderDateLimits(date) {
      let selectedDate = new Date(date);
      let y = selectedDate.getFullYear(), m = selectedDate.getMonth(), d = selectedDate.getDate();
      return this.enabledDates.find(limit => limit.number == d && limit.month == m && limit.year == y);
    },
    emitModels(date, source) {
      if (source == 'from') {
        this.$emit("update:startDate", this.getDatePart(date,"dateString"));
      } else {
        this.$emit("update:endDate", !date ? date : this.getDatePart(date,"dateString"));
      }
    }
  },
};
</script>
  
<style scoped>
.datepicker {
  position: relative;
}

.datepicker-popup {
  width: 100%;
  background-color: #fff;
  border: 1px solid #ccc;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
  z-index: 10;
  padding: 10px;
}

.datepicker>input {
  padding: 0 3px !important;
}

.datepicker-header {
  display: flex;
  justify-content: space-between;
  padding: 10px;
  /* border-bottom: 1px solid #ccc; */
}

.year-change {
  cursor: pointer;
}

.days {
  display: grid;
  grid-template-columns: repeat(7, 14%);
  justify-items: center;
}

.day-names {
  display: grid;
  grid-template-columns: repeat(7, 14%);
  justify-items: center;
  font-weight: bold;
  padding-top: 0.3rem;
}

.date-cell {
  padding: 5px;
  cursor: pointer;
  width: 100%;
  text-align: center;
}

.date-disabled {
  color: #b1b1b1;
}

.year-picker {
  display: inline-block;
  font-size: 14px;
  color: #333;
  top: 31px;
  z-index: 999;
  right: 16%;
  position: absolute;
}

.year-picker label {
  display: inline-block;
  margin-right: 10px;
}

.year-picker .year-picker-popup {
  width: 21vw;
  background-color: #fff;
  border: 1px solid #ccc;
  border-radius: 3px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
  padding: 8px;
  overflow: hidden;
  height: 35vh;
}

.year-picker .year-picker-popup .year-picker-header {
  display: flex;
  justify-content: space-between;
  padding-bottom: 5px;
  align-items: center;
  border-bottom: 1px solid #ccc;
}

.year-picker .year-picker-popup .year-picker-body {
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  grid-template-rows: repeat(5, 1fr);
  grid-gap: 5px;
  margin: 0;
  padding: 0;
}

.year-name {
  display: flex;
  align-items: center;
  justify-content: center;
  height: 30px;
  background-color: #fff;
  cursor: pointer;
}

.date-today {
  border: 1px solid #6244bb;
  color: #6244bb;
  font-weight: bold;
}

.current-year {
  border: 1px solid #6244bb;
  color: #6244bb;
  font-weight: bold;
}

.year-name:hover {
  background-color: #c0aef5;
  color: white;
}

.date-cell:hover {
  background-color: #c0aef5;
  color: white;
}

.year-name.active {
  background-color: #6244bb;
  color: white;
  font-weight: bold;
}

.date-cell.active {
  background-color: #6244bb;
  color: white;
  font-weight: bold;
}

.date-cell.in-range-active-class {
  background-color: #c0aef5;
  color: white;
  font-weight: bold;
}

.hideDatepicker {
  visibility: hidden;
}

.unhideDatepicker {
  visibility: visible;
}

.datepicker>span {
  display: inline-block;
}

.dateDivision {
  width: 100%;
  padding: 1px 0px;
  border: 1px solid #ccc;
  border-radius: 6px;
  height: 40px;
  color: #2c63a4 !important;
  overflow: hidden;
}

.dateDiv {
  width: 50%;
  padding: 1px 0px;
  border: 1px solid #ccc;
  border-radius: 6px;
  height: 40px;
  color: #2c63a4 !important;
  overflow: hidden;
  position: relative;
  margin: 10px 2.5px 20px 2.5px;
}

.dateDiv1 {
  width: 50%;
  padding: 1px 0px;
  border: 1px solid #ccc;
  border-radius: 6px;
  height: 40px;
  color: #2c63a4 !important;
  overflow: hidden;
}

.dateInput {
  width: 84%;
  float: left;
  border: none !important;
  padding: 0px 0px;
  height: 100%;
  text-align: center;
}

.dateInput:active,
.dateInput:focus {
  border: none !important;
}

.spanDate {
  width: 16%;
  display: flex;
  margin: 0px auto;
  justify-content: center;
  /* border-left: 1px solid #ccc; */
  border: 0px;
}

.calendar-icon {
  padding: 4px 0px;
  height: 32px;
  width: 36px;
  display: flex;
  align-items: center;
  margin-top:10px;
}

.arrow {
  border: none;
  background-color: #fff;
  cursor: pointer;
}

.time-picker {
  width: 7vw;
  z-index: 9;
  background-color: #fff;
  border: 1px solid #ccc;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
  padding: 2px 5px 2px 4px;
  border-radius: 5px;
}

.time-inner-div {
  display: flex;
  justify-content: space-between;
  height: 230px;
  z-index: 9;
  background-color: #fff;
  border-radius: 5px;
}

/* li{
    list-style-type: none;
    cursor: pointer;
    
  }
  li :hover{
    background-color: #6244BB;
    color: white;
    font-weight: bold;
  } */

.time-column {
  height: 100%;
  width: 44.33%;
  overflow-y: scroll;
  overflow-x: hidden;
}

.time-column>ul {
  padding: 0;
}

li.time-value {
  padding: 5px 2px !important;
}

.time-value.active {
  font-weight: bold;
  background-color: #6244bb;
  color: white;
}

.time-value:not(.active) .time-value {
  color: #ccc;
}

.time-value {
  list-style-type: none;
  cursor: pointer;
  padding: 5px;
}

.time-value:hover {
  background-color: #c0aef5;
  color: #333;
}

.time-transform {
  transform: translate(28vw, -17vh);
}

.time-transform-h1 {
  transform: translate(23rem, -2rem);
}

.cal-options {
  display: flex;
}

.cal-options input {
  margin: 0 auto;
  padding: 6px 4px;
  font-weight: bold;
  border: none;
  background: none;
  cursor: pointer;
}

.mainPopup {
  position: absolute;
  display: flex;
  z-index: 9999;
  width: 88%;
}


label {
  pointer-events: none;
  left: 12px;
  transition: 0.2s;
}

input:valid~label {
  top: -8px;
  left: 12px;
}

input:focus~label {
  top: -8px;
  left: 12px;
}

.u-datepicker-from-border {
  border-top-right-radius: 0px;
  border-bottom-right-radius: 0px;
}

.u-datepicker-to-border {
  border-top-left-radius: 0px;
  border-bottom-left-radius: 0px;
}


.u-date-label {
  position: absolute;
  left: 0;
  padding: 0 !important;
  margin-left: 4px;
  font-size: 11px !important;
  top: -2px;
}
.u-date-input{
    font-size: 12px !important;
    padding: 26px 0 3px 4px !important;
    color: #2C63A4;
  }


  .u-padding-top-1{
    padding-top: 1px;
  }
</style>