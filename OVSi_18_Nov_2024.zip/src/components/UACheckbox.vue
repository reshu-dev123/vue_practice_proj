<template>
  <div class="ua-checkbox" :class="cssClass" :id="id">
    <div class="checkbox-options ">
      <template v-if="isDynamicRowCol">
        <div v-for="(op,opInex) in updatedList" class="u-row" :key="opInex">
          <label
            v-for="(option, i) of op"
            :key="i+opInex" 
            :for="option"
            :class="['item u-margin-left-14 u-col l18 m18 s18',cellfontCss, disbaledIfIndxMtc(i) && 'u-disabled']"
          >
            <span > {{ option }} </span>
            <input  
              :id="option"
              v-model="checked"
              type="checkbox"
              :value="option"
              @change="onChange(option)"
              class="u-check"
            >
            <span :class="['checkmark',cssClass, disabled ? 'u-disabled':' ']"     />
          </label>
        </div>
      </template>
      <template v-else-if="!isDynamicRowCol && optionsType == 'ObjectArr'"> 
        <label
          v-for="(option, i) of options"
          :key="i"
          :for="option.id+id"
          :class="['item u-margin-left-14',cellCss]"
        >
          <span :for="option.id+id">{{ option.label }}</span>
          <input  
            :id="option.id+id"
            type="checkbox"
            :disabled=disabled
            v-model="checked"
            :value="option.id"
            @change="onChange(option)"
            class="u-check"
          >
          <span :class="['checkmark',cssClass, disabled ? 'u-disabled':' ']"     />
        </label>
      </template>
      <template v-else-if="!isDynamicRowCol">
        <label
          v-for="(option, i) of options"
          :key="i"
          :class="['item',cellCss]"
          :for="option"
        >
          <span :for="option">{{ option }}</span>
          <input  
            :id="option"
            v-model="checked"
            type="checkbox"
            :disabled=disabled
            :value="option"
            @change="onChange(option)"
            class="u-check"
          >
          <span :class="['checkmark',cssClass, disabled ? 'u-disabled':' ']"     />
        </label>
      </template>
    </div>
  </div>
</template>
<script>
import { mapMutations } from "vuex";
  export default {
  name: 'UACheckbox',
  created() {
    if(this.checkedProps){
      this.checked=this.checkedProps;
      this.$emit('selectedItem', this.checked,this.checkedProps, this.checked.length > 0 ? true : false);
    }
    // this.splitedOptions.push(this.options);
   this.crows= this.options.length%20==0?this.options.length/20:(this.options.length/20)+1;
  },
  data(){
    return {
      checked: [],
      splitedOptions: []
    };
  },
watch: {
  checkedProps(newV,old){
    this.checked = newV;
    if(newV){
      this.checked=newV;
      //this.$emit('selectedItem', this.checked,newV, this.checked.length > 0) ;
      if(this.checked.length == 0){
        this.setDisableExport(true)
      } else{
        this.setDisableExport(false)
      }
    }
  }
},
  props: {
    isDynamicRowCol: {
      type : Boolean,
      required: false,
      default: ()=>false
    },
    options: {
    type: Array,
    required: false,
    default: () => []
  },
  checkedProps: {
    type: Array,
    required: false,
    default: () => []
  },
  disabled: {
    type: Boolean    
  },
  cssClass:"",
  cellCss: "",
  cellfontCss:"",
  optionsType:"",
  id:{
    type: String,
    required: false,
    default: ()=>Date.now().toString()
  },
  enabledIndexs:{
    type : Array,
      required: false,
      default: ()=>[]
  }
},
computed:{
  updatedList(){
    this.splitedOptions=[]
    this.splitedOptions.push(this.options)
    return this.splitedOptions
  }
},
methods: {
  ...mapMutations(["setDisableExport"]),
  disbaledIfIndxMtc(i){
   return this.enabledIndexs.length>0?!this.enabledIndexs.includes(i):this.disabled;
  },
  onChange(item) {
    this.$emit('selectedItem', this.checked,item, this.checked.length > 0 ? true : false);
  }
}
  }
</script>

<style scoped>
.ua-checkbox {
display: block;
flex-direction: column;
align-items: center;
}

.ua-checkbox .checkbox-options {
display: block;
flex-direction: column;
align-items: left;
width: 100%;
}

.ua-checkbox label {
margin-left: 1rem;
}

.ua-checkbox .item {
display: block;
position: relative;
padding-left: 28px;
cursor: pointer;
font-size: 1rem;
height: 30px;
-webkit-user-select: none;
-moz-user-select: none;
-ms-user-select: none;
user-select: none;
display: flex;
align-items: center;
}

.ua-checkbox .item input {
position: absolute;
opacity: 0;
cursor: pointer;
height: 0;
width: 0;
}

.ua-checkbox .checkmark {
  position: absolute;
  /* top: 0; */
  left: 0;
  height: 18px;
  width: 18px;
  background-color: #fff;
  border: 1px solid grey;
  border-radius: 10%;
}

/* .ua-checkbox .item:hover input ~ .checkmark {
background-color: #949494;
} */

.ua-checkbox .item input:checked ~ .checkmark {
  background-color: #002244;
}

.ua-checkbox .checkmark:after {
content: "";
position: absolute;
display: none;
}

.ua-checkbox .item input:checked ~ .checkmark:after {
display: block;
}

.ua-checkbox .item .checkmark:after {
left: 6px;
top: 2px;
width: 6px;
height: 10px;
border: solid white;
border-width: 0 3px 3px 0;
-webkit-transform: rotate(45deg);
-ms-transform: rotate(45deg);
transform: rotate(45deg);
}
</style>