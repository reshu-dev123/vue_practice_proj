<template>
  <div 
  :class="[tableBorderCSS]">
    <div :class="[sectionHeader.cssClass]" v-if="sectionHeader">
      <div :class="[sectionHeader.textCSSClass]">
        <label>{{ sectionHeader.headerText || " " }}</label>
      </div>
    </div>
    <div class="u-row" v-if="showHeader">
      <div :class="['u-col l12 m12 s12',tblHeaders?.paddingClass,tblHeaders?.paddingClass?'u-border-bottom-lt':'']">
        <template v-for="(header, tKey) in tblHeaders.headerValues" :key="tKey">
          <div
            :class="[
              tblHeaders.cssClass,
              header && typeof header === 'object'
                ? header.colWiseCss
                : (tblHeaders.cssColClass || tblHeaders?.colWiseCssClass[tKey]),
              tblHeaders.css
            ]"
          >
            <div :class="[tblHeaders?.labelCssClass]">
              <label>{{
                header && typeof header === "object"
                  ? header.text
                  : header || " "
              }}</label>
            </div>
          </div>
        </template>
      </div>
    </div>

    <div class="u-row" v-if="tableData && tableData.length == 0">
       <template v-for="(i,index) in [1]" :key="index">
          <div >
            <span class="u-center u-fnt-bld"> No data Found ! </span>
          </div>
        </template>
    </div>
    <div :class="['u-col',contentScroll]" v-else>
      <template v-for="(tblField, rKey) in tableFields" :key="rKey">
        <div :class="[tblField?.subFields ? ['u-col l12 m12 s12',tblHeaders?.dataRowCss] : '',tblHeaders?.paddingClass,tblHeaders?.paddingClass?(tableFields.length==rKey+1)?'no-bottom-border':'u-border-bottom-lt':'']"
        :style="[tblHeaders?.bgColor?[(rKey + 1) % 2 == 0 ?  {}:{ 'background-color': '#E6E6E6' }]:[]] ">
          <template
            v-for="(subField, tKey) in getTableFields(tblField)"
            :key="tKey"
          >
            <div :class="[tblHeaders.cssColClass, subField.cssClass,(subField.btnLabelClass ? subField.btnLabelClass : 'u-flex-center')]">
              <div
                v-for="(inlineFields, inKey) in subField.displayInlineFields"
                :key="inKey"
                :class="[inlineFields.cssClass]"
              >
                <label v-if="inlineFields.inlineField == 'label'">{{
                  subField.textAppend
                    ? subField.label.replace(
                        "#timeVar",
                        getJPathValue(subField.textAppendPath, tableData[0])
                      )
                    : subField.label
                }}</label>
                <label v-if="inlineFields.inlineField == 'data'">
                  {{ getTableDataForField(subField.path, subField.cabin,subField) }}
                </label>
                <label v-if="inlineFields.inlineField == 'modalData' && subField.name === 'Refund Requested'
                 && subField.showColoredBtn && tableData[0].passenger.isRefundIssued">
                  <button :class="['finalised u-width-100 u-sans-serif u-padding-5 u-break-content']">{{subField.name }}</button>
                </label>
                <span :class="subField.isRedNotrequired == undefined ? 'u-padding u-text-red': ''"
                  v-if="
                    inlineFields.inlineField == 'data' &&
                    subField?.addtionalPath
                  "
                >
                  {{
                    getTableDataForField(
                      subField?.addtionalPath,
                      subField.cabin
                    )
                  }}</span
                >
                <div
                  v-if="
                    inlineFields.inlineField == 'field' &&
                    subField.setIsDDLLoading
                  "
                  class="nb-spinner"
                ></div>

                <component
                  :is="subField.fieldType"
                  v-if="
                    !subField.setIsDDLLoading &&
                    inlineFields.inlineField == 'field'
                  "
                  :cssClass="[subField.fieldsCssClass]"
                  :cssCalendar="subField.cssCalendar"
                  v-model="subField.model"
                  v-bind="subField.attributes"
                  :dataType="subField.dataType"
                  :errorMessage="subField.errorMessage"
                  :options="
                    subField.fieldType == 'UADropDown'
                      ? getSourceOptions(subField)
                      : []
                  "
                  :firstOption="subField.model"
                  :selectOptions="
                    subField.fieldType == 'UASelect' ||
                    subField.fieldType == 'UARadioButton'
                      ? getSourceOptions(subField)
                      : []
                  "
                  :onChangeFieldsToTrigger="subField.onChangeFieldsToTrigger"
                  @update:modelValue="
                    updateEditFields($event, subField, 'model')
                  "
                  @update-option="
                    updateOption($event, subField, 'model', subField.path)
                  "
                  @callApiOnDateChange="getValuesToBind($event, subField)"
                  :isDisabled="subField?.attributes?.disabled"
                  :currInputFieldInfo="subField"
                  :key="subField.id"
                  :text="getFieldText(subField)"
                  :id="subField.id"
                  :toolTipInfo="inlineFields.toolTipInfo"
                  @changeView="changeView(subField)"
                  :dataLength="subField?.dataLength"
                >
                </component>
                <template v-if="tblField.type == 'multi'">
                  <template v-for="(fi, ind) in tblField.fields" :key="ind">
                    <label v-if="inlineFields.inlineField == 'label'"
                      >{{ fi.label }}
                      {{ getJPathValue(fi.path, tableData[0]) }}</label
                    >
                  </template>
                </template>
              </div>
              <div
                v-if="subField.fieldDesc && subField.fieldDesc.length > 0"
                :class="[subField.fieldDesc && subField.fieldDesc[0].cssClass]"
              >
                {{ subField.fieldDesc[0].label }}
              </div>
              <template v-else-if="subField.type == 'action'">
                    <span>
                        <template v-for="(action,actionIndex) in subField.actions" :key="actionIndex">
                          <img  v-if="action.image && isActionDisplay" :src="getImageUrlM(action.image)" :id="action.id + `_`+ actionId"
                            :class="action.cssClass" @click="genericHandler(action, data,dKey)" v-bind="action.attributes"/>
                            <UAButton v-if="action.fieldType == 'UAButton' && isActionDisplay" :id="action.id + `_`+ actionId"
                            :class="action.cssClass" @click="genericHandler(action, data,dKey)" v-bind="action.attributes">
                              {{ action.label }}
                            </UAButton>
                        </template>
                        </span>
                </template> 
                <template v-if="subField?.handleMultipleCurrencies" >
                  <div class="u-innerTable-freeze">
                      <template v-for="(currData, cKey) in getMultipleCurrencyData(subField)" :key="cKey">
                        <div
                          :class="['u-col u-flex']" 
                        >
                          <template v-for="(currField, rKey) in subField.fields" :key="rKey">
                            <div
                              :class="[
                                'u-rtbl-cell u-white u-small lf mf sf u-padding-xsmall u-cell-middle u-primary-inv-border',
                                currField.textCSSClass
                              ]"
                              v-if="currField.isDisplay"
                              :style="currField?.attributes?.style"
                            >
                              <label
                                :class="['u-small lf mf sf u-block u-break-content']"
                                v-if="currField.inlineField == 'data'"
                              > 
                                {{
                                  combineFields(currField, currData)
                                }}
                              </label>
                            </div>
                          </template>
                        </div>
                      </template>
                  </div>
                </template>
            </div>
          </template>
        </div>
      </template>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapState } from "vuex";
import UADateTimePicker from "@/components/UADateTimePicker.vue";
import UATextbox from "@/components/UATextbox.vue";
import UADropDown from "@/components/UADropDown.vue";
import UASelect from "@/components/UASelect.vue";
import UADatePicker from "@/components/UADatePicker.vue";
import UATextarea from "@/components/UATextarea.vue";
import UARadioButton from "@/components/UARadioButton.vue";
import {mapDateToOtherFormat} from "@/helpers/utilities";
import UAToggleSwitch from './UAToggleSwitch.vue';
import UAButton from "./UAButton.vue";
export default {
  name: "UAOvsiTableColLayout",
  components: {
    UADateTimePicker,
    UATextbox,
    UADropDown,
    UASelect,
    UADatePicker,
    UATextarea,
    UARadioButton,
    UAToggleSwitch,
    UAButton
  },
  data() {
    return {
      aminitiesData: {},
    };
  },
  created(){
    if(this.tblHeaders.isAminities){

    }
  },
  props: [
    "tblHeaders",
    "tableData",
    "tableFields",
    "dropDownOption",
    "dnlnStns",
    "selectedDnlnStn",
    "sectionHeader",
    "tableBorderCSS",
    "isActionDisplay",
    "contentScroll","actionId"
  ],
  emits: ["getDynamicValuesOnChange", "setSelectedDnlnStn", "changeView","toggleEdit","deletePsngr","viewDetails"],
  computed: {
    ...mapState({
      isDDLLoading: (state) => state.ovsiDefaultModule.isDDLLoading,
      ddlLoadingMessage: (state) => state.ovsiDefaultModule.ddlLoadingMessage,
      selectedRecord: state => state.ovsiDefaultModule.selectedRecord,
    }),
    showHeader() {
      return (
        this.tblHeaders.headerValues &&
        this.tblHeaders.headerValues.length > 0 &&
        this.tblHeaders.headerValues.filter((hf) => hf != "").length > 0
      );
    },
    ...mapGetters(["getJPathValue",'getImageUrl']),
  },
  methods: {
    changeView(fieldInfo) {
      this.$emit("changeView", this.tableData[0], fieldInfo);
    },
    getFieldText(field) {
      let fieldText = "";
      if (field?.hyperlinkButton) {
        fieldText = field?.hyperlinkButton?.isTextBasedOnData
          ? this.getJPathValue(
              field?.hyperlinkButton?.textPath,
              this.tableData[0]
            )
          : field?.hyperlinkButton?.label;
      }
      return fieldText;
    },
    async getValuesToBind(selectedValue, currField) {
      try {
        this.$emit(
          "getDynamicValuesOnChange",
          selectedValue,
          currField,
          this.tableData
        );
      } catch (err) {}
    },
    getTableFields(tblFlds) {
      let arrField = [];
      if (tblFlds.hasOwnProperty("subFields")) {
        return tblFlds.subFields;
      } else {
        arrField.push(tblFlds);
        return arrField;
      }
    },
    getMultipleCurrencyData(field){
      let currData={}
        this.tableData.filter(tblData=>{
          if(field.name=='ETC'){
            currData = tblData.flightTotals?.etcTotal.length>0 ? tblData.flightTotals?.etcTotal:field.defaultValue
          }
          if(field.name=='Drafts'){
            currData = tblData.flightTotals?.draftAmountTotal.length>0 ? tblData.flightTotals?.draftAmountTotal:field.defaultValue
          }
          if(field.name=='Amenities'){
            currData = tblData.flightTotals.amenitiesByCurrency.length>0 ? tblData.flightTotals.amenitiesByCurrency:field.defaultValue
          } 
          else{
            currData;
          }
        })
        return currData;
    },
    getTableDataForField(tblFldsPath, cabin,fields) {
      let fieldData = "";
      if(fields.isAminities ){
        let  ams = this.getJPathValue(tblFldsPath, this.tableData[0]) || [];
        let aminities = ams.filter(am=>am[fields.filterPath] == fields.filterValue) || [];
        return aminities.length>0?fields.combinepath.map(path=>this.getJPathValue(path,aminities[0])).join(fields.combinePrefix||'').toString():fields.defaultValue;
      }
      if(fields.targetObj == 'selectedRecord'){
        if(fields.formatDate){
          return mapDateToOtherFormat(fields,this.selectedRecord)
        } else{
          return this.getJPathValue(fields.path, this.selectedRecord);
        }
      }
      
      if (this.tableData.length > 0) {
        fieldData = this.getJPathValue(tblFldsPath, this.tableData[0][cabin]);
        if(!cabin){
        fieldData = this.getJPathValue(tblFldsPath, this.tableData[0]);
        }
        if(fields.dataType && fields.dataType.toString() == "array"){
          fieldData =this.combineFields(fields,fieldData[0]);
        }
        if(fields.dataType && fields.dataType.toString() == "object"){
          fieldData =this.combineFields(fields,fieldData);
        }
        if(fields.dataType && fields.dataType.toString() == "nestiarray"){
          fieldData =this.combineFields(fields,fieldData[0]?fieldData[0][fields.subpath][0]:{});
        }
      }
      if(fieldData == 0){
        return fieldData;
      }
      if(!fieldData && fields && fields.defaultValue){
        fieldData = fields.defaultValue;
      }
      return fieldData;
    },
    combineFields(field,item){
      let FloatObj = {};
      let fieldValue ='';
      if(field.isFloatValue){
        field.combinepath.forEach(path=>{
          if(path == field.combinepath[0]){
            let amnt = this.getJPathValue(path,item) || field.defaultValue            
            let amntValue = Number.isInteger(amnt) ? amnt : parseFloat(amnt).toFixed(2)
            FloatObj["amount"] =  amntValue;
          } else {
            let currCode = this.getJPathValue(path,item)
            FloatObj["currencyCode"] =  currCode;
          }
        })
         fieldValue = field.combinepath.map(path=>this.getJPathValue(path,FloatObj)).join(field.combinePrefix||'').toString();
      } else{
         fieldValue = field.combinepath.map(path=>this.getJPathValue(path,item)).join(field.combinePrefix||'').toString();
      }
      if(fieldValue.trim().length === 0){
       return field.defaultValue;
      }
      return fieldValue;
    },
    getSourceOptions(entityItem) {
      switch (entityItem.sourceType) {
        case "api":
          return entityItem.source;
        case "inLine":
          return entityItem.source;
        case "custom":
          return this.dnlnStns;
        default:
          return "";
      }
    },
    getSelectedDNLNStnData(selectedItem, modal, path) {
      modal.model = selectedItem;
      this.$emit("setSelectedDnlnStn", selectedItem);
    },
    updateOption(eVal, modal, path, modalPath) {
      modal[path] = eVal;
    },
    updateEditFields(eVal, fieldItem) {
      fieldItem.model = eVal;
    },
    async genericHandler(actionBtnInfo, data,dataIndex){
        let {events} = actionBtnInfo;
        this.selectedDataIndex = dataIndex;
        if(events.name == "edit"){
          this.$emit('toggleEdit');
        }
        else if(events.name == "delete"){
          this.$emit('deletePsngr');
        }else if(events.name == "view"){
          this.$emit('viewDetails');
        }
    },
    getImageUrlM(img){
      return this.getImageUrl(img);
    }
  },
};
</script>

<style>
</style>