<template>
  <div :class="[
      'u-round u-input-1 u-text-3 u-bg-4 u-small', {' u-padding-msmall-1 u-msmall' :isFloatLabel},
      (errmsg && modelValue) ? 'u-tooltip tip-bottom u-border-err' : 'u-border u-input-1'
    ]" :data-tooltip="errmsg">
    <label :class="isFloatLabel ? floatClass:'u-msmall'" :for="id" v-if="showLabel">{{ this.modelValue != '' ? this.labelInfo : this.placeholder }}
        <span class="u-medium u-text-red" v-if="isMandatory">*</span>
      </label>
    <textarea
      :class="['u-text-0 u-round no-outline',cssClass,errmsg ? 'u-error' : '',{'u-text-0': isFloatLabel}]"
      v-bind="$attrs"
      @input="updateInput($event)"
      :value="modelValue"
      :disabled="isDisabled"
      :maxlength="maximumlength"
      :id="id"
      :placeholder="isFloatLabel ? '' : placeholder"
    />
  </div>
</template>
<script>
import { mapGetters} from "vuex";
export default {
  name: "UATextarea",
  inheritAttrs: false,
  data() {
    return {
      searchValue: "",
      errmsg: "",
    };
  },
  props: [
    "modelValue",
    "id",
    "isDisabled",
    "labelInfo",
    "isFloatLabel",
    "isMandatory",
    "placeholder",
    "showLabel",
    "cssClass",
    "cssLabel",
    "dataType",
    "maximumlength",
    "errorMessage",
    "currInputFieldInfo",
  ],
  computed: {
    floatClass() {
      return this.modelValue != '' ? 'u-floatFly-fix' : 'u-float';
    },
    ...mapGetters(["getPatternMatching" ]),
  },
  methods: {

updateInput(event) {
  this.searchValue = event.target.value;
  this.$emit("update:modelValue", this.searchValue);
  if (this.dataLength && this.modelValue) {
    if (this.searchValue.length != this.dataLength) {
      
      if (typeof this.errorMessage === "object") {
        this.errmsg = this.errorMessage.lengthMsg;
      } else {
        this.errmsg = this.errorMessage;
      }
      //this.currInputFieldInfo ? this.currInputFieldInfo.isError = true : "";
      if (this.currInputFieldInfo) {
        this.currInputFieldInfo.isError = true;
        this.currInputFieldInfo.dislayError = this.errmsg;
      }
      return;
    }
  }
  if (this.dataType && this.modelValue) {
    this.patternValidation(event, this.dataType);
  } else {
    this.errmsg = "";
    // this.currInputFieldInfo ? this.currInputFieldInfo.isError =  false :"";
    if (this.currInputFieldInfo) {
      this.currInputFieldInfo.isError = false;
      this.currInputFieldInfo.dislayError = "";
    }
  }
  if (
    this.onChangeFieldsToTrigger != undefined &&
    this.onChangeFieldsToTrigger.length > 0
  ) {
    this.$emit("callApiOnDateChange", this.searchValue);
  }
}
,
patternValidation(event, selectedDataType) {
  let res = this.getPatternMatching(event, selectedDataType);
  let hasNumber = /\d/;
  if (hasNumber.test(res)) {
    //this.currInputFieldInfo ? this.currInputFieldInfo.isError =  true :"";
    if (res == "1") this.errmsg = "max " + res + " character is allowed";
    else this.errmsg = "max " + res + " characters are allowed";
    if (this.currInputFieldInfo) {
      this.currInputFieldInfo.isError = true;
      this.currInputFieldInfo.dislayError = this.errmsg;
    }
    return;
  } else {
    if (!res) {
      if (typeof this.errorMessage === "object") {
        const splitedDataType = selectedDataType.split("_");
        if (splitedDataType[0] == "number") {
          this.errmsg = this.errorMessage.onlyNumberMsg;
        } else if (splitedDataType[0] == "char") {
          this.errmsg = this.errorMessage.onlyCharMsg;
        } else if (splitedDataType[0] == "negNumber") {
          this.errmsg = this.errorMessage.negNumberMsg;
        } else if (splitedDataType[0] == "alphaNumeric") {
          this.errmsg = this.errorMessage.alphaNumericMsg;
        }
      } else {
        this.errmsg = this.errorMessage;
      }
      if (this.currInputFieldInfo) {
        this.currInputFieldInfo.isError = true;
        this.currInputFieldInfo.dislayError = this.errmsg;
      }
      return;
    } else {
      this.errmsg = "";
      if (this.currInputFieldInfo) {
        this.currInputFieldInfo.isError = false;
        this.currInputFieldInfo.dislayError = "";
      }
    }
  }
},
},
};
</script>
<style scoped>
textarea {
  border-top-style: hidden !important;
  border-right-style: hidden !important;
  border-left-style: hidden !important;
  border-bottom-style: hidden !important;
  background-color: #ffffff;
}
.no-outline:focus {
  outline: none;
}

.u-tooltip:before {
  background: #cc0000;
}

.u-tooltip.tip-bottom:after {
  border-color: transparent transparent #cc0000 transparent;
}

.u-tooltip {
  display: block;
}
</style>