<template>
  <li
    @click="setMenuToggle(index)"
    :class="[cssClass, { 'u-menuItemActive': isToggleMenu(index) && showIcon }]"
  >
    <!-- <img
      v-if="showIcon"
      :src="imgPath"
      alt=""
      class="u-menuImg"
      @click="
        toggleMenuItems();
        setMenuToggle(index);
      "
    /> -->
    <div class="u-flex-center">
      <span
      :class="[
        showIcon ? 'u-menuInfo u-pointer' : 'u-subMenuInfo',
        (selectedMenuId == menuItem.id || selectedMainMenuId == menuItem.id) ? 'u-bg-color-ly u-text-black' : '',
      ]"
      v-show="showMenuItems"
      @click="navigateMenu(menuItem)"
      >{{ menuItem.label }}</span>
      <span>
    <button 
      class="u-menuBtn u-btn u-hover-none u-transparent u-medium u-right u-pad-0"
      v-if="hasSubMenu && showMenuItems" 
    >
      <img
        v-if="isToggleMenu(index)"
        src="@/assets/img/sub.png"
        class="u-menuPlus"
      />
      <img v-else src="@/assets/img/addw.png" class="u-menuPlus" />
    </button>
    </span>
    </div>
  </li>
  <ul
    v-if="hasSubMenu"
    :class="[subClass, 'u-submenu']"
    v-show="isToggleMenu(index)"
  >
    <template v-for="(subMenuItem, key) in subMenuItems" :key="key">
      <UAMenuList
        :menuItem="subMenuItem"
        :subMenuItems="getSubMenuItems(subMenuItem.id)"
        :cssClass="['u-subMenuItem u-no-bullet ', subMenuItem.cssClass]"
        :index="index + key"
        :subClass="[subMenuItem.subClass]"
      />
    </template>
  </ul>
</template>
<script>
import { mapActions, mapState, mapGetters, mapMutations } from "vuex";

export default {
  name: "UAMenuList",
  props: [
    "menuItem",
    "subMenuItems",
    "cssClass",
    "showIcon",
    "imgPath",
    "index",
    "subClass",
  ],
  data() {
    return {
      subMenuToggleIndex: [], //Azh - to toggle n sub items individually
    };
  },
  computed: {
    ...mapState({
      showMenuItems: (state) => state.menuModule.showMenuItems,
      breadCrumb: (state) => state.breadCrumb,
      screenLayout: (state) => state.ovsiDefaultModule.screenLayout,
      selectedMenuId: (state) => state.menuModule.selectedMenuId,
      menuDetails: (state) => state.menuModule.menuDetails,
      selectedMainMenuId: (state) => state.menuModule.selectedMainMenuId,
    }),
    ...mapGetters(["getSubMenuItems"]),
    hasSubMenu() {
      return Object.keys(this.subMenuItems).length > 0 ? true : false;
    },
  },
  methods: {
    ...mapActions([
      "toggleMenuItems",
      "setProcessStep",
      "getEntityDisplayDetailsAction",
      "clearAlertMessages",
    ]),
    ...mapMutations([
      "setShowInlineTable",
      "resetEntityDetails",
      "resetaddFilterItem",
      "reSetSearchOVSIData",
      "setSelectedMenuId",
      "setselectedMainMenuId",
      'toggleMenu',
      'setshowOrHideMainMenus',
      'setIntiateFlightPop'
    ]),
    setMenuToggle(index) {
      this.subMenuToggleIndex.indexOf(index) != -1
        ? this.subMenuToggleIndex.splice(
            this.subMenuToggleIndex.indexOf(index),
            1
          )
        : this.subMenuToggleIndex.push(index);
    },
    isToggleMenu(index) {
      return this.showMenuItems && this.subMenuToggleIndex.indexOf(index) != -1
        ? true
        : false;
    },
    navigateMenu(menuItem) {
      let id = menuItem.id=='create_ovs_report'?menuItem.parent:menuItem.id;
        this.clearAlertMessages();
        this.resetaddFilterItem();
        this.resetEntityDetails();
        this.reSetSearchOVSIData();
        this.setSelectedMenuId(id);
        if(menuItem.id == 'create_ovs_report'){//to show initiat flight modal popup on load
          this.setIntiateFlightPop(true)
        }
        if(menuItem.parent == "rootnode") {
          if(menuItem.showSubNavItems){//ex configuration menus
            //only main menu id which we need to show subitems in nav bar on click on main menu
            this.setselectedMainMenuId(id);
            if(menuItem.defaultNavigateToId) id = menuItem.defaultNavigateToId;//TO SELECT THE MENU OR NAVITEM ON CLICK OF LEFTSIDE MEAIN MENU
            this.setSelectedMenuId(id);
          } else if(menuItem.baseMenue && menuItem.defaultNavigateToId ){//ex create ovs report
            //only main menu id which we need to show subitems in nav bar on click on main menu
            this.setselectedMainMenuId(id);
            if(menuItem.defaultNavigateToId) id = menuItem.defaultNavigateToId;//TO SELECT THE MENU OR NAVITEM ON CLICK OF LEFTSIDE MEAIN MENU
            this.setSelectedMenuId(id);
          } else {
            this.setselectedMainMenuId('')
          }          
        }
        
        this.getEntityDisplayDetailsAction(id).then(() => {
          if (this.screenLayout != "") {
            this.setProcessStep(this.screenLayout);
          } else {
            this.setProcessStep(id);
          }
          
        });
        this.toggleMenu();
        this.setshowOrHideMainMenus();
    },
    findAllMenuHierachy(menuName, menuLabel) {
      let menuFinal = [];
      let currentMenuName = menuName;
      let pranetNode = "X";
      while (
        pranetNode != undefined &&
        pranetNode.toLowerCase() != "rootnode"
      ) {
        let currentMenu = "";
        currentMenu = this.getCurrentMenuParent(currentMenuName);
        if (currentMenu != undefined && currentMenu != "rootnode") {
          pranetNode = currentMenu[0].parent;
          currentMenuName = currentMenu[0].parent;
          menuFinal.push(currentMenu[0].label);
        } else {
          pranetNode = "rootnode";
        }
      }
      menuFinal.push("Home");
      return menuFinal;
    },
    getCurrentMenuParent(menuId) {
      return this.menuDetails.filter(
        (menu) => menu.id.toLowerCase() == menuId.toLowerCase()
      );
    },
  },
};
</script>
<style>
</style>