<template>
  <div :class="[
    'u-display-container u-border u-round u-input-1 u-text-3 u-bg-4 u-small', { 'u-msmall': isFloatLabel },
    (errmsg && modelValue) ? (this.filtersErrorTooltip ? 'u-tooltip tip-bottom-search u-border-err' : errorOnTop ? 'u-tooltip tip-top-buttons u-border-err' : modalError ? 'u-tooltip tip-bottom-buttons u-border-err' : 'u-tooltip tip-bottom u-border-err') : 'u-border u-input-1'
  ]" :data-tooltip="errmsg">
    <label :class="[isFloatLabel ? floatClass : 'u-msmall',cssMargin]" :for="id" v-if="showLabel">{{getLabelText}}
      <span class="u-medium u-text-red" v-if="isMandatory">*</span>
    </label>
    <input :class="['u-text-0 u-round no-outline',isDisabled?'u-disabled':'', cssClass, errmsg ? 'u-error' : '', cssClass, { 'u-text-0': isFloatLabel },{'u-disabled':$attrs.disabled}]"
      v-bind="$attrs" @paste="onPasteHandler($event)" :value="modelValue" :id="id"
      @mouseleave="prefixZeros($event)" @blur="prefixZeros($event)"  
      @keypress="onKeyPressHandler($event)" @input="updateInput($event)" :disabled="isDisabled" 
      autocomplete="off" :placeholder="getInputPlaceHolder" />
  </div>
</template>
<script>
import { mapGetters, mapState } from "vuex";
export default {
  name: "UATime",
  inheritAttrs: false,
  data() {
    return {
      searchValue: "",
      errmsg: "",
    };
  },
  props: [
    "modelValue",
    "id",
    "isDisabled",
    "labelInfo",
    "isFloatLabel",
    "isMandatory",
    "placeholder",
    "showLabel",
    "cssClass",
    "cssMargin",
    "dataType",
    "onChangeFieldsToTrigger",
    "errorMessage",
    "filtersErrorTooltip",
    "currInputFieldInfo",
    "errorOnTop",
    "modalError",
    "dataLength"
  ],
  computed: {
    ...mapState({
      applicationInfoDetails: (state) => state.ovsiDefaultModule.applicationInfoDetails,      
    }),
    floatClass() {
      return (this.modelValue != '' || (this.currInputFieldInfo && this.currInputFieldInfo.showBothLabelAndPlaceholder)) ? 'u-floatFly-fix' : 'u-float';
    },
    getLabelText() {
      return (this.modelValue != '' || (this.currInputFieldInfo && this.currInputFieldInfo.showBothLabelAndPlaceholder))  ? this.labelInfo : this.placeholder;
    },
    getInputPlaceHolder() {//SHOW PLACEHOLDER AND LABLE CASE : WHEN NEED TO SHOW DEFAULT BOTH LABEL AND PLACEHOLDER ON LOAD
      return (this.currInputFieldInfo && this.currInputFieldInfo.showBothLabelAndPlaceholder) ? this.placeholder : (this.isFloatLabel ? '' : this.placeholder);
    },
    ...mapGetters(["getPatternMatching", "validateKeyPressInput"]),
  },

  mounted() {
    if (this.modelValue) {          
        this.$emit("update:modelValue", this.modelValue);            
    }
  },

  methods: {
    onPasteHandler(event){
      let pasteText = event.clipboardData.getData('text/plain');
      let evtObj = {target : {value :pasteText }}
      if(!this.validateInputText(pasteText) ){
        event.preventDefault();
      }
    },
    validateInputText(pasteText){
      if(this.currInputFieldInfo && this.currInputFieldInfo.attributes && this.currInputFieldInfo.attributes.maxlength){
        if(pasteText.length > this.currInputFieldInfo.attributes.maxlength) return false;
      }
      if(this.dataType && this.dataType != '')  {
        let ptrnType = this.dataType.split('_')[0];
        let hhmmRegex = new RegExp(this.applicationInfoDetails.keyPressInputPatterns[ptrnType]);
        if (!hhmmRegex.test(pasteText)) return false;
      } 
      return true;
    },
    onKeyPressHandler(event){
      if(!this.validateKeyPressInput(event,this.dataType)){
        event.preventDefault();
      }
    },
    prefixZeros(e,type) {
        if(e.target.value.length == 0 || e.target.value.length == 10){
          return;
        }
        let str = e.target.value;
        let hh, min, strArr, finalStr = str;
        if (str.includes(":")) {
          strArr = str.split(":");
          if ((strArr[0] || strArr[1]) &&  strArr.length === 2) {
            hh = `${strArr[0]}`
            min = `${strArr[1]}`
            hh = (hh != '') ? ("0" + hh).slice(-2) : hh;
            min = (min != '') ? ("0" + min).slice(-2) : min;
            finalStr = `${hh}:${min}`;
            this.$emit(`update:modelValue`, finalStr);
            let evtObj = {target : {value :finalStr }}
            if(this.patternValidation(evtObj, this.dataType)){
              if(this.onChangeFieldsToTrigger != undefined && this.onChangeFieldsToTrigger.length >0){
                this.$emit("callApiOnDateChange", modelValue);
              }
            }
          }
        }
      },
    updateInput(event) {
      this.searchValue = event.target.value;
      let len = parseInt(this.searchValue.length);
      if( len == 2 ){
        if(!this.searchValue.includes(":")){
          this.$emit("update:modelValue", event.inputType == "deleteContentBackward"? this.searchValue:`${this.searchValue}:`);       
        }
      } else {
        this.$emit("update:modelValue", this.searchValue);
      }
      this.patternValidation(event, this.dataType);
      this.validateTimeFormat(this.searchValue);
      if (
        this.onChangeFieldsToTrigger != undefined &&
        this.onChangeFieldsToTrigger.length > 0
      ) {
        this.$emit("callApiOnDateChange", this.searchValue);
      }
    },
    patternValidation(event, selectedDataType) {
      let res = this.getPatternMatching(event, selectedDataType);
      if (!res) {
        this.errmsg = this.errorMessage;          
        if (this.currInputFieldInfo) {
          this.currInputFieldInfo.isError = true;
          this.currInputFieldInfo.dislayError = this.errmsg;
        }
        return false;//INVALID TIME
      } else {
        this.errmsg = "";
        if (this.currInputFieldInfo) {
          this.currInputFieldInfo.isError = false;
          this.currInputFieldInfo.dislayError = "";
        }
        return true;//VALID TIME
      }      
    },
    validateTimeFormat(text){
      if(text.length != 5){
        this.errmsg = "Please enter data in time Format(HH:MM)";
        if(this.currInputFieldInfo) {
          this.currInputFieldInfo.isError =  true;
          this.currInputFieldInfo.dislayError = this.errmsg
        }
        return false;
      } 
    }
  },
};
</script>
<style scoped>
input {
  border-top-style: hidden;
  border-right-style: hidden;
  border-left-style: hidden;
  border-bottom-style: hidden;
  background-color: #ffffff;
}

.no-outline:focus {
  outline: none;
}

.u-tooltip:before {
  background: #cc0000;
}

.u-tooltip.tip-top-buttons:after {
  border-color: #cc0000 transparent transparent transparent;
}

.u-tooltip.tip-bottom-buttons:after {
  border-color: transparent transparent #cc0000 transparent;
}

.u-tooltip.tip-bottom:after {
  border-color: transparent transparent #cc0000 transparent;
}

.u-tooltip.tip-bottom-search:after {
  border-color: transparent transparent #cc0000 transparent;
}

.u-tooltip {
  display: block;
}
</style>