<template>
  <div v-if="isInlineLoading" class="u-col l12 m12 s12">
    <div class="u-center u-fnt-bld">
      <span>{{ loadingMessage }}</span>
    </div>
  </div>
  <div
    v-if="
      !isInlineLoading && inlineTableFields && !displayHeader?.inlineheaderText
    "
    class="u-row"
  >
    <div class="u-col u-center u-small u-fnt-bld u-bg-color-ltylw">
      <template v-for="(inTblfld, ind) in inlineTableFields.fields" :key="ind">
        <label class="u-ls-ws">{{ inTblfld.label + ":     " }} </label>
        <label :class="['u-ls-ws', inTblfld.textCSSClass]">
          {{
            getJPathValue(
              inTblfld.path,
              inlinetableFieldsData?.length > 0 && inlinetableFieldsData[0]
            ) + "     "
          }}
        </label>
      </template>
    </div>
  </div>
  <div
    v-if="!isInlineLoading"
    :class="[
      'u-container u-tiny  u-centered  u-padding',tableCssClass,
      headerFields ? 'u-padding-top-4' : '',
    ]"
  >
    <div class="u-row">
      <div class="u-col u-flex">
        <template v-for="(hField, hKey) in headerFields" :key="hKey">
          <div
            :class="['u-rtbl-hc u-padding-msmall', hField.cssClass]"
            :style="[hField.styleHeader]"
          >
            <label
              class="u-small u-block u-break-content u-fnt-bld u-tu u-center"
            >
              {{ hField.name }}
            </label>
          </div>
        </template>
      </div>
    </div>
    <div :class="['u-row', (tableData && tableData.length>0 && !hideScroll) && 'contentScroll']">
      <div class="u-th-fixed">
        <div :class="['u-rtbl-th u-tbl-hd u-flex',borderCssClass]">
          <template v-for="(rField, rKey) in tableFields" :key="rKey">
            <div
              :class="['u-rtbl-hc u-padding-msmall', rField.cssClass]"
              :style="[rField.styleHeader]"
            >
              <span
                class="u-tooltip tip-bottom-buttons-header"
                :data-tooltip="rField.label"
              >
                <label class="u-small lf mf sf u-block u-break-content  u-tu">
                  {{ rField.name }}
                </label></span
              >
            </div>
          </template>
        </div>
      </div>
      <div class="u-innerTable-freeze" v-if="!isLoading">
        <template v-for="(data, dKey) in tableData" :key="dKey">
          <div
            :class="['u-col u-flex',cardRowCss]" 
          >
            <template v-for="(rField, rKey) in tableFields" :key="rKey">
              <div
                :class="[
                  'u-rtbl-cell u-white u-small lf mf sf u-padding-xsmall u-cell-middle',
                  rField.textCSSClass,borderCssClass
                ]"
                v-if="rField.isDisplay"
                :style="rField?.attributes?.style"
              >
                <template v-if="rField.name == 'Mileage Plus'">
                  <img  :src="getImageUrlM('bookmark.png')"/>
                </template>
                <template v-else-if="rField.isAccepted && data.isAccepted == true || rField.name == 'Processed'">
                          <img
                              @click="toggleInfoPop()"
                              src="@/assets/img/check_circle.png"
                              alt
                              class="u-menuImgSml u-border-0 u-transparent"
                          />
                </template>
                <template v-else-if="rField.name == 'Row'">
                  {{ dKey+1}}
                </template>
                <template v-if="rField.name === 'Status' && rField.showColoredBtn">
                  <button :class="[getOvslStatusColor(getStatusValue(rField,data)),'u-width-80 u-sans-serif u-padding-5 u-break-content']">{{getStatusValue(rField,data) }}</button>
                </template>
                <template v-else-if="rField?.displayDtRange">
                   <UATableColLayout  
                   :tableData="flow4"
                   :tableFields="rField.modalFields.tableFields"
                   :tblHeaders="rField.modalFields.headers[0]"/>
                </template>
                <template v-else-if="rField?.displayTableBlind">
                   <UAOvsiTableColLayout  
                   :tblHeaders="rField.modalFields.totalFields[0].headers[0]" 
                   :tableFields="rField.modalFields.totalFields[0].tableFields"
                   :tableData="flow4" 
                   />
                </template>
                <template v-else-if="rField.name == 'Bid details'">
                  <img
                    @click="toggleInfoPop(dKey)"
                    src="@/assets/img/view.png"
                    alt
                    class="u-menuImgSml u-border-0 u-transparent"
                    v-bind:title="tooltipText"
                  />
                  <UAModalDisplay v-if="infopop && (dKey == selectedDataIndex)" @close="hidePopup()"
                  :modalTable="addTableFields[0].modalTemp"
                  :tableData="[data]"
                  :footerFields="modalButtons[0].addButtons"
                  />
                </template>                
                <template v-else-if="rField.name === 'PBT'">
                    <div class="u-flex-center u-ht-40">
                        <span class="tooltip2">
                            <img v-if="data.isPbtOverCapacity" @mouseover="setTitleInfoPop(true,dKey)"
                                src="@/assets/img/error.png" alt
                                class="u-menuImgSml u-border-0 u-transparent printHide"
                                @mouseout="setTitleInfoPop(false,dKey)"
                                 />
                            <img v-else src="@/assets/img/check_circle.png" alt
                                class="u-menuImgSml u-border-0 u-transparent printHide" @mouseover="setTitleInfoPop(true,dKey)"
                                @mouseout="setTitleInfoPop(false,dKey)"
                                />
                            <span class="tooltiptext" v-if="titleInfopop && (selectedDataIndex == dKey)">
                                <UAInfoPop 
                                :tableCss="['u-white']" 
                                :headerCSS="[displayHeader1.cssClass,data.isPbtOverCapacity ?'errorimg':'u-margin-top-6']"
                                :secondaryHeaderCSS="[displayHeader1.cssClass,data.isPbtOverCapacity ?'':'u-margin-top-6']"
                                :Header="displayHeader1.headerText"
                                :secondaryHeader="data.isPbtOverCapacity? displayHeader1.headerText2:displayHeader1.headerText1"
                                :tableFields="innerFields1.tableFields"
                                :tableHeader="innerFields1.headers[0]"
                                :tableData="getCabinWiseData(data.cabins)"
                                :infoCsslass="['u-ht-30',data.isPbtOverCapacity ?'u-red':'u-bg-5-inv']" />
                                <!-- <UATableColLayout :tableData="getCabinWiseData(data.cabins)"

                                 :tableFields="innerFields1.tableFields"
                                  :tblHeaders="innerFields1.headers[0]"/> -->
                            </span>
                        </span>
                    </div>
                </template>
                <template v-else-if="rField.type == 'action'">
                    <span>
                        <template v-for="(action,actionIndex) in rField.actions" :key="actionIndex">
                            <img :src="getImageUrlM(action.image)" 
                            :class="action.cssClass" @click="genericHandler(action, data,dKey)" v-bind="action.attributes"/>
                        </template>
                        <UAModalDisplay v-if="oversaleLimits && (selectedDataIndex == dKey)" @close="ClosePopup()"
                        :modalTable="addTableFields[0].modalTemp"
                        :record="data"
                        :footerFields="modalButtons[0].editButtons"/>
                        </span>
                </template>
                <template v-else-if="rField.inlineField == 'data' && rField.mapDateFormat">
                  <label :class="['u-small lf mf sf u-block u-break-content']">
                    {{mapDateToOtherFormat(rField,data)}}
                  </label>
                </template>
                <label
                  :class="['u-small lf mf sf u-block u-break-content']"
                  v-else-if="rField.inlineField == 'data'"
                >
                  {{
                    rField.name == 'Flight'?String(getFieldData(rField, data)).padStart(4,'0'):getFieldData(rField, data)
                  }}
                </label>
                <component
                  :is="rField.fieldType"
                  v-if="rField.inlineField == 'field'"
                  :cssClass="rField.fieldsCssClass"
                  v-bind="
                    rField.inlineField == 'field' ? '' : rField.attributes
                  "
                  :text="getJPathValue(rField.path, data)"
                  :id="rField.id"
                  @changeView="changeView(data, rField)"
                  :isLoopOnce="rField.isLoopOnce"
                  :defaultState="rField.defaultState"
                  :activeToggleName="rField.activeToggleName"
                  :inactiveToggleName="rField.inactiveToggleName"
                  :currInputFieldInfo="filter"
                  :selectedKey="filter.selectedKey"
                  :selectedLabel="filter?.selectedLabel"
                  :dataLength="filter?.dataLength"
                  :errorOnTop="filter.errorOnTop"
                >
                </component>
              </div>
            </template>
          </div>

          <div
            class="u-col u-border-bottom u-padding-7"
            v-if="tableText && data.isShow"
            :style="[
              (dKey + 1) % 2 == 0 ? {} : { 'background-color': '#F6F6F6' },
            ]"
          >
            <template v-for="(tField, tKey) in tableText" :key="tKey">
              <div
                class="u-small u-padding-xsmall u-cell-middle"
                v-if="
                  getJPathValue(tField.path, data) &&
                  getJPathValue(tField.path, data).length > 0
                "
              >
                <label
                  class="u-small u-fnt-bld"
                  v-if="
                    tField.inlineField == 'data' && tField?.isBasic != undefined
                  "
                >
                  {{
                    tField.id == "cancellationdiversiondataerrors" &&
                    getJPathValue("status", data) &&
                    getJPathValue("status", data).toString().trim().length >
                      0
                      ? getJPathValue(tField.path, data)
                      : tField.id != "cancellationdiversiondataerrors"
                      ? getJPathValue(tField.path, data)
                      : ""
                  }}
                </label>

                <label
                  class="u-small u-text-red u-fnt-bld"
                  v-if="
                    tField.inlineField == 'data' && tField?.isBasic == undefined
                  "
                >
                  {{
                    tField.id == "cancellationdiversiondataerrors" &&
                    getJPathValue("status", data) &&
                    getJPathValue("status", data).toString().trim().length >
                      0
                      ? getJPathValue(tField.path, data)
                      : tField.id != "cancellationdiversiondataerrors"
                      ? getJPathValue(tField.path, data)
                      : ""
                  }}
                </label>
              </div>

              <div
                class="u-small u-padding-xsmall u-cell-middle"
                v-if="
                  getJPathValue(tField.path, data) == undefined &&
                  tField?.status != undefined
                "
              >
                <label class="u-small u-fnt-bld" v-if="tField?.concateMessage"
                  >{{ tField.concateMessage }}
                </label>
                <label
                  class="u-small u-text-red u-fnt-bld"
                  v-if="tField?.status"
                  >{{ tField.status }}
                </label>
              </div>
            </template>
          </div>

          <div
            class="u-col u-border-bottom u-flex"
            v-if="InlinetableText"
            :style="[
              (dKey + 1) % 2 == 0 ? {} : { 'background-color': '#F6F6F6' },
            ]"
          >
            <template v-for="(iField, iKey) in InlinetableText" :key="iKey">
              <div
                :class="[
                  'u-rtbl-cell u-small u-padding-xsmall u-cell-middle u-text-red',
                  iField.textCSSClass,
                ]"
                :style="iField?.attributes?.style"
              >
                <label
                  class="u-small u-block u-break-content"
                  v-if="
                    iField.inlineField == 'data' && iField?.isPath == undefined
                  "
                >
                  {{ getJPathValue(iField.path, data) }}</label
                >
                <label
                  class="u-small u-block u-break-content"
                  v-else-if="
                    iField.inlineField == 'data' && iField?.isPath != undefined
                  "
                >
                  {{ iField?.isPath }}</label
                >
              </div>
            </template>
          </div>
          <!-- <UAConfirmModal ref="uaconfirmmodal" /> -->
        </template>
        <template v-if="tableData && tableData.length == 0">
          <div class="u-center">
            <span class="u-center u-fnt-bld"> No data Found ! </span>
          </div>
        </template>
      </div>
      <div class="u-center" v-else><span class="u-center u-fnt-bld"> Loading . . . </span></div>
    </div>
  </div>
</template>
<script>
import { mapState, mapGetters, mapActions, mapMutations } from "vuex";
import UAButton from "@/components/UAButton.vue";
import UAConfirmModal from "@/components/UAConfirmModal.vue";
import UAInfoPop from "./UAInfoPop.vue";
import UATableColLayout from "./UATableColLayout.vue";
import { getDateTimePart } from "../helpers/utilities";
import UAOvsiTableColLayout from "./UAOvsiTableColLayout"
import UAModalDisplay from "@/components/UAModalDisplay.vue";

export default {
  name: "UAOVSITableDisplay",
  components: {
    UAButton,
    UAConfirmModal,
    UAModalDisplay,
    UAInfoPop,
    UATableColLayout,
    UAOvsiTableColLayout,
    
  },
  emits: ["changeView","navigateScreen"],
  props: [
    "tableData",
    "tableFields",
    "inlinetableFieldsData",
    "cssClass",
    "borderCssClass",
    "cardRowCss",
    "tableCssClass",
    "hideScroll"
  ],
  data() {
    return {
      isDisabled: false,
      infopop: false,
      selectedDataIndex: -1,
      titleInfopop: false,
      oversaleLimits:false,
      tooltipText: 'Undersold',
      flow4: [
        {blindbid_1_start: "0", blindbid_1_end: "1,000", blindbid_1_etc: "$300",
        blindbid_2_start: "0", blindbid_2_end: "1,000", blindbid_2_etc: "$300",
        blindbid_3_start: "0", blindbid_3_end: "1,000", blindbid_3_etc: "$300",
        blindbid_4_start: "0", blindbid_4_end: "1,000", blindbid_4_etc: "$300",
        start_dt:"01-Jan-2022",end_dt:"31-Mar-2023",start_time:"00:00",end_time:"15:00" ,
        start_value : "+1",end_value: "+3",currency:"Euro",min_curr:"€102.27",max_curr:"€2,556.63"
        ,mil_usd:"$0.02",cf_usd:"$0.04",intiation_starttime:"12 hours",intiation_stoptime:"1 hour",
        capacity:"-10%"
      },
      ],
    };
  },
  computed: {
    ...mapState({
      InnerRTFHeader: (state) => state.ovsiDefaultModule.InnerRTFHeader,
      isInlineLoading: (state) => state.ovsiDefaultModule.isInlineLoading,
      isLoading: (state) => state.ovsiDefaultModule.isLoading,
      loadingMessage: (state) => state.ovsiDefaultModule.loadingMessage,
      inlineTableFields: (state) => state.ovsiDefaultModule.inlineTableFields,
      headerFields: (state) => state.ovsiDefaultModule.headerFields,
      displayHeader: (state) => state.ovsiDefaultModule.displayHeader,
      dataCondition: (state) => state.ovsiDefaultModule.dataCondition,
      tableText: (state) => state.ovsiDefaultModule.tableText,
      modalButtons: (state) => state.ovsiDefaultModule.modalButtons,
      addTableFields: (state) => state.ovsiDefaultModule.addTableFields,
      InlinetableText: (state) => state.ovsiDefaultModule.InlinetableText,
      addEditObject: (state) => state.ovsiDefaultModule.addEditObject,
      selectedInputValues: (state) =>
        state.ovsiDefaultModule.selectedInputValues,
      displayHeader1:(state) => state.ovsiDefaultModule.displayHeader1,
      innerFields1:(state) => state.ovsiDefaultModule.innerFields1,
    }),
    ...mapGetters(["getOVSIFields", "getJPathValue", "getOVSIEntityId","getImageUrl","getOvslStatusColor"]),
  },
  methods: {
    ...mapActions(["getOVSIData", "verifyAdvanceSectionData"]),
    ...mapMutations(["setSelectedMenuId"]),
    combineFields(field,item) {
        return field.combinepath.map(path => this.getJPathValue(path,item)).join(field.combinePrefix||'').toString();
    },
    getFieldData(field, data){
      if(field.inlineField == 'data' && field.type == 'concat'){
       return this.combineFields(field,data);
      } else if(field.inlineField == 'data' && field.dataType == 'array'){
          let arrV= this.getData(field.path,data);
         return this.combineFields(field,arrV?arrV[0]:{});
       } 
       else if(field.inlineField == 'data' && field.formatDate){
        return getDateTimePart(this.getJPathValue(field.path,data), field.dateFormat);
      } else if(field.inlineField == 'data' && field.name != 'Bid details' && !field.showColoredBtn){
        return this.getJPathValue(field.path,data)
      }

    },
    getData(path,data){
      return this.getJPathValue(path,data);
    },
    mapDateToOtherFormat(rField,data){
      let date = this.getFieldData(rField, data);
      if(date){
       // return  new Date(date).toLocaleString('en-US', {  month: 'short' });
       const tokens= new Date(date).toLocaleDateString({},rField.mapDateFormat).split(' ');
       return `${tokens[1].toString().substring(0,2)}-${tokens[0]}-${tokens[2]}`;
      }
      return "";

    },
    setTitleInfoPop(flag,dataIndex){
      this.selectedDataIndex = flag?dataIndex:-1;
      this.titleInfopop = flag;
    },
    toggleInfoPop(dataIndex) {
      this.infopop = true;
      this.selectedDataIndex=dataIndex;
    },
    hidePopup() {
      this.infopop = false;
      this.selectedDataIndex=-1;
    },
    ClosePopup(){
      this.oversaleLimits = false
      this.selectedDataIndex =-1;
    },
    getStatusValue(rField,record){
      return this.getJPathValue(rField.path,record).toUpperCase();
      
    },
    getCabinWiseData(cabins){
          let cabinData ={}
          let cabinWiseData = [];
          if(this.innerFields1?.headers[0]?.isCabinWiseData){                
              for(let i=1; i< this.innerFields1.headers[0]?.headerValues?.length; i++){     
                  let filteredCabinData = cabins?.filter((item) => {      
                        return item?.cabinCode == this.innerFields1.headers[0]?.headerValues[i];
                  })                    
                  cabinData[this.innerFields1.headers[0]?.headerValues[i]] = filteredCabinData?.length>0 ? filteredCabinData[0] : {};                
              }
              cabinWiseData.push(cabinData);    
          }
          return cabinWiseData;
    },
    getImageUrlM(img){
      return this.getImageUrl(img);
    },
    async genericHandler(actionBtnInfo, data,dataIndex){
        let {events} = actionBtnInfo;
        this.selectedDataIndex = dataIndex;
        if(events.name == "navigateToOtherScreen"){
            this.$emit('navigateScreen', actionBtnInfo, data);
            this.setSelectedMenuId(actionBtnInfo.navigationInfo.navigateToID);
        }
        if(events.name == "edit"){
            this.oversaleLimits=true;
        }
    },
    changeView(data, fieldInfo) {
      if (fieldInfo?.verifyModel) {
        this.Verify(data);
      } else {
        this.$emit("changeView", data, fieldInfo);
      }
    },

    Verify(data) {
      let inParamObj = this.createInputObj(
        data,
        this.addEditObject.insert_field
      );
      let inpObj = {
        action: this.inlineTableFields.verifyeMacroName,
        actionId: "ActionType",
        inputObject: inParamObj,
      };

      // if (inpObj != undefined) {
      //   this.$refs.uaconfirmmodal[0]
      //     .dialogOpen({
      //       title: "Verify!",
      //       message: "Do you want to Verify the Data?",
      //       okButtonText: "Verify",
      //       cancelButtonText: "Cancel",
      //     })
      //     .then(async (ok) => {
      //       let isSuccess = await this.verifyAdvanceSectionData(inpObj);

      //       if (isSuccess) {
      //         await this.getOVSIData(this.selectedInputValues);
      //       }
      //       this.cancelButtonTxt = "Close";
      //     })
      //     .catch(() => {});
      // }
    },

    createInputObj(editedField, macroFields) {
      let inParamObj = {};
      macroFields.forEach((eField) => {
        if (editedField.hasOwnProperty(eField.path)) {
          if (eField.fieldType == "UADateTimePicker") {
            inParamObj[eField.id] = getDateTimePart(
              editedField[eField.path],
              eField.dateFormat
            );
          } else {
            inParamObj[eField.id] = editedField[eField.path].toString().trim();
          }
        } else {
          let curretnValue = "";
          if (eField.path == "customerID" || eField.path == "statusind") {
            curretnValue = eField.model;
          } else {
            curretnValue = this.getJPathValue(
              eField.path,
              this.selectedInlineData
            );
          }

          inParamObj[eField.id] =
            curretnValue != undefined ? curretnValue.toString().trim() : "";
        }
      });

      return inParamObj;
    },
  },
};
</script>

<style  >
  .u-rtbl-cell:last-child {
    border-right: 0 !important;
  }
  
  button {
      display: inline-block;
      padding: 5px 15px;
      font-size: 10px;
      text-align: center;
      text-decoration: none;
      outline: none;
      color: #000;
      background-color: #f0f0f0;
      border: none;
      border-radius: 15px;
      font-family: 'Times New Roman', Times, serif;
  }
  
.tooltip2 {
    position: relative;
}

.tooltip2 .tooltiptext {
    visibility: hidden;
    background-color: #fff;
    text-align: center;
    border-radius: 6px;
    /* Position the tooltip */
    position: absolute;
    z-index: 1;
    transform: translate(0%, -50%);
}

.tooltip2:hover .tooltiptext {
    visibility: visible;
}
</style>
