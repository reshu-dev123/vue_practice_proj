<template>
  <div
    :class="[isUserAccessHeader ? 'ua-select-none user-select' : 'ua-select user-select']"
    ref="dropdownMenu"
  >
    <div class="selected-items u-show" @click="isVisible = !isVisible">
      <label
        :class="[isFloatLabel ? floatClass : 'u-msmall', cssMargin]"
        :for="id"
        v-if="showLabel"
        >{{ this.modelValue != "" ? this.labelInfo : this.placeholder }}
        <span class="u-text-red" v-if="isMandatory">*</span>
      </label>
      <label :class="['u-input u-input-1 u-round searchDrpInput ', cssClass]">
        {{ selectedText }}
      </label>
      <span class="arrow-down"
        ><img
          src=".././assets/img/arrow-down.png"
          alt="arrow-down"
          class="arrow-down"
      /></span>
    </div>

    <div class="select-container" v-if="isVisible">
      <li v-if="multiSelect">
        <UATextbox
          type="search"
          id="UASearch"
          class="u-input u-border u-round multimodelValue"
          v-model="multimodelValue"
          placeholder="Serach DropDown"
          required="true"
        />
        <input
          type="checkbox"
          v-model="selectAll"
          value="Select All"
          @change="onSelectAll($event)"
        /><span class="selectAll">Select All</span>
      </li>
      <div class="options">
        <ul
          class="selectOptions"
          :style="[
            'margin-bottom: 0px',
            filteredSelectOptions.length < 1
              ? ''
              : 'height:auto;overflow:unset;min-height:auto',
          ]"
        >
          <li v-for="(item, index) in filteredSelectOptions" v-bind:key="index">
            <input
              type="checkbox"
              v-if="multiSelect"
              @change="onChange($event, item, index)"
              :checked="checkedItem(item)"
            />
            <span>{{ item.label }}</span>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
import { mapState, mapActions } from "vuex";
import UATextbox from "../components/UATextbox";
import UADropDown from "../components/UADropDown";
export default {
  name: "UAMultiSelect",
  data() {
    return {
      isVisible: false,
      selectAll: false,
      multiSelectItems: Array.isArray(this.modelValue)
        ? this.modelValue
        : this.modelValue
            .split(",")
            .map((i) => i.trim())
            .filter((item) => item),
      multimodelValue: "",
      selectedText: "",
    };
  },
  created() {
    this.setSelectedText();
  },
  mounted() {
    document.addEventListener("click", (e) => {
      if (!this.$el.contains(e.target)) {
        this.isVisible = false;
      }
    });
  },
  unmounted() {
    document.removeEventListener("click", () => {
      this.isVisible = false;
    });
  },
  computed: mapState({
    isUserAccessHeader: (state) => state.ovsiDefaultModule.isUserAccessHeader,
    filteredSelectOptions() {
      if (this.multimodelValue === "" && this.multiSelect) {
        return this.selectOptions;
      } else if (this.multimodelValue != "") {
        return this.selectOptions.filter((item) =>
          item.label.toLowerCase().includes(this.multimodelValue.toLowerCase())
        );
      }
    },
    floatClass() {
      return this.modelValue != "" ? "u-floatFly" : "u-float u-index";
    },
    selectedDDLValues() {
      let modelSelectedValues;
      if (this.multiSelectItems.length > 0) {
        if (modelSelectedValues) {
          //current selected values and already selected values which passed throgh parent
          let mergedArr = modelSelectedValues.concat(this.multiSelectItems);
          modelSelectedValues = [...new Set(mergedArr)]; //get unique values
        } else {
          modelSelectedValues = this.multiSelectItems;
        }
      }
      return modelSelectedValues && modelSelectedValues.join();
    },
  }),
  watch: {
    modelValue(newVal, oldVal) {
      this.setSelectedText();
    },
  },
  methods: {
    checkedItem(item) {
      return this.selectedDDLValues
        ? this.selectedDDLValues.includes(
            this.selectedKey ? item[this.selectedKey] : item.label
          )
        : false;
    },
    setSelectedText() {
      if (this.selectOptions.length > 0 && this.selectedDDLValues) {
        let filterObj = this.selectOptions.filter((item) => {
          let valFound = this.selectedDDLValues.split(",").filter((mval) => {
            return (
              mval == (this.selectedKey ? item[this.selectedKey] : item.label)
            );
          });
          return valFound.length > 0;
        });
        if (filterObj.length > 0) {
          let valuesToSHow;
          filterObj.forEach((ele) => {
            !valuesToSHow
              ? (valuesToSHow = ele.label)
              : (valuesToSHow = valuesToSHow + "," + ele.label);
          });
          this.selectedText = valuesToSHow;
        }
      } else {
        this.selectedText = "";
      }
    },
    onChange(event, item, i) {
      let itemKeyValue = this.selectedKey ? item[this.selectedKey] : item.label;
      if (event.target.checked) {
        this.multiSelectItems.push(itemKeyValue.toString());
        this.$emit("update:modelValue", this.selectedDDLValues);
      } else {
        let eleIndex = this.multiSelectItems.indexOf(itemKeyValue);
        eleIndex != -1 && this.multiSelectItems.splice(eleIndex, 1);
        this.$emit("update:modelValue", this.selectedDDLValues);
      }
      let selectedValues = this.selectedDDLValues
        ? this.selectedDDLValues.split(",")
        : [];
      if (selectedValues.length === this.selectOptions.length) {
        this.selectAll = true;
      } else {
        this.selectAll = false;
      }
      this.setSelectedText();
    },
    onSelectAll(event) {
      if (event.target.checked) {
        this.selectOptions.forEach((item, index) => {
          this.multiSelectItems.push(
            this.selectedKey
              ? item[this.selectedKey].toString()
              : item.label.toString()
          );
        });
        this.selectAll = true;
        this.$emit("update:modelValue", this.selectedDDLValues);
      } else {
        this.selectAll = false;
        this.multiSelectItems = [];
        this.$emit("update:modelValue", "");
      }
      this.setSelectedText();
    },
  },
  props: [
    "id",
    "selectOptions",
    "multiSelect",
    "sourceType",
    "modelValue",
    "labelInfo",
    "isFloatLabel",
    "isMandatory",
    "placeholder",
    "showLabel",
    "cssClass",
    "selectedKey",
    "cssMargin",
  ],

  components: {
    UADropDown,
    UATextbox,
  },
};
</script>
<style scoped lang="scss">
.ua-select-none {
    overflow-y: visible;
    position: none;
  .selected-items {
    position: relative;
    .arrow-down {
      position: absolute;
      top: 6px;
      right: 6px;
      cursor: pointer;
    }
    label {
      text-overflow: ellipsis;
      white-space: nowrap;
      overflow: hidden;
      padding-right: 39px;
      border: 1px solid #ccc;
    }
  }
  .select-container {
    border: 1px solid #e1e1e1;
    border-radius: 4px;
    background-color: #f6f6f6;
    position: absolute;
    width: -webkit-fill-available;
    z-index: 1;
    .u-display-container {
      margin-bottom: 10px;
    }
    .selectOptions {
      height: 200px;
      overflow-y: scroll;
    }
    li {
      list-style-type: none;
      padding: 10px 10px 0px 10px;
      font-size: 12px;
    }
    .selectAll {
      padding-left: 20px;
    }
    .multiSelectSearch {
      width: 90%;
      height: 100%;
      margin: 10px auto;
    }

    .searchDrpInput {
      width: 100%;
      height: 100%;
      padding-right: 2.5rem;
    }
    .options {
      width: 100%;

      ul {
        list-style: none;
        text-align: left;
        min-height: 200px;
        overflow-y: scroll;
        margin-top: 0px;
        padding-left: 0px;
        li {
          padding: 10px;
          border-bottom: 1px solid lightgray;
          display: flex;
          &:hover {
            background: #4985cc;
            color: #fff;
          }
          &:last-child {
            border-bottom: 0px;
          }
          span {
            margin-left: 22px;
          }
        }
      }
    }
  }
}

.ua-select {
    position: relative;
  .selected-items {
    position: relative;
    .arrow-down {
      position: absolute;
      top: 6px;
      right: 6px;
      cursor: pointer;
    }
    label {
      text-overflow: ellipsis;
      white-space: nowrap;
      overflow: hidden;
      padding-right: 39px;
      border: 1px solid #ccc;
    }
  }
  .select-container {
    border: 1px solid #e1e1e1;
    border-radius: 4px;
    background-color: #f6f6f6;
    position: absolute;
    width: -webkit-fill-available;
    z-index: 1;
    .u-display-container {
      margin-bottom: 10px;
    }
    .selectOptions {
      height: 200px;
      overflow-y: scroll;
    }
    li {
      list-style-type: none;
      padding: 10px 10px 0px 10px;
      font-size: 12px;
    }
    .selectAll {
      padding-left: 20px;
    }
    .multiSelectSearch {
      width: 90%;
      height: 100%;
      margin: 10px auto;
    }

    .searchDrpInput {
      width: 100%;
      height: 100%;
      padding-right: 2.5rem;
    }
    .options {
      width: 100%;

      ul {
        list-style: none;
        text-align: left;
        min-height: 200px;
        overflow-y: scroll;
        margin-top: 0px;
        padding-left: 0px;
        li {
          padding: 10px;
          border-bottom: 1px solid lightgray;
          display: flex;
          &:hover {
            background: #4985cc;
            color: #fff;
          }
          &:last-child {
            border-bottom: 0px;
          }
          span {
            margin-left: 22px;
          }
        }
      }
    }
  }
}
</style>