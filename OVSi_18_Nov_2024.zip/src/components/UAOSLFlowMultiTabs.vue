<template>
  <div class="u-row" v-if="tabs && tabs.length>0">
    <div class="u-row">
      <UATab :tabFields="tabs" @selectedTab="handleSelectTab" />
    </div>
    <div :class="['u-row']">
      <template v-for="(tabFlds, tabIndex) in tabs" :key="tabIndex">
        <div class="u-row" v-if="selectedTabIndex == tabIndex">
          <div class="u-col l12 m12 s12 u-padding">
            <div class="u-col l8 m8 s8 u-sans-serif">
              <label v-if="tabFlds.headerText" :class="tabFlds.headerCssClass">
                {{ tabFlds.headerText }}</label>
            </div>
            <div class="u-col l2 m2 s2 u-section-1">
              <UAButton
                @click="toggleEditPop()"
                cssClass="u-button u-round u-secondary-1 u-right u-padding-xsmall u-margin-right-70px"
                ><img
                  src="@/assets/img/edit.png"
                  alt
                  class="u-border-0 u-transparent"
                />
                Edit default
              </UAButton>
              <UAModalDisplay
                v-if="editpop"
                @close="CloseEditDefault()"
                :modalTable="getFieldByIdWrapper(tabFlds[tabFlds.id][0].editDefaultFields[0].modalTemp)"
                @addExtraAdditionalRow="
                  addTabsNewExtraFieldRows(tabFlds[tabFlds.id][0].editDefaultFields[0].modalTemp)"
                @deleteExtraAdditionalRow="
                  deleteNewExtraFieldRows('',tabFlds[tabFlds.id][0].editDefaultFields[0].modalTemp)"
                :footerFields="modalButtons[0].editButtons"
              />
            </div>
            <div class="u-col l2 m2 s2 u-section-1">
              <UAButton
                @click="toggleInfoPop()"
                cssClass="u-button u-round u-primary-1-pur u-right u-padding-xsmall"
              >
                + Add exception
              </UAButton>
            </div>
          </div>
          <div class="u-row u-padding">
            <UATableDisplay
              hideScroll=true
              :tableData="fltFlow1Data"
              :tableFields="tabFlds[tabFlds.id][0].tableDetails"
              :borderCssClass="['u-primary-inv-border']"
              :tableCssClass="['u-border u-white']"
            />
          </div>
          <!-- Sub Tabs -->
          <div class="u-row u-padding">
            <h3>11 Exceptions</h3>
            <div class="u-row">
              <UATab
                :tabFields="tabFlds[tabFlds.id][0].subTabs"
                @selectedTab="handleSelectSubTab"
              />
            </div>
            <template
              v-for="(subTabFlds, subTabIndex) in tabFlds[tabFlds.id][0].subTabs"
              :key="subTabIndex"
            >
              <div class="u-row" v-if="selectedSubTabIndex == subTabIndex">
                <!-- Search Keyword -->
                <div class="u-row u-section-1">
                  <UAConfigSearchKeyword
                    v-model:searchKeyword="searchKeyword"
                    :cssClass="['u-col 14 m4 s4 u-fnt-itlc']"
                    :placeholder="subTabFlds[subTabFlds.id][0].placeholder"
                  />
                </div>
                <!-- SubTabs TableDetails -->
                <div class="u-row">
                  <UATableDisplay
                    :cardRowCss="['u-card u-round u-padding-24 u-section-1 u-white']"
                    :borderCssClass="['u-primary-inv-border u-display-inline']"
                    @handleConfirmOk="handleConfirmOkFunc"
                    :tableData="filterRecords"
                    :tableFields="subTabFlds[subTabFlds.id][0].tableMetaData"
                    @setShowModalPopup="setShowModalPopup"
                  />
                  <!-- Add Exception -->
                  <UAModalDisplay
                    v-if="infopop"
                    @close="ClosePopup()"
                    :modalTable="getFieldByIdWrapper(subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp)"
                    @addNewFieldRow="
                      addTabsCustomerNewFieldRows(subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp)"
                    @addExtraFieldRow="
                      addTabsExtraFieldRows(subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp)"
                    @deleteNewFieldRow="
                      deleteCustomerNewFieldRows('',subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp)"
                    @deleteExtraFieldRow="
                      deleteExtraFieldRows('',subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp)"
                    @addExtraAdditionalRow="
                      addTabsNewExtraFieldRows(subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp)"
                    @deleteExtraAdditionalRow="
                      deleteNewExtraFieldRows('',subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp)"
                    :footerFields="modalButtons[0].addButtons"
                  />
                  <!-- Edit Exception -->
                  <UAModalDisplay
                    v-if="showModalPopup"
                    @close="ClosePopup()"
                    :modalTable="getFieldByIdWrapper(subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp)"
                    :tableData="modalData"
                    @addNewFieldRow="
                      addTabsCustomerNewFieldRows(subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp)"
                    @deleteNewFieldRow="
                      deleteCustomerNewFieldRows('',subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp)"
                    @addExtraFieldRow="
                      addTabsExtraFieldRows(subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp)"
                    @deleteExtraFieldRow="
                      deleteExtraFieldRows('',subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp)"
                    @addExtraAdditionalRow="
                      addTabsNewExtraFieldRows(subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp)"
                    @deleteExtraAdditionalRow="
                      deleteNewExtraFieldRows('',subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp)"
                    :footerFields="modalButtons[0].editDeleteButtons"
                  />
                </div>
                <!-- History Details -->
                <div
                  v-if="historyFilterRecords && historyFilterRecords.length > 0"
                  class="u-row u-msmall u-border-bottom u-margin-top"
                >
                  <div class="u-row u-section u-margin-left u-margin-right-26 u-border-bottom-2px">
                    <label>History ({{ historyFilterRecords.length }}) </label>
                    <span class="arrow-down u-right"
                      ><img
                        :src="getImageUrlM()"
                        @click="toggleIcon()"
                        alt="arrow-down"
                        class="arrow-down"
                      />
                    </span>
                  </div>
                  <UATableDisplay
                    v-if="history"
                    :cardRowCss="['u-card u-round u-padding-24 u-section-1 u-white']"
                    :borderCssClass="['u-primary-inv-border u-display-inline']"
                    :tableData="historyFilterRecords"
                    :tableFields="subTabFlds[subTabFlds.id][0].tableMetaData"
                  />
                </div>
              </div>
            </template>
          </div>
        </div>
      </template>
    </div>
  </div>
  <div class="u-row" v-else>
    <div class="u-col l12 m12 s12 u-padding">
      <div class="u-col l8 m8 s8 u-sans-serif">
        <label v-if="displayHeader" :class="displayHeader.cssClass">{{
          displayHeader.headerText
        }}</label>
      </div>
    <div class="u-col l2 m2 s2 u-section-1">
      <UAButton
        @click="toggleEditPop()"
        cssClass="u-button u-round u-secondary-1 u-right u-padding-xsmall u-margin-right-70px"
        ><img
          src="@/assets/img/edit.png"
          alt
          class="u-border-0 u-transparent"
        />
        Edit default
      </UAButton>
      <UAModalDisplay
        v-if="editpop"
        @close="CloseEditPopup()"
        :modalTable="editTableFields[0].modalTemp"
        @addNewFieldRow="addCustomerNewFieldRows(editTableFields[0].modalTemp)"
        @deleteNewFieldRow="deleteCustomerNewFieldRows('',editTableFields[0].modalTemp)"
        :footerFields="modalButtons[0].editButtons"
      />
    </div>
    <div class="u-col l2 m2 s2 u-section-1">
      <UAButton
        @click="toggleInfoPop()"
        cssClass="u-button u-round u-primary-1-pur u-right u-padding-xsmall"
      >
        + Add exception
      </UAButton>
    </div>
    </div>
    <!-- Search Filters -->
    <div class="u-row u-padding" v-if="searchfilters">
      <UASearchData
        :inlineFilterConfig="searchfilters[0]?.currencyFilters"
        @checkUFTableDataFound="enableTableData"
        @resetDefaultData="resetData"
      />
    </div>
    <!-- Desc Table -->
    <div class="u-row u-padding">
      <UATableDisplay
        hideScroll=true
        :tableData="fltFlow1Data"
        :tableFields="getOVSIFields"
        :borderCssClass="['u-primary-inv-border']"
        :tableCssClass="['u-border u-white']"
      />
    </div>
    <!-- Sub Tabs -->
    <div class="u-row u-padding">
            <h3>11 Exceptions</h3>
            <div class="u-row">
              <UATab
                :tabFields="subtabs"
                @selectedTab="handleSelectSubTab"
              />
            </div>
            <template
              v-for="(subTabFlds, subTabIndex) in subtabs"
              :key="subTabIndex"
            >
              <div class="u-row" v-if="selectedSubTabIndex == subTabIndex">
                <!-- Search Keyword -->
                <div class="u-row u-section-1">
                  <UAConfigSearchKeyword
                    v-model:searchKeyword="searchKeyword"
                    :cssClass="['u-col 14 m4 s4 u-fnt-itlc']"
                    :placeholder="subTabFlds[subTabFlds.id][0].placeholder"
                  />
                </div>
                <!-- SubTabs TableDetails -->
                <div class="u-row">
                  <UATableDisplay
                    :cardRowCss="['u-card u-round u-padding-24 u-section-1 u-white']"
                    :borderCssClass="['u-primary-inv-border u-display-inline']"
                    @handleConfirmOk="handleConfirmOkFunc"
                    :tableData="filterRecords"
                    :tableFields="subTabFlds[subTabFlds.id][0].tableMetaData"
                    @setShowModalPopup="setShowModalPopup"
                  />
                  <!-- Add Exception -->
                  <UAModalDisplay
                    v-if="infopop"
                    @close="ClosetabsPopup()"
                    :modalTable="subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp"
                    @addNewFieldRow="
                      addCustomerNewFieldRows(subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp)"
                    @addExtraFieldRow="
                      addExtraFieldRows(subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp)"
                    @deleteNewFieldRow="
                      deleteCustomerNewFieldRows('',subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp)"
                    @deleteExtraFieldRow="
                      deleteExtraFieldRows('',subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp)"
                    @addExtraAdditionalRow="
                    addNewExtraFieldRows(subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp)"
                    @deleteExtraAdditionalRow="
                    deleteNewExtraFieldRows('',subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp)"
                    :footerFields="modalButtons[0].addButtons"
                  />
                  <!-- Edit Exception -->
                  <UAModalDisplay
                    v-if="showModalPopup"
                    @close="ClosetabsPopup()"
                    :modalTable="subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp"
                    :tableData="modalData"
                    @addNewFieldRow="
                      addCustomerNewFieldRows(subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp)"
                    @deleteNewFieldRow="
                      deleteCustomerNewFieldRows('',subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp)"
                    @addExtraFieldRow="
                      addExtraFieldRows(subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp)"
                    @deleteExtraFieldRow="
                      deleteExtraFieldRows('',subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp)"
                    @addExtraAdditionalRow="
                    addNewExtraFieldRows(subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp)"
                    @deleteExtraAdditionalRow="
                    deleteNewExtraFieldRows('',subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp)"
                    :footerFields="modalButtons[0].editDeleteButtons"
                  />
                </div>
                <!-- History Details -->
                <div
                  v-if="historyFilterRecords && historyFilterRecords.length > 0"
                  class="u-row u-msmall u-border-bottom u-margin-top"
                >
                  <div class="u-row u-section u-margin-left u-margin-right-26 u-border-bottom-2px">
                    <label>History ({{ historyFilterRecords.length }}) </label>
                    <span class="arrow-down u-right"
                      ><img
                        :src="getImageUrlM()"
                        @click="toggleIcon()"
                        alt="arrow-down"
                        class="arrow-down"
                      />
                    </span>
                  </div>
                  <UATableDisplay
                    v-if="history"
                    :cardRowCss="['u-card u-round u-padding-24 u-section-1 u-white']"
                    :borderCssClass="['u-primary-inv-border u-display-inline']"
                    :tableData="historyFilterRecords"
                    :tableFields="subTabFlds[subTabFlds.id][0].tableMetaData"
                  />
                </div>
              </div>
            </template>
    </div>
  </div>
  <UAConfirmBox ref="uaconfirmbox" v-if="showConfrmBox"/>
</template>

<script>
import { mapState, mapGetters, mapMutations, mapActions } from "vuex";
import UATableDisplay from "./UATableDisplay.vue";
import UAOvsiTableColLayout from "./UAOvsiTableColLayout.vue";
import UAConfigSearchKeyword from "./UAConfigSearchKeyword.vue";
import UATab from "./UATab.vue";
import UASearchData from "./UASearchData.vue";
import UAButton from "./UAButton.vue";
import UAModalDisplay from "./UAModalDisplay.vue";
import UAConfirmBox from "./UAConfirmBox.vue";

export default {
  name: "UAOSLFlowMultiTabs",
  data() {
    return {
      selectedTabIndex: 0,
      selectedSubTabIndex: 0,
      infopop: false,
      editpop: false,
      history: false,
      isDisabled: false,
      isAddExtra: false,
      tabsObjCopy: {},
      searchKeyword: "",
      showModalPopup: false,
      modalData: [],
      newFltTblData: [],
      addTableFieldsCopy:[],
      editTableFieldsCopy:[],
      subTabsObjCopy: {},
      showConfrmBox:false,
      fltFlow1Data: [
        {
          desc: "Overbooking is sale of a volatile good or service in excess of actual supply.Overselling is a common practice in the travel and hospitality sectors, in which it is expected that some people will cancel.",
          threshold: "+4",
          capacity: "10%",
          start_value: "+1",
          end_value: "+3",
          mil_usd: "$0.02",
          currency: "Euro",
          min_curr: "€102.27",
          max_curr: "€2,556.63",
          intiation_starttime: "12 hours",
          intiation_stoptime: "1 hour",
          baseline_bid_ma: "0.60",
          baseline_bid_mb: "0.80",
          baseline_bid_mc: "1.00",
          xfactor: "3",
          olb_threshold: "OLB <= AU+3",
          hbd_threshold: "HBD > 18",
          combined_threshold: "OLB <= AU+1 and HBD > 12",
        },
      ],
      fltTblData: [
        {
          order: "01",
          status: "Active",
          flt: "UA 1234",
          // "dt_range":"start dt",
          threshold: "+3",
          origin: "SFO",
          destination: "LAX",
          c_origin: "France",
          c_destination: "Canada",
          time_bnd: "18:00",
          dt_range: "00:00",
          station: "SFO",
          xfactor: "3",
          olb_threshold: "OLB <= AU+3",
          hbd_threshold: "HBD > 18",
          combined_threshold: "OLB <= AU+1 and HBD > 12",
        },
        {
          order: "02",
          status: "Active",
          flt: "UA 219",
          // "dt_range":"start dt",
          threshold: "+3",
          origin: "IAH",
          destination: "EWR",
          c_origin: "Japan",
          c_destination: "Australia",
          time_bnd: "18:00",
          dt_range: "00:00",
          station: "EWR",
          xfactor: "3",
          olb_threshold: "OLB <= AU+3",
          hbd_threshold: "HBD > 18",
          combined_threshold: "OLB <= AU+1 and HBD > 12",
        },
        {
          order: "03",
          status: "Active",
          flt: "UA 219",
          dt_range: "start dt",
          threshold: "+3",
          origin: "ORD",
          destination: "LAX",
          c_origin: "United States",
          c_destination: "Columbia",
          time_bnd: "18:00",
          dt_range: "00:00",
          station: "LAX",
          xfactor: "3",
          olb_threshold: "OLB <= AU+3",
          hbd_threshold: "HBD > 18",
          combined_threshold: "OLB <= AU+1 and HBD > 12",
        },
        {
          order: "04",
          status: "Active",
          flt: "UA 219",
          // "dt_range":"start dt",
          threshold: "+3",
          origin: "IAH",
          destination: "EWR",
          c_origin: "Japan",
          c_destination: "Australia",
          time_bnd: "18:00",
          dt_range: "00:00",
          station: "EWR",
          xfactor: "3",
          olb_threshold: "OLB <= AU+3",
          hbd_threshold: "HBD > 18",
          combined_threshold: "OLB <= AU+1 and HBD > 12",
        },
        {
          order: "05",
          status: "Active",
          flt: "UA 219",
          // "dt_range":"start dt",
          threshold: "+3",
          origin: "ORD",
          destination: "SFO",
          c_origin: "Japan",
          c_destination: "Australia",
          time_bnd: "18:00",
          dt_range: "00:00",
          station: "SFO",
          xfactor: "3",
          olb_threshold: "OLB <= AU+3",
          hbd_threshold: "HBD > 18",
          combined_threshold: "OLB <= AU+1 and HBD > 12",
        }
      ],
      historyFltTblData: [
        {
          order: "01",
          status: "Modified",
          flt: "UA 1234",
          // "dt_range":"start dt",
          threshold: "+3",
          origin: "SFO",
          destination: "LAX",
          c_origin: "France",
          c_destination: "Canada",
          time_bnd: "18:00",
          dt_range: "00:00",
          station: "SFO",
          xfactor: "3",
          olb_threshold: "OLB<=AU+3",
          hbd_threshold: "HBD>18",
          combined_threshold: "OLB<=AU+1 and HBD>12",
        },
        {
          order: "02",
          status: "Deleted",
          flt: "UA 219",
          // "dt_range":"start dt",
          threshold: "+3",
          origin: "IAH",
          destination: "EWR",
          c_origin: "Japan",
          c_destination: "Australia",
          time_bnd: "18:00",
          dt_range: "00:00",
          station: "EWR",
          xfactor: "3",
          olb_threshold: "OLB<=AU+3",
          hbd_threshold: "HBD>18",
          combined_threshold: "OLB<=AU+1 and HBD>12",
        },
      ],
    };
  },
  created(){
    this.getOVSIData({
        partitionKey: this.partitionKeyID,
      actionId: this.actionId,
  })
  },
  mounted() {
    this.tabsObjCopy = JSON.parse(JSON.stringify(this.tabs));
  },
  props: [],
  computed: {
    ...mapState({
      displayHeader: (state) => state.ovsiDefaultModule.displayHeader,
      searchfilters: (state) => state.ovsiDefaultModule.searchfilters,
      searchOVSIData: (state) => state.ovsiDefaultModule.searchOVSIData,
      tableDetails: (state) => state.ovsiDefaultModule.tableDetails,
      sections: (state) =>
        state.ovsiDefaultModule.entityDisplayDetails.Layouts[0].InnerLayout
          .sections,
      prevNavigateViews: (state) => state.ovsiDefaultModule.prevNavigateViews,
      isNavigatedEvent: (state) => state.ovsiDefaultModule.isNavigatedEvent,
      tabs: (state) => state.ovsiDefaultModule.tabs,
      subtabs: (state) => state.ovsiDefaultModule.subtabs,
      modalButtons: (state) => state.ovsiDefaultModule.modalButtons,
      addTableFields: (state) => state.ovsiDefaultModule.addTableFields,
      editTableFields: (state) => state.ovsiDefaultModule.editTableFields,
      actionId: (state) => state.ovsiDefaultModule.actionId,
      partitionKeyID: (state) => state.ovsiDefaultModule.partitionKeyID,
      filterRecords() {
        this.finalResults = this.fltTblData;
        if (this.searchKeyword && Object.keys(this.searchKeyword).length > 0) {
          const search = this.searchKeyword.toLowerCase();
          return this.finalResults.filter((fltData) => {
            return (
              fltData.origin.toLowerCase().includes(search) ||
              fltData.flt.includes(search) ||
              fltData.station.toLowerCase().includes(search) ||
              fltData.destination.toLowerCase().includes(search) ||
              fltData.c_origin.toLowerCase().includes(search) ||
              fltData.c_destination.toLowerCase().includes(search)
            );
          });
        }else if(this.newFltTblData.length > 0){
          return this.newFltTblData;
        }
        //return final filter results
        return this.finalResults;
      },
      historyFilterRecords() {
        this.finalResults = this.historyFltTblData;
        if (this.searchKeyword && Object.keys(this.searchKeyword).length > 0) {
          const search = this.searchKeyword.toLowerCase();
          return this.finalResults.filter((fltData) => {
            return (
              fltData.origin.toLowerCase().includes(search) ||
              fltData.flt.includes(search) ||
              fltData.station.toLowerCase().includes(search) ||
              fltData.destination.toLowerCase().includes(search) ||
              fltData.c_origin.toLowerCase().includes(search) ||
              fltData.c_destination.toLowerCase().includes(search)
            );
          });
        }
        //return final filter results
        return this.finalResults;
      },
    }),
    ...mapGetters([
      "getOVSIFields",
      "getJPathvalue",
      "getOVSIEntityId",
      "getImageUrl",
    ]),
  },
  methods: {
    ...mapActions(["getOVSIData"]),

    ...mapMutations([
      "getShowUFInlineTable",
      "getSelectedUFDataId",
      "setShowFilters",
      "setShowInnerLayoutTable",
    ]),
    getFieldByIdWrapper(tblMetaData){
      this.addTableFieldsCopy = JSON.parse(JSON.stringify(this.addTableFields));
      let fields = this.addTableFieldsCopy.filter( field => tblMetaData.fieldIdsToBind.includes(field.id));
      let tableInfoTemp = JSON.parse(JSON.stringify(tblMetaData));
      tableInfoTemp.modalFields=fields;
      return tableInfoTemp;
    },
    handleConfirmOkFunc(confrmInfoObj){
      this.showConfrmBox =true;
      let {events, data} = confrmInfoObj;
      setTimeout(() => {  
        if(events.name == "delete"){
            this.$refs.uaconfirmbox
            .dialogOpen({
              title: "Delete flight !",
              message: `Are you sure you want to delete selected flight ${data.flt}`,
              okButtonText: "Yes",
              cancelButtonText: "No",
            })
            .then(async (ok) => {
              this.deleteFlightFieldRows(data);
            })
            .catch((er) => {});
        }
      }, 50);
    },
    deleteFlightFieldRows(data) {
      this.newFltTblData = [];
      this.newFltTblData = this.fltTblData.filter((item) => item.flt != data?.flt);
    },
    getImageUrlM() {
      if (this.history) return this.getImageUrl("expand_less.png");
      else return this.getImageUrl("arrow-down.png");
    },
    toggleIcon() {
      this.history = !this.history;
    },
    setShowModalPopup(currRowData) {
      this.modalData = [currRowData];
      this.showModalPopup = true;
    },

    addTabsCustomerNewFieldRows(currmodalData) {
      currmodalData.addNewRowFields.push(
        JSON.parse(JSON.stringify(this.addTableFields[0].additionalFields[0]))
      );
    },

    addTabsExtraFieldRows(currmodalData) {
      currmodalData.addExtraRowFields.push(
        JSON.parse(JSON.stringify(this.addTableFields[0].extraAdditionalFields[0]))
      );
    },
    addTabsNewExtraFieldRows(currmodalData) {
      currmodalData.addNewExtraRowFields.push(
        JSON.parse(JSON.stringify(this.addTableFields[0].addNewAdditionalFields[0]))
      );
    },

    addCustomerNewFieldRows(currmodalData) {
      currmodalData.addNewRowFields.push(
        JSON.parse(JSON.stringify(currmodalData.additionalFields[0]))
      );
    },

    addExtraFieldRows(currmodalData) {
      currmodalData.addExtraRowFields.push(
        JSON.parse(JSON.stringify(currmodalData.extraAdditionalFields[0]))
      );
    },

    addNewExtraFieldRows(currmodalData) {
      currmodalData.addNewExtraRowFields.push(
        JSON.parse(JSON.stringify(currmodalData.addNewAdditionalFields[0]))
      );
    },

    deleteCustomerNewFieldRows(indx, currmodalData) {
      currmodalData.addNewRowFields = currmodalData.addNewRowFields.filter(
        (item, ind) => ind != indx
      );
    },

    deleteExtraFieldRows(indx, currmodalData) {
      currmodalData.addExtraRowFields = currmodalData.addExtraRowFields.filter(
        (item, ind) => ind != indx
      );
    },

    deleteNewExtraFieldRows(indx, currmodalData) {
      currmodalData.addNewExtraRowFields = currmodalData.addNewExtraRowFields.filter(
        (item, ind) => ind != indx
      );
    },

    handleSelectTab(tab, tabIndex) {
      this.ResetSelectTab();
      this.ResetSelectSubTab();
      this.selectedTabIndex = tabIndex;
      this.selectTab(tab);
    },

    handleSelectSubTab(tab, tabIndex) {
      this.ResetSelectSubTab();
      this.selectedSubTabIndex = tabIndex;
      this.selectTab(tab);
    },

    selectTab(tab) {},
    ResetSelectSubTab() {
      this.selectedSubTabIndex = '';
      this.infopop = false;
      this.showModalPopup = false;
      this.editpop = false;
    },

    ResetSelectTab() {
      this.selectedTabIndex = '';
      this.infopop = false;
      this.showModalPopup = false;
      this.editpop = false;
    },
    
    toggleEditPop() {
      this.editpop = true;
    },
    CloseEditPopup() {
      this.editTableFieldsCopy = JSON.parse(JSON.stringify(this.editTableFields));
      this.editTableFields[0].modalTemp = JSON.parse(JSON.stringify(this.editTableFieldsCopy[0].modalTemp));
      this.editpop = false;
    },
    CloseEditDefault() {
      //this.tabs[this.selectedTabIndex][this.tabs[this.selectedTabIndex].id][0].editDefaultFields[0].modalTemp = 
      //JSON.parse(JSON.stringify(this.tabsObjCopy[this.selectedTabIndex][this.tabsObjCopy[this.selectedTabIndex].id][0].editDefaultFields[0].modalTemp));
      this.editpop = false;
    },
    toggleInfoPop() {
      this.infopop = true;
    },
    ClosePopup() {
      this.infopop = false;
      this.showModalPopup = false;
      this.tabs.forEach((tabFlds) => {
        tabFlds[tabFlds.id][0].subTabs.forEach((subTabFlds) =>{
          subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp.addNewRowFields = [];
          subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp.addExtraRowFields = [];
          subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp.addNewRowFields = [];
          subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp.addExtraRowFields = [];
        })
      });
    },
    ClosetabsPopup() {
      this.infopop = false;
      this.showModalPopup = false;
      this.subtabs.forEach((subTabFlds) => {
          subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp.addNewRowFields = [];
          subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp.addExtraRowFields = [];
          subTabFlds[subTabFlds.id][0].addExceptionFields[0].modalTemp.addNewExtraRowFields = [];
          subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp.addNewRowFields = [];
          subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp.addExtraRowFields = [];
          subTabFlds[subTabFlds.id][0].editExceptionFields[0].modalTemp.addNewExtraRowFields = [];
      });
    },
    enableTableData(isShow) {
      this.setShowInnerLayoutTable(isShow);
      this.setShowFilters(true);
      if (isShow) {
        // this.$refs.uaInnerLayout.getSearchData();
      }
    },
    resetData() {
      this.showInlineTables = false;
      //  this.setShowInnerLayoutTable(this.searchOVSIData.length == 0 ? false : this.showInnerLayoutTable);
      this.getShowUFInlineTable(false);
      this.getSelectedUFDataId(0);
      this.searchOVSIData.map((obj) => (obj.expandTable = true));
    },
  },
  components: {
    UATableDisplay,
    UAOvsiTableColLayout,
    UAConfigSearchKeyword,
    UATab,
    UAButton,
    UAModalDisplay,
    UASearchData,
    UAConfirmBox
  },
};
</script>
<style scoped>
.u-margin-right-70px {
  margin-right: -70px !important;
}
</style>
