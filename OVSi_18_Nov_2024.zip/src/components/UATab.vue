<template>
    <div :class="['tab u-top-border-radius',cssClass,headerSticky ? 'u-ovsi-sub':'']">
        <template v-for="(tab, tabIndex) in tabFields" :key="tabIndex">
            <UAButton @click="selectedTab(tab, tabIndex)" :id="tab.id"
                :cssClass="[tab.cssClass, (tabIndex == (getSelectedTabIndex) )? 'active' : '']">
                {{ tab.label }} <span v-if="countArray" >({{countArray[tabIndex]}})</span></UAButton>
        </template>
    </div>
</template>

<script>
import UAButton from './UAButton.vue';
export default {
    name: 'UATab',
    components: {
        UAButton
    },
    data() {
        return {
            selectedTabIndex: 0,
        }
    },
    emits:["selectedTab"],
    props: ['tabFields','cssClass', 'selectedTabInd','countArray','headerSticky'],
    computed:{
        getSelectedTabIndex(){
            return this.selectedTabInd ? this.selectedTabInd :this.selectedTabIndex;
        }
    },
    methods: {
        selectedTab(tab, tabIndex) {
            if(this.getSelectedTabIndex != tabIndex){
                this.selectedTabIndex = tabIndex;
                this.$emit('selectedTab', tab, tabIndex);
            }
        }
    }

}
</script>

<style scoped>
/* Style the tab */
.tab {
    overflow: hidden;
    border-bottom: 2px solid #a0a5ab;
}

/* Style the buttons inside the tab */
.tab button {
    background-color: inherit;
    border-radius: inherit;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    transition: 0.3s;
    font-size: 14px;
}

/* Change background color of buttons on hover */
.tab button:hover {
    background-color: #ddd;
}

/* Create an active/current tablink class */
.tab button.active {
    /* background-color: #ccc; */
    font-weight: bold;
   color: #0c2340;
    border-bottom: 3px solid #0c2340
}

/* Style the tab content */
.tabcontent {
    display: none;
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;
}
</style>