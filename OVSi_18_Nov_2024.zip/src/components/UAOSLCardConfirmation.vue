<template>
  <div  class="u-modal u-col u-overlay" :style="['display: block']">
    <UAModalAlertMessage v-once />
    <div ref="cardConfirmCompRef" @mouseleave="mouseLeaveHandler()" @mouseover="mouseOverHandler()" class="u-round u-card-confirm-content">
      <div class="u-row u-padding-bottom-4">
           <div :class="['u-col l11 m11 s11 u-col u-medium u-fnt-bld u-ht-15 u-left-align']">
             <label :class="['u-ls-ws u-panel-xsmall u-section-1']">
                {{ConfirmActionTitle}}
             </label>
          </div>
           <div class="u-col l1 m1 s1">
                 <UAButton
                   @click="$emit('close')"
                   cssClass=" u-transparent u-medium u-primary-inv-border u-fnt-bld u-right u-pad-0 u-pointer"
                 >
                 <img src="../assets/img/close_grey.png" alt="Close icon" class="" id="close_delete_icon"/>
                 </UAButton>
           </div>
        </div>
      <div class="u-row">
      <label v-if="ConfirmActionMsg" class="u-ls-ws1 u-panel-xsmall u-section-1"> {{ ConfirmActionMsg }}</label>
     </div>
  <div
  class="u-card u-row u-white u-section-1 u-cardView u-border-top u-round-10px u-margin-left-16"
      style="min-height: 9.4rem;width:90%"
    >
    <div :class="['u-row u-top-border-radius',cssClass]">
        <h6 :class="['u-text-0 u-section-1 u-padding-small u-text-white']" >
          <label >
            <a >{{label}}</a>
            <a class="u-right" v-if="secondaryLabel" >{{secondaryLabel}}</a></label>
        </h6>
      </div>
      <div class="u-row u-center" v-if="fields">
        <UATable :fields="fields" :data="records" imgpath="poi.png"/>
      </div>
       <div :class="['u-row']" v-if="cardTable && cardTable.cardFields && cardTable.cardFields.length >0">
      <template v-for="(cardData, cardIndex) in cardTable.cardFields" :key="cardIndex">
        <div :class="[cardData.styles.cardDivCss]">
        <component
        :is="cardData.ComponentType"
        :tblHeaders="cardData[cardData.id][0].headers[0]" 
        :tableData="tableData" 
        :tableFields="cardData[cardData.id][0].tableFields"
        :sectionHeader="cardData[cardData.id][0].sectionHeader" />
      </div>
      </template>
      </div>
      <div v-else class="u-row u-center" style="cursor:auto">
        <h2 ><b>{{ data }}</b></h2>
        <a v-if="link" @click="$emit('linkClicked')">{{link}}</a>
      </div>
  </div>
  <div>
      <div class="u-row u-pad-0 u-section-1">
      <div class="u-col l12 m12 s12">
      <div class="u-row-padding u-pad-0 u-center">
        <template v-for="(hField, hKey) in CardBtnFields" :key="hKey">
          <div class= 'u-col l6 u-margin-top' >
            <!-- UAButton -->
          <component
            :is="hField.fieldType"
            @click="genericHandler(hField.events)"
            :cssClass="hField.fieldsCssClass"         
            ><img
              v-if="hField.icon"
              :class="hField.CssClass"
              :src="getImageUrl(hField.icon)"
            />
            {{ hField.name }}
          </component>
          </div>
        </template>
      </div>
      </div>
      </div>
     </div>
    </div>
</div>
</template>

<script>
import UATable from './UATable.vue';
import UAOvsiTableColLayout from './UAOvsiTableColLayout.vue';
import UAConfirmModal from './UAConfirmModal.vue';
import UAButton from './UAButton.vue';
import UAModalAlertMessage from './UAModalAlertMessage.vue';
export default {
    name: 'UAOSLCardConfirmation',
    components: {UATable, UAOvsiTableColLayout,UAConfirmModal,UAButton,UAModalAlertMessage },
    emits:['delete','close'],
    props: ['cardTable','label','cssClass','data','link','fields','records','labelCss','tableData','details','secondaryLabel','CardBtnFields','cardBtnClass','ConfirmActionMsg','ConfirmActionTitle'] ,
    data(){
  return {
    deletepop: false,
    mouseVisitedOnModal:false,//TO Verify THE mouse FOCUS OR MOUSE OVER ON MODAL DISPLAY at least one time 
    mouseLeaveDetected:false

  }
},
mounted() {
    setTimeout(() =>  document.addEventListener("click",this.handleOutSideClick),100) ;
  },
methods:{
        mouseLeaveHandler(){
          this.mouseLeaveDetected = true;
        },
        mouseOverHandler(){
          this.mouseLeaveDetected = false;
          this.mouseVisitedOnModal = true;
        },
        handleOutSideClick(e){
          if((this.mouseLeaveDetected && this.mouseVisitedOnModal) || (!this.mouseLeaveDetected && !this.mouseVisitedOnModal)){//IF AT LEAST ONCE THE MOUSE OVER THE MODAL DISPLAY AND THEN ONLY DETECT THE MOUSE LEAVE
            if(this.$refs?.cardConfirmCompRef && !this.$refs?.cardConfirmCompRef?.contains(e.target)){
              this.$emit('close');       
            } 
          }
        },
        CloseDeletePopup(){
          this.deletepop = false
        },
        toggleDeletePop() {
            this.deletepop = true
        },
        genericHandler(eventName) {
      if (eventName.name === "cancel") this.$emit("close");
     else {
        this.$emit("delete", this.modalTable);
      }
    },

},



}
</script>

<style>

</style>