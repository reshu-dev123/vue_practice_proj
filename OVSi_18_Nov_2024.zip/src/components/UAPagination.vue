<template>
 <UAButton cssClass="u-button u-round u-primary-1-pur  u-wd-5rem u-padding-8 "
 :disabled="pagination.tokens.length ==0 || isLoading" @click="getPrevData" >PREV</UAButton>
 <label class="u-padding-small" v-if="!isLoading">Page:{{pagination.tokens.length+1  }} Record:{{searchOVSIData.length}}</label>
 <UAButton  cssClass="u-button u-round u-primary-1-pur  u-wd-5rem u-padding-8"
 :disabled="!this.apiResponse.nextPage || isLoading" @click="getData(apiResponse.nextPage,'next')">NEXT</UAButton>
</template>

<script>
import { mapActions, mapMutations, mapState } from 'vuex';
import UAButton from './UAButton.vue'
export default {
  components: { UAButton },
    name: 'UAPagination',
    data(){
      return {
        // tokens: [],
        // prevToke: '',
      }
    },
    computed: {
        ...mapState({
            actionId: (state) => state.ovsiDefaultModule.actionId,
            isLoading: (state) => state.ovsiDefaultModule.isLoading,
            selectedInputValues: (state)=>state.ovsiDefaultModule.selectedInputValues,
            apiResponse: (state)=> state.ovsiDefaultModule.apiResponse,
            searchOVSIData: (state)=> state.ovsiDefaultModule.searchOVSIData,
            pagination: (state)=> state.ovsiDefaultModule.pagination,
        })
    },
    methods: {
        ...mapActions(['getOVSIData']),
        ...mapMutations([
          'setPaginationPrevToken',
          'setSelectedInputValues',
          'setPaginationToken',
          'setPaginationTokens'
        ]),
        getData(token,event){
            const finalObj = {
              inputObject: {
                ...this.selectedInputValues.inputObject
              },
              actionId: this.actionId,
          };
          finalObj.inputObject.page=token.toString();
          if(token){
            if(event == 'next'){
              if(this.pagination.tokens.length ==0){
                //this.tokens.push('');
                this.setPaginationToken('')
              }else{
                //this.tokens.push(this.prevToke);
                this.setPaginationToken(this.pagination.prevToken);
              }
              
            }
          }
           this.getOVSIData(finalObj)
          .then(res=>console.log(res,' this.pagination:- ',this.pagination,'finalObj',finalObj))
          .finally(()=>{
            //this.prevToke=token;
            this.setPaginationPrevToken(token);
            let selectedObj = JSON.parse(JSON.stringify(this.selectedInputValues));
            if (event == 'next') {
              selectedObj.inputObject.page = token;
             }else{
              selectedObj.inputObject.page = this.pagination.prevToken;
             }
            this.setSelectedInputValues(selectedObj);
          });
        },
        getPrevData(){
          let tokens=JSON.parse(JSON.stringify(this.pagination.tokens));
          this.getData(tokens.pop(),'prev');
          this.setPaginationTokens(tokens);
        },
    }

}
</script>

<style>

</style>