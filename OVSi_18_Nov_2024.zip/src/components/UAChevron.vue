<template>
    <span @click="$emit('toggleArrow')" class="u-col l1"
        :title="toggle ? 'Close' : 'Expand'">
        <img v-if="toggle" src="@/assets/img/expand_less.png" alt="chevron-down"
            class="u-menuImgSml u-border-0 u-section-1 u-transparent printHide" />
        <img v-else src="@/assets/img/expand_more.png" alt="chevron-down"
            class="u-menuImgSml u-border-0 u-section-1 u-transparent printHide" />
    </span>
</template>
<script>
export default {
    name: 'UAChevron',
    props: ['toggle'],
    emits:['toggleArrow']
}
</script>