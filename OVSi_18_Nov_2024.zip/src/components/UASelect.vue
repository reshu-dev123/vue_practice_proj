<template>
  <div class="ua-select u-pointer" ref="selectComRef">
    <div
      class="selected-items u-show"
      @click="listDD"
      :id="`select_toggle_${id}`"
    >
      <label
        :class="[isFloatLabel ? floatClass : 'u-msmall', cssMargin]"
        :for="id"
        v-if="showLabel"
        >{{ this.modelValue != "" ? this.labelInfo : this.placeholder }}
        <span class="u-text-red" v-if="isMandatory">*</span>
      </label>
      <UATextbox
        type="textbox"
        :class="[ isViewDetails? 'u-disabled' :'',
          'u-input u-input-1 u-round searchDrpInput',
          cssClass,
          { 'u-padding-top-32 u-text-0': isFloatLabel },
        ]"
        style="cursor: pointer; padding-right: 2rem"
        :readOnly="currInputFieldInfo.isTextInputReadOnly"
        v-model="selectedText"
        required="true"
        :placeholder="isFloatLabel ? '' : placeholder"
        autocomplete="off"
        v-if="!multiSelect"
        :id="id"
      />
      <span
        ><img
          src=".././assets/img/arrow-down.png"
          alt="arrow-down"
          
          class="arrow-down"
      /></span>
    </div>
    <div :class="['select-container',dropDownCss ? 'u-z-index-0' : 'u-z-index-999']" v-if="isVisible">
      <li v-if="multiSelect">
        <UATextbox
          type="search"
          id="UASearch"
          class="u-input u-border u-round multimodelValue"
          v-model="multimodelValue"
          placeholder="Serach DropDown"
          required="true"
        />
        <input
          type="checkbox"
          v-model="selectAll"
          value="Select All"
          @change="onSelectAll($event)"
        /><span class="selectAll">Select All</span>
      </li>
      <div class="options">
        <ul
          class="selectOptions"
          :style="[
            'margin-bottom: 0px',
            filteredSelectOptions.length > 5
              ? ''
              : 'height:auto;overflow:unset;min-height:auto',
          ]"
        >
          <li
            @click="selectSingleItem(item)"
            v-for="(item, index) in filteredSelectOptions"
            v-bind:key="index"
          >
            <input
              type="checkbox"
              v-if="multiSelect"
              v-model="item.name"
              @change="onChange($event, item, index)"
            />
            <span>{{ item.label }}</span>
          </li>
        </ul>
      </div>
    </div>
  </div>
</template>
<script>
import { mapState, mapGetters, mapActions, mapMutations } from "vuex";
import UATextbox from "../components/UATextbox";
import UADropDown from "../components/UADropDown";
export default {
  name: "UASelect",
  data() {
    return {
      //modelValue:'',
      selectedItem: null,
      isVisible: false,
      selectAll: false,
      multiSelectItems: [],
      multimodelValue: "",
      selectedText: "",
      selectedOptions :{}
    };
  },
  created() {
    this.setSelectedText();
  },
  mounted() {
    if (this.modelValue && this.isModalvalueSwap==undefined) {     
      this.setSelectedText();   
        this.$emit("update:modelValue", this.modelValue);  
        //
       // this.selectedText = this.modelValue;
      
    } else {
       this.$emit("update:modelValue", this.selectedText);  
    }

    document.addEventListener("click", (e) => {
      //if (!this.$el.contains(e.target)) {
      if( this.isVisible){
        if(this.$refs.selectComRef && !this.$refs.selectComRef.contains(e.target)){
          this.isVisible = false;
        }
      }
    });
  },
  unmounted() {
    document.removeEventListener("click", () => {
      this.isVisible = false;
    });
  },
  computed: {
  ...mapState({
    isViewDetails: (state) => state.ovsiDefaultModule.isViewDetails,
    prevOptions: (state) => state.ovsiDefaultModule.prevOptions,
    filteredSelectOptions() {
      if (!this.multiSelect) {
        return this.selectOptions;
      } else if (this.multimodelValue === "" && this.multiSelect) {
        return this.selectOptions;
      } else if (this.multimodelValue != "") {
        return this.selectOptions.filter((item) =>
          item.label.toLowerCase().includes(this.multimodelValue.toLowerCase())
        );
      }
    },
    floatClass() {
      return this.modelValue != "" ? "u-floatFly" : "u-float u-index";
    },
  }),
  ...mapGetters(["getUserName","getPrevOptions"]),
  },
  watch: {
    modelValue(newVal, oldVal) {
      this.setSelectedText();
    },
  },
  methods: {
    ...mapActions(["clearAlertMessages","updatePrevOptions"]),
    listDD() {
      if(this.isViewDetails){
        this.isVisible = false;
      } else{
      this.isVisible = !this.isVisible;
      //this.$emit("update:modelValue", "");
      //this.selectedText = "";
      this.multiSelectItems = [];
    }
    },
    async setSelectedText() {
      if (this.selectedKey) {
        if (this.selectOptions.length > 0) {
         
          let filterObj = this.selectOptions.filter((item) => {
            return item[this.selectedKey] === this.modelValue;
          });
          if (filterObj.length > 0) {
            this.selectedText = filterObj[0].label;
          } else {
            this.selectedText = this.modelValue;
          }
        }
      } else {
        if(this.isModalvalueSwap==undefined){
          this.selectedText = this.modelValue;
        } else {
         
          let filterObj = this.selectOptions.filter((item) => {
            return item['id'] == this.modelValue;
          });
          if (filterObj.length > 0) {
             this.selectedText = filterObj[0].label;
          } else {
            this.selectedText = this.modelValue;
          }
        }
        
      }
    },
    selectSingleItem(item) {
      if (!this.multiSelect) {
        this.selectedOptions = this.getPrevOptions;
        this.selectedOptions[item?.key] = item.label; //updating curent selected value
        this.selectedText = item.label;
        this.selectedText = item.showPrevOpt ? this.prevOptions[item?.key] : item.label; //updating selected value from state
        setTimeout(() => this.updatePrevOptions(JSON.parse(JSON.stringify(this.selectedOptions))), 1 * 1);
        setTimeout(() => this.getPrevOptions, 1 * 1);
        this.$emit(
          "update:modelValue",
          this.selectedKey ? item[this.selectedKey] : item.label
        );
        this.isVisible = false;
      }
    },
    onChange(event, item, i) {
      if (event.target.checked) {
        this.multiSelectItems.push(item.label);
      } else {
        let eleIndex = this.multiSelectItems.indexOf(item.label);
        this.multiSelectItems.splice(eleIndex, 1);
      }
      this.selectedItem = this.multiSelectItems.join(", ");

      if (this.multiSelectItems.length > 3) {
        this.selectedItem =
          this.multiSelectItems.length + " " + "Options" + " " + "selected";
      }
      if (this.multiSelectItems.length === this.selectOptions.length) {
        this.selectAll = true;
      } else {
        this.selectAll = false;
      }
    },
    onSelectAll(event) {
      if (event.target.checked) {
        let selectedArrayValues = this.multiSelectItems;
        let filterUnselectedOptions = this.selectOptions.filter(
          (o1) => !selectedArrayValues.some((o2) => o1.label === o2)
        );
        filterUnselectedOptions.forEach((item, index) => {
          item.name = true;
          this.multiSelectItems.push(item.label);
        });
        if (this.multiSelectItems.length === this.selectOptions.length) {
          this.selectAll = true;
          this.selectedItem = this.multiSelectItems.join(", ");
          if (this.multiSelectItems.length > 3) {
            this.selectedItem =
              this.multiSelectItems.length + " " + "Options" + " " + "selected";
          }
        } else {
          this.selectAll = false;
        }
      } else {
        this.selectOptions.forEach((item, index) => {
          item.name = false;
          this.multiSelectItems = [];
          this.selectedItem = "";
        });
      }
    },
  },
  props: [
    "id",
    "selectOptions",
    "multiSelect",
    "sourceType",
    "modelValue",
    "labelInfo",
    "isFloatLabel",
    "isMandatory",
    "placeholder",
    "showLabel",
    "cssClass",
    "selectedKey",
    "cssMargin",
    "isModalvalueSwap",
    "currInputFieldInfo",
    "dropDownCss"
  ],

  components: {
    UADropDown,
    UATextbox,
  },
};
</script>
<style scoped lang="scss">
.ua-select {
  position: relative;
  .selected-items {
    border-radius: 4px;
    display: flex;
    justify-content: space-between;
    .arrow-down {
      position: absolute;
      top: 1.4rem;
      right: 0.8rem;
      // width: 15px;
      //height: 10px;
    }
  }
    .u-z-index-0 {
      z-index: 0 !important;
    }
    .u-z-index-999 {
      z-index: 999;
    }
  .select-container {
    position: absolute;
    border: 1px solid #e1e1e1;
    top: 3.2rem;
    left: 0;
    right: 0;
    border-radius: 4px;
    background-color: #fff;
    width: 100%;
    .selectOptions {
      height: 200px;
      overflow-y: scroll;
    }
    li {
      list-style-type: none;
      padding: 10px 10px 0px 10px;
      font-size: 12px;
    }
    .selectAll {
      padding-left: 20px;
    }
    .multiSelectSearch {
      width: 90%;
      height: 100%;
      margin: 10px auto;
    }

    .searchDrpInput {
      width: 100%;
      height: 100%;
      padding-right: 2.5rem;
    }
    .options {
      width: 100%;

      ul {
        list-style: none;
        text-align: left;
        min-height: 200px;
        overflow-y: scroll;
        margin-top: 0px;
        padding-left: 0px;
        li {
          width: 100%;
          padding: 10px;
          border-bottom: 1px solid lightgray;

          &:hover {
            background: #4985cc;
            color: #fff;
          }
          &:last-child {
            border-bottom: 0px;
          }
        }
      }
    }
  }
}
</style>