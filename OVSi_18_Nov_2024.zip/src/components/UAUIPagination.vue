<template>
 <UAButton cssClass="u-button u-round u-primary-1-pur  u-wd-5rem u-padding-8 "
 :disabled="currentPage<=startPage" @click="getPrevData" >PREV</UAButton>
 <label class="u-padding-small" v-if="!isLoading">Page:{{currentPage }} Record:{{tableData.length}}</label>
 <UAButton  cssClass="u-button u-round u-primary-1-pur  u-wd-5rem u-padding-8"
 :disabled="currentPage>=endpage" @click="getNextData()">NEXT</UAButton>
</template> 

<script>
import { mapActions, mapMutations, mapState } from 'vuex';
import UAButton from './UAButton.vue'
export default {
  components: { UAButton },
    name: 'UAUIPagination',
    props:['tableData','startPage','endpage'],
    computed: {
        ...mapState({
            actionId: (state) => state.ovsiDefaultModule.actionId,
            isLoading: (state) => state.ovsiDefaultModule.isLoading,
            selectedInputValues: (state)=>state.ovsiDefaultModule.selectedInputValues,
            apiResponse: (state)=> state.ovsiDefaultModule.apiResponse,
            searchOVSIData: (state)=> state.ovsiDefaultModule.searchOVSIData,
            pagination: (state)=> state.ovsiDefaultModule.pagination,
            currentPage: (state) => state.ovsiDefaultModule.currentPage,
        })
    },
    methods: {
        ...mapActions(['getOVSIData']),
        ...mapMutations([
          'setPaginationPrevToken',
          'setSelectedInputValues',
          'setPaginationToken',
          'setPaginationTokens',
          'setCurrentPage'
        ]),
        getNextData(){
          this.setCurrentPage(this.currentPage+1)
        },
        getPrevData(){
          this.setCurrentPage(this.currentPage-1)
        },

    }

}
</script>

<style>

</style>