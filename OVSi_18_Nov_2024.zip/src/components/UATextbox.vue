<template>
  <div :class="[
    'u-display-container u-border u-round u-input-1 u-text-3 u-bg-4 u-small', { 'u-msmall': isFloatLabel },
    (errmsg && modelValue) ? (this.filtersErrorTooltip ? 'u-tooltip tip-bottom-search u-border-err' : errorOnTop ? 'u-tooltip tip-top-buttons u-border-err' : modalError ? 'u-tooltip tip-bottom-buttons u-border-err' : 'u-tooltip tip-bottom u-border-err') : 'u-border u-input-1'
  ]" :data-tooltip="errmsg">
    <label :class="[isFloatLabel ? floatClass : 'u-msmall',cssMargin]" :for="id" v-if="showLabel">{{getLabelText}}
      <span class="u-medium u-text-red" v-if="isMandatory">*</span>
    </label>
    <input :class="['u-text-0 u-round no-outline',isDisabled?'u-disabled':'', cssClass, errmsg ? 'u-error' : '', cssClass, { 'u-text-0': isFloatLabel },{'u-disabled':$attrs.disabled}]"
      v-bind="$attrs" @paste="onPasteHandler($event)" @keypress="onKeyPressHandler($event)" @input="updateInput($event)" :value="modelValue" :disabled="isDisabled" :id="id"
      autocomplete="off" :placeholder="getInputPlaceHolder" @mousedown="prefixZeros($event)"  @blur="prefixZeros($event)" />
  </div>
</template>
<script>
import { mapGetters, mapState } from "vuex";
export default {
  name: "UATextbox",
  inheritAttrs: false,
  data() {
    return {
      searchValue: "",
      errmsg: "",
    };
  },
  props: [
    "modelValue",
    "id",
    "isDisabled",
    "labelInfo",
    "isFloatLabel",
    "isMandatory",
    "placeholder",
    "showLabel",
    "cssClass",
    "cssMargin",
    "dataType",
    "onChangeFieldsToTrigger",
    "errorMessage",
    "filtersErrorTooltip",
    "currInputFieldInfo",
    "errorOnTop",
    "modalError",
    "dataLength"
  ],
  computed: {
    ...mapState({
      applicationInfoDetails: (state) => state.ovsiDefaultModule.applicationInfoDetails,      
    }),
    floatClass() {
      return (this.modelValue != '' || (this.currInputFieldInfo && this.currInputFieldInfo.showBothLabelAndPlaceholder)) ? 'u-floatFly-fix' : 'u-float';
    },
    getLabelText() {
      return (this.modelValue != '' || (this.currInputFieldInfo && this.currInputFieldInfo.showBothLabelAndPlaceholder))  ? this.labelInfo : this.placeholder;
    },
    getInputPlaceHolder() {//SHOW PLACEHOLDER AND LABLE CASE : WHEN NEED TO SHOW DEFAULT BOTH LABEL AND PLACEHOLDER ON LOAD
      return (this.currInputFieldInfo && this.currInputFieldInfo.showBothLabelAndPlaceholder) ? this.placeholder : (this.isFloatLabel ? '' : this.placeholder);
    },
    ...mapGetters(["getPatternMatching", "validateKeyPressInput"]),
  },

  mounted() {
    if (this.modelValue) {          
        this.$emit("update:modelValue", this.modelValue);            
    }
  },

  methods: {
    prefixZeros(event){
      if(this.currInputFieldInfo?.prefixDefaultvalueOnClear && event.target.value.length == 0){
        event.target.value = this.currInputFieldInfo.defaultPrefixValue;
        this.$emit("update:modelValue", event.target.value);
      }      
    },
    onPasteHandler(event){
      let pasteText = event.clipboardData.getData('text/plain');
      if(!this.validateInputText(pasteText) ){
        event.preventDefault();
      }
    },
    validateInputText(pasteText){
      if(this.currInputFieldInfo && this.currInputFieldInfo.attributes && this.currInputFieldInfo.attributes.maxlength){
        if(pasteText.length > this.currInputFieldInfo.attributes.maxlength) return false;
      }
      if(this.dataType && this.dataType != '')  {
        let ptrnType = this.dataType.split('_')[0];
        let txtRegex = new RegExp(this.applicationInfoDetails.keyPressInputPatterns[ptrnType]);
        if (!txtRegex.test(pasteText)) return false;
      }      
      return true;
    },
    onKeyPressHandler(event){
      if(!this.validateKeyPressInput(event,this.dataType)){
        event.preventDefault();
      }
    },
    updateInput(event) {      
      this.searchValue = event.target.value;
      this.$emit("update:modelValue", this.searchValue);
      if (this.dataLength && this.searchValue) {
        let val = this.getPatternMatching(event,this.dataType);
        if ((this.searchValue.length != this.dataLength) && val) {
          if (typeof this.errorMessage === "object") {
            this.errmsg = this.errorMessage.lengthMsg;
          } else {
            this.errmsg = this.errorMessage;
          }
          //this.currInputFieldInfo ? this.currInputFieldInfo.isError = true : "";
          if (this.currInputFieldInfo) {
            this.currInputFieldInfo.isError = true;
            this.currInputFieldInfo.dislayError = this.errmsg;
          }
          return;
        }
      }
      if (this.dataType && this.searchValue) {
        this.patternValidation(event, this.dataType);
      } else {
        this.errmsg = "";
        // this.currInputFieldInfo ? this.currInputFieldInfo.isError =  false :"";
        if (this.currInputFieldInfo) {
          this.currInputFieldInfo.isError = false;
          this.currInputFieldInfo.dislayError = "";
        }
      }
      if (
        this.onChangeFieldsToTrigger != undefined &&
        this.onChangeFieldsToTrigger.length > 0
      ) {
        this.$emit("callApiOnDateChange", this.searchValue);
      }
    },
    patternValidation(event, selectedDataType) {
      let res = this.getPatternMatching(event, selectedDataType);
      let hasNumber = /\d/;
      if (hasNumber.test(res)) {
        //this.currInputFieldInfo ? this.currInputFieldInfo.isError =  true :"";
        if (res == "1") this.errmsg = "max " + res + " character is allowed";
        else this.errmsg = "max " + res +" "+`${this.errorMessage.lengthNumMsg ? this.errorMessage.lengthNumMsg : "characters are allowed"} `;
        if (this.currInputFieldInfo) {
          this.currInputFieldInfo.isError = true;
          this.currInputFieldInfo.dislayError = this.errmsg;
        }
        return;
      } else {
        if (!res) {
          if (typeof this.errorMessage === "object") {
            const splitedDataType = selectedDataType.split("_");
            if (splitedDataType[0] == "number") {
              this.errmsg = this.errorMessage.onlyNumberMsg;
            } else if (splitedDataType[0] == "char") {
              this.errmsg = this.errorMessage.onlyCharMsg;
            } else if (splitedDataType[0] == "negNumber") {
              this.errmsg = this.errorMessage.negNumberMsg;
            } else if (splitedDataType[0] == "alphaNumeric") {
              this.errmsg = this.errorMessage.alphaNumericMsg;
            } else if (splitedDataType[0] == "charOrSpace") {
              this.errmsg = this.errorMessage.onlyCharOrSpace;
            }
          } else {
            this.errmsg = this.errorMessage;
          }
          if (this.currInputFieldInfo) {
            this.currInputFieldInfo.isError = true;
            this.currInputFieldInfo.dislayError = this.errmsg;
          }
          return;
        } else {
          this.errmsg = "";
          if (this.currInputFieldInfo) {
            this.currInputFieldInfo.isError = false;
            this.currInputFieldInfo.dislayError = "";
          }
        }
      }
    },
  },
};
</script>
<style scoped>
input {
  border-top-style: hidden;
  border-right-style: hidden;
  border-left-style: hidden;
  border-bottom-style: hidden;
  background-color: #ffffff;
}

.no-outline:focus {
  outline: none;
}

.u-tooltip:before {
  background: #cc0000;
}

.u-tooltip.tip-top-buttons:after {
  border-color: #cc0000 transparent transparent transparent;
}

.u-tooltip.tip-bottom-buttons:after {
  border-color: transparent transparent #cc0000 transparent;
}

.u-tooltip.tip-bottom:after {
  border-color: transparent transparent #cc0000 transparent;
}

.u-tooltip.tip-bottom-search:after {
  border-color: transparent transparent #cc0000 transparent;
}

.u-tooltip {
  display: block;
}
</style>