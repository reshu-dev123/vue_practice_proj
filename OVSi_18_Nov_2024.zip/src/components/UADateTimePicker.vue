<template>
  <div class="u-col " style="position: relative;">
  <div class="calendarDiv u-border u-round u-input-1 u-text-3  u-small"  :class="[cssClass,calenderClass]" v-bind="$attrs">
    <div class="calImage">
      <img class="iconSize" src="../assets/img/calendar.png"/>    
  
    <div class="calendarDivChild">
      <input id="date" :disabled="isDisabled"  type="date" name="date" v-model="temp"  @change="handleSelectDate"  style="text-decoration: none; display: block;" />
     
      <!-- Actually date -->
      <input class="u-light-yellow inputDate u-round u-input-1 u-text-3 u-bg-4 u-padding-msmall-1 u-text-0 u-primary-inv-border" style="border:none"
        placeholder="yyyy-mm-dd" v-bind="$attrs"  :class="[inputDateClass]"  type="text" v-model="dateVmodel" readonly  @click="isTimePick=!isTimePick"
        :disabled="isDisabled"/>
      </div>
    </div>
      <!-- Time -->
      
      <div class="timeDiv"  :class="[cssClass,calenderTimeClass]" v-bind="$attrs">
      <input class="u-light-yellow inputDate2   u-round u-input-1 u-text-3  u-padding-msmall-1 u-text-0 u-primary-inv-border" style="border:none"
             v-model="timeHHVmodel"   @click="isTimeHHPick=!isTimeHHPick" @input="handleTimeInput($event,'hh')"
             min="0" max="23" minlength="2" maxlength="2" type="text" 
             placeholder="HH" :disabled="isDisabled" />
      <select name="HH" id="HH" class=" select1 time-picker__select" @change="handleTime($event,'hh')" v-if="isTimeHHPick" :class="select1Class" :disabled="isDisabled">
          <template v-for="(h, index) in hours" :key="index">
            <option :value="h" :selected="parseInt(h)===parseInt(selectedHH.length>0?selectedHH:currenHour)">{{ h }}</option>
          </template>
      </select>
      <span>:</span>
      <input class="u-light-yellow inputDate2  u-round u-input-1 u-text-3   u-padding-msmall-1 u-text-0 u-primary-inv-border" style="border:none"
             v-model="timeMMVmodel"   @click="isTimeMMPick=!isTimeMMPick" @input="handleTimeInput($event,'mm')"
             min="0" max="23" minlength="2" maxlength="2" type="number"
             placeholder="MM" :disabled="isDisabled"/> 
      <select name="MM" id="MM" class=" select2 time-picker__select" :disabled="isDisabled" @change="handleTime($event,'mm')" v-if="isTimeMMPick" :class="select2Class">
          <template v-for="(m, index) in minutes" :key="index">
            <option :value="m" :selected="parseInt(m)==parseInt(selectedMM.length>0?selectedMM:currentMinute)">{{ m }}</option>
          </template>
      </select>
    </div>      
  </div>
</div>
</template>

<script>

export default {
  name: "UADateTimePicker",
  props: ['modelValue',"labelInfo","isMandatory","placeholder", "showLabel","cssClass", "cssLabel","isDisabled",'calenderClass','calenderTimeClass','inputDateClass','select1Class','select2Class',"onChangeFieldsToTrigger"],
  created() {
    this.clearSelectedFields();
    this.setData();
    this.validateAndSet();
  },
  data() {
    return {
      isTimeHHPick: false,
      isTimeMMPick: false,
      temp: `${this.append0If1lengthValue(new Date().getFullYear())}-${this.append0If1lengthValue(new Date().getMonth())}-${this.append0If1lengthValue(new Date().getDate())}`,
      dateVmodel: '',
      timeHHVmodel: '',
      years: [],
      hours: [],
      minutes: [],
      date: '',
      currenHour: new Date().getHours(),
      currentMinute: new Date().getMinutes(),
      selectedHH: this.append0If1lengthValue(new Date().getHours()),
      selectedMM: this.append0If1lengthValue( new Date().getMinutes()),
    };
  },
  watch: {
    modelValue(newModel,oldModel){
      //if(newModel.length > 0){
        this.validateAndSet();
      //}
    }
  },
  methods: {
    //...mapMutations(['setErrorMessage']),
    setCurrentTime(){
      this.currenHour= this.append0If1lengthValue(new Date().getHours());
      this.currentMinute=this.append0If1lengthValue( new Date().getMinutes());
      
    },
    setErrorMessage(){},
    validateAndSet(){
      if(this.modelValue && this.modelValue.length ==16){ // If parent pass the dateTime
            let dateFromParent=this.modelValue.substring(0,10);
            let timeFromParent=this.modelValue.substring(11,this.modelValue.length);

            this.temp=dateFromParent;
            this.dateVmodel=dateFromParent;
            let timeTokens=timeFromParent.toString().split(':');

            this.selectedHH=timeTokens[0];
            this.selectedMM=timeTokens[1];
           

            this.timeHHVmodel=`${timeTokens[0]}`;
            this.timeMMVmodel=`${timeTokens[1]}`;
    }else { // if parent not passed the date or time
           // temp we already set on component creation
           this.dateVmodel='';
           this.temp='';
           this.timeHHVmodel=this.append0If1lengthValue(new Date().getHours());
            this.timeMMVmodel=this.append0If1lengthValue( new Date().getMinutes());
    }

    },
    setData() {
      for (var i = 1991; i <= 2022; i++) {
        this.years.push(i);
      }
      for(let i=0;i<=59;i++){
            this.minutes.push(this.append0If1lengthValue(i));
      }
      for(let i=0;i<=23;i++){
        this.hours.push(this.append0If1lengthValue(i));
      }
    },
    /**
     * return always 2 digit string appending 0 If passed 1 digit as argument
     * @param {*} tKey 
     */
    append0If1lengthValue(tKey){
      return tKey.toString().padStart(2,"0");
    },
    clearSelectedFields() {
      this.currenHour= new Date().getHours();
      this.currentMinute=new Date().getMinutes();
      
    },   
    handleSelectDate(event){
      this.dateVmodel=event.target.value;
      if(this.timeHHVmodel && this.timeHHVmodel.length >0){
        this.$emit('update:modelValue'
        ,event.target.value.concat(`T${this.append0If1lengthValue(this.selectedHH)}:${this.append0If1lengthValue(this.selectedMM)}`));
        if(this.onChangeFieldsToTrigger != undefined && this.onChangeFieldsToTrigger.length >0){ 
          this.$emit("callApiOnDateChange", event.target.value.concat(`T${this.append0If1lengthValue(this.selectedHH)}:${this.append0If1lengthValue(this.selectedMM)}`));
        }
      }else {
        this.$emit('update:modelValue',this.dateVmodel.concat(`T${this.append0If1lengthValue(this.selectedHH)}:${this.append0If1lengthValue(this.selectedMM)}`));
        if(this.onChangeFieldsToTrigger != undefined && this.onChangeFieldsToTrigger.length >0){ 
          this.$emit("callApiOnDateChange", this.dateVmodel.concat(`T${this.append0If1lengthValue(this.selectedHH)}:${this.append0If1lengthValue(this.selectedMM)}`));
        }
      }
      
    },
    handleTimeInput(event,option){ // Input of HH and MM handler
      this.isTimeHHPick=false;
      this.isTimeMMPick=false;
      let value=event.target.value;
      
      switch(option){
        case 'hh':
             if(this.hours.includes(value)){
               this.handleTime(event,option);
             }else{
           
              this.setErrorMessage({type:'error', message: value+': Invalid HH Entered'});
             }
             break;
        case 'mm':
             if(this.minutes.includes(value)){
               this.handleTime(event,option);
             }else{
              
              this.setErrorMessage({type:'error', message: value+': Invalid MM Entered'});
             }
             break;
        default:
            break;
      }
    },
    handleTime(event,option){ // Select box  of HH and MM handler
     let value =event.target.value;
     
     switch( option ){
       case 'hh':
           this.selectedHH=this.append0If1lengthValue(value);
           this.timeHHVmodel= this.selectedHH;
           break;
       case 'mm':
           this.selectedMM=this.append0If1lengthValue(value);
           this.timeMMVmodel=this.selectedMM;
           break;
        default:
           break;   
     }
      
       if(this.dateVmodel.length == 8){  
        this.$emit('update:modelValue',this.dateVmodel.concat(`T${this.selectedHH}:${this.timeMMVmodel}`));
        if(this.onChangeFieldsToTrigger != undefined && this.onChangeFieldsToTrigger.length >0){            
          this.$emit("callApiOnDateChange", this.dateVmodel.concat(`T${this.selectedHH}:${this.timeMMVmodel}`));
          }
       }else{
        this.$emit('update:modelValue',this.dateVmodel.substring(0,10).concat(`T${this.selectedHH}:${this.timeMMVmodel}`));
        if(this.onChangeFieldsToTrigger != undefined && this.onChangeFieldsToTrigger.length >0){ 
          this.$emit("callApiOnDateChange", this.dateVmodel.substring(0,10).concat(`T${this.selectedHH}:${this.timeMMVmodel}`));
        }
       }
        
    }
  }
};
</script>

<style scoped >
  .time-picker {
				position: absolute;
				display: inline-block;
				padding: 10px;
				background: #eeeeee;
				border-radius: 6px;
			}

			.time-picker__select {
				-webkit-appearance: none;
				-moz-appearance: none;
				appearance: none;
				outline: none;
				text-align: center;
				border: 1px solid #dddddd;
				border-radius: 6px;
				padding: 6px 10px;
				background: #ffffff;
				cursor: pointer;
				font-family: 'Heebo', sans-serif;
			}
      .date:focus {
outline: none /* Removes the border when the input is clicked */
}
input#date {
  top: 0px;
  position: absolute;
  opacity: 0;
  left: 0px;
  /* width: 4.8rem;
  height: 17px; */
  z-index: 1;
}
.timeSpan{
  position: relative;
  top: -29px;
  left: 37px;
  opacity: 0;
}


input[type="date" i]::-webkit-calendar-picker-indicator {
    background: transparent !important;
    bottom: 0;
    color: transparent !important;
    cursor: pointer;
    height: auto !important;
    left: 0;
    position: absolute !important;
    right: 0 !important;
    top: 0;
    width: auto;
}
.calendarDiv{ 
  padding: 6px 3px;
    font-size: 10px !important;
    width: 8.5rem;
}
.calendarDiv3Col{ 
  padding: 0px 3px;
    font-size: 10px !important;
    /* height: 31px; */
    width: 100%;
     
}
.calendarDiv4Col{ 
    padding: 0px;
    font-size: 9px !important;
    height: 34px;
    width: 100%;
}
.calender4ColumnRim {
  width:4.8rem;
}
.calender2ColumnRim {
  width: 7.8rem;
}
.iconSize{
  width: 13px;
  float: left;
  margin-top: 1px;
}

.inputDate{
  width: 4.3rem; 
  padding:0px;
  /* font-size: 10px !important; */
}

.inputDate4Col{
  width: 3.56rem;
}
.inputDate2{
  width: 0.98rem;
  /* font-weight: bold;  */
  font-size: 10px !important;
  /* vertical-align: top; */
  padding: 0;
  height: 9px;
  }

  /* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* Firefox */
input[type=number] {
  -moz-appearance: textfield;
}
.select1
  {
    padding: 0;
    opacity: 0;
    margin-left: -16px;
  } 
.select1_4ColumnRightRim{
  right: 2.6rem;
}
.select1_3ColumnRightRim{
  right: 3.9rem;
}
  .select2
  {
    padding: 0;
    opacity: 0;
    margin-left: -17px;
  }
.select2_4ColumnRightRim{
  right: 1.2rem;
}
.select2_3ColumnRightRim{
  right: 2.7rem;
}
  .timeDiv{ 
    height: 21px;
    width: 2.5rem;
    float: left;
    padding: 0;
    border: 0;
  }
  .timeDiv2{      
    height: 12px;
    width: 3.5rem;
    padding-left: 15px;
  }
  .timeDiv3{
    height: 12px;
    width: 3.5rem;
    padding-left: 2px;
  }
  .calendarDivChild{ 
    text-align: left;
    float: left;
    padding: 0px 2px;
  }
  .calImage{
    width: 5.45rem;
    /* width: 0.9rem */
    /* float:left;
    padding: 3%; */
  }
  
</style>