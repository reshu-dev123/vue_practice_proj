<template>
  <div :class="[showSuggestions ? 'u-col u-pad-0 dropdown' : 'u-col u-pad-0',cssClass]">
    <input type='search' v-model="searchKeyword" :placeholder='placeholder' :value='searchKeyword' :id="id"
      @input="updateSuggestions" :class="['u-input u-border u-round u-medium lf mf sf',srchCssClass,(searchIcon && !searchKeyword)?'searchinput':'']" aria-label="search Keyword" />
    <div v-if="showSuggestions" class="u-padding dropdown-list u-dropdown-item-border">

      <li v-for="(pass, index) in filteredSuggestions" :key="index" @click="selectSuggestion(pass)"
        class="u-small u-fnt-cst-1 dropdown-item">
        <div class="u-col l12 m12 s12">
          <div class="u-col l8 m8 s8">
            {{ pass.lastName + ", " + pass.firstName }}<br>
            {{ pass.pnr }}
          </div>
          <div v-if="pass.tabName" class="u-col l4 m4 s4">
            {{ pass.tabName }}
          </div>
        </div>
        
      </li>
    </div>
  </div>
</template>
<script>
export default {
  name: "UASearchKeyword",

  data() {
    return {
      searchKeyword: '',
      showSuggestions: false,
    };
  },
  computed: {
    filteredSuggestions() {
      let keyword = this.searchKeyword.trim().toLowerCase();
      return this.passengerList.filter(pass =>
        pass.firstName?.toLowerCase().includes(keyword)
        || pass.lastName?.toLowerCase().includes(keyword) ||
        pass.pnr?.toLowerCase().includes(keyword) ||
        pass.lastName?.toString().concat(', ').concat(pass.firstName)?.toLowerCase().includes(keyword)
      );

    },
  },
  methods: {
    updateSuggestions() {
      this.showSuggestions = this.searchKeyword.trim().length > 0;
      if(!this.searchKeyword){
        this.$emit("setSearchText", '');
      }
      if(this.filteredSuggestions.length<=0){
        this.showSuggestions = false;
      }
    },

    selectSuggestion(selectedPsngrDetail) {    
      this.$emit("setSearchText", selectedPsngrDetail);
      this.searchKeyword = selectedPsngrDetail.lastName + ", " + selectedPsngrDetail.firstName;
      this.showSuggestions = false;        
    },
    resetSearchText(){
     this.searchKeyword = '';
    }
  },
  props: ['placeholder', 'cssClass', 'passengerList','searchIcon','srchCssClass','id']
};
</script>
<style scoped>
.dropdown {
  display: block;
  position: relative;
  width: 100%;
  /* max-width: 400px; */
  /* margin: 0 auto; */
}

.dropdown-input,
.dropdown-selected {
  width: 100%;
  /* padding: 10px 16px; */
  border: 1px solid transparent;
  background: #edf2f7;
  line-height: 1.5em;
  /* outline: none; */
  /* border-radius: 8px; */
}

.dropdown-input:focus,
.dropdown-selected:hover {
  background: #fff;
  border-color: #e2e8f0;
}

.dropdowninput::placeholder {
  opacity: 0.7;
}

.dropdown-selected {
  font-weight: bold;
  cursor: pointer;
}

.dropdown-list {
  position: absolute;
  width: 100%;
  max-height: 300px;
  overflow-y: auto;
  background: #ffffff;
  box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
  border-radius: 8px;
  max-width: 430px;
  top: 40px;
  z-index: 2;
}

.dropdown-item {
  display: flex;
  width: 100%;
  cursor: pointer;
  border-bottom: 1px solid #ccc;
}

.dropdown-item:hover {
  background: #edf2f7;
}

.dropdown-item-flag {
  max-width: 24px;
  max-height: 18px;
  margin: auto 12px auto 0px;
}
.searchinput {
  background-position: 100%;
  background-image: url('.././assets/img/search2.png');
  background-repeat: no-repeat;
}
.u-dropdown-item-border {
  border: 1px solid #ccc;
  border-top: none;
}
</style>
