<template>
  <div :class="alertCssClass" v-if="setAlertMessage()">
    <div class="u-col l11 m11 s11 u-padding-small">
      <ul class="u-ul">
        <li
          class="u-border-0"
          style="padding: 0px; white-space: break-spaces"
          v-for="(alert, index) in alertMessages"
          :key="index"
        >
          {{ alert }}
        </li>
      </ul>
    </div>
    <div class="u-col l1 m1 s1">
      <button
        type="button"
        class="close u-button u-xlarge u-right"
        style="
          background-color: transparent !important;
          padding: 0px !important;
          height: 2rem;
          margin-top: -5px;
        "
        @click="clearAlertMessage()"
      >
        &times;
      </button>
    </div>
  </div>
</template>

<script>
// Import statements
import { mapState, mapMutations } from "vuex";

export default {
  name: "UAModalAlertMessage",
  computed: mapState({
    alertType: (state) => state.alertMessage.modalAlertType,
    alertMessages: (state) => state.alertMessage.modalAlertMessages,
    appInfo: (state)=> state.ovsiDefaultModule.applicationInfoDetails,
    alertCssClass(state) {
      switch (state.alertMessage.modalAlertType.toLowerCase()) {
        case "error":
          return "errorAlert u-padding-small u-row u-margin u-card u-center u-text-white u-round";
        case "warning":
          return "warningAlert u-padding-small u-row u-margin u-card u-center u-text-white u-round";
        case "success":
          return "successAlert u-padding-small u-row u-margin u-card u-center u-text-white u-round";
        case "information":
          return "infoAlert u-padding-small u-row u-margin u-card u-center u-text-white u-round";
        default:
          return "u-padding-small u-row u-margin u-card u-center u-text-white u-round";
      }
    },
  }),
  methods: { 
    ...mapMutations(["clearModalAlertMessages"]),// Azh - call action directly   
    clearAlertMessage() {
      this.clearModalAlertMessages();
    },
    //Azh - Alert to disappear after 10s
    setAlertMessage() {
      if(this.alertMessages.length > 0){
        if(this.alertType=="success"){
         setTimeout(() => {this.clearAlertMessage()}, 1000*this.appInfo.alertMessage.timedOut)
        }
        return true;
      }else{
         false;
      }
    },
  },
};
</script>

<style lang="scss">
.errorAlert {
  background-color: #cc0000;
}
.warningAlert {
  background-color: #ff8800;
}
.successAlert {
  background-color: #007e33;
}
.infoAlert {
  background-color: #0099cc;
}
</style>
