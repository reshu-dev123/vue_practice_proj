<template>
  <div class="u-col l12 m12 s12 u-padding " > 
           <div class="u-col l8 m8 s8  u-sans-serif">
     <label v-if="displayHeader" :class="displayHeader.cssClass">{{displayHeader.headerText}}</label>
     <UACopyURL disableQuery="true"/>
            </div>
            <div class="u-col l2 m2 s2 u-section-1">
           <UAButton
              @click="toggleEditPop()"
              cssClass="u-button u-round u-secondary-1 u-right u-padding-xsmall u-margin-right-70px"
            ><img src="@/assets/img/edit.png" alt class="u-border-0 u-transparent"/>
             Edit default
            </UAButton>
            <UAModalDisplay v-if="editpop" @close="CloseEditPopup()" 
            :modalTable="editTableFields[0].modalTemp"
            :footerFields="modalButtons[0].editButtons" />
            </div>
            <div class="u-col l2 m2 s2 u-section-1">
            <UAButton
             @click="toggleInfoPop()"
              cssClass="u-button u-round u-primary-1-pur u-right u-padding-xsmall"
            >
              + Add exception
            </UAButton>
          
             <UAModalDisplay v-if="infopop" @close="ClosePopup()"
             :modalTable="addTableFields[0].modalTemp"
             @addNewFieldRow="addCustomerNewFieldRows(addTableFields[0].modalTemp)"
             @addExtraFieldRow="addExtraFieldRows"
             @deleteNewFieldRow="deleteCustomerNewFieldRows('',addTableFields[0].modalTemp)"
             @deleteExtraFieldRow="deleteExtraFieldRows"
             :footerFields="modalButtons[0].addButtons"
            />
            </div>
  </div>
<div class="u-row u-padding" v-if="searchfilters">
<UASearchData 
 :inlineFilterConfig="searchfilters[0]?.currencyFilters"
@checkUFTableDataFound="enableTableData"
 @resetDefaultData="resetData"
 />    
</div> 
<div class="u-row u-padding"> 
<UATableDisplay 
 :tableData="fltFlow1Data" 
 :tableFields="getOVSIFields"
 :borderCssClass="['u-primary-inv-border']"
 :tableCssClass="['u-border u-white']"/>
</div>

<div class="u-row u-padding">
<h3>11 Exceptions</h3>
<UATab :tabFields="subtabs" @selectedTab="handleSelectTab" />

<div class="u-row">
<div class="u-row u-section-1">
<UAConfigSearchKeyword
v-model:searchKeyword="searchKeyword"
:cssClass="['u-col 14 m4 s4 u-fnt-itlc']" :placeholder="selectedTabIndex == 0 ? 'search by flight Number' : selectedTabIndex == 1 ? ' search by citypair' : selectedTabIndex == 2 ? ' search by country' : selectedTabIndex == 3 ? ' search by region' : selectedTabIndex == 4 ? 'search by station' : ''"/>
</div>
<div class="u-row" >
  <UAModalDisplay v-if="showModalPopup" @close="ClosePopup()"
      @update="editOversaleLimit"
      :modalTable="editModalDisplayTableFields[0].modalTemp"
      :tableData="modalData"
      @addNewFieldRow="addCustomerNewFieldRows(editModalDisplayTableFields[0].modalTemp)"
      @deleteNewFieldRow="deleteCustomerNewFieldRows('',editModalDisplayTableFields[0].modalTemp)"
      :footerFields="modalButtons[0].editButtons"
    />
<UATableDisplay 
:cardRowCss="['u-card u-round u-padding-24 u-section-1 u-white']"
:borderCssClass="['u-primary-inv-border u-display-inline']"
:tableData="filterRecords"
:tableFields="selectedTabIndex == 0 ? sections[0].tableMetaData : selectedTabIndex == 1 ? sections[0].tableMetaData1 : selectedTabIndex == 4 ? sections[0].tableMetaData2 : sections[0].tableMetaData3" 
@setShowModalPopup="setShowModalPopup" />
</div>
</div>
<div v-if="sections[0]?.historySection" class="u-row u-msmall u-border-bottom u-margin-top">
<div class="u-row u-section u-margin-left u-margin-right-26 u-border-bottom-2px">
      <label >History ({{  historyFilterRecords.length}})
</label> 
<span class="arrow-down u-right"
   ><img
     :src="getImageUrlM()"
          @click="toggleIcon()"
     alt="arrow-down"
     class="arrow-down"/>
</span>
</div>
    <UATableDisplay v-if="history"
    :cardRowCss="['u-card u-round u-padding-24 u-section-1 u-white']"
    :borderCssClass="['u-primary-inv-border u-display-inline']"
    :tableData="historyFilterRecords"
    :tableFields="selectedTabIndex == 0 ? sections[0]?.historySection[0]?.tableMetaData : selectedTabIndex == 1 ? sections[0]?.historySection[0]?.tableMetaData1 : selectedTabIndex == 4 ? sections[0]?.historySection[0]?.tableMetaData2 : sections[0]?.historySection[0]?.tableMetaData3"  />
</div>
</div>
</template>

<script>
import { mapState, mapGetters,mapMutations,mapActions} from 'vuex';

import UATableDisplay from "./UATableDisplay.vue";
import UAOvsiTableColLayout from "./UAOvsiTableColLayout.vue";
import UAConfigSearchKeyword from "./UAConfigSearchKeyword.vue";
import UATab from "./UATab.vue";
import UASearchData from "./UASearchData.vue";
import UAButton from "./UAButton.vue";
import UAModalDisplay from "./UAModalDisplay.vue";
import UACopyURL from './UACopyURL.vue';

export default {
name: "UAOSLFlowTable",
data() {
 return {
    selectedTabIndex : 0,         
    infopop: false,
    editpop:false,
    history:false,
   // Undersold:false,
    isDisabled:false,
    isAddExtra:false,
    tabsObjCopy : {},
    searchKeyword:'',
    showModalPopup:false,
    modalData:[],
    editModalDisplayTableFields:[],
    fltFlow1Data: [
         {
         "desc": "Overbooking is sale of a volatile good or service in excess of actual supply.Overselling is a common practice in the travel and hospitality sectors, in which it is expected that some people will cancel.",
         "default_fl1":"OversaleProcess Trigger",
         "default_fl2":"OversaleProcess Trigger Threshold",
         "default_fl3":"Threshold",
         "default_fl4":"Oversale Bind bid mileage Table",
         "default_fl6":"Block time Table",
         "default_init":"Oversale initiation hours before departure",
         "default_mil":"Conversion factor",
         "default_etc":"ETC amounts",
         "threshold":"+4",
         "capacity": "10%",
         "start_value" : "+1",
         "end_value": "+3",
         "mil_usd":"$0.02",
         "currency":"Euro","min_curr":"€102.27","max_curr":"€2,556.63",
         "intiation_starttime":"12 hours","intiation_stoptime":"1 hour"
         }
     ],
 fltTblData: [
   {
 "order":"01",
 "status":"Active",
 "flt" : "UA 1234",
 // "dt_range":"start dt",
 "threshold":"+3",
 "origin" : "SFO",
 "destination":"LAX",
 "c_origin" : "France",
 "c_destination":"Canada",
 "time_bnd":"18:00",
 "dt_range":"00:00",
 "station" : "SFO"
   },
   {
 "order":"02",
 "status":"Active",
 "flt" : "UA 219",
 // "dt_range":"start dt",
 "threshold":"+3",
 "origin" : "IAH",
 "destination":"EWR",
 "c_origin" : "Japan",
 "c_destination":"Australia",
 "time_bnd":"18:00",
 "dt_range":"00:00",
 "station" : "EWR"
   },
     {
 "order":"03",
 "status":"Active",
 "flt" : "UA 219",
 "dt_range":"start dt",
 "threshold":"+3",
 "origin" : "ORD",
 "destination":"LAX",
 "c_origin" : "United States",
 "c_destination":"Columbia",
 "time_bnd":"18:00",
 "dt_range":"00:00",
 "station" : "EWR"
   },
     {
 "order":"04",
 "status":"Active",
 "flt" : "UA 219",
 // "dt_range":"start dt",
 "threshold":"+3",
 "origin" : "IAH",
 "destination":"EWR",
 "c_origin" : "Japan",
 "c_destination":"Australia",
 "time_bnd":"18:00",
 "dt_range":"00:00",
 "station" : "EWR"
   },
     {
 "order":"05",
 "status":"Active",
 "flt" : "UA 219",
 // "dt_range":"start dt",
 "threshold":"+3",
 "origin" : "ORD",
 "destination":"SFO",
 "c_origin" : "Japan",
 "c_destination":"Australia",
 "time_bnd":"18:00",
 "dt_range":"00:00",
 "station" : "SFO"
   }
 
 ],
historyFltTblData: [
   {
 "order":"01",
 "status":"Modified",
 "flt" : "UA 1234",
 // "dt_range":"start dt",
 "threshold":"+3",
 "origin" : "SFO",
 "destination":"LAX",
 "c_origin" : "France",
 "c_destination":"Canada",
 "time_bnd":"18:00",
 "dt_range":"00:00",
 "station" : "SFO"
   },
   {
 "order":"02",
 "status":"Deleted",
 "flt" : "UA 219",
 // "dt_range":"start dt",
 "threshold":"+3",
 "origin" : "IAH",
 "destination":"EWR",
 "c_origin" : "Japan",
 "c_destination":"Australia",
 "time_bnd":"18:00",
 "dt_range":"00:00",
 "station" : "EWR"
   }
 ],
 };
},
mounted(){
this.tabsObjCopy = JSON.parse(JSON.stringify(this.tabs));
},
props: [ ],
computed: {
...mapState({
 displayHeader: (state)=>state.ovsiDefaultModule.displayHeader,
 searchfilters: (state) => state.ovsiDefaultModule.searchfilters,
 searchOVSIData: (state)=>state.ovsiDefaultModule.searchOVSIData,
 tableDetails: (state)=>state.ovsiDefaultModule.tableDetails,
 sections: (state)=>state.ovsiDefaultModule.entityDisplayDetails.Layouts[0].InnerLayout.sections,
 prevNavigateViews: state => state.ovsiDefaultModule.prevNavigateViews,
 isNavigatedEvent: state => state.ovsiDefaultModule.isNavigatedEvent,
 tabs: state => state.ovsiDefaultModule.tabs,
 subtabs: state => state.ovsiDefaultModule.subtabs,
 modalButtons: state => state.ovsiDefaultModule.modalButtons,
 addTableFields: state => state.ovsiDefaultModule.addTableFields,
 editTableFields: state => state.ovsiDefaultModule.editTableFields,
 editConfigTableFields: state => state.ovsiDefaultModule.editConfigTableFields,
 filterRecords() {
   this.finalResults = this.fltTblData;
   if (this.searchKeyword && Object.keys(this.searchKeyword).length > 0) {
     const search = this.searchKeyword.toLowerCase();
     return this.finalResults.filter(fltData => {
       return (fltData.origin.toLowerCase().includes(search)) || (fltData.flt.includes(search)) || (fltData.station.toLowerCase().includes(search))|| (fltData.destination.toLowerCase().includes(search)) || (fltData.c_origin.toLowerCase().includes(search)) || (fltData.c_destination.toLowerCase().includes(search));
     });
   }
   //return final filter results
   return this.finalResults;
 },
historyFilterRecords() {
   this.finalResults = this.historyFltTblData;
   if (this.searchKeyword && Object.keys(this.searchKeyword).length > 0) {
     const search = this.searchKeyword.toLowerCase();
     return this.finalResults.filter(fltData => {
       return (fltData.origin.toLowerCase().includes(search)) || (fltData.flt.includes(search)) || (fltData.station.toLowerCase().includes(search))|| (fltData.destination.toLowerCase().includes(search)) || (fltData.c_origin.toLowerCase().includes(search)) || (fltData.c_destination.toLowerCase().includes(search));
     });
   }
   //return final filter results
   return this.finalResults;
 },
}),
...mapGetters(["getOVSIFields", "getJPathvalue", "getOVSIEntityId","getImageUrl"]),
},
methods:{
    ...mapActions(['getOVSIData']),

...mapMutations(["getShowUFInlineTable",
  "getSelectedUFDataId",
  "setShowFilters", 
  "setShowInnerLayoutTable", ]),
  getImageUrlM(){
    if(this.history)
    return this.getImageUrl('expand_less.png')
    else
    return this.getImageUrl('arrow-down.png')
  },
  toggleIcon(){
    this.history=!this.history
  },
  setShowModalPopup(currRowData){
      this.editModalDisplayTableFields = JSON.parse(JSON.stringify(this.editConfigTableFields));
      this.modalData=[currRowData];
      this.showModalPopup =true;
    },
  addCustomerNewFieldRows(currmodalData){
  currmodalData.addNewRowFields.push(JSON.parse(JSON.stringify(currmodalData.additionalFields[0])))     
  },

  addExtraFieldRows(){
  this.addTableFields[0].modalTemp
 .addExtraRowFields.push(JSON.parse(JSON.stringify(this.addTableFields[0].modalTemp.extraAdditionalFields[0])))
  },
  
deleteCustomerNewFieldRows(indx, currmodalData){
  currmodalData.addNewRowFields = currmodalData.addNewRowFields.filter((item,ind) => ind != indx);
},
 
 deleteExtraFieldRows(indx, currmodalData){
   this.addTableFields[0].modalTemp
   .addExtraRowFields = this.addTableFields[0].modalTemp
   .addExtraRowFields.filter((item,ind) => ind != indx);
 },

enableTableData(isShow) {
    this.setShowInnerLayoutTable(isShow);
    this.setShowFilters(true);
    if(isShow){
      // this.$refs.uaInnerLayout.getSearchData();    
    }
    
  },
  resetData() {
    this.showInlineTables = false;
  //  this.setShowInnerLayoutTable(this.searchOVSIData.length == 0 ? false : this.showInnerLayoutTable);
    this.getShowUFInlineTable(false);
    this.getSelectedUFDataId(0);
    this.searchOVSIData.map((obj) => (obj.expandTable = true));
    },
handleSelectTab(tab, tabIndex) {
       this.selectedTabIndex = tabIndex;
       this.selectTab(tab);
   },
selectTab(tab) {

   },
     toggleEditPop() {
       this.editpop = true
   },
   CloseEditPopup(){
     this.editpop = false
   },
 toggleInfoPop() {
       this.infopop = true
   },
   ClosePopup(){
     this.infopop = false;
     this.showModalPopup = false;
     this.addTableFields[0].modalTemp.addNewRowFields = []  ;
     this.addTableFields[0].modalTemp.addExtraRowFields = [];

   }
},
components: {
UATableDisplay,
UAOvsiTableColLayout,
UACopyURL,
UAConfigSearchKeyword,
UATab,
UAButton,
UAModalDisplay,
UASearchData
}
};
</script>
<style scoped>
.u-margin-right-70px{
margin-right: -70px !important;
}
</style>

