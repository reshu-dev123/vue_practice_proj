<template>
  <div class="u-row"  > 
    <label v-if="displayHeader" :class="['u-col l10 m10 s10',displayHeader.cssClass]">{{getHeaders(displayHeader.header)}}</label>
  </div>
  <div class="u-col l12 m12 s12 u-padding-bottom-25">
    <UASearchData :inlineFilterConfig="{filters:getInlineUIfilters,showSearchButton: true,showResetButton: true}" :key="getInlineUIfilters" />
  </div>
  <UAModalDisplay v-if="showModalPopup" @close="ClosePopup()"
    :modalTable="addTableFields[0].modalTemp"
    :tableData="modalData"
    :bidData ="bidOptionData"
    :footerFields="modalButtons[0].addButtons"
  />
  <UATableDisplay 
    :tableData="getFilterData" 
    cardRowCss="u-white"
    :tableFields="getOVSIFields"
    @setShowModalPopup="setShowModalPopup"
  />
     
</template>

<script>
import { mapState, mapGetters,mapActions, mapMutations} from 'vuex';
import UASearchData from './UASearchData.vue';
import UATableDisplay from "./UATableDisplay.vue";
import UAButton from "./UAButton.vue";
import UAModalDisplay from "./UAModalDisplay.vue";
import {getDateTimePart, mapDateToOtherFormat} from "@/helpers/utilities";

export default {
  name: "UAHistory",
  data(){
    return {
      tableFields:[],
      showModalPopup:false,
      modalData:[],
      bidOptionData:[],
      editModalDisplayTableFields:[]
    }
  },
  components: {
    UATableDisplay,
    UASearchData,
    UAButton,
    UAModalDisplay,
  },
  async created(){
    this.reSetSearchOVSIData();
    await this.getOVSIData({
        inputObject: {
          FlightOrigin:this.selectedRecord['flightOrigin'],
          FlightNumber:this.selectedRecord['flightNumber'],
          FlightDate:this.selectedRecord['flightDate'],
        },
        actionId: this.actionId,
    });
  },
  computed: {
    ...mapState({
      displayHeader: (state)=>state.ovsiDefaultModule.displayHeader,
      searchOVSIData: (state)=>state.ovsiDefaultModule.searchOVSIData,
      prevNavigateViews: state => state.ovsiDefaultModule.prevNavigateViews,
      isNavigatedEvent: state => state.ovsiDefaultModule.isNavigatedEvent,
      actionId: (state) => state.ovsiDefaultModule.actionId,
      selectedRecord: state => state.ovsiDefaultModule.selectedRecord,
      isLoading: (state) => state.ovsiDefaultModule.isLoading,
      filterInputData: state => state.ovsiDefaultModule.filterInputData,
      exportToExcelConfig: (state) => state.ovsiDefaultModule.exportToExcelConfig,
      applicationInfoDetails:(state) => state.ovsiDefaultModule.applicationInfoDetails,
      addTableFields: (state) => state.ovsiDefaultModule.addTableFields,
      modalButtons: (state) => state.ovsiDefaultModule.modalButtons,    
      getInlineUIfilters(){
        this.tableFields = JSON.parse(JSON.stringify(this.getOVSIFilters));      
        if(this.searchOVSIData.length >0){
          this.tableFields.forEach(fltItem =>{
            if(fltItem.sourceType == "module_data"){
              fltItem.source = this.getDDlData(fltItem);
            }
          });
        }  
        return this.tableFields;
      },
      getFilterData(){
          let finalResults = this.searchOVSIData;
          if (!this.filterInputData || Object.keys(this.filterInputData).length == 0) {//IF INLINE FILTER INPUT SELECTED TO FILTER RECORDS
            return finalResults;
          }
          let uiObj = {};let dateObj={};let timeObj={};
          this.getOVSIFilters.forEach(uf => {  
            if(uf.fieldType == "UADateRangePicker"){
              for(let [key,value] of Object.entries(uf.model)){                
                this.filterInputData[uf.attributes.id[key]] ? 
                  dateObj[uf.attributes.id[key]] = this.filterInputData[uf.attributes.id[key]]:'';
              }
            } else if(uf.attributes.id == "startTime" || uf.attributes.id =="endTime"){
              this.filterInputData[uf.attributes.id] ? timeObj[uf.attributes.id] = this.filterInputData[uf.attributes.id]:'';
            } else if((uf.attributes.id == "ovsEventType" || uf.attributes.id == "createdChannel" )) {
              if(this.filterInputData[uf.attributes.id] != 'all')
                this.filterInputData[uf.attributes.id] ? uiObj[uf.pathToCompare] = this.getJPathValue(uf.attributes.id,this.filterInputData) : '';
            } else {
              this.filterInputData[uf.attributes.id] ? uiObj[uf.pathToCompare] = this.getJPathValue(uf.attributes.id,this.filterInputData) : '';
            }
          });
          let rowCount = 1;
          finalResults = finalResults.filter(f => {
            for (let [key,value] of Object.entries(uiObj)) {
              let fieldValue = this.getJPathValue(key,f) ? this.getJPathValue(key,f).toString().toLowerCase():'';
              if( fieldValue != value.toString().toLowerCase()){
                return false;
              }
            }
            if(Object.keys(dateObj).length > 0) {
              let dtpickrFld = this.getOVSIFilters.filter(filter=> {
                return filter.fieldType == "UADateRangePicker"
              })[0];
              let dtValue =  new Date(getDateTimePart(this.getJPathValue(dtpickrFld.pathToCompare,f), "yyyy-mm-dd"));
              let startdtValue =  new Date(getDateTimePart(dateObj[dtpickrFld.attributes.id["startDate"]] , "yyyy-mm-dd"));
              let enddtValue =  new Date(getDateTimePart(dateObj[dtpickrFld.attributes.id["endDate"]], "yyyy-mm-dd"));
              if(startdtValue != "Invalid Date" && enddtValue == "Invalid Date" && !(dtValue >= startdtValue)){//IF ONLY START DATE PRESENT THEN MATCH ROW DATE FROM START DATE
                return false;
              } else if(startdtValue == "Invalid Date" && enddtValue != "Invalid Date" && !(dtValue <= enddtValue)){//IF ONLY END DATE PRESENT THEN MATCH ROW DATE TILL END DATE
                return false;
              } else if(startdtValue != "Invalid Date" && enddtValue != "Invalid Date"){//IF ONLY BOTH DATE PRESENT THEN MATCH RECORDS BETEWEEN START DATE AND END DATE
                if(!(dtValue >= startdtValue && dtValue <= enddtValue)) return false;
              }              
            }
            if(Object.keys(timeObj).length > 0){
              let startDtFld = this.getOVSIFilters.filter(filter=> {
                return filter.attributes.id == 'startTime' && filter.filterByTime
              });
              let endDtFld = this.getOVSIFilters.filter(filter=> {
                return filter.attributes.id == 'endTime' && filter.filterByTime
              });
              if(!this.getJPathValue(startDtFld[0].pathToCompare,f)){
                return false;
              }
              let deptDt = new Date(getDateTimePart(this.getJPathValue(startDtFld[0].pathToCompare,f),"yyyy-mm-dd hh:mm")).getTime();//date to compare
              
              let startDatePart = getDateTimePart(this.getJPathValue(startDtFld[0].pathToCompare,f), "yyyy-mm-dd");
              let endDatePart = getDateTimePart(this.getJPathValue(endDtFld[0].pathToCompare,f), "yyyy-mm-dd");
              let startDtTime = ''; let endDtTime = '';
              if(timeObj['startTime']){
                let startTime = startDatePart + ' ' + (timeObj['startTime'] ? timeObj['startTime'] : '00:00');
                startDtTime = new Date(startTime).getTime();
              }
              if(timeObj['endTime']){
                let endTime = endDatePart + ' ' + (timeObj['endTime'] ? timeObj['endTime'] : '00:00');                
                endDtTime = new Date(endTime).getTime();
              }
              if(startDtTime && endDtTime){
                //compare start and date time with date if both time present
                if(!(deptDt >= startDtTime && deptDt <= endDtTime))  return false;
              } else if(startDtTime && !endDtTime){
                if(!(deptDt >= startDtTime)) return false;
              } else if(!startDtTime && endDtTime){
                if(!(deptDt <= endDtTime)) return false;
              }
            }     
            //RESET ROW COUNT ON FILTER
            f["__row"]= rowCount;
            rowCount++;
            return true;
          });
         return finalResults;
      }
    }),
     ...mapGetters(["getOVSIFields", "getJPathValue", "getOVSIEntityId","getOVSIFilters"]),
  },
  methods: {
    ...mapActions(["getOVSIData"]),
    ...mapMutations(["reSetSearchOVSIData"]),
    getDDlData(fldInfo){
      let ddlData = [ fldInfo.defaultSelectedModelValue];
      this.searchOVSIData.forEach(data => {  
        let colVal = data[fldInfo.pathToCompare];
        if(colVal && colVal.length>0 && !ddlData.find(item => item.id.toLowerCase() === colVal.toLowerCase())) {          
          ddlData.push({"name" : colVal, "id" : colVal, "label" : colVal});
        }
      });
      return ddlData;
    },
    getHeaders(header){
       return  header.combineFields.map(f=>{
          return f.path?(f.formatDate? mapDateToOtherFormat(f, this.selectedRecord):this.getJPathValue(f.path,this.selectedRecord)):f.concatePath.map(p=>this.getJPathValue(p,this.selectedRecord)).join(f.concatePrefix ||'')
        }).join(header.combineBy|| ' ');
     },
    ClosePopup(){
      this.showModalPopup =false;
    },
    setShowModalPopup(currRowData){
      this.editModalDisplayTableFields = JSON.parse(JSON.stringify(this.addTableFields));
      this.modalData=[currRowData];
      if(currRowData.compensation?.passengerOffers){
        this.bidOptionData = currRowData.compensation.passengerOffers;
      }else{
        this.bidOptionData=[];
      }
      this.showModalPopup =true;
    },
    getBidOptionData(psngrData){
      let filteredBidData ={};    
      psngrData.forEach((psngr) => {
          filteredBidData = psngr.bidOptions;
        })
        return filteredBidData;
    },
  },
};
</script>

