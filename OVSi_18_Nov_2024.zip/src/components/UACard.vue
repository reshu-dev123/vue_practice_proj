<template>
  <div class="u-col l3 m4 s6" style="min-height: 13.2rem">
    <div
      class="u-card u-row u-padding-small u-section-1 u-cardView"
      style="min-height: 13.4rem"
    >
      <div class="u-col">
        <h6 class="u-text-0 u-section-1" >
          <a @click="selectCardDetails($event, docType, id)" alt="" class="u-pointer">{{ label }}</a>
        </h6>
      </div>
      <div class="u-col" style="cursor:auto">
        <p class="u-medium u-text-2 u-section-1">{{ description }}</p>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: "UACard",
  props: ["label", "description", "id", "docType"],
  methods: {
    selectCardDetails(event , docType , id) {
      this.$emit("select-cardDetail",event, docType, id);
    },
  },
};
</script>
<style >

</style>