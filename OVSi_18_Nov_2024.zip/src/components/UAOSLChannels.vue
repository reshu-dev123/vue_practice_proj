<template>
       <div class="u-col l12 m12 s12 u-padding"> 
          <h3 v-if="displayHeader" :class="displayHeader.cssClass">{{displayHeader.headerText}}</h3>
       </div>    

<div class="u-row u-padding"> 
     <UATableDisplay 
      :tableData="fltFlow1Data" 
      :tableFields="getOVSIFields"
      :borderCssClass="['u-primary-inv-border']"
      :tableCssClass="['u-border u-white']"/>
</div>
<div class="u-row u-padding u-section">
  <UAOvsiTableColLayout 
      :tableBorderCSS="sections[0].tableBorderCSS"
      :tableData="fltTblData" 
      :tableFields="sections[0].tableMetaData[0].tableFields" 
      :tblHeaders="sections[0].tableMetaData[0].headers[0]" 
      />
</div>
</template>

<script>
import { mapState, mapGetters,mapMutations,mapActions} from 'vuex';

import UATableDisplay from "./UATableDisplay.vue";
import UAOvsiTableColLayout from "./UAOvsiTableColLayout.vue";
import UAButton from "./UAButton.vue";

export default {
  name: "UAOSLChannels",
  data() {
      return {
         selectedTabIndex : 0,
        // Undersold:false,
         isDisabled:false,
         checkedValue:false,
         fltFlow1Data: [
              {
              "desc": "Overbooking is sale of a volatile good or service in excess of actual supply.Overselling is a common practice in the travel and hospitality sectors, in which it is expected that some people will cancel.",
              "default":"Channel setting",
              "threshold":"Threshold +4",
              "default_etc":"ETC amounts",
              "default_mil":"Conversion factor"
              }
          ],
      fltTblData: [
        {
      "order":"01",
      "status":"Active",
      "flt#" : "UA 1234",
      "dt_range":"start dt",
      "threshold":"+3"
        },
        {
      "order":"02",
      "status":"Active",
      "flt#" : "UA 219",
      "dt_range":"start dt",
      "threshold":"+3"
        },
          {
      "order":"03",
      "status":"Active",
      "flt#" : "UA 219",
      "dt_range":"start dt",
      "threshold":"+3"
        },
          {
      "order":"04",
      "status":"Active",
      "flt#" : "UA 219",
      "dt_range":"start dt",
      "threshold":"+3"
        },
          {
      "order":"05",
      "status":"Active",
      "flt#" : "UA 219",
      "dt_range":"start dt",
      "threshold":"+3"
        }
      
      ],
      citypairTblData:[
         {
      "order":"03",
      "status":"Active",
      "origin" : "ORD",
      "destination":"LAX",
      "time_bnd":"18:00",
      "dt_range":"00:00",
      "threshold":"+3"
        },
        {
      "order":"04",
      "status":"Active",
      "origin" : "SFO",
      "destination":"SEA",
      "time_bnd":"18:00",
      "dt_range":"00:00",
      "threshold":"+3"
        },
      ],
      countryTblData:[
         {
      "order":"03",
      "status":"Active",
      "origin" : "France",
      "destination":"Canada",
      "time_bnd":"18:00",
      "dt_range":"00:00",
      "threshold":"+3"
        },
         {
      "order":"04",
      "status":"Active",
      "origin" : "United States",
      "destination":"Columbia",
      "time_bnd":"18:00",
      "dt_range":"00:00",
      "threshold":"+3"
        },
          {
      "order":"05",
      "status":"Active",
      "origin" : "Japan",
      "destination":"Australia",
      "time_bnd":"18:00",
      "dt_range":"00:00",
      "threshold":"+2"
        },
      ],
      regionTblData:[
          {
      "order":"04",
      "status":"Active",
      "origin" : "Asia",
      "destination":"North America",
      "time_bnd":"18:00",
      "dt_range":"00:00",
      "threshold":"+3"
        },
      ],
      stationTblData:[
        {  
      "order":"04",
      "status":"Active",
      "station" : "ORD",
      "time_bnd":"15:00 18:00",
      "dt_range":"01-Jan-2022 31-Mar-2023",
      "threshold":"+3"
      },
       {  
      "order":"04",
      "status":"Active",
      "station" : "SFO",
      "time_bnd":"15:00 18:00",
      "dt_range":"01-Jan-2022 31-Mar-2023",
      "threshold":"+3"
      },
       {  
      "order":"04",
      "status":"Active",
      "station" : "IAH",
      "time_bnd":"15:00 18:00",
      "dt_range":"01-Jan-2022 31-Mar-2023",
      "threshold":"+3"
      },
      ]
      };
  },
  props: [ ],
  computed: {
    ...mapState({
      displayHeader: (state)=>state.ovsiDefaultModule.displayHeader,
      searchfilters: (state) => state.ovsiDefaultModule.searchfilters,
      searchOVSIData: (state)=>state.ovsiDefaultModule.searchOVSIData,
      tableDetails: (state)=>state.ovsiDefaultModule.tableDetails,
      sections: (state)=>state.ovsiDefaultModule.entityDisplayDetails.Layouts[0].InnerLayout.sections,
      prevNavigateViews: state => state.ovsiDefaultModule.prevNavigateViews,
      isNavigatedEvent: state => state.ovsiDefaultModule.isNavigatedEvent,
      tabs: state => state.ovsiDefaultModule.tabs,
      subtabs: state => state.ovsiDefaultModule.subtabs,
      modalButtons: state => state.ovsiDefaultModule.modalButtons,
      editmodalButtons: state => state.ovsiDefaultModule.editmodalButtons,
      addTableFields: state => state.ovsiDefaultModule.addTableFields,
      modalHeader: state => state.ovsiDefaultModule.modalHeader,
      editExcModalHeader: state => state.ovsiDefaultModule.editExcModalHeader,
      editExceptionTableFields: state => state.ovsiDefaultModule.editExceptionTableFields,


    }),
     ...mapGetters(["getOVSIFields", "getJPathvalue", "getOVSIEntityId"]),
  },
  methods:{
         ...mapActions(['getOVSIData']),

     ...mapMutations(["getShowUFInlineTable",
       "getSelectedUFDataId",
       "setShowFilters", 
       "setShowInnerLayoutTable", ]),
     enableTableData(isShow) {
         this.setShowInnerLayoutTable(isShow);
         this.setShowFilters(true);
         if(isShow){
           // this.$refs.uaInnerLayout.getSearchData();    
         }
         
       },
       resetData() {
         this.showInlineTables = false;
       //  this.setShowInnerLayoutTable(this.searchOVSIData.length == 0 ? false : this.showInnerLayoutTable);
         this.getShowUFInlineTable(false);
         this.getSelectedUFDataId(0);
         this.searchOVSIData.map((obj) => (obj.expandTable = true));
         },
   handleSelectTab(tab, tabIndex) {
            this.selectedTabIndex = tabIndex;
            this.selectTab(tab);
        },
   selectTab(tab) {

        },
},
  components: {
    UATableDisplay,
    UAOvsiTableColLayout,
    UAButton,
}
};
</script>
<style scoped>
.u-margin-right-70px{
  margin-right: -70px !important;
}
</style>

