<template>
  <div class="u-row">
  <header id="header" class="u-header u-center">
    <div class="u-container u-block u-padding-lt-22 u-pad-right-1 u-font-wt-300 u-margin-top">
      <div class="u-row u-flex-center">
        <div class="u-col l3 m4 s3 ">
          <div class="u-row u-flex-center ">
            <div class="u-col l2 m2 s4">
              <a class="u-left" href="#" @click="toggleMenus">
                <img :src="require(`.././assets/img/${showMenuItems ? 'menuOpen.png' : 'menu.png'
                  }`)
                  " alt="Toggle Menu" class="u-imageSize l m s" />
              </a>
            </div>
            <div class="u-col l10 m12 s10 u-left-align">
              <a href="#">
                <img src=".././assets/img/logo.png" alt="United" class="u-logo u-main-header m s" @click="redirectToLanding" />
              </a>
            </div>
          </div>
        </div>
        <div class="u-col l8 m6 s4 u-center u-padding-left l s" >
            <label class="u-large">Oversale Insight</label>
        </div>
        <div class="u-col l4 m7 s5" >
          <div class="u-row u-flex-center">
            <div class="u-col l12 m11 s9 u-flex-center">
              <div class="u-col l10 m10 s9 u-flex-center">
                <div class="u-col l9 m10 s11 u-right-align u-padding-right m s u-line-height-15">
                  <label for="ovsi_app_username" class="u-small"> {{getUserName ||'Caroline Herschel'}}</label> <br>
                  <label for="ovsi_app_role" class="u-small" v-if="applicationInfoDetails">{{getUserRole}}</label>
                </div>
                <div class="u-col l3 m2 s1 u-right u-flex-center" ref="selectComRef">
                    <img src=".././assets/img/account_circle1.png" alt="United" class="u-logo u-menuImgSml u-margin-top-6" @click="logout()"/>
                    <img src=".././assets/img/down_arrow_1.png" alt="signout_arrow" class="u-logo u-menuImgSml" @click="logout()"/>
                    <div class="logoutMenu u-padding-xsmall" v-if="logoutTab">
                    <div class="no-border u-pointer-event u-flex u-align-center" @click="signout"  > <img alt="signout" src=".././assets/img/logout.png" class="u-logo u-menuImgSml" /><label class="u-flex u-padding-right-8 u-padding-left-6" >Sign Out</label></div>
                </div>
              </div>
            </div>
                <div class="u-col l2 m2 s3 u-right u-padding-left-10" ref="searchHeaderBtn" @click="flightSearch()" @mouseleave="mouseLeave()" >
                      <img src=".././assets/img/search1.png" alt="Flight search" class="u-logo u-menuImgSml u-margin-0" />
                  </div> 
            </div>
          </div>
        </div>
      </div>
      </div>
  </header>
    <div v-if="isHeaderSrchClicked && searchFilterFlds" class="u-modal-search-container" ref="headerSearchFilterModal" >
      <div class="u-col l12 m12 s12 u-padding-top-7 u-pad-btm-10" @mouseleave="mouseLeave()" @mouseover="mouseOver()">
        <UASearchData 
          :inlineFilterConfig="{filters:searchFilterFlds,showSearchButton: true,showResetButton: true}"
          :key="searchFilterFlds" 
        />
      </div>
    </div>
  </div>
</template>
<script>
import { mapState, mapActions, mapMutations, mapGetters } from "vuex";
import UAModalDisplay from "./UAModalDisplay.vue";
import UASearchData from "@/components/UASearchData.vue";
import { getEntityDisplayDetails } from '../services/rtfDefault.api.js';
export default {
  name: "UAHeader",
  data() {
    return {
      cardOptions: {
        docType: "Domain",
        id: "",
        isShow: true,
      },
      logoutTab: false,
      searchFilterFlds: [],
      mouseLeaveDetected: false
    };
  },
  props: {
    msg: String,
  },
  components: {
    UAModalDisplay,
    UASearchData
  },
  computed: {
    ...mapState({
      breadCrumb: (state) => state.breadCrumb,
      showMenuItems: (state) => state.menuModule.showMenuItems,
      isHeaderSrchClicked: (state) => state.ovsiDefaultModule.isHeaderSrchClicked,
      applicationInfoDetails: (state)=>state.ovsiDefaultModule.applicationInfoDetails
    }),
    ...mapGetters(['getUserName', 'getMenuItems','getUserRole']),
  },
  mounted() {
    document.addEventListener("click", (e) => {
      //if (!this.$el.contains(e.target)) {
      if( this.logoutTab){
        if(this.$refs.selectComRef && !this.$refs.selectComRef.contains(e.target)){
          this.logoutTab = false;
        }
      }
      if(this.mouseLeaveDetected && this.isHeaderSrchClicked){
        let searchDataDivRef = this.$refs.headerSearchFilterModal;
        if(searchDataDivRef && (!searchDataDivRef.contains(e.target) && !this.$refs.searchHeaderBtn.contains(e.target))){
          this.setIsHeaderSrchClicked(false);
        }
      }
    });
  },
  unmounted() {
    document.removeEventListener("click", () => {
      this.logoutTab = false;
      this.setIsHeaderSrchClicked(false);
    });
  },
  methods: {
    ...mapMutations(["getViewType","setshowOrHideMainMenus","resetEntityDetails","setIsHeaderSrchClicked"]),
    ...mapActions(["toggleMenu", "setProcessStep", "getCardDetailsData", "userLogout","navigateMenuAction","setAlertMessages","clearAlertMessages","unAuthorizedHandler","getPayLoad"]),
    mouseOver(){
      this.mouseLeaveDetected = false;
    },
    mouseLeave(){
    this.isHeaderSrchClicked ? this.mouseLeaveDetected = true : this.mouseLeaveDetected = false;
    },
    toggleMenus(){
      this.toggleMenu();
      this.setshowOrHideMainMenus();
    },
    logout(){
      this.logoutTab=!this.logoutTab
    },
    redirectToLanding() {
      this.resetEntityDetails();
      this.clearAlertMessages();
      this.setProcessStep("/");
      this.navigateMenuAction({ menu: this.getMenuItems[0]});
      this.$router.push("/");
    },
    toogleMenu(event) {
      var element = document.getElementById("notShown");
      element.classList.toggle("logoutMenuHidden");
    },

    signout() {
      this.userLogout();
    },
    async flightSearch(){
      this.setIsHeaderSrchClicked(!this.isHeaderSrchClicked);
      if(this.isHeaderSrchClicked){
       await getEntityDisplayDetails('flight_Management')
      .then(async(response) => {
          if (response.status === 200 ) {
             let payload = await this.getPayLoad(response)
              this.searchFilterFlds = payload.Layouts[0].filters; // api
          } else {
            this.setAlertMessages({
               alertType: "warning",
               alertMessages: ["!Warning: No Records Exists. - flight_Management"]
             });
          }
        })
        .catch((error) => {
          console.error(error)
          this.setAlertMessages({
               alertType: "warning",
               alertMessages: ["!Warning: No Records Exists. - flight_Management"]
             });
          this.unAuthorizedHandler(error);
        });
      }
      this.mouseLeaveDetected = false;
    },
    deleteCookie(name) {
      this.setCookie(name, "", {
        'max-age': -1
      })
    },
    setCookie(name, value, options = {}) {
      options = {
        path: '/',
        // add other defaults here if necessary
        ...options
      };

      if (options.expires instanceof Date) {
        options.expires = options.expires.toUTCString();
      }

      let updatedCookie = encodeURIComponent(name) + "=" + encodeURIComponent(value);
      for (let optionKey in options) {
        updatedCookie += "; " + optionKey;
        let optionValue = options[optionKey];
        if (optionValue !== true) {
          updatedCookie += "=" + optionValue;
        }
      }
      document.cookie = updatedCookie;
    }
  }
};
</script>
<style scoped>
.mystyle {
  display: block;
  transition: 0.5s;
}

.logoutMenu {
  background: white;
  /* width: 21rem; */
  position: absolute;
  /* right: -1px; */
  top: 3.7rem;
  z-index: 10;
  /* padding: 0.25rem 1.5rem; */
  border-radius: 3px 3px 3px 3px;
  border: 1px solid #ccc;
  color: black;
  text-align: left;

  /* box-shadow: 2px 1px 3px 2px #ccc; */
}

.logoutMenuHidden {
  display: none;
}

.logoutMenu::before {
  content: " ";
  position: absolute;
  top: -5px;
  right: 40%;
  width: 20px;
  height: 20px;
  background: white;
  transform: rotate(45deg);
  z-index: -1;
}

.logName {
  border-bottom: 1px solid #ccc;
  margin-bottom: 7px;
  padding-left: 19px;
  padding-top: 10px;
  padding-bottom: 12px;
}

.logName:hover {
  background: #fbf7f7f5;
}

.logoutBtn {
  text-align: center;
  margin-bottom: 10px;
}
.u-pad-btm-10{
  padding-bottom: 10px ;
}
</style>
 