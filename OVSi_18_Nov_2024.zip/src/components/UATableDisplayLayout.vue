<template>
  <div
    :class="[' u-small lf mf sf u-round u-border-grey u-centered u-white',tblHeaders.blockCss]"
  >
    <div class="u-row">
      <template v-for="(tblField, rKey) in tableFields" :key="rKey">
        <div :class="[tblField?.subFields ? 'u-col l12 m12 s12' : '']">
          <template v-for="(subField, tKey) in getTableFields(tblField)" :key="tKey">
            <div :class="['u-col',tblHeaders.cssClass]">
            <div class="u-row">
              <div class="u-row u-padding-xsmall">
              <div v-if="subField.label" :class="[subField.optionallabel?'u-col l8 m8 s8':'u-row']">
               <label >{{
                  subField.label
                }}</label>
                </div>
                <div v-if="subField.optionallabel" :class="['u-col l4 m4 s4']">
               <label >{{
                  subField.optionallabel
                }}</label>
                </div>
                </div>
              <div
                v-for="(inlineFields, inKey) in subField.displayInlineFields"
                :key="inKey"
                :class="[inlineFields.cssClass]"
              ><label v-if="inlineFields.inlineField == 'data'">{{
                  getTableDataForField(subField.path, subField.cabin)
                }}</label>
                <div v-if="inlineFields.inlineField == 'field' && subField.setIsDDLLoading" class="nb-spinner"></div>
                <component
                  :is="subField.fieldType"
                  v-if="!subField.setIsDDLLoading && inlineFields.inlineField == 'field'"
                  :cssClass="[subField.fieldsCssClass]"                  
                  :cssCalendar="subField.cssCalendar"
                  v-model="subField.model"
                  v-bind="subField.attributes"
                  :dataType="subField.dataType"
                  :modelError="subField?.modelError"
                  :errorMessage="subField.errorMessage"
                  :options="
                    subField.fieldType == 'UADropDown'
                      ? getSourceOptions(subField)
                      : []
                  "
                  :firstOption="subField.model"
                  :selectOptions="
                    subField.fieldType == 'UASelect' ||
                    subField.fieldType == 'UARadioButton'
                      ? getSourceOptions(subField)
                      : []
                  "
                  :onChangeFieldsToTrigger="subField.onChangeFieldsToTrigger"
                  @update:modelValue="
                    updateEditFields($event, subField, 'model')
                  "
                  @update-option="
                    updateOption($event, subField, 'model', subField.path)
                  "
                  @callApiOnDateChange="getValuesToBind($event, subField)"
                  :isDisabled="isViewDetails || subField?.attributes?.disabled"
                  :currInputFieldInfo="subField"
                  :text="subField.label"
                   @changeView="changeView(subField)"
                   :dataLength="subField?.dataLength"
                >
                </component>
              </div>
               <div v-if="subField.subCommentText" class="u-row u-padding-xsmall">
                <label :class="['u-ls-ws u-break-content', subField.textCSSClass]">
                  {{subField.comments }}  "{{ generateText(subField.subCommentText) }}"
                </label>
                </div> 
              </div>
            </div>
          </template>
        </div>
      </template>
    </div>
  </div>
</template>

<script>
import { mapGetters,  mapState } from "vuex";
import UADateTimePicker from "@/components/UADateTimePicker.vue";
import UATextbox from "@/components/UATextbox.vue";
import UADropDown from "@/components/UADropDown.vue";
import UASelect from "@/components/UASelect.vue";
import UADatePicker from "@/components/UADatePicker.vue";
import UATextarea from "@/components/UATextarea.vue";
export default {
  name: "UATableDisplayLayout",
  components: {
    UADateTimePicker,
    UATextbox,
    UADropDown,
    UASelect,
    UADatePicker,
    UATextarea
  },
  props: [
    "tblHeaders",
    "tableData",
    "tableFields",
    "dropDownOption",
    "dnlnStns",
    "selectedDnlnStn",
  ],
  emits:["getDynamicValuesOnChange", "setSelectedDnlnStn","changeView","onChangeValue"],
  computed: {
     ...mapState({
        isDDLLoading: (state) => state.ovsiDefaultModule.isDDLLoading,
        ddlLoadingMessage: (state) => state.ovsiDefaultModule.ddlLoadingMessage,
        isViewDetails: (state) => state.ovsiDefaultModule.isViewDetails
     }),
    showHeader() {      
      return (
        this.tblHeaders.headerValues &&
        this.tblHeaders.headerValues.length > 0 &&
        this.tblHeaders.headerValues.filter((hf) => hf != "").length > 0
      );
    },
    ...mapGetters(["getJPathValue"]),
  },
  methods: {   
     changeView(subField){ 
      this.$emit("changeView",subField);
    },
    async getValuesToBind(selectedValue, currField) {
      try {
        this.$emit(
          "getDynamicValuesOnChange",
          {selectedValue,
          currField}
        );
      } catch (err) {
      }
    },
    getTableFields(tblFlds) {
      let arrField = [];
      if (tblFlds.hasOwnProperty("subFields")) {
        return tblFlds.subFields;
      } else {
        arrField.push(tblFlds);
        return arrField;
      }
    },
    getTableDataForField(tblFldsPath, cabin) {
      let fieldData = "";
      if (this.tableData.length > 0) {
        if (
          this.tblHeaders?.isCabinWiseData &&
          cabin !== undefined &&
          cabin !== ""
        ) {
          //for cabin wise data

          if (this.dropDownOption != undefined && this.dropDownOption)
            //for dnln specific data
            fieldData = this.getJPathValue(
              tblFldsPath,
              this.tableData[0][this.selectedDnlnStn][cabin]
            );
          else
            fieldData = this.getJPathValue(
              tblFldsPath,
              this.tableData[0][cabin]
            );
        } else {
          if (this.dropDownOption != undefined && this.dropDownOption)
            //for dnln specific data
            fieldData = this.getJPathValue(
              tblFldsPath,
              this.tableData[0][this.selectedDnlnStn]
            );
          else
            fieldData = this.getJPathValue(tblFldsPath, this.tableData[0]);
        }
      }
      return fieldData;
    },
    getSourceOptions(entityItem) {
      switch (entityItem.sourceType) {
        case "api":
          return entityItem.source;
        case "inLine":
          return entityItem.source;
        case "custom":
          return this.dnlnStns;
        default:
          return "";
      }
    },
    getSelectedDNLNStnData(selectedItem, modal, path) {
      modal.model = selectedItem;
      this.$emit("setSelectedDnlnStn", selectedItem);
    },
    updateOption(eVal, modal, path, modalPath) {
      modal[path] = eVal;
    },
    updateEditFields(eVal, fieldItem) {
      fieldItem.model = eVal;
      this.$emit('onChangeValue');
    },
    generateText(headerText) {
      let str = "";
      headerText.forEach((field) => {
        if (field.type == "concat") {
          let temp = [];
          field.path.forEach((p) => {
            let value = this.getJPathValue(p,this.tableData[0])
            if(value!=undefined)
            temp.push(value);
          });
          if(temp && temp!=undefined && temp.length>0)
          str += `${temp.join(field.prefix)}`;
        } else if (field.formatDate) {
          let temp = mapDateToOtherFormat(field, this.getJPathValue);
          str += `${temp}${field.additionalText}`;
        } else {
          let temp = this.getJPathValue(field.path,this.tableData[0])
          if(temp && temp!=undefined)
          str += `${temp}${field.additionalText}`;
        }
      });
      return str;
    },
  },
};
</script>

<style>
</style>