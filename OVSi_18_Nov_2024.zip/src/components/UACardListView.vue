<template>
  <div class="u-col">
    <div class="u-row u-border-bottom u-margin-top u-border-blue-grey u-cardList">
      <div class="u-col l2 m3 s4" >
        <h6 class="u-text-0 u-margin-0">
          <a @click="selectCardDetails($event, docType, id)" alt="" class="u-pointer">{{label}}</a>
        </h6>
      </div>
      <div class="u-col l8 m7 s4" style="cursor:auto">
        <p class="u-medium u-margin-0 u-text-2">{{ description }}</p>
      </div>
    </div>
  </div>
</template>
<script>

export default {
  name: "UACardListView",
  props:["label","description","id","docType"],
  methods: {
    selectCardDetails(event , docType , id) {
      this.$emit("select-cardDetail",event, docType, id);
    },
  },
};
</script>