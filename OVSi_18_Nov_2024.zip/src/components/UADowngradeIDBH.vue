<template>
  <div class="u-row">
    <div class="u-col l12 m12 s12">
      <div
        v-if="displayHeader"
        :class="['u-col l10 m10 s10', displayHeader.cssClass]"
      >
        <label>{{ getHeaders(displayHeader.header) }}</label>
        <h6>{{ displayHeader.subHeader }}</h6>
      </div>
    </div>
    <template v-for="(cabin, cabinIndex) in cabins" :key="cabinIndex">
      <div class="u-row">
        <div class="u-row u-padding u-border-bottom-lt-2px">
          <label class="u-row">{{ cabin.name }}</label>
        </div>
        <UATableDisplay
          :cardRowCss="['u-white']"
          :tableData="getFilteredCabinData(cabinIndex)"
          :tableFields="getOVSIFields"
        />
      </div>
    </template>
  </div>
</template>

<script>
import { mapState, mapGetters,mapActions,mapMutations } from "vuex";
import UATableDisplay from "./UATableDisplay.vue";
import { mapDateToOtherFormat, createRowsData, createHeadersCells, generateAndDownloadExcel } from "@/helpers/utilities";
const ExcelJS = require('exceljs');

export default {
  name: "UADowngradeIDBH",
  data() {
    return {
      isDisabled: false,
    };
  },
  props: [],
  created(){
    this.reSetSearchOVSIData();
    this.getOVSIData({
      inputObject: {
        FlightOrigin:this.selectedRecord["flightOrigin"],
        FlightNumber:this.selectedRecord["flightNumber"],
        FlightDate:this.selectedRecord["flightDate"],
      },
      actionId: this.actionId,
    })
  },
  computed: {
    ...mapState({
      displayHeader: (state) => state.ovsiDefaultModule.displayHeader,
      searchOVSIData: (state) => state.ovsiDefaultModule.searchOVSIData,
      prevNavigateViews: (state) => state.ovsiDefaultModule.prevNavigateViews,
      isNavigatedEvent: (state) => state.ovsiDefaultModule.isNavigatedEvent,
      actionId: (state) => state.ovsiDefaultModule.actionId,
      selectedRecord: (state) => state.ovsiDefaultModule.selectedRecord,
      isLoading: (state) => state.ovsiDefaultModule.isLoading,
      cabins: (state) => state.ovsiDefaultModule.entityDisplayDetails.Layouts[0].InnerLayout.cabins,
      exportToExcelConfig: (state) => state.ovsiDefaultModule.exportToExcelConfig,
    
    }),
    ...mapGetters(["getOVSIFields", "getJPathValue"]),
  },
  methods: {
    ...mapActions(["getOVSIData"]),
    ...mapMutations(["reSetSearchOVSIData"]),
    getFilteredCabinData(cbnIndex){
        if(Object.keys(this.searchOVSIData).length == 0) return this.searchOVSIData;
        let filterData = this.searchOVSIData.downgradeList || [];
        let selectedCabinInfo = this.cabins.filter((cbn, ind) => {
          return ind == cbnIndex;
        });
        let cabinInfo = selectedCabinInfo[0];
        filterData = filterData.filter(psnrInfo => {
          return psnrInfo.currentCabin == cabinInfo.compareCabinCode;
        });
        filterData.forEach((item, ind) => {
          item.row = ind + 1;
        });
        return filterData;
      },
    getHeaders(header) {
      return header.combineFields
        .map((f) => {
          return f.path
            ? f.formatDate
              ? mapDateToOtherFormat(f, this.selectedRecord)
              : this.getJPathValue(f.path, this.selectedRecord)
            : f.concatePath
                .map((p) => this.getJPathValue(p, this.selectedRecord))
                .join(f.concatePrefix || "");
        })
        .join(header.combineBy || " ");
    },
    async exportTOExcleFileFunc(){
      let workbook = new ExcelJS.Workbook();
	    let worksheet = workbook.addWorksheet("Sheet1");
      let headerData = [{"concateFlightData" : this.getHeaders(this.displayHeader.header)}];
      let commonHeaderInfo = this.exportToExcelConfig.excelRowDetails[0];
        if(commonHeaderInfo.headerColumnsInfo){
            createHeadersCells(commonHeaderInfo.headerColumnsInfo, worksheet, this.applicationInfoDetails, headerData);
        }
      this.cabins.forEach((cbnInfo,cbnIdx) =>{
        let headercabinData = {};
        headercabinData["cabinName"] = cbnInfo.name;
        headercabinData["cabinHeader"] = cbnInfo.label;
        let cabinHeaderData = [headercabinData];
        let excelTblFldsInfo = this.exportToExcelConfig.excelRowDetails.slice(1);
        excelTblFldsInfo.forEach((excelFieldsObj)=> {
          if(excelFieldsObj.headerColumnsInfo){
            createHeadersCells(excelFieldsObj.headerColumnsInfo, worksheet, this.applicationInfoDetails, cabinHeaderData);
          }	
          //generate the required rows with actual data for the sheet
          if(excelFieldsObj.rowInfo) {
            let rowSeq = 0;            
            let cabinData = this.getFilteredCabinData(cbnIdx)
            cabinData.forEach(cbInfo => {
              rowSeq++;
              cbInfo.row = rowSeq;
            }) 
            
            createRowsData(excelFieldsObj.rowInfo, worksheet, this.applicationInfoDetails,cabinData);		
          }
        });
      })
     
      generateAndDownloadExcel(workbook,this.exportToExcelConfig.reportFileName)
    },
  },
  components: {
    UATableDisplay,
  },
};
</script>
<style scoped>
.u-border-bottom-lt-2px {
  border-bottom: 2px solid #ccc !important;
}
</style>