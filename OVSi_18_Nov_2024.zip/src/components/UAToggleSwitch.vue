<template>
<div :class="isDisabled && 'u-disabled'">
    <span v-if="activeToggleName && isActive"  class="u-margin-right-10">{{activeToggleName}}</span>
    <span v-if="inactiveToggleName && !isActive"  class="u-margin-right-10">{{inactiveToggleName}}</span>
    <label class="u-switch">
        <input type="checkbox" id="u-switch"  v-model="checkedValue">
        <span class="u-slider u-round"></span>
    </label>
</div>
</template>

<script>
    export default {
        name:'UAToggleSwitch',
        props: {
            modelValue: {
                type: Boolean, 
                default: false
            },
            activeToggleName:{
                type: String, 
                default: ""
            },
            inactiveToggleName:{
                type: String, 
                default: ""
            }
            },

        emits:["toggleChanged",'update:modelValue'],
        computed: {
            isActive() {
                return this.modelValue;
            },
            isDisabled(){
                return this.$attrs.disabled;
            },
            checkedValue: {
                get() {
                    return this.modelValue;
                },
                set(newValue) {
                    this.$emit('update:modelValue',newValue);
                    this.$emit("toggleChanged",newValue)
                }
            }
        }
    }
</script>