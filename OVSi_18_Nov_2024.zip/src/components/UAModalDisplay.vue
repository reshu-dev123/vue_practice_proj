<template>
  <div class="u-row u-overlay" style="display: block">
    <div :class="[modalTable.modalCss]"  style="display: block"  ref="modalComRef" @mouseleave="mouseLeaveHandler()" @mouseover="mouseOverHandler()">
      <form :class="['u-modal-add-content u-modCont-ht',modalTable.isDisScroll && modalTable.modalContHt]">
        <div id="modalContainer" :class="['u-round contentScroll',modalTable.maxHt]" style="height:82vh">
          <UAModalAlertMessage v-once />
        <div class="u-row u-th-fixed u-background-white">
          <div class="u-row">
            <div v-if="!isViewDetails && modalTable.headerText" :class="['u-col l11 m11 s11', modalTable.cssClass]">
              <label :class="['u-ls-ws', modalTable.textCSSClass]">
                {{ modalTable.headerText }}
              </label>
            </div>
            <div v-else :class="['u-col l11 m11 s11', modalTable.cssClass]">
              <label :class="['u-ls-ws', modalTable.textCSSClass]">
                {{ modalTable.viewHeaderText }}
              </label>
            </div>
            <div class="u-col l1 m1 s1">
              <UAButton
                @click.prevent="$emit('close')"
                cssClass=" u-transparent u-primary-inv-border u-pad-0 u-right u-pointer"
                id="close_modal"
              >
              <img :src="getImageUrl('close_grey.png')" />
              </UAButton>
            </div>
          </div>
          <div class="u-row u-medium u-fnt-cst-1 u-left u-pad-left-1" v-if="subHeader">
            <label class="u-row u-ls-ws"> {{ subHeader }} </label>
          </div>
          <div v-if="modalTable.secondhHeaderText" class="u-row">
            <label :class="['u-ls-ws', modalTable.textCSSClass]">
              {{ generateText(modalTable.secondhHeaderText) }}
            </label>
          </div>
        </div>
          <div :class="['u-col', modalTable.blockCssClass]" v-if="modalTable">
            <template
              v-for="(modalData, modalIndex) in modalTable.modalFields"
              :key="modalIndex"
            >
              <!--  modalData: custname,pnr table and headers  -->
              <div :class="['u-col u-panel', modalData.styles.divCssClass,{'u-disabled':modalData.disableSection}]">
                <div :class="[modalData.styles.cssClass]">
                  <label class="u-ls-ws">
                    {{ modalData.headerText }}
                  </label>
                </div>
                <div
                  v-if="modalData.subHeaderText"
                  :class="[modalData.styles.textCSSClass]"
                >
                  <label class="u-ls-ws">
                    {{ modalData.subHeaderText }}
                  </label>
                </div>
                <div v-if="modalData.combineHeaderText" class="u-row">
                  <label
                    :class="['u-ls-ws', modalData.combineHeaderText.textCSSClass]"
                  >
                    {{ combineFields(modalData.combineHeaderText, tableData[0]) }}
                  </label>
                </div>
                <div :class="['u-row',modalData.styles.paddingClass]">
                  <!-- UATableColLayout -->
                <template v-for="(mdlSecFilds,mdlScIndx) in modalData[modalData.id]" :key="mdlScIndx">
                  <component
                    :is="modalData.ComponentType"
                    :tblHeaders="mdlSecFilds.headers[0] || []"
                    :tableFields="mdlSecFilds.tableFields"
                    :tableData="getTableData(modalData)"
                    v-model="modalData.value"
                    :value ="mdlScIndx+1"
                    :fields="mdlSecFilds.tableFields"
                    :chevronImg="mdlSecFilds.headers[0]?.chevronImg"
                    :data="data"
                    :headerCssClass="modalData.styles.headerCssClass"
                    @getDynamicValuesOnChange="
                      performActionOnChnage($event, modalData)
                    "
                    @onChangeValue="modalTable.isTriggerForValue && onChangeValue()"
                  >
                  </component>
                </template>
                <!-- Pushing the additional Fields -->
                  <div  v-if="modalData.addRowInstance">
                  <div v-if="!modalData.addExtraRowInstance && !modalData.addExtraAdditionalRowInstance">
                    <template
                      v-for="(addFieldInfo, index) in modalTable.addNewRowFields"
                      :key="index"
                    >
                      <component
                        class="u-section-1"
                        :is="addFieldInfo.ComponentType"
                        :tblHeaders="addFieldInfo.headers[0]"
                        :tableFields="addFieldInfo.tableFields"
                        :tableData="tableData"
                        :value="(modalData[modalData.id].length + index + 1)"
                        @getDynamicValuesOnChange="
                          performActionOnChnage($event, addFieldInfo)
                        "
                        @delete="deleteRow((modalData[modalData.id].length + index + 1), modalData,'add')"
                        :deleteimg="addFieldInfo.headers[0].deleteimg"
                        :chevronImg="addFieldInfo.headers[0].chevronImg"
                        :borderCssClass="['u-primary-inv-border']"
                        :tableCssClass="['u-border u-white']"
                      >
                      </component>
                    </template>
                  </div> 
                  <div v-if="modalData.addExtraRowInstance && !modalData.addExtraAdditionalRowInstance">
                    <template
                      v-for="(addExtraFieldInfo, index) in modalTable.addExtraRowFields"
                      :key="index"
                    >
                      <component
                        class="u-section-1"
                        :is="addExtraFieldInfo.ComponentType"
                        :tblHeaders="addExtraFieldInfo.headers[0]"
                        :tableFields="addExtraFieldInfo.tableFields"
                        :tableData="tableData"
                        :value="index + 2"
                        @getDynamicValuesOnChange="
                          performActionOnChnage($event, addExtraFieldInfo)
                        "
                        @delete="deleteExtraFieldRows(index, modalData)"
                        :deleteimg="addExtraFieldInfo.headers[0].deleteimg"
                        :chevronImg="addExtraFieldInfo.headers[0].chevronImg"
                        :borderCssClass="['u-primary-inv-border']"
                        :tableCssClass="['u-border u-white']"
                      >
                      </component>
                    </template>
                  </div>
                  <div v-if="!modalData.addExtraRowInstance && modalData.addExtraAdditionalRowInstance">
                    <template
                      v-for="(addExtraNewFieldInfo, index) in modalTable.addNewExtraRowFields"
                      :key="index"
                    >
                      <component
                        class="u-section-1"
                        :is="addExtraNewFieldInfo.ComponentType"
                        :tblHeaders="addExtraNewFieldInfo.headers[0]"
                        :tableFields="addExtraNewFieldInfo.tableFields"
                        :tableData="tableData"
                        :value="index + 2"
                        @getDynamicValuesOnChange="
                          performActionOnChnage($event, addExtraNewFieldInfo)
                        "
                        @delete="deleteExtraRow(index, modalData)"
                        :deleteimg="addExtraNewFieldInfo.headers[0].deleteimg"
                        :chevronImg="addExtraNewFieldInfo.headers[0].chevronImg"
                        :borderCssClass="['u-primary-inv-border']"
                        :tableCssClass="['u-border u-white']"
                      >
                      </component>
                    </template>
                  </div>
                    <div class="u-col u-margin-bottom-12">
                      <UAButton
                        v-if="modalData.addRowInstance && !isViewDetails" :class="[modalData.addRowInstance && modalData.addInstClass ]"
                        cssClass="u-text-purple u-transparent u-padding-top-24 u-pointer" :id="modalTable.headerText.replaceAll(' ','_')+`_`+subHeader.replaceAll(', ','_')+`_add_instance`"
                        @click.prevent="modalData.addExtraRowInstance  ? addExtraNewRow() : modalData.addExtraAdditionalRowInstance ? addExtraRow() : addNewRow() "
                        >{{ modalData.addRowInstance }}
                      </UAButton>
                    </div>
                  </div>
                </div>
              </div>
            </template>
            <!-- Iterating the Bid Table as per Data -->
            <div
              v-if="modalTable?.altModalFields && bidData && bidData.length > 0"
            >
              <template
                v-for="(altData, altIndex) in modalTable.altModalFields"
                :key="altIndex"
              >
                <template v-for="(bData, bIndex) in bidData" :key="bIndex">
                  <div :class="['u-col u-margin-top-16', altData.styles.divCssClass]">
                    <div :class="[altData.styles.cssClass]">
                      <label class="u-ls-ws">
                        {{ altData.headerText }}
                      </label>
                      <label class="u-ls-ws">
                        {{
                          getHeaders(
                            altData.fltOptCount,
                            bData
                          )
                        }}
                      </label>
                    </div>
                    <div
                      v-if="altData.subHeaderText && bData?.alternateSchedule?.alternateFlights[0]"
                      :class="[altData.styles.textCSSClass]"
                    >
                      <label
                        :class="['u-ls-ws', altData.subHeaderText.textCSSClass]"
                      >
                        {{
                          getHeaders(
                            altData.subHeaderText,
                            bData?.alternateSchedule?.alternateFlights[0]
                          )
                        }}
                      </label>
                    </div>
                    <div class="u-row">
                      <component
                        :is="altData.ComponentType"
                        :tblHeaders="altData[altData.id][0].headers[0]"
                        :tableFields="altData[altData.id][0].tableFields"
                        :tableData="bData.bidOptions"
                      >
                      </component>
                    </div>
                  </div>
                </template>
              </template>
            </div>
          </div>
        </div>
      </form>
      <div :class="['u-footer-fixed u-background-white ',modalTable.footerCssClass]">
        <footer class="u-row u-margin-10">
          <template v-for="(hField, hKey) in footerFields" :key="hKey">
            <component
              :is="hField.fieldType"
              @click="genericHandler(hField.events)"
              :cssClass="hField.fieldsCssClass"
              :disabled="hField?.isDisableBtn && (record?.oversaleStatus == ('Finalized' || 'FINALIZED') || !isFoundNewValue)"
              :id="!isViewDetails ? modalTable.headerText.replaceAll(' ','_')+`_`+hField.name 
                : modalTable.viewHeaderText.replaceAll(' ','_')+`_`+subHeader.replaceAll(', ','_')+`_`+hField.name"
              ><img
                v-if="hField.icon"
                :class="hField.CssClass"
                :src="getImageUrl(hField.icon)"
              />
              {{ hField.name }}
            </component>
          </template>
        </footer>
      </div>
    </div>
  </div>
</template>
<script>
import UATextbox from "@/components/UATextbox.vue";
import UAButton from "@/components/UAButton.vue";
import UADropDown from "@/components/UADropDown.vue";
import UATableColLayout from "@/components/UATableColLayout.vue";
import UATableDisplayLayout from "@/components/UATableDisplayLayout.vue";
import UAOVSITableDisplay from "@/components/UAOVSITableDisplay.vue";
import UATableDisplay from "@/components/UATableDisplay.vue";
import { mapGetters, mapState, mapMutations } from "vuex";
import UAOvsiTableColLayout from "./UAOvsiTableColLayout.vue";
import { getImageUrl,mapDateToOtherFormat } from "../helpers/utilities.js";
import UAModalAlertMessage from "./UAModalAlertMessage.vue";

export default {
  name: "UAModalDisplay",
  components: {
    UATextbox,
    UAButton,
    UADropDown,
    UATableColLayout,
    UATableDisplayLayout,
    UAOVSITableDisplay,
    UAOvsiTableColLayout,
    UAModalAlertMessage,
    UATableDisplay,
      },
  props: [
    "modalTable",
    "tableData",
    "data",
    "footerFields",
    "record",
    "subHeader",
    "bidData",
    "paddingClass"
  ],
  emits: [
    "close",
    "add",
    "bindDependentValuesOnCHange",
    "addNewFieldRow",
    "addExtraFieldRow",
    "update",
    "deleteNewFieldRow",
    "deleteExtraFieldRow",
    "deleteExtraAdditionalRow",
    "viewEditEnable"
  ],
  data() {
    return {
      searchFiltersOptions: {
        pathParam: "",
        data: "",
        docType: "",
      },
      val: 0,
      isFoundNewValue: false,
      mouseVisitedOnModal:false,//TO Verify THE mouse FOCUS OR MOUSE OVER ON MODAL DISPLAY at least one time 
      mouseLeaveDetected:false
    };
  },
  mounted() {
    this.tableData ? this.showModalData() : "";
    setTimeout(() =>  document.addEventListener("click",this.handleOutSideClick),100) ;
  },
  unmounted() {
    document.removeEventListener("click",this.handleOutSideClick);
  },
  computed: {
    ...mapState({
        isViewDetails: (state) => state.ovsiDefaultModule.isViewDetails,
    }),
    ...mapGetters(["getJPathValue", "getOVSIFields"]),
  },
  methods: {
    ...mapMutations(["setAlertMessages"]),
      scrollToTop(){
        var elem = document.getElementById('modalContainer');
        elem.scrollTop = 0;
      },
       mouseLeaveHandler(){
        this.mouseLeaveDetected = true;
      },
      mouseOverHandler(){
        this.mouseLeaveDetected = false;
        this.mouseVisitedOnModal = true;
      },
      handleOutSideClick(e){
        if((this.mouseLeaveDetected && this.mouseVisitedOnModal) || (!this.mouseLeaveDetected && !this.mouseVisitedOnModal)){//IF AT LEAST ONCE THE MOUSE OVER THE MODAL DISPLAY AND THEN ONLY DETECT THE MOUSE LEAVE
          if(this.$refs?.modalComRef && !this.$refs?.modalComRef?.contains(e.target)){
            this.$emit("close");       
          } 
        }
      },
      onChangeValue(){ // validate new values for each field if found enable the button
          let cnt =0;
          let modelLenCnt = 0;
          this.modalTable.modalFields.forEach(modalFlds =>{
            modalFlds[modalFlds.id].forEach((mdlFldItem) => { 
              mdlFldItem.tableFields.forEach((inHeader) => {
                let modalBindData = [];
                modalBindData = this.getTableData(modalFlds);
                if(!inHeader?.attributes?.disabled){
                  if (inHeader.model.length==0)
                    modelLenCnt++;
                  if (
                    inHeader.combinepath &&  inHeader.combinepath.length > 0 
                  ){
                    if(inHeader.model != this.combineFields(inHeader, modalBindData[0]))
                      cnt++;
                  } else {
                    if(inHeader.model != this.getJPathValue(inHeader.path, modalBindData[0]))
                      cnt++;
                  }
                }
              }) 
            })
          })
          this.isFoundNewValue = (modelLenCnt == 0 && cnt>0)
      },
    getTableData(modalInfo){
      if(modalInfo.isCabinWiseData){
        return this.tableData[0][modalInfo.cabinCode];
      }
      return this.tableData;
    },
    performActionOnChnage(inputFieldInfo, currModalData) {
      this.$emit("bindDependentValuesOnCHange", {
        inputFieldInfo,
        currModalData,
      });
    },
    addNewRow() {
     this.$emit("addNewFieldRow")
    },
    addExtraNewRow() {
      this.$emit("addExtraFieldRow")
    },
    addExtraRow() {
      this.$emit("addExtraAdditionalRow")
    },

    deleteRow(index, modalData,selMode) {
      this.$emit("deleteNewFieldRow", index, modalData, selMode);
    },
     
    deleteExtraFieldRows(index, modalData){
      this.$emit("deleteExtraFieldRow", index, modalData);
    },
    deleteExtraRow(index, modalData){
      this.$emit("deleteExtraAdditionalRow", index, modalData);
    },

    getCopy(field) {
      return JSON.parse(JSON.stringify(field));
    },
    genericHandler(eventName) {
      if (eventName.name === "cancel") this.$emit("close");
      else if (eventName.name === "update") {
        this.$emit("update", this.modalTable,'Updated');
      } else if (eventName.name === "viewEdit") {
        this.$emit("viewEditEnable", this.modalTable);
      } else {
        this.$emit("add", this.modalTable,'Added');
      }
      if(eventName.name != "cancel") this.scrollToTop();
    },
    generateText(headerText) {
      let str = "";
      headerText.forEach((field) => {
        if (field.type == "concat") {
          let temp = [];
          field.path.forEach((p) => {
            temp.push(this.record[p]);
          });
          //temp = temp.substring(temp.length-1,0).concat(field.additionalText);
          str += `${temp.join(field.prefix)}`;
        } else if (field.formatDate) {
          let temp = mapDateToOtherFormat(field, this.record);
          //temp = temp.substring(temp.length-1,0).concat(field.additionalText);
          str += `${temp}${field.additionalText}`;
        } else {
          //str.concat(this.getJPathValue(field.path,this.record).toString().concat(field.additionalText));
          str += `${this.record[field.path]}${field.additionalText}`;
        }
      });
      return str;
    },
    getHeaders(subHeaderText, item) {
      return subHeaderText.combineFields
        .map((f) => {
          return f.path
            ? (f.formatDate? mapDateToOtherFormat(f, item) : this.getJPathValue(f.path, item))
            : f.concatePath
                .map((p) => this.getJPathValue(p, item))
                .join(f.concatePrefix || "");
        })
        .join(subHeaderText.combineBy || " ");
    },
    getImageUrl(params) {
      return getImageUrl(params);
    },
    showModalData() {
      this.modalTable.modalFields.forEach((modalFlds) => {
        if(modalFlds.showTotalInfo) return;
        let modalBindData = [];
        modalBindData = this.getTableData(modalFlds);
        if(modalFlds.bindModalFieldWithIteratbleData) {
          if(modalFlds.multiDataParentPathToIterateTblFilds){
            modalBindData = this.getJPathValue(modalFlds.multiDataParentPathToIterateTblFilds,modalBindData[0])
          }
        }
        modalFlds[modalFlds.id].forEach((mdlFldItem, mdlFldIndx) => { 
          if(modalBindData && modalBindData.length>0){
            mdlFldItem.tableFields.forEach((inHeader) => {
          if (
            !inHeader.isAminities &&
            inHeader.combinepath &&
            inHeader.combinepath.length > 0
          ) {
            inHeader.model = this.combineFields(inHeader, modalBindData[mdlFldIndx]);
          } else if (inHeader.isAminities && inHeader.isEdit) {
            let ams =
              this.getJPathValue(inHeader.path, modalBindData[mdlFldIndx]) || [];
            let aminities =
              ams.filter(
                (am) => am[inHeader.filterPath] == inHeader.filterValue
              ) || [];
            inHeader.model =
              aminities.length > 0
                ? this.combineFields(inHeader, aminities[0])
                : inHeader.defaultValue;
          } else {
            inHeader.path
              ? (inHeader.model = this.getJPathValue(
                  inHeader.path,
                  modalBindData[mdlFldIndx]
                ))
              : "";
              }
            });
          }
        });
      });
    },
    combineFields(field, item) {
      let FloatObj = {};
      let fieldValue ='';
      if(field.isFloatValue){
          let aminObj ={};
          FloatObj[field.updtPath] =aminObj;
          field.combinepath.forEach(path=>{
          if(path == field.combinepath[0]){
          let amnt = this.getJPathValue(path,item)
          let amntValue = Number.isInteger(amnt) ? amnt : parseFloat(amnt).toFixed(2)
          aminObj["amount"] =  amntValue;      
          }else{
            let currCode = this.getJPathValue(path,item)
            aminObj["currencyCode"] =  currCode;
          }
        })
        fieldValue = field.combinepath.map(path=>this.getJPathValue(path,FloatObj)).join(field.combinePrefix||'').toString();
      } else{
         fieldValue = field?.combinepath.map(path=>this.getJPathValue(path,item)).join(field.combinePrefix||'').toString();
      }
      if(fieldValue.trim().length === 0){
       return field.defaultValue;
      }
      return fieldValue;
    },   
    }  
};
</script>

<style scoped></style>
