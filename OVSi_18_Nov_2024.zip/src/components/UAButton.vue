<template>
    <button :id="id" @click="onClick(eventClick)" :class="cssClass" :disabled="disabled" v-bind="$attrs" :type=" type ? type : 'submit'" >
      <slot/>
    </button>
</template>
<script>
export default {
    name: 'UAButton',
   props: ["href","buttonTxt","eventClick","background","color","cssClass","type","disabled","id"], 
    methods:{
        onClick(eventName){        
          if(eventName!=undefined) {
               this.$emit("onClick");            
          }
        }
    }
}
</script>
<style scoped>
  .button:hover {
    background:#816ac9;
    color: #fff;
    border: 3px solid #816ac9;
  }
</style>