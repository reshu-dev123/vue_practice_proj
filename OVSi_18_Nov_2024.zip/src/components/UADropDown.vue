 <template>
    <select :class="[' u-input-1 u-border u-round',cssClass]" :name="id" :id="id" :disabled="isDisabled" @change="changeView($event)">
        <option v-for="(option,index) in options" :selected="modelValue==option[selectedKey]" :value="selectedKey?option[selectedKey]:option.name" :key="index">{{ option.label }}</option>
    </select>
 </template>
 <script>
    export default{
      name:'UADropDown',
      inheritAttrs:false,
         methods:{
            changeView (event) {
              let selectedOption = event.target.value;
               this.$emit('update-option', selectedOption);
               if(this.onChangeFieldsToTrigger != undefined && this.onChangeFieldsToTrigger.length >0){
                  this.$emit("callApiOnDateChange", selectedOption);
               }  
            } 
         },
         props:["options","isDisabled","cssClass", "onChangeFieldsToTrigger","selectedKey","id","modelValue"]

    }
 </script>