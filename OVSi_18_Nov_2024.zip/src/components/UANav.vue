<template>
  <div  class=" u-flex">
  <div class=" u-col 112 m12 s12 topnav u-pad-right-1 u-pad-left-1 u-flex">
    <a id="return_menue" v-if="isNavigatedEvent" :class="isLoading && 'u-disabled u-disabled-a'" class="tab u-msmall lf mf sf" @click="backToprevious()" href="#"><span class="return-style u-text-underline"><img src="../assets/img/leftArrow.png"/> Return</span> </a>
    <template v-for=" (menuItem, key) in getMenuItems" :key="key">
      <a :id="menuItem.id" v-if="!menuItem.baseMenue" class="tab u-msmall lf mf sf" :class="getCurrentActiveMenuId(menuItem, key) ? 'active u-fnt-500' : 'u-text-underline',isLoading && 'u-disabled u-disabled-a'" @click="navigateMenu(menuItem)" href="#">{{ menuItem.label }}</a>
    </template>
    
  </div>
  <div v-if="showExportOptions" class="u-col l2 m2 s2 u-right topnav u-container u-flex-end u-padding-bottom-4 u-pad-right-24px u-fnt-wt-300" >
   <span  class="u-margin-right u-msmall lf mf sf"> <UAExport/> </span> 
    <span class="u-msmall lf mf sf"> <UACopyURL/> </span>
  </div>
</div>
</template>

<script>
import { mapGetters, mapActions, mapState, mapMutations } from 'vuex';
import { decodeData } from '../helpers/utilities';
import UAExport from "./UAExport.vue";
import UAButton from "./UAButton.vue";
import UACopyURL from "./UACopyURL.vue"

export default {
  name: 'UANav',
  data() {
    return {
      currSelectedId: '',
    }
  },
  components:{
    UAButton,
    UAExport,
    UACopyURL
  },
 async mounted() {
   let query= this.$route.query;
   let pathInfo = this.$route.params.path;
    if(this.$route.path == '/oauth2/idpresponse' || this.$route.path == ''){ // from oam
      if(query.state){ // if from copy url feature
          let url =new URL(decodeData(query.state));
          let params =Object.fromEntries(url.searchParams);
          this.setCurrRouteDDetails({query:params});
        await  this.routeToSPecificMenu(url.pathname.replace('/',''))
          //window.location.replace(url);
      }else{// from direct OAM
        this.redirectToDeafultPage();
        this.$router.push("/");
      }
    }else{
      this.setCurrRouteDDetails(this.$route);
     await this.routeToSPecificMenu(pathInfo)
    }
  },
  computed: {
    ...mapState({
      screenLayout: (state) => state.ovsiDefaultModule.screenLayout,
      isNavigatedEvent: (state) => state.ovsiDefaultModule.isNavigatedEvent,
      prevNavigateViews: (state) => state.ovsiDefaultModule.prevNavigateViews,
      mainViewId: (state) => state.ovsiDefaultModule.mainViewId,
      menuDetails: (state)=>state.menuModule.menuDetails,
      currRouteDDetails: state => state.ovsiDefaultModule.currRouteDDetails,
      showExportOptions: state => state.ovsiDefaultModule.showExportOptions,
      isLoading: state=>state.ovsiDefaultModule.isLoading
    }),
    ...mapGetters(["getMenuItems", "getSubMenuItems", "getImageUrl", "getCurrentActiveMenuId",'getParent']),
  },
  methods: {
    ...mapActions([
      "setProcessStep",
      "clearAlertMessages",      
      "getEntityDisplayDetailsAction",
      "navigateMenuAction",
      "getFlight"
    ]),
    ...mapMutations(["setCurrRouteDDetails","setAlertMessages",
     "setIsNavigatedEvent", "setIsRouteNavigationMenu","setSelectedRecord",
     "setIsNavigateToInnerOtherView", "clearAlertMessages","setFilterInputData",
     "deletePrevNavigateViews","setSelectedMenuId","resetPrevNavigateViews","resetEntityDetails",
    "setselectedMainMenuId"]),
    exportFunc(){
      this.$emit("openExportModalPopup")
    },
    redirectToDeafultPage(){
      setTimeout(() => this.navigateMenuAction({ menu: this.getMenuItems[0] }), 1 * 1);
    },
    async routeToSPecificMenu(pathInfo){
      let pathMatchFound= false;
      if(pathInfo){
         await this.getSelectRecordIfRouting();
          this.menuDetails.forEach((menu,menuIndex)=>{         
            if(menu.id == pathInfo){
              this.setIsNavigateToInnerOtherView(true)
              pathMatchFound=true;
              let parentMenu = this.getParent(menu.parent)[0];
              if(parentMenu && parentMenu.parent == "rootnode" && parentMenu.showSubNavItems){
                this.setselectedMainMenuId(parentMenu.id);
                this.setSelectedMenuId(menu.id);
              }
              if(menu.isNavigationMenu) {
                this.setIsRouteNavigationMenu(true);
              }
              setTimeout(() => this.navigateMenu(menu ), 1 * 1);
              
            }
          });
          this.$router.push("/");
          if(!pathMatchFound){
            this.redirectToDeafultPage();
          }
          
      } else {
        this.redirectToDeafultPage();
      }
    },
    async backToprevious() {      
      this.clearAlertMessages();
      this.deletePrevNavigateViews();
      if (
        this.prevNavigateViews.length == 1 &&
        this.prevNavigateViews[0].id == this.mainViewId
      ) {
        this.setIsNavigatedEvent(false);
      }
      await this.getEntityDisplayDetailsAction(this.prevNavigateViews[this.prevNavigateViews.length - 1].id);
      this.setSelectedMenuId(this.prevNavigateViews[this.prevNavigateViews.length - 1].id);
      if (
        this.prevNavigateViews.length == 1 &&
        this.prevNavigateViews[0].id == this.mainViewId
      ) {
        this.setIsNavigateToInnerOtherView(false);
      }
    },
   async getSelectRecordIfRouting(){
    let queryInfo = this.currRouteDDetails.query;
    if(queryInfo.fltOrigin && queryInfo.fltnum &&  queryInfo.fltDt){
      let   inpObj = {
          FlightOrigin: queryInfo.fltOrigin,
          FlightNumber: queryInfo.fltnum,
          FlightDate: queryInfo.fltDt,
        }
      // set select record data from API for direct land
      await this.getFlight(inpObj);
    }
    },
    navigateMenu({ id,parent, isNavigationMenu ,fetchFromLocal}) {
      this.clearAlertMessages();
      this.prevNavigateViews.length>1?'':this.resetPrevNavigateViews();
      this.setFilterInputData();
      if(parent.toLowerCase() == 'rootnode' && !isNavigationMenu){
        this.resetEntityDetails();
        this.setselectedMainMenuId(id);
      } else if(parent.toLowerCase() == 'configuration_tool') {
        this.resetEntityDetails();
        this.setselectedMainMenuId(parent);
      }
      this.setSelectedMenuId(id);
      this.getEntityDisplayDetailsAction(id).then(() => {
        if (this.screenLayout != "") {
          this.setProcessStep(this.screenLayout);
        } else {
          this.setProcessStep(id);
        }
      })
    }
  }

}
</script>

<style scoped>
.topnav {
  overflow: hidden;
  background-color: #002244;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  /* font-size: 14px; */
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #f6f8f7;
  color: rgb(0, 34, 68);
}

.topnav .tab {
    padding: 6px 10px 6px 10px;
    display: flex;
    align-self: flex-end;
    border-radius: 0;
    margin:8px 10px 0px 0px;
}  
.return-style{
    left: -7px;
    position: relative;
    top: 6px;
}

</style>