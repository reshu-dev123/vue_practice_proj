<template>
  <div  :style="[cssDivStyle?'width:81%':'','position: relative']"
  :class="[
        {'u-input u-border u-round u-input-1 u-padding-xsmall-xs u-text-3 u-bg-4 u-small': isFloatLabel},
        (errmsg && modelValue) ?(this.filtersErrorTooltip?'u-tooltip tip-bottom-search u-border-err'
        : errorOnTop?'u-tooltip tip-top-buttons u-border-err' :modalError?'u-tooltip tip-bottom-buttons u-border-err'
        :'u-tooltip-1 tip-bottom-1 u-round u-border-err') : 'u-display-container u-input-1 u-text-3 u-bg-4 u-small'
      ]" :data-tooltip="errmsg">
      <label v-if="showLabel" :class="[labelClass]">
        {{ this.modelValue != "" ? this.labelInfo : this.placeholder }} 
        <span class="u-medium u-text-red" v-if="isMandatory">*</span> </label
      >
        <input id="date" 
          type="date" name="date" 
          :value="modelValue" 
          @change="onDateChange"  
          hidden
          style="text-decoration: none; display: block; outline: none; border-radius: 4px;"
          :class="cssClass" 
          :disabled="isDisabled"/>
       
        <!-- Actually date  :value="modelValue getFormattedDate"  -->
       
        <input :class="[{'u-input-xs u-text-0 inputDate no-outline': isFloatLabel},cssCalendar]"
           class="calenderCla u-text-0"
          :placeholder="this.dateConfig.defaultShowDateFormat" 
          v-bind="$attrs" 
          @input="onTextInput" 
          @focusout="prefixZeros"
          @mouseout="prefixZeros"
          type="text" 
          :value="getFormattedDate" 
          @keypress="onKeyPressHandler($event)"
          :disabled="isDisabled"
          @paste="onPasteHandler($event)"/>
  </div>
  </template>
   
  <script>
  import { getDefaultDate,createLocalDate,validateDateWithDDMM } from "@/helpers/utilities";
  import { mapState ,mapGetters} from "vuex";
  export default {
    name: "UADatePicker",
    inheritAttrs: false,
    data(){
      return {
        errmsg: "",
      }
    },
    watch: {
      modelValue(newModel,oldModel){ // clearing error message for valid date and empty string
        if((newModel?.length == 10 && this.isValidDate(newModel))||newModel?.length==0){
          this.errmsg='';
          if(this.currInputFieldInfo) {
            this.currInputFieldInfo.isError =  false;
            this.currInputFieldInfo.dislayError = this.errmsg
          }
        }
      }
    },
    computed: {
      ...mapGetters(["validateKeyPressInput"]),
      ...mapState({
        dateConfig: (state)=> state.ovsiDefaultModule.applicationInfoDetails.dateConfig,
        applicationInfoDetails: (state)=> state.ovsiDefaultModule.applicationInfoDetails,
        getFormattedDate(){
          if(this.modelValue && this.modelValue.length != 1 && !this.errmsg){
            return this.getDatePart(createLocalDate(this.modelValue, false), "dateString", this.dateConfig.defaultShowDateFormat)
          } else if(this.modelValue){
            return this.modelValue;
          }
        }
      })
    },
    methods:{
      onPasteHandler(event){
        let pasteText = event.clipboardData.getData('text/plain');
        if(!this.validateInputText(pasteText) ){
          event.preventDefault();
        }
      },
      validateInputText(pasteText){
        if(this.currInputFieldInfo && this.currInputFieldInfo.attributes && this.currInputFieldInfo.attributes.maxlength){
          if(pasteText.length > this.currInputFieldInfo.attributes.maxlength) return false;
        }
        if(this.currInputFieldInfo.dataType && this.currInputFieldInfo.dataType != '')  {
          let ptrnType = this.currInputFieldInfo.dataType.split('_')[0];
          let dateRegex = new RegExp(this.applicationInfoDetails.keyPressInputPatterns[ptrnType]);
          if (!dateRegex.test(pasteText)) return false;
        } 
        return true;
        // let  regEx = new RegExp(this.dateConfig.defaultDatePattern); ///^\d{4}-\d{2}-\d{2}$/;
        // if(!pasteText.match(regEx)) return false;
        // let isvalid = validateDateWithDDMM(pasteText);
        // if(!isvalid) return false;//IF DAYS AND MONTH NOT PROPER THEN INVALIDATE THE DATE
        // let dt = createLocalDate(pasteText,false)//false for to consider the entered month number
        // return dt.toString()  != 'Invalid Date';    
      },
      onKeyPressHandler(event){
        if(!this.validateKeyPressInput(event,this.currInputFieldInfo.dataType)){
          event.preventDefault();
        }
      },
      getDatePart(date, type = "date",formatDate){
        if(!date) return;
        let year = date.getFullYear();
        let month = date.getMonth();
        let dd = date.getDate();
        let mon = month + 1;
        if(type == "date"){
          let datePart = createLocalDate(mon+"/"+dd+"/"+year, false);
          return datePart;
        } else if(type == "dateString"){
          let mm = month+1;
          let mon = ("0" + mm).slice(-2);
          let day = ("0" + dd).slice(-2);
          if(formatDate == "MM-DD-YYYY"){
            return  mon + "-" + day + "-" + year;
          } else if(formatDate == "MM/DD/YYYY"){
            return  mon + "/" + day + "/" + year;
          } else {
            return year  + "-" + mon + "-" + day;
          }        
        }      
      },
      onDateChange(e){  
        this.errmsg='';
        let selectedDt = e.target.value;
        this.$emit("update:modelValue", selectedDt);
        if(this.currInputFieldInfo) {
          this.currInputFieldInfo.isError =  false;
          this.currInputFieldInfo.dislayError = this.errmsg
        }
        if(this.onChangeFieldsToTrigger != undefined && this.onChangeFieldsToTrigger.length >0){
          this.$emit("callApiOnDateChange", selectedDt);
        }        
      },
      prefixZeros(e) {
        let str = e.target.value;
        let mon, day, yyyy, strArr, finalStr = str;
        if (str.includes("/")) {
          strArr = str.split("/");
          if (strArr.length === 3) {
            mon = `${strArr[0]}`
            day = `${strArr[1]}`
            yyyy = `${strArr[2]}`
            mon = mon != "0" ? ("0" + mon).slice(-2) : mon;
            day = day != "0" ? ("0" + day).slice(-2) : day;
            finalStr = `${mon}/${day}/${yyyy}`;
            this.$emit("update:modelValue", finalStr);            
            if(this.isValidDate(finalStr)){              
              this.errmsg = '';
              if (this.currInputFieldInfo) {
                this.currInputFieldInfo.isError = false;
                this.currInputFieldInfo.dislayError = this.errmsg
              }
              let finalDt =  `${yyyy}-${mon}-${day}`;
              this.$emit("update:modelValue", finalDt);
              this.$emit("callApiOnDateChange", finalDt);
            }
          }
        }
      },
      
      onTextInput(e) {
        let text = e.target.value;
        this.checkSlashPrefix(text, e);
        if (text?.length == 0) return;
        if (text?.length != 10) {
          this.errmsg = "Invalid Date Found";
          if (this.currInputFieldInfo) {
            this.currInputFieldInfo.isError = true;
            this.currInputFieldInfo.dislayError = this.errmsg
          }
          return;
        }
        if (this.isValidDate(text)) {
          this.errmsg = '';
          if (this.currInputFieldInfo) {
            this.currInputFieldInfo.isError = false;
            this.currInputFieldInfo.dislayError = this.errmsg
          }
          let selectedDt = this.getDatePart(createLocalDate(text, false), "dateString");
          this.$emit("update:modelValue", selectedDt);
          if(this.onChangeFieldsToTrigger != undefined && this.onChangeFieldsToTrigger.length >0){
            this.$emit("callApiOnDateChange", selectedDt);
          }
        } else {
          this.errmsg = "Invalid Date Found";
          if (this.currInputFieldInfo) {
            this.currInputFieldInfo.isError = true;
            this.currInputFieldInfo.dislayError = this.errmsg
          }
        }
      },
      isValidDate(str){
        //let pattern = /(0[1-9]|1[1,2])(\/)(0[1-9]|[12][0-9]|3[01])(\/)(19|20)\d{2}/;
        let  regEx = new RegExp(this.dateConfig.defaultDatePattern); 
        if(!str.match(regEx))  return false;
        let isvalid = validateDateWithDDMM(str);
        if(!isvalid) return false;//IF DAYS AND MONTH NOT PROPER THEN INVALIDATE THE DATE
        let dt = createLocalDate(str, false);
        return dt.toString()  != 'Invalid Date';
      },
      
    //this method to prefix slash and zeros in fews cases while entering date text 
    checkSlashPrefix(str,e){
      let len = parseInt(str.length); 
      switch (len) {
        case 2:
              if(!str.includes("/")){
                    this.$emit("update:modelValue", str+"/")
                  }
              break;
        case 5:
              if(!str.substring(4,5).includes("/") && str.lastIndexOf("/") <= 2){
                this.$emit("update:modelValue",`${str}/`)
              } 
         break;
        
        default:
        this.$emit("update:modelValue", `${str}`)
      }
    },
   
    },
    props: [
      "modelValue",
      "labelInfo",
      "isMandatory",
      "placeholder",
      "showLabel",
      "isFloatLabel",
      "cssClass",
      "cssLabel",
      "labelClass",
      "onChangeFieldsToTrigger",
      "cssCalendar",
      "isDisabled",
      "currInputFieldInfo",
      "cssDivStyle",
      "errorOnTop",
      "modalError",
      "filtersErrorTooltip",
    ],
  };
  </script>
   
  <style scoped>
   .calendarDivChild{ 
      text-align: left;
      float: left;
      padding: 0px 2px;
    }
  input {
    border-top-style: hidden;
    border-right-style: hidden;
    border-left-style: hidden;
    border-bottom-style: hidden;
    background-color: #ffffff;
  }
  input[type="date"]::-webkit-calendar-picker-indicator {
    color: rgba(0, 0, 0, 0);
    opacity: 1;
    display: block;
    background: url(../assets/img/calendar.png) no-repeat;
    width: 20px;
    height: 20px;
    border-width: thin;
    cursor: pointer;
  }
  .no-outline:focus {
    outline: none;
  }
  
  .calenderCla{
    position: absolute;
      bottom: 4px;
      padding: 4px 2px 0px 2px;
      text-align: left;
      width: 80%;
      margin-left: 2px;
      outline: none;
      top: 3px;
      
      border-radius: 4px;
  }
  .calendarInline{
    margin-left: 11px;
    margin-bottom: 6px;
    background: #FDFFE2 !important;
    outline: none;
    min-width: 6.5rem;
    text-align: left;
    color: #2C63A4 !important;
  }
  .u-terrDate{
    margin-bottom: 6px;
    margin-left: 8px; 
    color: #2C63A4
  }
  .u-dateColSmall{
    margin-bottom: 7px;
      width: 75%;
      margin-left: 4px;
  }
  .u-tooltip:before{
    background:#cc0000;
  }
  .u-tooltip-1:before{
    background:#cc0000;
  }
  .u-tooltip.tip-top-buttons:after{
    border-color: #cc0000 transparent transparent transparent;
  }
  .u-tooltip.tip-bottom-buttons:after{
    border-color: transparent transparent #cc0000 transparent;
  }
  .u-tooltip.tip-bottom:after{
    border-color: transparent transparent #cc0000 transparent;
  }
  .u-tooltip-1.tip-bottom-1:after{
    border-color: transparent transparent #cc0000 transparent;
  }
  
  .u-tooltip.tip-bottom-search:after {
    border-color: transparent transparent #cc0000 transparent;
  }
  </style>