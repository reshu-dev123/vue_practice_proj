<template>
  <div v-if="displayHeader" class="u-row">
    <div class="u-col l12 m12 s12">
      <label  :class="[displayHeader.cssClass,'u-col l10 m10 s10']">{{ displayHeader.headerText }}</label>
    </div>
  </div>
  <div class="u-row">
    <form class="u-content-scroll" @submit.prevent="submitData">
      <!-- Sections -->
    <div class="u-row u-margin-bottom-40"> 
      <template v-for="section in addEditSections" :key="section.id">
        <div :class="[section.tableInfo.styles.cssClass]">
          <h2>{{ section.tableInfo.headerText }}</h2>
          <div class="u-row u-padding-xsmall u-card u-card-radius">
            <template v-for="(sectionFlds,sectionInd) in section.tableInfo[section.tableInfo.id]" :key="sectionInd">
              <UATableColLayout :tblHeaders="sectionFlds.headers[0]"
                :tableFields="sectionFlds.tableFields"
                @getDynamicValuesOnChange="bindValueToField"
                @toggleChanged="e=>handleAllStationChanged(e,section.id)"
                :fields="sectionFlds.tableFields" 
                :headerCssClass="section.tableInfo.styles.headerCssClass"
                />
            </template>
          </div>
        </div>
      </template>
    </div>
      <!-- Save Buttons -->
  <div class="u-row u-footer-fixed u-background-white u-border-top u-width-100">
    <footer class="u-row u-margin-10">
      <template v-for="(btn,btnIndex) in buttonList" :key="btnIndex">
          <UAButton
            :cssClass="btn.fieldsCssClass"
            :disabled="!isShowSaveButton()" >
           {{btn.label}}
          </UAButton>
        </template>
      </footer>
    </div>
    </form>
  </div>
</template>

<script>
import { mapActions, mapState,mapGetters } from 'vuex';
import UATableColLayout from './UATableColLayout.vue';
import UAButton from './UAButton.vue';

export default {
  name: 'UAUserManagement',
  components: {
    UATableColLayout,
    UAButton,
  },
  created(){
    this.addEditSections = JSON.parse(JSON.stringify(this.sections));
    this.rolePropertyBind3Case(this.currentRoleInfo.accessInfo);
  },
  mounted(){
    if(!this.isAdminEnabled && !this.isSuperUser){
      this.setAlertMessages({
        alertType: this.erMsg.errorType,
        alertMessages: [this.erMsg.text]
      })
    }
  },
  data() {
    return {
      addEditSections: [],
      selectedRoleInDropDown:'',
    }
  },
  computed: {
    ...mapGetters(['isSuperUser']),
    ...mapState({
      displayHeader: (state) => state.ovsiDefaultModule.displayHeader,
      erMsg: (state) => state.ovsiDefaultModule.applicationInfoDetails.errorMessageList.PERMISSION_DENIED,
      tokenResponse: state =>state.userModule.tokenResponse,
      roleInfoList: state =>state.userModule.roleInfoList,
      sections:  (state)=>state.ovsiDefaultModule.entityDisplayDetails.Layouts[0].InnerLayout.sections,
      buttonList: (state)=> state.ovsiDefaultModule.entityDisplayDetails.Layouts[0].InnerLayout.buttons,
      currentRoleInfo: (state) => state.userModule.currentRoleInfo,
      isAdminEnabled: state=>state.userModule.currentRoleInfo.accessInfo.adminstration.enabled, // admin by config
    })
  },
  methods: {
    ...mapActions(["updateData"]),
   bindValueToField({ selectedValue, currField }) { // dropdown bind role;
      if(currField.id == 'role_ad')
      this.selectedRoleInDropDown=selectedValue;
      this.addEditSections.forEach(section=>{
        section.tableInfo[section.tableInfo.id].forEach(tblInfo=>{
        tblInfo.tableFields.forEach(field=>{
          if(currField.onChangeFieldsToTrigger.includes(field.id)){ // find the target field to change
            this.roleInfoList.forEach(roleConfig=>{
              if(roleConfig.ad.toLowerCase() == selectedValue.toLowerCase()){
                field.model=roleConfig.accessInfo.role.role;
              this.rolePropertyBind3Case(roleConfig.accessInfo);
              }
            })
          }
        })
        })
      })

    },
    handleAllStationChanged({value,subField},sectionId){ // from toggle button
        this.addEditSections.forEach(section=>{
          section.tableInfo[section.tableInfo.id].forEach(tblInfo=>{
          tblInfo.tableFields.forEach((field,index)=>{
            if(subField.id == 'flight_Management_enabled'){ // if emmited from fltmgmt module toggle
              if(tblInfo.id == 'report'){
                field.attributes.disabled = !value;
              }
            }
            if(subField.id == 'all_station'){ 
              if(tblInfo.id == 'report' && field.id == 'all_stations_report'){
                field.attributes.disabled=!value;
              }
            }
            if(section.id == 'overSaleOverView'){
              if(subField.id == 'ovsl_enabled'){
                index!=0?field.attributes.disabled = !value:'';
              }
              if(subField.id == 'all_station_overvw' && field.id == 'stations'){
                field.checkedProps = ["Local Stations", "Hubs"];
                field.attributes.disabled=value;
              }
            }
            if(section.id == 'config_managment' && subField.id == 'config_enabled'){
              index!=0?field.attributes.disabled = !value:'';
            }
            if(section.id == 'adminstration' && subField.id == 'admin_enabled'){
              index!=0?field.attributes.disabled = !value:'';
            }
          })
        })
      }) 
    },
    isShowSaveButton(){
      if(this.selectedRoleInDropDown.toLowerCase() == this.currentRoleInfo.accessInfo.role.ad.toLowerCase())
        return false;
      if(this.isSuperUser )
        return true;
      if(this.isAdminEnabled && this.currentRoleInfo.accessInfo.adminstration.Permission == 'Edit'){
        let list= this.roleInfoList.filter(rc=>rc.priority!=1 && rc.accessInfo.role.ad.toLowerCase() == this.selectedRoleInDropDown.toLowerCase())
        return list.length !=0;
      }
      return false;

    },
    rolePropertyBind3Case(selectedAcessInfo){
        this.addEditSections.forEach(section => {
          section.tableInfo[section.tableInfo.id].forEach(tblInfo=>{
            tblInfo.tableFields.forEach((field,index) =>{
              this.bindModels(index,field,tblInfo,section,selectedAcessInfo[section.id],selectedAcessInfo)
            })
          })
        });
      
    },
    bindModels(index,field,tblInfo,section,obj,selectedAcessInfo){
      let value = obj[field.path];
      let isDisableField= !this.isShowSaveButton();
      // model binding  . . .
          if (field.fieldType == 'UACheckbox') {
            field.checkedProps = value
          }else {
            if (value != undefined) {
              field.model = value
              if(section.id == 'role' && field.id=='role_ad')
              this.selectedRoleInDropDown = value;
            }
          }
          // Field enable/disable
          if(!isDisableField){ // ENABLING
            field.attributes.disabled= false;
            if(tblInfo.id == 'report'){ // Conditions based on role config 
              field.attributes.disabled = !selectedAcessInfo.flight_Management.enabled;
            }
            if(section.id == 'overSaleOverView'){ // Conditions based on role config 
                index!=0?field.attributes.disabled = !selectedAcessInfo.overSaleOverView.enabled:'';
              if(field.id == 'stations' && selectedAcessInfo.overSaleOverView.allStation){
                field.checkedProps = ["Local Stations", "Hubs"];
                field.attributes.disabled=true;
              }
            }
            if(section.id == 'adminstration'){ // Conditions based on role config 
              index!=0?field.attributes.disabled = !selectedAcessInfo.adminstration.enabled:'';
            }
            if(section.id == 'config_managment'){ // Conditions based on role config
              index!=0?field.attributes.disabled = !selectedAcessInfo.config_managment.enabled:'';
            }
          }else{
            field.attributes.disabled= true;
          }
          // Enable based on role and priority
          if(section.id == 'role'){
              if(this.isSuperUser || (this.currentRoleInfo.accessInfo.adminstration.Permission == 'Edit' && this.isAdminEnabled))
              field.attributes.disabled= false;
            }
    },
    submitData(){
      let apiObj = {};
      this.addEditSections.forEach(sec=>{
         let secObj= {};
        sec.tableInfo[sec.tableInfo.id].forEach(tbleinfo2 =>{
         tbleinfo2.tableFields.forEach(fld=>secObj[fld.path]=fld.model)
        })
        apiObj[sec.id]=secObj;
      })
      this.updateData(apiObj);
    },
    genericHandler() {
    }
  }

}
</script>

<style>
.u-content-scroll{
  overflow-y: scroll;
  max-height: 72vh;
}
</style>