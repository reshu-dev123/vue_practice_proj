<template>
  <div>
    <table :id="id">
      <thead>
        <tr :class="[sections[0].hubsCard.tableHeaderFont ? 'u-tiny u-fnt-normal':'u-small']">
          <th v-for="(field, key) in fields" :key="key" :style="[field.headerStyle]">{{ field.label }}</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(item, index) in data" :key="index" style="font-size:12px;" :class="[sections[0].hubsCard.tableDataBold ? 'thin-hubs':'']">
          <td v-for="(field, fIndex) in fields" :key="fIndex+index" :style="[field.style]">
            <span v-if="field.type == 'cabin'">{{getCabinValues(item[field.path])}}</span>
            <!-- <UAButton v-if="field.type == 'button'" :class="['u-transparent']"><img :src="getImageUrl(field.icon)"/></UAButton> -->
            <div v-else-if="field.type == 'button'">
           <span>
             <template v-for="(action,actionIndex) in field.actions" :key="actionIndex">
                 <UAButton :id="field.id+'_'+item[field.path]" :class="action.cssClass" @click="genericHandler(action, item,index)"><img :src="getImageUrl(field.icon)"/></UAButton>
             </template>
           </span>
            </div>
            <span v-else >{{item[field.path]}}</span>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<script>
import { mapState, mapGetters, mapActions, mapMutations } from "vuex";
import UAButton from './UAButton.vue';
import { getImageUrl,getCombinedCabinValues} from '../helpers/utilities.js';
export default {
    name: 'UATable',
    props: ['fields', 'data', 'imgpath','id'],
    emits:["navigateScreen"],
    components: {
      UAButton
    },
    data() {
    return {
      isInProgess: '',


    };
  },
  computed: {
    ...mapState({
      sections: (state) => state.ovsiDefaultModule.entityDisplayDetails.Layouts[0].InnerLayout.sections,
    }),
  },
  methods: {
  ...mapMutations(["setSelectedMenuId"]),
    getImageUrl(params){
      return getImageUrl(params);
    },
    getCabinValues(cabins){
      return getCombinedCabinValues(cabins);
    },
  async genericHandler(actionBtnInfo, data,dataIndex){
        let {events} = actionBtnInfo;
        this.selectedDataIndex = dataIndex;
        if(events.name == "navigateToOtherScreen"){
            this.$emit('navigateScreen', actionBtnInfo, data);
            this.setSelectedMenuId(actionBtnInfo.navigationInfo.navigateToID);
        }
    },
  },

}
</script>

<style>
table,
tr {
  border: 1px solid #ddd;
  text-align: left;
}

th {
  background-color: #f0f0f0 !important;
}

table {
  border-collapse: collapse;
  width: 100%;
}

th,
td {
  padding: 4px;
}

svg {
  color: blue;
}


.volunteersAdded {
  background-color: goldenrod;
}

.finalised {
  background-color: green;
}

button {
  display: inline-block;
  padding: 5px 15px;
  font-size: 10px;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #000;
  background-color: #f0f0f0;
  border: none;
  border-radius: 15px;
  font-family: 'Times New Roman', Times, serif;
}
</style>