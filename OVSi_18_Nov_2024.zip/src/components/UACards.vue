<template>
  <div class="card u-white u-text-nyblue" v-for="item in data" :key="item.id">
    <div class="u-padding-8">
      <label class="u-flex u-align-center">
        <a v-if="item.icon" class="u-padding-right-4"><img :src="getImageUrl(item.icon)" /></a><a>{{ item.label }}</a>
      </label>
    </div>
    <div :class="['u-row u-center u-contentCrdScroll']">
      <template v-if="item?.handleMultipleCurrencies" >
            <template v-for="(currData, cKey) in getMultipleCurrencyData(item)" :key="cKey">
              <div :class="['u-col u-flex']" > 
                <label :class="['u-block u-break-content u-fnt-500',getDynamicFontSize(currData)]"> 
                  {{ combineFields(item, currData) }}
                </label>
              </div>
            </template>
      </template>
      <label v-else class="u-jumbo lf mf sf u-break-content u-center u-fnt-500">{{getFieldValue(item) }} </label>
    </div>
  </div>
</template>
<script>
import { getImageUrl,getCommaSeperatedValue } from '../helpers/utilities.js';
import { mapGetters } from "vuex";
export default {
  name: 'UACards',
  props: ['data','crdData'],
  computed: {
  ...mapGetters (["getJPathValue"]),
  },
  methods: {
    getFieldValue(field){
      let fldValue = this.getJPathValue(field.path,this.crdData) || field.defaultValue;
      return field.isCommaSeperated ? getCommaSeperatedValue(fldValue) : fldValue;
    },
    getDynamicFontSize(data) {
      //let dtSz = data.length;
      let amount = data.amount;
      let intAmnt = parseInt(amount);
      let floatAmnt = Number.isInteger(amount) ? amount : parseFloat(amount).toFixed(2);
      let dtSz = (data.currencyCode.length + intAmnt.toString().length + (Number.isInteger(amount) ? 0 : floatAmnt.toString().split('.')[1].length))
      if (dtSz > 4 && dtSz <13)
        return 'u-fnt-size-40';
      if (dtSz >= 13 && dtSz <=16)
        return 'u-xxlarge';
      if (dtSz > 16 && dtSz <= 19)
        return 'fnt-size-30';
      if (dtSz > 16 && dtSz <= 19)
        return 'fnt-size-30';
      if (dtSz > 19)
        return 'u-xlarge'
      return 'u-jumbo lf mf sf'
    },
    getMultipleCurrencyData(field){
      let currData={}
      let defaultCurrValue=[]
      if(this.crdData){
          if(field.combineStructure){
            field.combineStructure.forEach(strctr => {
              currData[strctr.id] =strctr.defaultValue;
            })
              defaultCurrValue.push(currData)
          }
          if(field.name=='ETC'){
            currData = this.crdData.totalEtc?.totalEtc?.length>0 ? this.crdData.totalEtc?.totalEtc:defaultCurrValue
          }
          if(field.name=='Drafts'){
            currData = this.crdData.totalDraft?.totalDraft?.length>0 ? this.crdData.totalDraft?.totalDraft:defaultCurrValue
          } 
          else{
            currData;
          }
        } 
        return currData;
    },
    combineFields(field,item){
      let FloatObj = {};
      let fieldValue ='';
      if(field.isFloatValue){
        field.combinepath.forEach(path=>{
          if(path == field.combinepath[0]){
            let amnt = this.getJPathValue(path,item) || field.defaultValue;          
            let amntValue = Number.isInteger(amnt) ? amnt : parseFloat(parseFloat(amnt).toFixed(2));
            FloatObj["amount"] = amntValue;
          } else {
            let currCode = this.getJPathValue(path,item)
            FloatObj["currencyCode"] =  currCode;
          }
        })
         fieldValue = field.combinepath.map(path=>{
          return field.isCommaSeperated ? getCommaSeperatedValue(this.getJPathValue(path,FloatObj)) : this.getJPathValue(path,FloatObj);
        }).join(field.combinePrefix||'').toString();
      } else{
        fieldValue = field.combinepath.map(path=> {
          return field.isCommaSeperated ? getCommaSeperatedValue(this.getJPathValue(path,item)) : this.getJPathValue(path,item);
        }).join(field.combinePrefix||'').toString();
      }
      if(fieldValue.trim().length === 0){
       return field.defaultValue;
      }
      return fieldValue;
    },
    getImageUrl(params) {
      return getImageUrl(params);
    }
  }
}

</script>

<style  scoped>
.card {
  width: 100%;
  height: 160px;
  /* padding: 15px; */
  border-radius: 5px;
  /* border-top:5px solid rgb(27, 15, 42); */
  box-shadow: 0 4px 4px 0px grey;
  border-top: 7px solid #0c2340 !important;
  display: inline-block;
  margin-top: -2px;
}


.u-contentCrdScroll{
  overflow-y: scroll;
  max-height: 74%;
}
</style>