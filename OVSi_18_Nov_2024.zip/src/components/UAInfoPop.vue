<template>
  <div class="u-col l12 m12 s12 u-small u-left u-border">
    <div :class="['u-row', infoCsslass]">
      <div :class="[headerCSS]">   {{ Header }}  </div>
      <div v-if="secondaryHeader" :class="[secondaryHeaderCSS]">
      {{ secondaryHeader }} {{ overSoldCount }}
      </div>
    </div>
    <table>
      <thead>
        <tr>
          <th :class="[tableCss]" v-for="(rlabel, rkey) in tableHeader.headerValues" :key="rkey"><span>{{ rlabel }}</span></th>
        </tr>
      </thead>
      <tbody>
        <!-- <tr v-for="(item,index) in tableData" :key="index"> -->
        <tr v-for="(field, index) in tableFields" :key="index+'f'">
          <td v-for="(subField, index) in field.subFields" :key="index+'s'">
            
            <template v-if="subField.type == 'concat'">
               <template v-for="(bookField) in getConcat(subField,index)" :key="bookField">
                  <label>{{bookField.value}}</label>
                  <label v-if="bookField.dependecyValue" >(<span :class="bookField.classes">{{bookField.dependecyValue}}</span>)</label>
               </template>
            </template> 
            <template v-else-if="subField.path">
            {{getTableDataForField(subField)}}
            </template>
            <template v-else>
           {{subField.label}}
            </template>
          </td>
        </tr>
        <!-- </tr> -->
      </tbody>
    </table>
  </div>
</template>

<script>
import UAButton from "./UAButton.vue";
import UAOSLCard from './UAOSLCard.vue';
import UATab from "./UATab.vue";
import {  mapState, mapGetters } from 'vuex';
import UACards from "./UACards.vue";
export default {
  name: "UAInfoPop",
  data() {
    return {
      overSoldCount: 0,
      jCnt:0,
      yCnt:0,
      isDisabled: false,
    };
  },
  props: ["infoCsslass", 'tableHeader', "tableFields", "tableData", "Header", "secondaryHeader", "headerCSS","secondaryHeaderCSS", "tableCss"],

  components: {
    UAButton,
    UAOSLCard,
    UATab,
        UACards
  },
  computed: {
    ...mapState({
    }),
    ...mapGetters(["getOVSIFields", "getJPathValue", "getOVSIEntityId"]),
  },
  methods: {
    extractData(item, field) {
      return item[field.path]
    },
    getConcat(field,index){
      this.overSoldCount = 0;
      let value = this.getTableDataForField(field);
      if(!value && field.defaultValue){return [{value:field.defaultValue.toString()}]}
      let dependecyField= this.tableFields[field.dependencyIndex].subFields[index];
           let dependValue= this.getTableDataForField(dependecyField);
            let result = parseInt(dependValue) -parseInt(value);
      if(!result || result == 0){return [{value}];};
      if(field?.cabin === 'J'){
        this.jCnt =  result;
      }else if(field?.cabin === 'Y'){
        this.yCnt =  result;
      } 
      this.overSoldCount = parseInt(this.jCnt) + parseInt(this.yCnt);
      if(this.overSoldCount > 0){
        this.overSoldCount = 0
      }else{
        this.overSoldCount = Math.abs(this.overSoldCount)
      }
    return  [{
         value,
        "dependecyValue": result<0?result:'+'+result,
        "classes": result<0?field.negativeClass:field.positiveClass
      }]
    },
    getTableDataForField(tblFld) {
      let fieldData = "";
      if (this.tableData.length > 0) {
        if (
          this.tableHeader?.isCabinWiseData &&
          tblFld.cabin !== undefined &&
          tblFld.cabin !== ""
        ) {
          //for cabin wise data

          
            fieldData = this.getJPathValue(
              tblFld.path,
              this.tableData[0][tblFld.cabin]
            );
        } else {
            fieldData = this.getJPathValue(tblFld.path, this.tableData[0]);
        }
      }
      if(fieldData == undefined && tblFld.defaultValue){return tblFld.defaultValue.toString();}
      return fieldData;
    },
  },
};
</script>

<style scoped>
/* Style the tab */
.tab {
  overflow: hidden;
  border: 1px solid #ccc;
  background-color: #f1f1f1;
}

/* Style the buttons inside the tab */
.tab button {
  background-color: inherit;
  float: left;
  border: none;
  outline: none;
  cursor: pointer;
  padding: 14px 16px;
  transition: 0.3s;
  font-size: 17px;
}

/* Change background color of buttons on hover */
.tab button:hover {
  background-color: #ddd;
}

.row {
  display: flex;
}

/* Create an active/current tablink class */
.tab button.active {
  background-color: #ccc;
}

.tooltip {
  position: relative;
  display: block;
  margin: auto;
  font-size: 1.2em;
  background-color: #1f74e1;
  border: none;
  cursor: pointer;
  color: #fff;
  text-align: center;
  padding: 0.8em 2em;
}

.tooltip-bottom:before {
  font-size: 0.8rem;
  position: absolute;
  width: 150%;
  background-color: #000000;
  padding: 0.8em 1em;
}

.tooltip-content {
  display: none;
  top: 100%;
  left: 0;
  padding: 5px;
  position: absolute;
  background-color: #f9f9f9;
  border: 1px solid #ccc;
  padding: 10px;
  z-index: 1;
}

.tooltip-content.active {
  display: block;
}

.tooltip:hover .tooltip-content {
  display: block;
}

/* Style the tab content */
.tooltip-container {
  position: relative;
}

.tooltip-trigger::before {
  content: attr(data-tooltip);
  position: absolute;
  background-color: #333;
  color: #fff;
  padding: 5px;
  border-radius: 3px;
  display: none;
  white-space: nowrap;
  z-index: 1;
  bottom: 100%;
  left: 50%;
  transform: translateX(-50%);
}

.tooltip-trigger:hover::before {
  display: block;
}

.tabcontent {
  display: none;
  padding: 6px 12px;
  border: 1px solid #ccc;
  border-top: none;
}

th,
td {
    padding: 10px;
}
</style>
