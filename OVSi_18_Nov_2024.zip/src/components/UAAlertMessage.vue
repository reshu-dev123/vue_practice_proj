<template>
  <div :class="alertCssClass" v-if="setAlertMessage()">
    <div class="u-col l11 m11 s11 u-padding-small">
      <ul class="u-ul">
        <li
          class="u-border-0"
          style="padding: 0px; white-space: break-spaces"
          v-for="(alert, index) in alertMessages"
          :key="index"
        >
          {{ alert }}
        </li>
      </ul>
    </div>
    <div class="u-col l1 m1 s1">
      <button
        type="button"
        class="close u-button u-xlarge u-right"
        style="
          background-color: transparent !important;
          padding: 0px !important;
          height: 2rem;
          margin-top: -5px;
        "
        @click="clearAlertMessage()"
      >
        &times;
      </button>
    </div>
  </div>
</template>

<script>
// Import statements
import { mapState, mapActions } from "vuex";

export default {
  name: "UAAlertMessage",
  computed: mapState({
    alertType: (state) => state.alertMessage.alertType,
    alertMessages: (state) => state.alertMessage.alertMessages,
    appInfo: (state)=> state.ovsiDefaultModule.applicationInfoDetails,
    alertCssClass(state) {
      switch (state.alertMessage.alertType.toLowerCase()) {
        case "error":
          return "errorAlert u-padding-small u-row u-margin u-card u-center u-text-white u-round";
        case "warning":
          return "warningAlert u-padding-small u-row u-margin u-card u-center u-text-white u-round";
        case "success":
          return "successAlert u-padding-small u-row u-margin u-card u-center u-text-white u-round";
        case "information":
          return "infoAlert u-padding-small u-row u-margin u-card u-center u-text-white u-round";
        default:
          return "u-padding-small u-row u-margin u-card u-center u-text-white u-round";
      }
    },
  }),
  emits:['scrollTop'],
  methods: { 
    ...mapActions(["clearAlertMessages"]),// Azh - call action directly   
    clearAlertMessage() {
      this.clearAlertMessages();
    },
    //Azh - Alert to disappear after 10s
    setAlertMessage() {
      if(this.alertMessages.length > 0){
        if(this.alertType=="success"){
          setTimeout(() => {this.clearAlertMessages()}, 1000*((this.appInfo?.alertMessage?.timedOut) || 5))
        }
        this.$emit("scrollTop");
        return true;
      }else{
         false;
      }
    },
  },
};
</script>

<style lang="scss">
.errorAlert {
  background-color: #cc0000;
}
.warningAlert {
  background-color: #ff8800;
}
.successAlert {
  background-color: #007e33;
}
.infoAlert {
  background-color: #0099cc;
}
</style>
