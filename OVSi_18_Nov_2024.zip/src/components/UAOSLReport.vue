<template>
  <div class="u-col l12 m12 s12">
  <label v-if="displayHeader" :class="['u-col l10 m10 s10',displayHeader.cssClass]">{{ getReportHeader }}</label>
  </div>
  <div v-if="isLoading" class="u-row u-center u-bold">Loading . . .</div>
  <div v-if="!searchOVSIData && !isLoading" class="u-row u-center u-bold">No Record Found</div>
  <template v-if="searchOVSIData && isSHowTemp">
    <div class="u-row u-padding">
      <div class="u-col l12 m12 s12 u-border u-white">
        <template v-for="(tblDetail, tblIndex) in tableDetails" :key="tblIndex">
          <div :class="tblDetail.tableClasses">
            <UAOvsiTableColLayout :tblHeaders="tblDetail[tblDetail.id][0].headers[0]"
              :tableData="extractData(searchOVSIData, tblDetail)" :tableFields="tblDetail[tblDetail.id][0].tableFields"
              :sectionHeader="tblDetail[tblDetail.id][0].sectionHeader" :contentScroll="tblDetail.contentScroll && 'u-content-tbl-scroll u-margin-left'" />
          </div>
        </template>
      </div>
    </div>
    <div v-if="isAllPassengerList" class="u-row u-overlay" style="display:block">
      <div class="u-modal-container" style="display:block;left:40% !important;width:60% !important" ref="allPassengerMdoalRef" @mouseleave="mouseLeaveAllPsnrModal()" @mouseover="mouseOverAllPsnrModal()">
        <form class="u-modal-add-content u-modCont-ht" style="padding-bottom:3px">
          <div class="u-row u-th-fixed u-pad-left-1">
            <div class="u-col l12 m12 s12">
            <label class="u-col l11 m11 s11 u-large u-fnt-cst-1 u-panel-xsmall"> All Passenger List </label>
            <div class="u-col l1 m1 s1">
              <UAButton
                @click="closeIsAllPassengerList()"
                cssClass=" u-transparent u-primary-inv-border u-pad-0 u-right u-pointer"
              >
              <img src="@/assets/img/close_grey.png" />
              </UAButton>
          </div>
          </div>
          <label class="u-row u-ls-ws u-medium u-fnt-cst-1 u-left">{{ getReportHeader }}</label>
          <div class="u-row u-padding-bottom-7">
            <UASearchKeyword @setSearchText="setSelectedSearchPsnrText" :passengerList="getAllAddPngrSrchList" searchIcon="true"
            :cssClass="['u-col l4 m8 s12 u-padding-top-4 u-padding-bottom-4  u-fnt-itlc']" srchCssClass="u-small lf mf sf"
            placeholder="Search by customer name or PNR" ref="searchKeyCom" id="passenger_search" />
          </div>
          </div>
          <div class="u-row contentScroll u-position-relative" style="max-height:80% !important;">
              <!-- <UARadioButton :selectOptions="getPassengerLists" :cssClass="['u-col l12 m12 s12 u-margin-bottom']" 
              v-model="selectedOption" @radioOptionSelectedfromChild="handleSelectedRadioOption"/> -->
              <UATableDisplay ref="refTableDisplay" tableCssClass="u-padding-0-top-right"
                cardRowCss="u-white" :tableData="getPassengerLists" :tableFields="getOVSIFields" hideScroll=true
                @radioOptionSelectedfromChild="handleSelectedRadioOption"
              /> 
          </div>
        </form>
        <div class="u-row u-padding-7 u-margin-right u-footer-fixed u-border-top u-wd-60per u-background-white">
          <template v-for="(hField, hKey) in modalButtons[0].addListButtons" :key="hKey">
            <component
              :is="hField.fieldType"
              @click="genericHandler(hField.events,selectedOption)"
              :cssClass="hField.fieldsCssClass"
              :id="hField.id"
              :disabled="(hField?.isDisableBtn && selectedOption.length == 0) || (hField?.isDisableSelectedBtn && selectedOption.length != 0)"
              >
              {{ hField.name }}
            </component>
          </template>
        </div>
      </div>
    </div>
    <div class="u-row u-padding">
      <div class="u-row u-section-1">
        <h4>Customer Lists</h4>
        <UASearchKeyword @setSearchText="setSearchText" :passengerList="getAllPassengerList" searchIcon="true"
         id="customer_search" :cssClass="['u-col l3 m4 s12 u-fnt-itlc']" placeholder="Search by customer name or PNR" />
      </div>
      <UATab :countArray="[processedResultCnt, updowngradeResultCnt , filterMustRide.length ]" :tabFields="tabs"
        @selectedTab="handleSelectTab" :selectedTabInd="selectedTabIndex" />
      <div v-if="selectedTabIndex == 0" style="height: 1000px;line-height: normal;" class="u-row">
        <div class="u-row u-margin-small u-bg-1 u-border u-border-4 u-round-large">
          <div class="u-col l10 m9 s6">
            <UASearchData :inlineFilterConfig="tabs[0]"/>
          </div>
          <div class="u-col l2 m3 s6 u-border-left u-section-1 u-pad-0 u-display-flex-space u-padding-top">
            <UAButton @click="enableIsAllPassengerList()" id="processed_add_customer"
              :cssClass="['u-button u-round u-primary-1-pur u-right u-white-space u-medium lf mf sf',(getStatusValue() == 'STOPPED') ? 'u-disabled' : '']">
              Add Customer
            </UAButton> 
            <!-- Add Processed passenger modal -->
            <UAModalDisplay v-if="(addPopup || manualAddPop)" @close="ClosePopup()" :subHeader="getReportHeader"
              @add="addEditPassenger" :tableData="addPopup && getSelectedPasngr" :modalTable="tabs[0].addTableFields[0].modalTemp"
              @addNewFieldRow="addCustomerNewFieldRows"
              @deleteNewFieldRow="deleteCustomerNewFieldRows"
              @bindDependentValuesOnCHange="setDependentValuesOnCHange($event, tabs[0].addTableFields[0].modalTemp)"
              :footerFields="modalButtons[0].addButtons" />
          </div>
        </div>
        <div class="u-row">
          <div class="u-row u-margin-bottom u-padding-7">
            <div class="u-col l12 u-msmall lf mf sf u-border-bottom u-margin-left u-margin-right u-section-1">
              <label class="u-col l11 u-section-1 u-show-inline-block" v-if="inVol">Involuntary ({{ filterRecords.filter(p =>
                p.passenger.volunteerStatus == 'I').length }})</label>
               <UAChevron v-if="filterRecords.filter(p => p.passenger.volunteerStatus == 'I').length > 0"
                :toggle="isShowFRowCards" @toggleArrow="toggleChevron('PI'+selectedTabIndex)"/>
            </div>
            <div class="u-row u-margin-left" v-if="isShowFRowCards">
              <label class="u-medium lf mf sf"
                v-if="filterRecords.filter(p => p.passenger.volunteerStatus == 'I').length == 0">
                No Involuntary customers were processed for this flight
              </label>
              <template v-for="(psngr, passIndex) in filterRecords" :key="passIndex">
                          <div class="u-col l3 m6 s12" v-if="psngr.passenger.volunteerStatus == 'I'">
                  <UAOSLCard :cssClass="tabs[0].cardsConfig[0].cardTemp.cssClass" :cardCssClass="['u-round-10px']"
                    :labelCss="tabs[0].cardsConfig[0].cardTemp.textCssclass" :cardTable="tabs[0].cardsConfig[0].cardTemp"
                    :label="getFullName(psngr)" secondaryLabel="Invol" :tableData="[getPssngrCardData(psngr)]"
                    ref="uaoslcard" details=true @enableEdit="enableEdit('PI' + passIndex,true,getPssngrCardData(psngr))" 
                    @deletePsngr="enableDelete('PI' + passIndex)"  @viewDetails="enableViewPopup('PI' + passIndex,true,getPssngrCardData(psngr))"/>
                  <UAModalDisplay v-if="(isViewDetails || editPopup) && selectedModal == 'PI' + passIndex" @close="CloseEditPopup()"
                    @update="addEditPassenger" :modalTable="tabs[0].editTableFields[0].modalTemp"
                    @addNewFieldRow="addNewFieldRows"
                    @deleteNewFieldRow="deleteNewFieldRows" @viewEditEnable="enableEdit('PI' + passIndex,true,getPssngrCardData(psngr),true)"
                    @bindDependentValuesOnCHange="setDependentValuesOnCHange($event, tabs[0].editTableFields[0].modalTemp)"
                    :footerFields="isViewDetails ? modalButtons[0].viewButtons : modalButtons[0].editButtons" :subHeader="getReportHeader"
                    :tableData="[getPssngrCardData(psngr)]" />
                   <UAOSLCardConfirmation v-if="oslDeletePop && selectedModal == 'PI' + passIndex" :cssClass="tabs[0].cardsConfig[0].cardTemp.cssClass" :cardCssClass="['u-round-10px']"
                    :labelCss="tabs[0].cardsConfig[0].cardTemp.textCssclass" :cardTable="tabs[0].cardsConfig[0].cardTemp"
                    :label="getFullName(psngr)" secondaryLabel="Invol" :tableData="[getPssngrCardData(psngr)]" :ConfirmActionMsg="displayHeader.deleteConfimMsg" :ConfirmActionTitle = "displayHeader.ConfimTitle"
                    ref="uaoslcard" details=true :CardBtnFields="modalButtons[0].deleteButtons" @delete="deletePassenger(psngr,'PI' + passIndex)" @close="CloseDeletePopup()"/> 
                </div>
              </template>
            </div>
          </div>
          <div class="u-row u-margin-bottom u-padding-7">
            <div class="u-col l12 u-msmall lf mf sf u-border-bottom u-margin-left u-margin-right u-section-1">
              <label class="u-col l11 u-section-1 u-show-inline-block" v-if="Vol">Voluntary ({{ filterRecords.filter(p =>
                p.passenger.volunteerStatus ==
                'V').length }})</label>
               <UAChevron v-if="filterRecords.filter(p => p.passenger.volunteerStatus == 'V').length > 0"  
                :toggle="isShowSRowCards"  @toggleArrow="toggleChevron('PV'+selectedTabIndex)"/>
            </div>
            <div class="u-row u-margin-left" v-if="isShowSRowCards">
              <label class="u-medium lf mf sf"
                v-if="filterRecords.filter(p => p.passenger.volunteerStatus == 'V').length == 0">
                No Voluntary customers were processed for this flight
              </label>
              <template v-for="(psngr, passIndex) in filterRecords" :key="passIndex">
                <div class="u-col l3 m6 s12" v-if="psngr.passenger.volunteerStatus == 'V'">
                  <UAOSLCard :cssClass="tabs[0].cardsConfig[0].cardTemp.cssClass" :cardCssClass="['u-round-10px']"
                    :labelCss="tabs[0].cardsConfig[0].cardTemp.textCssclass" :cardTable="tabs[0].cardsConfig[0].cardTemp"
                    :label="getFullName(psngr)" secondaryLabel="Vol" :tableData="[getPssngrCardData(psngr)]"
                    ref="uaoslcard" details=true @enableEdit="enableEdit('PV' + passIndex,true,getPssngrCardData(psngr))" 
                     @deletePsngr="enableDelete('PV' + passIndex)"  @viewDetails="enableViewPopup('PV' + passIndex,true,getPssngrCardData(psngr))"/>
                  <UAModalDisplay v-if="(isViewDetails || editPopup) && selectedModal == 'PV' + passIndex" @close="CloseEditPopup()"
                    @update="addEditPassenger" :modalTable="tabs[0].editTableFields[0].modalTemp"
                    @addNewFieldRow="addNewFieldRows"
                    @deleteNewFieldRow="deleteNewFieldRows" @viewEditEnable="enableEdit('PV' + passIndex,true,getPssngrCardData(psngr),true)"
                    @bindDependentValuesOnCHange="setDependentValuesOnCHange($event, tabs[0].editTableFields[0].modalTemp)"
                    :footerFields="isViewDetails ? modalButtons[0].viewButtons : modalButtons[0].editButtons" :subHeader="getReportHeader"
                    :tableData="[getPssngrCardData(psngr)]" />
                    <UAOSLCardConfirmation v-if="oslDeletePop && selectedModal == 'PV' + passIndex" :cssClass="tabs[0].cardsConfig[0].cardTemp.cssClass" :cardCssClass="['u-round-10px']"
                    :labelCss="tabs[0].cardsConfig[0].cardTemp.textCssclass" :cardTable="tabs[0].cardsConfig[0].cardTemp"
                    :label="getFullName(psngr)" secondaryLabel="Vol" :tableData="[getPssngrCardData(psngr)]" :ConfirmActionMsg="displayHeader.deleteConfimMsg" :ConfirmActionTitle = "displayHeader.ConfimTitle"
                    ref="uaoslcard" details=true :CardBtnFields="modalButtons[0].deleteButtons" @delete="deletePassenger(psngr,'PV' + passIndex)" @close="CloseDeletePopup()"/> 
                </div>
              </template>
            </div>
          </div>
        </div>
      </div>

      <div v-if="selectedTabIndex == 1" style="height: 1000px;line-height: normal;" class="u-row">
        <div class="u-row u-margin-small u-bg-1 u-border u-border-4 u-round-large">
          <div class="u-col l10 m9 s8">
            <UASearchData :inlineFilterConfig="tabs[1]"  />
          </div>
          <div class="u-col l2 m3 s4  u-section-1 u-pad-0 u-display-flex-space u-padding-top">
            <UAButton @click="enableIsAllPassengerList()" id="upDowngrade_add_customer"
              :cssClass="['u-button u-round u-primary-1-pur u-right u-white-space u-medium lf sf mf',(getStatusValue() == 'STOPPED') ? 'u-disabled' : '']">
              Add Customer
            </UAButton>
            <!-- Add Upgrade/Downgrade passenger modal -->
            <UAModalDisplay v-if="(addPopup || manualAddPop)" @close="ClosePopup()" 
            :tableData="addPopup && getSelectedPasngr"
              @add="addEditPassenger" :subHeader="getReportHeader" :modalTable="tabs[1].addTableFields[0].modalTemp"
              @addNewFieldRow="addCustomerNewFieldRows"
              @deleteNewFieldRow="deleteCustomerNewFieldRows"
              @bindDependentValuesOnCHange="setDependentValuesOnCHange($event, tabs[1].addTableFields[0].modalTemp)"
              :footerFields="modalButtons[0].addButtons" />
          </div>
        </div>
        <div class="u-row">
          <div class="u-row u-margin-bottom u-padding-7">
            <div class="u-col l12 u-msmall lf mf sf u-border-bottom u-margin-left u-margin-right  u-section-1">
              <label class="u-col l11 u-section-1 u-show-inline-block">Downgrade ({{ filterUpgradeDownGrade?.filter(psngr => {
                return psngr.passenger.deniedBoardingCode == 'B';
              }).length }})</label>
               <UAChevron v-if="filterUpgradeDownGrade?.filter(psngr => psngr.passenger.deniedBoardingCode == 'B').length > 0"
                :toggle="isShowFRowCards" @toggleArrow="toggleChevron('PI'+selectedTabIndex)"/>
            </div>
            <div class="u-row u-margin-left" v-if="isShowFRowCards">
              <label class="u-medium lf mf sf"
                v-if="filterUpgradeDownGrade?.filter(psngr => psngr.passenger.deniedBoardingCode == 'B').length == 0">
                No Downgrade customers found for this flight
              </label>
              <template v-for="(psngr, passIndex) in filterUpgradeDownGrade" :key="passIndex">
                <div class="u-col l3 m6 s12" v-if="psngr.passenger.deniedBoardingCode == 'B'">
                  <UAOSLCard :cssClass="tabs[1].cardsConfig[0].cardTemp.cssClass" :cardCssClass="['u-round-10px']"
                    :labelCss="tabs[1].cardsConfig[0].cardTemp.textCssclass" :label="getFullName(psngr)"
                    :secondaryLabel="psngr.passenger.volunteerStatus== 'I'?'Invol':'Vol'"
                    :tableData="[getPssngrCardData(psngr)]" details=true @enableEdit="enableEdit('PV' + passIndex,true,getPssngrCardData(psngr))"
                    :cardTable="tabs[1].cardsConfig[0].cardTemp"  @deletePsngr="enableDelete('PV' + passIndex)" @viewDetails="enableViewPopup('PV' + passIndex,true,getPssngrCardData(psngr))" />
                </div>
                <UAModalDisplay v-if="(isViewDetails || editPopup) && selectedModal == 'PV' + passIndex" @close="CloseEditPopup()"
                  :modalTable="tabs[1].editTableFields[0].modalTemp" :footerFields="isViewDetails ? modalButtons[0].viewButtons : modalButtons[0].editButtons"
                  :tableData="[getPssngrCardData(psngr)]" @update="addEditPassenger"
                  @addNewFieldRow="addNewFieldRows"
                  @deleteNewFieldRow="deleteNewFieldRows" @viewEditEnable="enableEdit('PV' + passIndex,true,getPssngrCardData(psngr),true)"
                  @bindDependentValuesOnCHange="setDependentValuesOnCHange($event, tabs[1].editTableFields[0].modalTemp)"
                  :subHeader="getReportHeader" />
                  <UAOSLCardConfirmation v-if="oslDeletePop && selectedModal == 'PV' + passIndex" :cssClass="tabs[1].cardsConfig[0].cardTemp.cssClass" :cardCssClass="['u-round-10px']"
                  :labelCss="tabs[1].cardsConfig[0].cardTemp.textCssclass" :cardTable="tabs[1].cardsConfig[0].cardTemp"
                  :label="getFullName(psngr)"  :tableData="[getPssngrCardData(psngr)]"
                  :secondaryLabel="psngr.passenger.volunteerStatus== 'I'?'Invol':'Vol'"
                  ref="uaoslcard" details=true :CardBtnFields="modalButtons[0].deleteButtons" :ConfirmActionMsg="displayHeader.deleteConfimMsg" :ConfirmActionTitle = "displayHeader.ConfimTitle"
                  @delete="deletePassenger(psngr,'PV' + passIndex)" @close="CloseDeletePopup()"/> 

              </template>
            </div>
          </div>
          <div class="u-row u-margin-bottom u-padding-7">
            <div class="u-col l12 u-msmall lf mf sf u-border-bottom u-margin-left u-margin-right u-section-1">
              <label class="u-col l11 u-section-1 u-show-inline-block">Upgrade ({{ filterUpgradeDownGrade?.filter(psngr => {
                return psngr.passenger.deniedBoardingCode == 'A';
              }).length }})</label>
               <UAChevron v-if="filterUpgradeDownGrade?.filter(psngr => psngr.passenger.deniedBoardingCode == 'A').length > 0"
                :toggle="isShowSRowCards" @toggleArrow="toggleChevron('PV'+selectedTabIndex)"/>
            </div>
            <div class="u-row u-margin-left" v-if="isShowSRowCards">
              <label class="u-medium lf mf sf"
                v-if="filterUpgradeDownGrade?.filter(psngr => psngr.passenger.deniedBoardingCode == 'A').length == 0">
                No Upgrade customers found for this flight
              </label>
              <template v-for="(psngr, passIndex) in filterUpgradeDownGrade" :key="passIndex">
                <div class="u-col l3 m6 s12" v-if="psngr.passenger.deniedBoardingCode == 'A'">
                  <UAOSLCard :cssClass="tabs[1].cardsConfig[0].cardTemp.cssClass" cardCssClass="u-round-10px"
                    :labelCss="tabs[1].cardsConfig[0].cardTemp.textCssclass" :label="getFullName(psngr)"
                    :secondaryLabel="psngr.passenger.volunteerStatus== 'I'?'Invol':'Vol'"
                    :tableData="[getPssngrCardData(psngr)]" details=true @enableEdit="enableEdit('PI' + passIndex,true,getPssngrCardData(psngr))"
                    :cardTable="tabs[1].cardsConfig[0].cardTemp" @deletePsngr="enableDelete('PI' + passIndex)"  @viewDetails="enableViewPopup('PI' + passIndex,true,getPssngrCardData(psngr))" />
                </div>
                <UAModalDisplay v-if="(isViewDetails || editPopup) && selectedModal == 'PI' + passIndex" @close="CloseEditPopup()"
                  :modalTable="tabs[1].editTableFields[0].modalTemp" :footerFields="isViewDetails ? modalButtons[0].viewButtons : modalButtons[0].editButtons"
                  :tableData="[getPssngrCardData(psngr)]" @update="addEditPassenger"
                  @addNewFieldRow="addNewFieldRows"
                  @deleteNewFieldRow="deleteNewFieldRows" @viewEditEnable="enableEdit('PI' + passIndex,true,getPssngrCardData(psngr),true)"
                  @bindDependentValuesOnCHange="setDependentValuesOnCHange($event, tabs[1].editTableFields[0].modalTemp)"
                  :subHeader="getReportHeader" />
                  <UAOSLCardConfirmation v-if="oslDeletePop && selectedModal == 'PI' + passIndex" :cssClass="tabs[1].cardsConfig[0].cardTemp.cssClass" :cardCssClass="['u-round-10px']"
                  :labelCss="tabs[1].cardsConfig[0].cardTemp.textCssclass" :cardTable="tabs[1].cardsConfig[0].cardTemp"
                  :label="getFullName(psngr)"  :tableData="[getPssngrCardData(psngr)]"
                  :secondaryLabel="psngr.passenger.volunteerStatus== 'I'?'Invol':'Vol'"
                  ref="uaoslcard" details=true :CardBtnFields="modalButtons[0].deleteButtons" :ConfirmActionMsg="displayHeader.deleteConfimMsg" :ConfirmActionTitle = "displayHeader.ConfimTitle"
                  @delete="deletePassenger(psngr,'PI' + passIndex)" @close="CloseDeletePopup()"/> 
              </template>

            </div>
          </div>
        </div>
      </div>

      <div v-if="selectedTabIndex == 2" style="height: 1000px;line-height: normal;" class="u-row">
        <div class="u-row u-margin-small u-bg-1 u-border u-border-4 u-round-large">
          <div class="u-col l10 m9 s8">
            <UASearchData :inlineFilterConfig="getMustRideFltr"  ref="mustRideSrchFilters" />
          </div>
          <div class="u-col l2 m3 s4 u-display-flex-space  u-section-1 u-pad-0 u-padding-top">
            <UAButton @click="mustRideInfoPop()" id="mustride_add_customer"
              :cssClass="['u-button u-round u-primary-1-pur u-right u-white-space u-medium lf mf sf',(getStatusValue() == 'STOPPED') ? 'u-disabled' : '']">
              Add Must Ride
            </UAButton>
            <UAModalDisplay v-if="mustrideinfopop" @close="ClosePopup()" @add="addMustRidePassenger"
              :subHeader="getReportHeader" :modalTable="tabs[2].addTableFields[0].modalTemp"
              :footerFields="modalButtons[0].addButtons" />
          </div>
</div>
        <div class="u-row">
          <div class="u-row u-margin-bottom u-padding-7">
            <div class="u-col l12 u-msmall lf mf sf u-border-bottom u-margin-left u-margin-right u-section-1">
              <label class="u-col l11 u-section-1 u-show-inline-block">Default Must Rides ({{ filterMustRide.filter(p =>
                p.mustRideStatus =='DEFAULT').length }})
              </label>
               <UAChevron v-if="filterMustRide.filter(p =>p.mustRideStatus =='DEFAULT').length > 0"
                :toggle="isShowFRowCards" @toggleArrow="toggleChevron('PI'+selectedTabIndex)"/>
        </div>
        <div class="u-row u-margin-left" v-if="isShowFRowCards">
          <label class="u-padding-top-16 u-section-1 u-show-inline-block u-medium lf mf sf"
            v-if="filterMustRide.filter(p => p.mustRideStatus =='DEFAULT').length == 0">
            No Default Must rides passengers were processed for this flight
          </label>
          <template v-for="(psngr, passIndex) in filterMustRide" :key="passIndex">
            <div class="u-col l3 m6 s12" v-if="psngr.mustRideStatus =='DEFAULT'">
              <UAOSLCard :cssClass="tabs[2].cardsConfig[0].cardTemp.cssClass" :cardCssClass="['u-round-10px']"
                :labelCss="tabs[2].cardsConfig[0].cardTemp.textCssclass" :label="psngr.lastName + ', ' + psngr.firstName"
                :tableData="[psngr]" :cardTable="tabs[2].cardsConfig[0].cardTemp"  @enableEdit="enableEdit('DefM' + passIndex)"
                    @viewDetails="enableViewPopup('DefM' + passIndex)"   @deletePsngr="enableDelete('DefM' + passIndex)"/>
                <UAModalDisplay v-if="(isViewDetails || editPopup) && selectedModal == 'DefM' + passIndex" @close="CloseEditPopup()" 
                    @update="updateEditMustRidePassenger" @viewEditEnable="enableEdit('DefM' + passIndex)"
              :subHeader="getReportHeader" :modalTable="tabs[2].editTableFields[0].modalTemp" :tableData="[psngr]"
              :footerFields=" isViewDetails ? modalButtons[0].viewButtons : modalButtons[0].editButtons" /> 
              <!-- Must ride delete popup -->
              <UAOSLCardConfirmation v-if="oslDeletePop && selectedModal == 'DefM' + passIndex" :cssClass="tabs[2].cardsConfig[0].cardTemp.cssClass" :cardCssClass="['u-round-10px']"
                :labelCss="tabs[2].cardsConfig[0].cardTemp.textCssclass" :label="psngr.lastName + ', ' + psngr.firstName"
                :tableData="[psngr]" :cardTable="tabs[2].cardsConfig[0].cardTemp" :CardBtnFields="modalButtons[0].deleteButtons" 
                :ConfirmActionMsg="displayHeader.deleteConfimMsg" :ConfirmActionTitle = "displayHeader.ConfimTitle" @enableEdit="enableEdit('DefM' + passIndex)"
                @viewDetails="enableViewPopup('DefM' + passIndex)" @delete="deletePsngrMustRide(psngr,'DefM' + passIndex)" @close="CloseDeletePopup()"
              />           
            </div>
          </template>
</div>
          </div>

          <div class="u-row u-margin-bottom u-padding-7">
            <div class="u-col l12 u-msmall lf mf sf u-border-bottom u-margin-left u-margin-right u-section-1">
              <label class="u-col l11 u-section-1 u-show-inline-block" >Declared Must Rides ({{ filterMustRide.filter(p =>
                p.mustRideStatus =='DECLARED').length }})
              </label>
               <UAChevron v-if="filterMustRide.filter(p =>p.mustRideStatus =='DECLARED').length > 0" 
                :toggle="isShowSRowCards" @toggleArrow="toggleChevron('PV'+selectedTabIndex)"/>
            </div>
            <div class="u-row u-margin-left" v-if="isShowSRowCards">
              <label class="u-padding-top-16 u-section-1 u-show-inline-block u-medium lf mf sf"
                v-if="filterMustRide.filter(p => p.mustRideStatus =='DECLARED').length == 0">
                No Declared Must rides passengers were processed for this flight
              </label>
              <template v-for="(psngr, passIndex) in filterMustRide" :key="passIndex">
                <div class="u-col l3 m6 s12" v-if="psngr.mustRideStatus =='DECLARED'">
                  <UAOSLCard :cssClass="tabs[2].cardsConfig[0].cardTemp.cssClass" :cardCssClass="['u-round-10px']"
                    :labelCss="tabs[2].cardsConfig[0].cardTemp.textCssclass" :label="psngr.lastName + ', ' + psngr.firstName"
                    :tableData="[psngr]" :cardTable="tabs[2].cardsConfig[0].cardTemp"  @enableEdit="enableEdit( 'DecM' + passIndex)"
                    @viewDetails="enableViewPopup('DecM' + passIndex)"  @deletePsngr="enableDelete('DecM' + passIndex)"/>
                    <UAModalDisplay v-if="(isViewDetails || editPopup) && selectedModal == 'DecM' + passIndex" @close="CloseEditPopup()" 
                    @update="updateEditMustRidePassenger" @viewEditEnable="enableEdit('DecM' + passIndex)"
                  :subHeader="getReportHeader" :modalTable="tabs[2].editTableFields[0].modalTemp" :tableData="[psngr]"
                  :footerFields="isViewDetails ? modalButtons[0].viewButtons : modalButtons[0].editButtons" />
                  <!-- Must ride delete popup -->
                  <UAOSLCardConfirmation v-if="oslDeletePop && selectedModal == 'DecM' + passIndex" :cssClass="tabs[2].cardsConfig[0].cardTemp.cssClass" :cardCssClass="['u-round-10px']"
                    :labelCss="tabs[2].cardsConfig[0].cardTemp.textCssclass" :label="psngr.lastName + ', ' + psngr.firstName"
                    :tableData="[psngr]" :cardTable="tabs[2].cardsConfig[0].cardTemp" :CardBtnFields="modalButtons[0].deleteButtons" 
                    :ConfirmActionMsg="displayHeader.deleteConfimMsg" :ConfirmActionTitle = "displayHeader.ConfimTitle" @enableEdit="enableEdit( 'DecM' + passIndex)"
                    @viewDetails="enableViewPopup('DecM' + passIndex)" @delete="deletePsngrMustRide(psngr,'DecM' + passIndex)" @close="CloseDeletePopup()"/>
                </div>
              </template>
            </div>
          </div>
        </div>
      </div>
    </div>
    <UAConfirmBox ref="uaconfirmbox" v-if="showConfrmBox" :commentFields="(showCmtField && commentsFooterFields.addCmntFld) || []"/>
    <footer class="u-container u-width-100 u-bottom u-light-gray1 u-margin-8 u-ht-60 u-topbar"
      :class="[space && 'footer-space']">
      <div class="u-row u-pad-0 u-section-1">
        <div class="u-col l12 m12 s12">
          <div class="u-pad-4 u-left u-col l1-5 m1 s1">
            <UAButton :id="getStatusValue().replaceAll(' ', '').toLowerCase()+`_`+selectedRecord.sortKey"
              :cssClass="[getOvslStatusColor(getStatusValue()), 'u-round  u-width-100 u-break-content u-msmall lf mf sf']">
              {{ getStatusValue() }}
            </UAButton>
          </div>
          <div class="u-pad-4 u-left u-col l1-5 m2 s2">
            <UAButton :id="'comments_'+ selectedRecord.sortKey"
              cssClass="u-button u-round u-pad-0 u-text-0 u-right u-primary-inv-border u-transparent u-width-90 u-break-content u-medium lf mf sf u-white-space"
              @click="CommentInfoPop(true)"> <img class="u-padding-right-8" v-if="commentData.length > 0" src="@/assets/img/comments_dot.png" alt="" /><img v-else class="u-padding-right-8" src="@/assets/img/comments.png" alt="" />Comments
            </UAButton>
            <UAReportComments v-if="commentspop" @closeComment="CloseCommentInfoPop()" @addComment="addComment($event)"
              @update_comment="updateComment" :modalCssClass="addCustomerComments?.commentsHeader?.cssClass"
              :headers="addCustomerComments.addCommentsTableFields[0].modalFields.headers[0]"
              :modalFields="addCustomerComments.addCommentsTableFields[0].modalFields"
              :modaltextCSSClass="addCustomerComments.commentsHeader.textCSSClass"
              :modalHeaderText="addCustomerComments.commentsHeader.headerText"
              :tableFields="addCustomerComments.addCommentsTableFields[0].modalFields.tableFields"
              :tblHeaders="addCustomerComments.addCommentsTableFields[0].modalFields.headers[0]"
              :commentData="commentData" :footerFields="addCustomerComments.modalButtons[0].addButtons"
              :addCustomerCommentsInfo="addCustomerComments.addCommentsTableFields[0].modalFields1.reportCommentsInfo" />
          </div>
          <div class="u-col l4 m4 s4">
            <div class="u-row">
              <div class="u-col l6 m6 s6 u-row-padding u-pad-4 u-left u-break-content"
                v-if="space && getStatusValue() == 'FINALIZED'">
                <div class="u-col u-msmall lf mf sf">
                  Report finalized by:
                </div>
                <template v-for="(rField, rKey) in commentsFooterFields.finalizedDetails" :key="rKey">
                  <template v-if="rField.combineFields">
                    <label :class="['u-col u-small lf mf sf u-block u-break-content', rField.cssClass]">
                      {{ combineDataFields(rField, selectedRecord) }}
                    </label>
                  </template>
                  <template v-else>
                    <label :class="['u-col u-msmall lf mf sf', rField.cssClass]">
                      {{ getJPathValue(rField.path, selectedRecord) }}
                    </label>
                  </template>
                </template>
              </div>
              <div class="u-col l6 m6 s6 u-row-padding u-pad-4 u-left u-break-content" v-if="space">
                <div class="u-col u-msmall lf mf sf">
                  Report last updated by:
                </div>
                <template v-for="(rField, rKey) in commentsFooterFields.lastUptDetails" :key="rKey">
                  <template v-if="rField.combineFields">
                    <label :class="['u-col u-small lf mf sf u-block u-break-content', rField.cssClass]">
                      {{ combineDataFields(rField, selectedRecord) }}
                    </label>
                  </template>
                  <template v-else>
                    <label :class="['u-col u-msmall lf mf sf', rField.cssClass]">
                      {{ getJPathValue(rField.path, selectedRecord) }}
                    </label>
                  </template>
                </template>
              </div>
            </div>
            <div>
            </div>
          </div>
          <div class="u-right u-col l1 m1 s1 u-flex-center">
            <UAButton @click="toggleIcon" id="toggle_report_footer">
              <span v-if="showIcon">
                <img src="@/assets/img/expand_less.png" class="u-pointer" :alt="'upArrow_'+selectedRecord.sortKey" @click="toggleShevron()" /></span>
              <span v-else>
                <img src="@/assets/img/expand_more.png" class="u-pointer" :alt="'downArrow_'+selectedRecord.sortKey" @click="toggleShevron()" />
              </span>
            </UAButton>
          </div>
          <div class="u-col l4 m4 s4 u-right u-display-flex-end">
            <!-- should be shown for initiated flight and volunteer added flight which doesn't have any processed passengers -->
            <div class="u-pad-4 u-margin-right"
              v-if="!((getStatusValue() == 'FINALIZED') || (getStatusValue() == 'STOPPED'))">
              <UAButton v-if="searchOVSIData.processedPassengers.length == 0" @click="stopOversale" :id="'stop_oversale_'+selectedRecord.sortKey"
                :cssClass="['u-button u-round u-right  u-secondary-cst u-break-content u-msmall lf mf sf u-white-space']">
                Stop oversale
              </UAButton>
            </div>
            <div :class="['u-pad-4']"
              v-if="!((getStatusValue() == 'FINALIZED') || (getStatusValue() == 'STOPPED'))">
              <UAButton :id="'FinalizeReport_'+selectedRecord.sortKey"
                cssClass="u-button u-round  u-right u-primary-cst u-break-content u-msmall lf mf sf u-white-space"
                @click="finalizeReport">Finalize report
              </UAButton>
            </div>
          </div>
        </div>
      </div>
    </footer>
  </template>
</template>
 
<script>
import { mapState, mapMutations, mapActions, mapGetters } from 'vuex';

import UAOvsiTableColLayout from "./UAOvsiTableColLayout.vue";
import UASearchKeyword from "./UASearchKeyword.vue";
import UAButton from "./UAButton.vue";
import UAOSLCard from './UAOSLCard.vue';
import UATab from "./UATab.vue";
import UASearchData from "./UASearchData.vue";
import UAModalDisplay from "./UAModalDisplay.vue";
import UAReportComments from "./UAReportComments.vue"
import { getDateTimePart, validatInputParams, getAmtAndCurrencyCode,mapDateToOtherFormat } from "../helpers/utilities";
import { getFlightComments, addflightcomment, updateflightcomment,  removeprocessedpassenger,removemustride,getPassengers,addProcessPassenger,addMustride } from '../services/passengerService';
import { deactiveFlight, finalizeFlight } from '../services/flightService';
import UAConfirmBox from './UAConfirmBox.vue';
import UAOSLCardConfirmation from './UAOSLCardConfirmation.vue';
import UAConfirmModal from './UAConfirmModal.vue';
import UARadioButton from './UARadioButton.vue';
import UATableDisplay from './UATableDisplay.vue';
import UAChevron from './UAChevron.vue';

export default {
  name: "UAOSLReport",
  async created() {
    if(Object.keys(this.selectedRecord).length >0){
      await this.fetchReport();
    }else{
      this.setAlertMessages({ alertType: 'warning', alertMessages: ['Unable To Find Record. Retry'] });
    }
     },
    beforeUnmount(){
      this.setIsInlineLoading({flag:false})
  },
  unmounted(){
    document.removeEventListener("click", () => {
      this.isAllPassengerList = false;
    });
  },
  mounted() {
    let defaultOptions = {"type":"All","cabin":"All","compensation":"All","compensation_1": "All","pass_class":"All"};
    this.updatePrevOptions(defaultOptions);
  },
  data() {
    return {
      filtersData:[],
      isSHowTemp: false,
      selectedTabIndex: 0,
      addPopup: false,
      showIcon: true,
      searchKeyword: '',
      mustrideinfopop: false,
      manualAddPop: false,
      commentspop: false,
      space: false,
      inVol: true,
      Vol: true,
      editPopup: false,
      selectedModal: '',
      commentData: [],
      displayfinalize: false,
      finalizeData: {},
      tabsObjCopy : {},
      oslDeletePop : false,
      isAllPassengerList: false,
      passengerList: [],
      selectedOption:'',
      modalSelectedSearchValue: '',
      processedResultCnt: 0,
      updowngradeResultCnt: 0,
      isShowSRowCards: true, // for toggling second row card list
      isShowFRowCards: true,  // for toggling first row card list
      mouseDetectedAllPsnrModal: false,
      showConfrmBox: false,
      showCmtField: false
    };
  },
  props: [],
  components: {
    UAOvsiTableColLayout,
    UASearchKeyword,
    UAButton,
    UAOSLCard,
    UATab,
    UASearchData,
    UAModalDisplay,
    UAReportComments,
    UAConfirmBox,
    UAOSLCardConfirmation,
    UAConfirmModal,
    UARadioButton,
    UATableDisplay,
    UAChevron
  },
  computed: {
    ...mapState({
      displayHeader: (state) => state.ovsiDefaultModule.displayHeader,
      searchfilters: (state) => state.ovsiDefaultModule.searchfilters,
      searchOVSIData: (state) => state.ovsiDefaultModule.searchOVSIData,
      tableDetails: (state) => state.ovsiDefaultModule.tableDetails,
      modalButtons: state => state.ovsiDefaultModule.modalButtons,
      cardsConfig: state => state.ovsiDefaultModule.cardsConfig,
      addTableFields: state => state.ovsiDefaultModule.addTableFields,
      addUpgradeTableFields: state => state.ovsiDefaultModule.addUpgradeTableFields,
      addUpgradeTableFields: state => state.ovsiDefaultModule.addUpgradeTableFields,
      addMustRideTableFields: state => state.ovsiDefaultModule.addMustRideTableFields,
      modalButtons: state => state.ovsiDefaultModule.modalButtons,
      prevNavigateViews: state => state.ovsiDefaultModule.prevNavigateViews,
      isNavigatedEvent: state => state.ovsiDefaultModule.isNavigatedEvent,
      modalHeader: state => state.ovsiDefaultModule.modalHeader,
      upgradeModalHeader: state => state.ovsiDefaultModule.upgradeModalHeader,
      mustRideHeader: state => state.ovsiDefaultModule.mustRideHeader,
      selectedRecord: state => state.ovsiDefaultModule.selectedRecord,
      actionId: (state) => state.ovsiDefaultModule.actionId,
      addCustomerComments: (state) => state.ovsiDefaultModule.addCustomerComments,
      tabs: state => state.ovsiDefaultModule.tabs,
      isLoading: (state) => state.ovsiDefaultModule.isLoading,
      filterInputData: state => state.ovsiDefaultModule.filterInputData,
      commentsFooterFields: state => state.ovsiDefaultModule.commentsFooterFields,
      appInfo: (state)=> state.ovsiDefaultModule.applicationInfoDetails,
      isRouteNavigationMenu: state=> state.menuModule.isRouteNavigationMenu,
      exportToExcelConfig: (state) => state.ovsiDefaultModule.exportToExcelConfig,
      isViewDetails: (state) => state.ovsiDefaultModule.isViewDetails,
      channel: (state) => state.userModule.channel,
      additionalFields: (state) => state.ovsiDefaultModule.entityDisplayDetails.Layouts[0].InnerLayout.additionalFields,
      getSelectedPasngr(){
        let res = [];
        res = this.passengerList.filter((psnr,pInd) => psnr.passenger.pnr + pInd == this.selectedOption.id);
        return res;
      },
      getPassengerLists(){
        let psnrArr = [];
        if(this.passengerList && this.passengerList.length>0 && this.passengerList != (null || undefined)){
          this.passengerList.forEach((psnr,pInd) =>{
            if(this.modalSelectedSearchValue && (psnr.passenger.pnr == this.modalSelectedSearchValue.pnr) && (psnr.passenger.firstName == this.modalSelectedSearchValue.firstName) && (psnr.passenger.lastName == this.modalSelectedSearchValue.lastName)) {
              this.selectedOption = {"id": psnr.passenger.pnr + pInd,"pnr": psnr.passenger.pnr, "name": "psnrName", "psnrName" : `${this.getFullName(psnr)}`, "defaultChecked":true, "numberInParty":psnr.passenger.numberInParty, "dateOfBirth":psnr.passenger.dateOfBirth};
              //psnrArr.push({"id": psnr.passenger.pnr + pInd,"pnr": psnr.passenger.pnr, "name": "psnrName", "label" : `${this.getFullName(psnr)} (${psnr.passenger.pnr})`, "defaultChecked":true, "cssClass":"u-small"});
              psnrArr.push({"id": psnr.passenger.pnr + pInd,"pnr": psnr.passenger.pnr, "name": "psnrName", "psnrName" : `${this.getFullName(psnr)}`, "defaultChecked":true, "numberInParty":psnr.passenger.numberInParty, "dateOfBirth":psnr.passenger.dateOfBirth});
            } else
              psnrArr.push({"id": psnr.passenger.pnr + pInd,"pnr": psnr.passenger.pnr, "name": "psnrName", "psnrName" : `${this.getFullName(psnr)}`, "defaultChecked":false, "numberInParty":psnr.passenger.numberInParty, "dateOfBirth":psnr.passenger.dateOfBirth});
              //psnrArr.push({"id": psnr.passenger.pnr + pInd,"pnr": psnr.passenger.pnr, "name": "psnrName", "label" : `${this.getFullName(psnr)} (${psnr.passenger.pnr})`, "defaultChecked":false, "cssClass":"u-small"});
          });
        }
        return psnrArr;
      },
      getAllAddPngrSrchList() {
        let psngerList = [];
        if(this.passengerList && this.passengerList.length>0 && this.passengerList != (null || undefined)){
          this.passengerList.forEach((psngr) => {
            psngerList.push({
              firstName: psngr.passenger.firstName,
              lastName: psngr.passenger.lastName,
              pnr: psngr.passenger.pnr,
            });
          });
        }
        return psngerList;
      },
      getAllPassengerList() {
        let psngerList = [];
        this.searchOVSIData?.processedPassengers?.forEach((psngr) => {
          psngerList.push({
            firstName: psngr.passenger.firstName,
            lastName: psngr.passenger.lastName,
            pnr: psngr.passenger.pnr,
            tabName: "Processed"
          });
        });
        this.searchOVSIData?.processedPassengers?.forEach((psngr) => {
          if (psngr.passenger?.deniedBoardingCode == 'A' || psngr?.passenger?.deniedBoardingCode == 'B') {
            psngerList.push({
              firstName: psngr.passenger.firstName,
              lastName: psngr.passenger.lastName,
              pnr: psngr.passenger.pnr,
              tabName: "Upgrade/Downgrade"
            });
          }
        });
        this.searchOVSIData?.mustRidePassengers?.forEach((mstPsngr) => {
          psngerList.push({
            firstName: mstPsngr.firstName,
            lastName: mstPsngr.lastName,
            pnr: mstPsngr.pnr,
            tabName: "Must ride"
          });
        });
        return psngerList;
      },
      filterRecords() { // proccessed passengers
        let finalResults = this.searchOVSIData?.processedPassengers;
        if (!this.filterInputData || Object.keys(this.filterInputData)?.length == 0) {//IF INLINE FILTER INPUT SELECTED TO FILTER RECORDS
          finalResults = this.searchOVSIData.processedPassengers;
        } else {
          const typeSearch = this.filterInputData.type ? this.filterInputData.type.toLowerCase() : 'all';
          const cabinSearch = this.filterInputData.cabin ? this.filterInputData.cabin.toLowerCase() : 'all';
          const compensationSearch = this.filterInputData.compensation ? this.filterInputData.compensation.toLowerCase() : 'all';
          if (typeSearch == 'all' && cabinSearch == 'all' && compensationSearch == 'all') {
            finalResults = this.searchOVSIData.processedPassengers;
          }
          if (typeSearch != 'all' || cabinSearch != 'all' || compensationSearch != 'all') {
            finalResults = this.searchOVSIData.processedPassengers.filter((psngr, index) => {
              let ameAmount = 0;
              return (
                (typeSearch == 'all' ? true : psngr.passenger?.deniedBoardingCode?.toLowerCase().includes(typeSearch)) &&
                (compensationSearch == 'all' ? true :
                  (compensationSearch.toLowerCase() == 'miles' ? eval(this.getIssuancesValues(psngr,'processedMiles') > 0) :
                    compensationSearch.toLowerCase() == 'etc' ? eval(this.getIssuancesValues(psngr,'processedEtc.amount') > 0) :
                     compensationSearch.toLowerCase() == 'draft' ? eval(this.getIssuancesValues(psngr,'draftAmount.amount') > 0) :
                     compensationSearch.toLowerCase() == 'amenities' ? eval (this.getTotalAmenities(psngr) > 0) : true
                  )
                ) && (cabinSearch == 'all' ? true : psngr.passenger?.currentCabinCode?.toLowerCase().includes(cabinSearch))
              );
            });
          }
        }
        //} else 
        if (this.searchKeyword && Object.keys(this.searchKeyword)?.length > 0) {//IF SEARCH INPUT FOUND IN UASearchKeyword Component to search the records as per input
          const firstName = this.searchKeyword.firstName.toLowerCase();
          const lastName = this.searchKeyword.lastName.toLowerCase();
          const pnr = this.searchKeyword.pnr.toLowerCase();
          return finalResults.filter(psngr => {
            return (psngr.passenger.pnr.toLowerCase().includes(pnr)) && psngr.passenger.lastName.toLowerCase().includes(lastName) && (psngr.passenger.firstName.toLowerCase().includes(firstName));
          });
        }
        //return final filter results
        this.processedResultCnt = finalResults?.length;
        return finalResults.sort((a,b) =>{
          let firstValue = a.passenger.lastName;
          let secValue = b.passenger.lastName;
          return firstValue.toString().toLowerCase().localeCompare(
          secValue.toString().toLowerCase());
        });
      },
      filterMustRide() { // Mustride passengers
        let mustRideList = this.searchOVSIData?.mustRidePassengers;
        const passClassSearch = this.getPrevOptions?.pass_class?.toLowerCase();
        if (passClassSearch != 'all') {
          mustRideList = this.searchOVSIData.mustRidePassengers.filter(mustRide => {
            return mustRide.passRiderCode.toLowerCase().includes(passClassSearch);
          });
        }
        if (this.searchKeyword && Object.keys(this.searchKeyword)?.length > 0) {
          const firstName = this.searchKeyword.firstName.toLowerCase();
          const lastName = this.searchKeyword.lastName.toLowerCase();
          const pnr = this.searchKeyword.pnr.toLowerCase();
          return mustRideList.filter(psngr => {
            return (psngr.pnr.toLowerCase().includes(pnr)) && psngr.lastName.toLowerCase().includes(lastName) && (psngr.firstName.toLowerCase().includes(firstName));
          });
        }
        return mustRideList.sort((a,b) =>{
          let firstValue = a.lastName;
          let secValue = b.lastName;
          return firstValue.toString().toLowerCase().localeCompare(
          secValue.toString().toLowerCase());
        });
      },
      filterUpgradeDownGrade() { // upgrade/downgraede passengers
        let updnGradeList = this.searchOVSIData?.processedPassengers?.filter(psngr => psngr?.passenger?.deniedBoardingCode == 'A' || psngr?.passenger?.deniedBoardingCode == 'B');
        const compensationSearch = (this.filterInputData && this.filterInputData?.compensation_1) ?
          this.filterInputData?.compensation_1?.toLowerCase() : this.getPrevOptions?.compensation_1?.toLowerCase();

        if (compensationSearch != 'all') {
            updnGradeList = this.searchOVSIData?.processedPassengers?.filter(psngr => psngr?.passenger?.deniedBoardingCode == 'A' || psngr?.passenger?.deniedBoardingCode == 'B').filter(psngr => {
            if (compensationSearch?.toLowerCase() == 'miles') {
              return (eval(this.getIssuancesValues(psngr,'processedMiles') > 0));
            }
            else if (compensationSearch?.toLowerCase() == 'etc') {
              return (eval(this.getIssuancesValues(psngr,'processedEtc.amount') > 0));
            }
            else if (compensationSearch.toLowerCase() == 'draft') {
              return (eval(this.getIssuancesValues(psngr,'draftAmount.amount') > 0));
            }
            else if (compensationSearch.toLowerCase() == 'amenities') {
              return  eval(this.getTotalAmenities(psngr) > 0); 
            }

          });
        }
        if (this.searchKeyword && Object.keys(this.searchKeyword).length > 0) {
          const firstName = this.searchKeyword.firstName?.toLowerCase();
          const lastName = this.searchKeyword.lastName?.toLowerCase();
          const pnr = this.searchKeyword.pnr?.toLowerCase();
          updnGradeList = updnGradeList?.filter(psngr => {
            return (psngr?.passenger?.pnr?.toLowerCase()?.includes(pnr)) && psngr?.passenger?.lastName?.toLowerCase()?.includes(lastName) && (psngr?.passenger?.firstName?.toLowerCase()?.includes(firstName));
          });
        }
        this.updowngradeResultCnt = updnGradeList?.length;
        return updnGradeList.sort((a,b) =>{
          let firstValue = a.passenger.lastName;
          let secValue = b.passenger.lastName;
          return firstValue.toString().toLowerCase().localeCompare(
          secValue.toString().toLowerCase());
        });
      },
      getReportHeader(){
        return this.displayHeader.header?.combineFields?.map(f=>{
          return f.path?(f.formatDate? mapDateToOtherFormat(f, this.selectedRecord):this.getJPathValue(f.path,this.selectedRecord)):f.concatePath.map(p=>this.getJPathValue(p,this.selectedRecord)).join(f.concatePrefix ||'')
        }).join(header.combineBy|| ', ');
      },
      getMustRideFltr(){
        let filtersData = JSON.parse(JSON.stringify(this.tabs[this.selectedTabIndex] || []));
        const passClassSearch =  this.getPrevOptions?.pass_class;
          filtersData?.filters?.forEach(fltItem =>{
            if(fltItem.sourceType == "module_data"){
              fltItem.source = this.getDDlData(fltItem,passClassSearch);
            }
          });
        return filtersData;
      },
    }),
    ...mapGetters(["getOVSIEntityId", "getJPathValue","getEmployeeId","getUserName","getPrevOptions","getOVSIFields","getOvslStatusColor"]),
  },
  methods: {
    ...mapActions(['getOVSIData','updatePrevOptions','authorizeModule','getFlight']),
    ...mapMutations(["setAlertMessages","setModalAlertMessages","clearAlertMessages","setSelectedRecord","setIsViewDetails","setIsInlineLoading"]),
    mouseLeaveAllPsnrModal(){
      this.mouseDetectedAllPsnrModal = true
    },
    mouseOverAllPsnrModal(){
      this.mouseDetectedAllPsnrModal = false
    },
    handleOutSideClick(e){
      if(this.isAllPassengerList && this.mouseDetectedAllPsnrModal){
        if(this.$refs?.allPassengerMdoalRef && !this.$refs?.allPassengerMdoalRef?.contains(e.target)){
          this.isAllPassengerList = false;
        } 
      }
    },
    handleSelectedRadioOption(selectedRDOOption){
      this.selectedOption = selectedRDOOption;
      this.modalSelectedSearchValue = '';
      this.$refs.searchKeyCom.resetSearchText();
    },
    getDDlData(fldInfo,pass_class){
      let AllValue={
        "name" : fldInfo.defaultSelectedValue, 
        "id" : fldInfo.defaultSelectedValue, 
        "label" : fldInfo.defaultSelectedValue,
        "key": fldInfo.id,
        "showPrevOpt":true
      };
      let ddlData = [];
      let matchedName=''; //track prevValue
      ddlData.push(AllValue)
      this.searchOVSIData?.mustRidePassengers?.forEach(data => {  
        let colVal = data[fldInfo.pathToCompare];
        let name ='';
        if(colVal && colVal.length >3){
          name= colVal.slice(0,-1);
        } else{
          name= colVal;    
        }
        if(!ddlData.find(item => item.label === name)) {        
          ddlData.push({"name" : name, "id" : colVal, "label" : name, "key": fldInfo.id,"showPrevOpt":true});
          if(pass_class == name){
            matchedName=name;
          }
        }
      });
      
      fldInfo.defaultSelectedValue=matchedName|| fldInfo.defaultSelectedValue;
      fldInfo.model=fldInfo.defaultSelectedValue;
      let prevU = JSON.parse(JSON.stringify(this.getPrevOptions));
      prevU["pass_class"] = fldInfo.defaultSelectedValue;
      this.updatePrevOptions(prevU);
      return ddlData;
    },

    getCabinWiseDataForExcel(cabins) {
      let cabinData = {}
      let cabinWiseData = [];
      for (let i = 0; i < cabins.length; i++) {
        let filteredCabinData = this.searchOVSIData.cabinTotals.filter((item) => {
          return item.cabinCode == cabins[i];
        })
        cabinData[cabins[i]] = filteredCabinData.length > 0 ? filteredCabinData[0] : {};
      }
      cabinWiseData.push(cabinData);
      return cabinWiseData;
    },
    addNewFieldRows(){
      this.tabs[this.selectedTabIndex].editTableFields[0].modalTemp
      .addNewRowFields.push(JSON.parse(JSON.stringify(this.additionalFields[0] || [])))
    },
    deleteNewFieldRows(indx, currmodalData, mode){
      if (mode =='add'){
      this.tabs[this.selectedTabIndex].editTableFields[0].modalTemp
      .addNewRowFields = this.tabs[this.selectedTabIndex].editTableFields[0].modalTemp
        .addNewRowFields.filter((item,ind) => currmodalData[currmodalData.id].length +ind +1  != indx);
        this.setAmmentiesTotalValues(this.tabs[this.selectedTabIndex].editTableFields[0].modalTemp);
      } 
      // else {
      //     currmodalData[currmodalData.id] = currmodalData[currmodalData.id].filter((item,ind) => ind +1 != indx);
      //     this.setAmmentiesTotalValues(this.tabs[this.selectedTabIndex].editTableFields[0].modalTemp);
      // }
    },
    addCustomerNewFieldRows(){
       this.tabs[this.selectedTabIndex].addTableFields[0].modalTemp
      .addNewRowFields.push(JSON.parse(JSON.stringify(this.additionalFields[0] || [])))
    },
    deleteCustomerNewFieldRows(indx, currmodalData,mode){
      if (mode =='add'){
      this.tabs[this.selectedTabIndex].addTableFields[0].modalTemp
      .addNewRowFields = this.tabs[this.selectedTabIndex].addTableFields[0].modalTemp
        .addNewRowFields.filter((item,ind) => currmodalData[currmodalData.id].length +ind +1  != indx);
        this.setAmmentiesTotalValues(this.tabs[this.selectedTabIndex].addTableFields[0].modalTemp);
      } 
      // else {
      //     currmodalData[currmodalData.id] = currmodalData[currmodalData.id].filter((item,ind) => ind +1 != indx);
      //     this.setAmmentiesTotalValues(this.tabs[this.selectedTabIndex].addTableFields[0].modalTemp);
      // }
    },
    combineFields(field, item) {
      return field.combinepath
        .map((path) => this.getJPathValue(path, item))
        .join(field.combinePrefix || "")
        .toString();
    },
    setAmmentiesTotalValues(currModalInfo, tblDataInfo={}){
      let newRowData = [];   
      let tblMdlData = JSON.parse(JSON.stringify(tblDataInfo));
  if(tblMdlData.compensation && Object.keys(tblMdlData.compensation).length>0){ 
      currModalInfo.modalFields.forEach(modalData => {        
        let tblIssuanceData;
        if(modalData.fieldsToAddAssuance){
          if(modalData.bindModalFieldWithIteratbleData) {//IN CASE OF MULTIPLE ISSUANCE WE NEED TO SHOW MULTIPLE ISSUANCE ROW AS PER ISSUANCE RECORD LENGTH
            if(modalData.multiDataParentPathToIterateTblFilds){
              tblIssuanceData = this.getJPathValue(modalData.multiDataParentPathToIterateTblFilds,tblMdlData)
            }
          }
          let fieldWiseTotalCount = {};
          modalData[modalData.id].forEach((mdlFieldItem,mdlFldIndx) => {
            mdlFieldItem.tableFields.forEach(fieldItem => {
            let totalCount = 0;
              let tblData = {};
              if(Array.isArray(tblIssuanceData)){//IF MULTIPLE ISSUANCE FOUND - AS DATA IN ARRAY TYPE
                tblData = tblIssuanceData[mdlFldIndx];
              } else {
                tblData = JSON.parse(JSON.stringify(tblDataInfo));
              }
            if(tblData && Object.keys(tblData).length > 0 ){
              //totalCount = this.getJPathValue(fieldItem.path, tblData);
              if (fieldItem.isAminities && fieldItem.isEdit) {
                let ams =
                  this.getJPathValue(fieldItem.path, tblData) || [];
                let aminities =
                  ams.filter(
                    (am) => am[fieldItem.filterPath] == fieldItem.filterValue
                  ) || [];
                  let fieldValue  = 
                  aminities.length > 0
                    ? this.combineFields(fieldItem, aminities[0])
                    : fieldItem.defaultValue;
                    totalCount = parseFloat(fieldValue.split(' ')[0]);
              } else if(!fieldItem.isAminities &&
                  fieldItem.combinepath &&
                  fieldItem.combinepath.length > 0) {
                totalCount = parseFloat(this.combineFields(fieldItem, tblData).split(' ')[0]);
              } else {
                totalCount = this.getJPathValue(fieldItem.path, tblData);
              }
            } else {
              totalCount = fieldItem.model ? parseInt(fieldItem.model) : 0;
            }
              if(fieldWiseTotalCount.hasOwnProperty(fieldItem.id)){                
                totalCount = fieldWiseTotalCount[fieldItem.id] + totalCount;
                fieldWiseTotalCount[fieldItem.id]= totalCount;
              } else {
                fieldWiseTotalCount[fieldItem.id]=totalCount;
            }
            //GET THE VALUES FROM NEW ROW ADDED FIELDS AND ADD IT IN TOTAL
            currModalInfo.addNewRowFields.forEach(addModalField => {           
              addModalField.tableFields.forEach(addFieldItem => {
                if(addFieldItem.id == fieldItem.id){
                  totalCount = totalCount + (addFieldItem.model ? parseFloat(addFieldItem.model) : 0);
                }                
              });
            });
            //SET THE TOTAL FOR ALL ROWS
            currModalInfo.modalFields.forEach(modalData => {  
              if(modalData.showTotalInfo){
                modalData[modalData.id].forEach(mdlFieldItem => {
                    mdlFieldItem.tableFields.forEach(totalFieldItem => {
                      if(totalFieldItem.id == fieldItem.id){
                        totalFieldItem.model = Number.isInteger(totalCount) ? totalCount : parseFloat(totalCount).toFixed(2);
                      }
                    });
                  });
                }                         
              });
            });
          });
        }                          
      });
    }
    },
   //ON CHNAGE IN FIELD GET/CALCULATE THE FILED WISE VALUE
    setDependentValuesOnCHange(inputFieldDetails, currModalInfo) {
      let totalCount = 0;
      try {
        if (inputFieldDetails.inputFieldInfo.currField.dependOnOtherSection
          && inputFieldDetails.inputFieldInfo.currField.dependOnOtherSection.length > 0) {
          currModalInfo.modalFields.forEach(modalData => {
            if(modalData[inputFieldDetails.inputFieldInfo.currField.currentSectionId]){
              modalData[inputFieldDetails.inputFieldInfo.currField.currentSectionId].forEach(modlRowFiledInfo => {
                modlRowFiledInfo.tableFields.forEach(fieldItem => {
                if (fieldItem.model && inputFieldDetails.inputFieldInfo.currField.id == fieldItem.id) {
                  if(inputFieldDetails.inputFieldInfo.currField.id == "miles"){
                    totalCount = totalCount + (fieldItem.model ? parseInt(fieldItem.model) : 0);
                  }else{
                    let amt = fieldItem.model.toString().trim();
                    let amtCode = getAmtAndCurrencyCode(amt);
                    totalCount = totalCount + (amtCode.amount ? parseFloat(amtCode.amount) : 0);
                  }
                }
                });
              });              
            }           
          });
            currModalInfo.addNewRowFields.forEach(addModalField =>{
              addModalField.tableFields.forEach(fieldItem => {
                if (fieldItem.model && inputFieldDetails.inputFieldInfo.currField.id == fieldItem.id) {
                  if(inputFieldDetails.inputFieldInfo.currField.id == "miles"){
                    totalCount = totalCount + (fieldItem.model ? parseInt(fieldItem.model) : 0);
                  }else{
                      let amt = fieldItem.model.toString().trim();
                      let amtCode = getAmtAndCurrencyCode(amt);
                      totalCount = totalCount + (amtCode.amount ? parseFloat(amtCode.amount) : 0);
                  }
                }
              });
            });
          //BIND THE TOTAL OF FIELD IN BELOW TOTAL FIELDS
          currModalInfo.modalFields.forEach(modalData => {            
            if(inputFieldDetails.inputFieldInfo.currField.dependOnOtherSection 
              && modalData[inputFieldDetails.inputFieldInfo.currField.dependOnOtherSection[0]]){
                modalData[inputFieldDetails.inputFieldInfo.currField.dependOnOtherSection[0]][0].tableFields.forEach(fieldItem => {
                  if (inputFieldDetails.inputFieldInfo.currField.dependOnOtherSectionField[0] == fieldItem.id) {
                    fieldItem.model =  Number.isInteger(totalCount) ? totalCount : parseFloat(totalCount).toFixed(2);
                  }
                });
            }            
          });
        }
      } catch (err) {
        console.error(err)
      }
    },
    setSelectedSearchPsnrText(psngrSearchText){
      //if search text empty from searchkeyword component then clear selected option value
      if(!psngrSearchText) this.selectedOption = psngrSearchText; 
      this.modalSelectedSearchValue = psngrSearchText;
      //To set focus on the selected option
      if(this.modalSelectedSearchValue && Object.keys(this.modalSelectedSearchValue).length > 0)
        this.$refs.refTableDisplay.setFocus(psngrSearchText);
    },
    setSearchText(psngrSearchText) {
      if (Object.keys(psngrSearchText).length > 0) {
        this.searchKeyword = {
          firstName: psngrSearchText.firstName,
          lastName: psngrSearchText.lastName,
          pnr: psngrSearchText.pnr,
        };
        if(psngrSearchText.tabName){        
          this.tabs.forEach((tab, indx) => {
            if (tab.label == psngrSearchText.tabName) {
              this.selectedTabIndex = indx;
              return;
            }
          });
        }
      } else {
        this.searchKeyword = '';
      }

    },
    formattedTimeDate(dateTimeString) {
      if (dateTimeString) {
        const formattedDate = new Date(dateTimeString).toLocaleDateString();
        const formattedTime = new Date(dateTimeString).toLocaleTimeString();
        return `${formattedDate} ${formattedTime};`
      }
      return "";
    },
    getTotalAmenities(psngr) {
      let ameAmount = 0;
      let issuances = psngr.compensation.issuances;
      issuances?.forEach(issu => {
        issu?.amenitiesCompensated?.forEach(amenities=>ameAmount = ameAmount  + eval(amenities?.amountCompensated?.amount))   
        })
      return eval(ameAmount);
    },
    getIssuancesValues(psngr,path){
      let ameAmount = 0;
      let issuances = psngr.compensation.issuances;
      issuances?.forEach(issu => {
        ameAmount = ameAmount  + eval(this.getJPathValue(path,issu))
        })
      return eval(ameAmount);
    },
    mapDateToOtherFormat(rField, data) {
      let date = this.getFieldData(rField, data);
      if (date) {
        // return  new Date(date).toLocaleString('en-US', {  month: 'short' });
        const tokens = new Date(date).toLocaleDateString({}, rField.mapDateFormat).split(' ');
        return `${tokens[1].toString().substring(0, 2)}-${tokens[0]}-${tokens[2]}`;

      }
      return "";
    },
    getFieldData(field, data) {
      if (field.inlineField == 'data' && field.formatDate) {
        return getDateTimePart(this.getJPathValue(field.path, data), field.dateFormat);
      }
    },
    combineDataFields(field, data) {
      let temp = [];
      field.combineFields.forEach(z => {
        let subF = { ...field, ...z }
        if (z.name == "Date") {
          temp.push(this.mapDateToOtherFormat(subF, data));
        }
        if (z.name == "Time") {
          temp.push(this.getFieldData(subF, data));
        }
      })
      return temp.join(',');
    },
    stopOversale() {
      this.showConfrmBox =true;
      setTimeout(() => {   
        this.$refs.uaconfirmbox
          .dialogOpen({
            title: "Stop Oversale!",
            message: `Are you sure you want to stop oversale for the flight ${this.selectedRecord.flightNumber}?`,
            okButtonText: "Yes",
            cancelButtonText: "No",
          })
          .then(async (ok) => {
            this.stopOversaleApi()
          })
          .catch((er) => {});
      }, 50);
      this.showCmtField = false;
    },
    async addMustRidePassenger(tableFields) {
      this.clearAlertMessages();
      let errFound = [];
      tableFields.modalFields.forEach(modal => {
        let modalTableFields = modal[modal.id][0];
        let err = validatInputParams(modalTableFields.tableFields);
        if (err) {
          errFound = [...errFound, ...err];
        }
      });
      if (errFound.length > 0) {
        let alertInfo = {
          alertType: "error",
          alertMessages: [...errFound],
        };
        this.setModalAlertMessages(alertInfo);
        return;
      }
      let uiObj = {};
      tableFields.modalFields.forEach(modal => {
        let mf = modal[modal.id][0];
        mf.tableFields.forEach(f => {
          f.path ? uiObj[f.path] = f.model : ''
        });
      })
      uiObj["carrierCode"] = this.selectedRecord.carrierCode;
      uiObj["flightOrigin"] = this.selectedRecord['flightOrigin'];
      uiObj["flightNumber"] = this.selectedRecord['flightNumber'];
      uiObj["flightDate"] = this.selectedRecord['flightDate'];
      uiObj["employeeId"] = this.getEmployeeId;
      uiObj["station"] = this.selectedRecord['flightOrigin'];
      uiObj["flightDestination"] = this.selectedRecord['flightDestination'];
      uiObj["passengers"] = [];
      uiObj["passengers"].push({ passengerFirstName: uiObj.passengerFirstName, passengerLastName: uiObj.passengerLastName });
      delete uiObj.passengerFirstName;
      delete uiObj.passengerLastName;
      uiObj["channel"] = this.channel;
      uiObj["isMustRide"] = true;
      await this.addMustRidePassengerApi(uiObj, 'Added', tableFields)
      this.$refs.mustRideSrchFilters.reassignFilterFields();
    },
    async updateEditMustRidePassenger(tableFields) {
      this.clearAlertMessages();
      let errFound = [];
      tableFields.modalFields.forEach(modal => {
        let modalTableFields = modal[modal.id][0];
        let err = validatInputParams(modalTableFields.tableFields);
        if (err) {
          errFound = [...errFound, ...err];
        }
      });
      if (errFound.length > 0) {
        let alertInfo = {
          alertType: "error",
          alertMessages: [...errFound],
        };
        this.setModalAlertMessages(alertInfo);
        return;
      }
      let uiObj = {};
      tableFields.modalFields.forEach(modal => {
        let mf = modal[modal.id][0];
        mf.tableFields.forEach(f => {
          f.updtPath ? uiObj[f.updtPath] = f.model : ''
        });
      })
      uiObj["carrierCode"] = this.selectedRecord.carrierCode;
      uiObj["flightOrigin"] = this.selectedRecord['flightOrigin'];
      uiObj["flightNumber"] = this.selectedRecord['flightNumber'];
      uiObj["flightDate"] = this.selectedRecord['flightDate'];
      uiObj["employeeId"] = this.getEmployeeId;
      uiObj["station"] = this.selectedRecord['flightOrigin'];
      uiObj["flightDestination"] = this.selectedRecord['flightDestination'];
      uiObj["passengers"] = [];
      uiObj["passengers"].push({ passengerFirstName: uiObj.passengerFirstName, passengerLastName: uiObj.passengerLastName });
      delete uiObj.passengerFirstName;
      delete uiObj.passengerLastName;
      uiObj["channel"] = this.channel;
      uiObj["isMustRide"] = true;
      await this.addMustRidePassengerApi(uiObj, 'Updated',tableFields );
      this.$refs.mustRideSrchFilters.reassignFilterFields();
    },
   async stopOversaleApi() {
      let isAuthorized = await this.authorizeModule({ operationId: 'deactivateflight', moduleId: 'report',origin:this.selectedRecord.flightOrigin })
      if (!isAuthorized) { return; }
      let apiObj = {
        "carrierCode": this.selectedRecord.carrierCode,
        "flightOrigin": this.selectedRecord.flightOrigin,
        "flightNumber": this.selectedRecord.flightNumber,
        "flightDate": this.selectedRecord.flightDate,
        "employeeId": this.getEmployeeId,
        "station": this.selectedRecord['flightOrigin'],
        "channel": this.channel,
        //"flightComment": "string"
      }
      deactiveFlight(apiObj).then(res => {
        if (res.status == 200) {
          if (res.data.isSuccessful) {
            setTimeout(() => this.setAlertMessages({
              alertType: "success",
              alertMessages: [`Flight  ${this.selectedRecord.flightNumber} Stopped Successfully`]
            }), 500 * 1);
            this.changeStatus('Stopped');
          } else {
            let msgArray = res.data.messages.map(m => m.message);
            this.setAlertMessages({
              alertType: "warning",
              alertMessages: ['Stop Oversale Failed']
            })
            this.setAlertMessages({
              alertType: "warning",
              alertMessages: msgArray
            })
          }
        }

      }).catch(er => {
        this.setAlertMessages({ alertType: 'warning', alertMessages: [`Stop Oversale Failed for Flight ${this.selectedRecord.flightNumber}`] })
      })
    },
    async fetchGetFlightApi(){
      let inpObj= {
          FlightOrigin: this.selectedRecord['flightOrigin'],
          FlightNumber: this.selectedRecord['flightNumber'],
          FlightDate: this.selectedRecord['flightDate'],
        }
      return await this.getFlight(inpObj);
    },
   async fetchReport() {
     await this.getOVSIData({
        inputObject: {
          FlightOrigin: this.selectedRecord['flightOrigin'],
          FlightNumber: this.selectedRecord['flightNumber'],
          FlightDate: this.selectedRecord['flightDate'],
        },
        actionId: this.actionId,
      }).finally(async () => {
        let isAuthorized = await this.authorizeModule({operationId: 'ua_get_flight_report',moduleId: 'report',origin:this.selectedRecord.flightOrigin})
        if(!isAuthorized){return; }
        this.isSHowTemp = true;
        this.tabsObjCopy = JSON.parse(JSON.stringify(this.tabs || []));
        this.CommentInfoPop(false);
      });
      this.getAllAddPassengerList();
    },
    async addPassenger(apiObj, operation, mdlTblFieldsInfo) {
      let isAuthorized = await this.authorizeModule({ operationId: 'addProcessPassenger', moduleId: 'report',isModalErr:true,origin:this.selectedRecord.flightOrigin })
      if (!isAuthorized) { return; }
      await addProcessPassenger(apiObj).then(async(res) => {
        if (res.status == 200) {
          if (res.data.isSuccessful) {
            this.setAlertMessages({
              alertType: "success",
              alertMessages: [`Passenger ${apiObj.passengers[0].passengerFirstName} ${apiObj.passengers[0].passengerLastName} ${operation} successfully`]
            })
            this.ClosePopup();
            this.CloseEditPopup();
             this.fetchGetFlightApi();
            await this.fetchReport();
          } else {
            let msgArray = this.addEditCustomerErrMSG(mdlTblFieldsInfo,res.data.messages);
            this.setModalAlertMessages({
              alertType: "warning",
              alertMessages: msgArray
            })
          }
        }
      }).catch(er => {
        this.handleError(er,true,mdlTblFieldsInfo);
      })
    },

    async addMustRidePassengerApi(apiObj, operation, mdlTblInfoFlds) {
      let isAuthorized = await this.authorizeModule({ operationId: 'addMustride', moduleId: 'report',isModalErr:true ,origin:this.selectedRecord.flightOrigin})
      if (!isAuthorized) { return; }
      await addMustride(apiObj).then(async(res) => {
        if (res.status == 200) {
          if (res.data.isSuccessful) {
            this.setAlertMessages({
              alertType: "success",
              alertMessages: [`Passenger ${apiObj.passengers[0].passengerFirstName} ${apiObj.passengers[0].passengerLastName} ${operation} successfully`]
            })
            this.ClosePopup();
            this.CloseEditPopup();
            this.fetchGetFlightApi();
            await this.fetchReport();
          } else {
            let msgArray = this.addEditCustomerErrMSG(mdlTblInfoFlds,res.data.messages);// will get messages if any error
            this.setModalAlertMessages({
              alertType: "warning",
              alertMessages: msgArray
            })
          }
        }
      }).catch(er => {
        this.handleError(er,true,mdlTblInfoFlds);
      })
    },
     finalizeReport() {
      this.showConfrmBox =true;
      this.showCmtField = true;
      let cmtFlds = this.commentsFooterFields.addCmntFld[0];
      cmtFlds.model='';
      setTimeout(() => {   
        this.$refs.uaconfirmbox
          .dialogOpen({
            title: "Finalize Report!",
            message: `Are you sure you want to finalize the flight ${this.selectedRecord.flightNumber}?`,
            okButtonText: "Yes",
            cancelButtonText: "No",
          })
          .then(async (ok) => {
            if(cmtFlds.model.length > 0){
              await this.addComment(cmtFlds.model)
            }
            await this.finalizeReportApi()          
          })
          .catch((er) => {});
      }, 50);
    },
   async finalizeReportApi() {
      let isAuthorized = await this.authorizeModule({ operationId: 'finalizeflight', moduleId: 'report',origin:this.selectedRecord.flightOrigin })
      if (!isAuthorized) { return; }
      this.displayfinalize = true;
      let apiObj = {
        "carrierCode": this.selectedRecord.carrierComde,
        "flightOrigin": this.selectedRecord.flightOrigin,
        "flightNumber": this.selectedRecord.flightNumber,
        "flightDate": this.selectedRecord['flightDate'],
        "channel": this.channel,
        "employeeName": this.getUserName,
        "employeeId": this.getEmployeeId,
        "station": this.selectedRecord['flightOrigin'],
      }

      await finalizeFlight(apiObj).then(async(res) => {
        if (res.status == 200) {
          if (res.data.isSuccessful) {
            this.finalizeData = res.data.flight;
            this.changeStatus('FINALIZED');
            this.fetchGetFlightApi();
            await this.fetchReport();
            this.toggleShevron();
            setTimeout(() => {
              this.toggleShevron();
            }, 5000);
          } else {
            let msgArray = res.data.messages.map(m => m.message);
            this.setAlertMessages({
              alertType: "warning",
              alertMessages: msgArray
            })
          }

        }

      }).catch(er => {
        this.setAlertMessages({ alertType: 'warning', alertMessages: [`Can't Oversale  Flight ${this.selectedRecord.flightNumber}`] })
      })
    },
    async addComment(modelValue) {
      let isAuthorized = await this.authorizeModule({ operationId: 'addflightcomment', moduleId: 'report',origin:this.selectedRecord.flightOrigin })
      if (!isAuthorized) { return; }
      let apiObj = {
        "carrierCode": this.selectedRecord['carrierCode'],
        "flightOrigin": this.selectedRecord['flightOrigin'],
        "flightNumber": this.selectedRecord['flightNumber'],
        "flightDate": this.selectedRecord['flightDate'],
        "employeeId": this.getEmployeeId,
        "employeeName": this.getUserName,
        "station": this.selectedRecord['flightOrigin'],
        "commentText": modelValue
      }
      await addflightcomment(apiObj)
        .then(res => {
          if (res.status == 200) {
            if (res.data.isSuccessful) {
              let comment = res.data.flightComment;
              comment.employeeName = this.getUserName
              this.commentData.push(comment);
            } else {
              let msgArray = res.data.messages.map(m => m.message);
              this.setAlertMessages({
                alertType: "warning",
                alertMessages: msgArray
              })
            }
          }
        }).catch(er => {
          this.handleError(er);
        });
    },
   async deletePassenger(psngr,index){
      let isAuthorized = await this.authorizeModule({ operationId: 'removeprocessedpassenger', moduleId: 'report',isModalErr:true,origin:this.selectedRecord.flightOrigin})
      if (!isAuthorized) { return; }
      let apiObj = {
        "carrierCode": this.selectedRecord['carrierCode'],
        "flightOrigin": this.selectedRecord['flightOrigin'],
        "flightNumber": this.selectedRecord['flightNumber'],
         "flightDate": this.selectedRecord['flightDate'],
        "employeeId": this.getEmployeeId,
        "station": this.selectedRecord['flightDestination'],
        "pnr": psngr.passenger.pnr,
        "channel": psngr.passenger.transactionDetails.createdChannel,
        "passengers":[
          {
            
      "passengerFirstName": psngr.passenger.firstName,
      "passengerLastName": psngr.passenger.lastName
          }
        ]
      }
      await removeprocessedpassenger(apiObj)
        .then(async(res) => {
          if (res.status == 200) {
            if (res.data.isSuccessful) {
              this.setAlertMessages({
              alertType: "success",
              alertMessages: [`Passenger ${apiObj.passengers[0].passengerFirstName} ${apiObj.passengers[0].passengerLastName} Deleted Successfully`]
            })
            this.CloseDeletePopup();
            this.fetchGetFlightApi();
            await this.fetchReport();
            } else {
              let msgArray = res.data.messages.map(m => m.message);
              this.setModalAlertMessages({
                alertType: "warning",
                alertMessages: msgArray
              })
            }
          }
        }).catch(er => {
          console.error("errrrrr",er)
           this.handleError(er,true);
        });
    },
    // Must ride delete popup
    async deletePsngrMustRide(psngr,index){
      let isAuthorized = await this.authorizeModule({ operationId: 'removemustride', moduleId: 'report',isModalErr:true ,origin:this.selectedRecord.flightOrigin})
      if (!isAuthorized) { return; }
      let apiObj = {
      
        "carrierCode": this.selectedRecord['carrierCode'],
        "flightOrigin": this.selectedRecord['flightOrigin'],
        "flightNumber": this.selectedRecord['flightNumber'],
         "flightDate": this.selectedRecord['flightDate'],
        "employeeId": this.getEmployeeId,
        "station": this.selectedRecord['flightDestination'],
        "pnr": psngr.pnr,
        "channel": psngr.transactionDetails.createdChannel,
        "passengers":[
          {
            
      "passengerFirstName": psngr.firstName,
      "passengerLastName": psngr.lastName
          }
        ]
      }
      await removemustride(apiObj)
        .then(async(res) => {
          if (res.status == 200) {
            if (res.data.isSuccessful) {
              this.setAlertMessages({
                alertType: "success",
                alertMessages: [`Passenger ${apiObj.passengerFirstName} ${apiObj.passengerLastName} Deleted Successfully`]
              })
              this.CloseDeletePopup();
              this.fetchGetFlightApi();
              await this.fetchReport();
              this.$refs.mustRideSrchFilters.reassignFilterFields();
            } else {
              let msgArray = res.data.messages.map(m => m.message);
              this.setModalAlertMessages({
                alertType: "warning",
                alertMessages: msgArray
              })
            }
          }
        }).catch(er => {
          console.error("errrrrr",er)
          this.handleError(er,true);
        });
    },
    getFullName(p) {
      return p.passenger.lastName + ', ' + p.passenger.firstName;
    },
    async getAllAddPassengerList(){
      this.setIsInlineLoading({flag:true,msg: "Please wait while fetching Passengers ..."});
      let apiObj = {
        inputObject:{
          FlightOrigin:this.selectedRecord['flightOrigin'],
          FlightNumber:this.selectedRecord['flightNumber'],
          FlightDate:this.selectedRecord['flightDate'], 
          PassengerType: 'A'
        }
      }
      await getPassengers(apiObj).then(res => {
        if (res.status == 200) {
          if (res.data.isSuccessful) {
            res.data.passengers = res.data.passengers.sort((a,b) =>{
              let firstValue = a.passenger.lastName;
		          let secValue = b.passenger.lastName;
              return firstValue.toString().toLowerCase().localeCompare(
              secValue.toString().toLowerCase());
            })
            this.passengerList = res.data.passengers;
          } else {
            let msgArray = res.data.messages.map(m => m.message);
            this.setModalAlertMessages({
              alertType: "warning",
              alertMessages: msgArray
            })
          }
        }
      }).catch(er => {
        console.error(er)
        //this.handleError(er,true);
      }).finally(()=>this.setIsInlineLoading({flag:false}))
    },
    addEditCustomerErrMSG( mdltblFields,errmessages){
      let errorMsgs = errmessages.map( errmsgobj => {
          let errmsg=errmsgobj.message;
          mdltblFields.modalFields.forEach(modal => {
            let modalTableFields = modal[modal.id][0];
            modalTableFields.tableFields.forEach(tblFld =>{
              if(tblFld.compareFieldNameInErrMSG && errmsg.includes(tblFld.compareFieldNameInErrMSG)) {
                errmsg= errmsg.replace(tblFld.compareFieldNameInErrMSG, tblFld.label);//REPLACE UI FIELD NAME IN API ERROR MESSAGE        
              }
            }); 
          });             
          return errmsg;
        });
        return errorMsgs;
     },
    addEditPassenger(mdlTemp,selMode) {
      this.clearAlertMessages();
      let errFound = [];
      let header= {};
      mdlTemp.modalFields.forEach(modal => {
        modal[modal.id].forEach((modalTblFlds,modalTblFldInd) => {
          if(modalTblFlds.headers[0]?.tableHeaderText){
            header["headerText"]=`${modalTblFlds.headers[0]?.tableHeaderText} ${modalTblFldInd+1}`
            header["headerPrefix"]=`${modalTblFlds.headers[0]?.headerPrefix}`
          }
        let err = validatInputParams(modalTblFlds.tableFields,header);
        if (err) {
          errFound = [...errFound, ...err];
        }
        })
      });
      if(mdlTemp.addNewRowFields && mdlTemp.addNewRowFields.length>0){
        header={};
        mdlTemp.addNewRowFields.forEach((addRowFlds,addRowInd) =>{         
          if(addRowFlds.headers[0]?.tableHeaderText){
            header["headerText"]=`${addRowFlds.headers[0]?.tableHeaderText} ${addRowInd+2}`
            header["headerPrefix"]=`${addRowFlds.headers[0]?.headerPrefix}`
          }
          let err = validatInputParams(addRowFlds.tableFields,header);
          if (err) {
            errFound = [...errFound, ...err];
          }
        })
      }
      if (errFound.length > 0) {
        let alertInfo = {
          alertType: "error",
          alertMessages: [...errFound],
        };
        this.setModalAlertMessages(alertInfo);
        return;
      }
      let uiObj = {};
      mdlTemp.modalFields.forEach(modal => {
        modal[modal.id].forEach(mf => {
          if(mf.showTotalInfo) return;
          let headers = mf.headers[0];
          if(!uiObj.hasOwnProperty(headers.tableRootPath)) uiObj[headers.tableRootPath] =[];
          let tempObj = {};
        if (headers.isAminities) { // header is under  aminities
            tempObj[headers.aminitiesRootPath] = [];
          mf.tableFields.forEach(f => {
            if (f.isAminities) { // field is under  aminities
              let aminObj = { amenityCode: f.filterValue, count: 100 }; aminObj[f.updtPath] = {};
              let amt = f.model.toString().trim();
              let amtCode = getAmtAndCurrencyCode(amt);
              f.combineStructure.forEach(stcr => {
                let value = '';
                if(stcr.target == 'model') {
                  value = amtCode[stcr.id] || stcr.defaultValue;
                } else {
                  value = stcr.defaultValue;
                }
                //let value = stcr.target == 'model' ? parseInt(f.model) : stcr.defaultValue;
                if (value) { aminObj[f.updtPath][stcr.id] = value }
              })
                tempObj[headers.aminitiesRootPath].push(aminObj);
            } else {
              if (f.updtPath) {
                if (f.combineStructure) {
                  let currObj = {};
                  let amt = f.model.toString().trim();
                  let amtCode = getAmtAndCurrencyCode(amt);
                  f.combineStructure.forEach(strctr => {
                    if(strctr.target == 'model') {
                      currObj[strctr.id] = amtCode[strctr.id] || strctr.defaultValue;
                    } else {
                      currObj[strctr.id] = strctr.defaultValue;
                    }
                    //currObj[strctr.id] = strctr.target == 'model' ? f.model : strctr.defaultValue;
                  })
                  headers.tableRootPath ? tempObj[f.updtPath] = currObj : uiObj[f.updtPath] = currObj;
                } else {
                  headers.tableRootPath ? tempObj[f.updtPath] = f.model || f.defaultValue : uiObj[f.updtPath] = f.model || f.defaultValue;
                }
              }
            }
          });
            uiObj[headers.tableRootPath].push(tempObj);
        }
        else {
          mf.tableFields.forEach(f => {
              f.updtPath ? uiObj[f.updtPath] = f.model || f.defaultValue : ''
          });
        }
      })
      })
      if(mdlTemp.addNewRowFields && mdlTemp.addNewRowFields.length>0){
        mdlTemp.addNewRowFields.forEach(addRowFlds =>{
          let headers = addRowFlds.headers[0];
          let newRowFldObj = {};
        if (headers.isAminities) { // header is under  aminities
          newRowFldObj[headers.aminitiesRootPath] = [];
          addRowFlds.tableFields.forEach(f => {
            if (f.isAminities) { // field is under  aminities
              let aminObj = { amenityCode: f.amenityCode, count: 100 }; aminObj[f.updtPath] = {};
              let amt = f.model?f.model.toString().trim():"";
              let amtCode = getAmtAndCurrencyCode(amt);
              f.combineStructure.forEach(stcr => {
                let value = '';
                if(stcr.target == 'model') {
                  value = amtCode[stcr.id] || stcr.defaultValue;
                } else {
                  value = stcr.defaultValue;
                }
                //let value = stcr.target == 'model' ? parseInt(f.model) : stcr.defaultValue;
                if (value) { aminObj[f.updtPath][stcr.id] = value }
              })
              newRowFldObj[headers.aminitiesRootPath].push(aminObj);
            } else {
              if (f.updtPath) {
                if (f.combineStructure) {
                  let currObj = {};
                  let amt = f.model?f.model.toString().trim():undefined;
                  let amtCode = getAmtAndCurrencyCode(amt);
                  f.combineStructure.forEach(strctr => {
                    if(strctr.target == 'model') {
                      currObj[strctr.id] = amtCode[strctr.id] || strctr.defaultValue;
                    } else {
                      currObj[strctr.id] = strctr.defaultValue;
                    }
                    //currObj[strctr.id] = strctr.target == 'model' ? f.model : strctr.defaultValue;
                  })
                  headers.tableRootPath ? newRowFldObj[f.updtPath] = currObj : uiObj[f.updtPath] = currObj;
                } else {
                  headers.tableRootPath ? newRowFldObj[f.updtPath] = f.model || f.defaultValue : uiObj[f.updtPath] = f.model || f.defaultValue ;
                }
              }
            }
          });
            }
            uiObj[headers.tableRootPath].push(newRowFldObj);
        })
      }
      uiObj["carrierCode"] = this.selectedRecord.carrierCode;
      uiObj["flightOrigin"] = this.selectedRecord['flightOrigin'];
      uiObj["flightNumber"] = this.selectedRecord['flightNumber'];
      uiObj["flightDate"] = this.selectedRecord['flightDate'];
      uiObj["employeeId"] = this.getEmployeeId;
      uiObj["station"] = this.selectedRecord['flightOrigin'];
      uiObj["channel"] = this.channel;
      uiObj["passengers"] = [];
      uiObj["passengers"].push({ passengerFirstName: uiObj.passengerFirstName, passengerLastName: uiObj.passengerLastName })
      delete uiObj.passengerFirstName;
      delete uiObj.passengerLastName;
      this.addPassenger(uiObj, selMode, mdlTemp)
    },
    async updateComment(eve) {
      let isAuthorized = await this.authorizeModule({ operationId: 'updateflightcomment', moduleId: 'report',origin:this.selectedRecord.flightOrigin })
      if (!isAuthorized) { return; }
      let { event, reportCommentsInfo } = eve
      let modelValue = event;
      let apiObj = {
        "carrierCode": this.selectedRecord['carrierCode'],
        "flightOrigin": this.selectedRecord['flightOrigin'],
        "flightNumber": this.selectedRecord['flightNumber'],
        "flightDate": this.selectedRecord['flightDate'],
        "employeeId": this.getEmployeeId,
        "employeeName": this.getUserName,
        "station": this.selectedRecord['flightOrigin'],
        "commentText": modelValue,
        "commentId": reportCommentsInfo.commentId,
      }
      updateflightcomment(apiObj)
        .then(res => {
          if (res.status == 200) {
            if (res.data.isSuccessful) {
              this.CommentInfoPop(true);

            } else {
              let msgArray = res.data.messages.map(m => m.message);
              this.setAlertMessages({
                alertType: "warning",
                alertMessages: msgArray
              })
            }
          }
        }).catch(er => {
          this.handleError(er);
        });
    },
    changeStatus(status) {
      let inObj = JSON.parse(JSON.stringify(this.selectedRecord || []));
      inObj['oversaleStatus'] = status;
      this.setSelectedRecord(inObj);
    },
    getStatusValue() {
      let rField= this.commentsFooterFields.statusField;
      let actualValue = this.getJPathValue(rField.path, this.selectedRecord) || this.getJPathValue(rField.overViewPath, this.selectedRecord);
      return actualValue.toUpperCase();

    },
    extractDataForPassCard(p) {
      let obj = {
        ...p,
        flightDestination: this.searchOVSIData.flightDestination,

      };
      return obj;
    },
    getPssngrCardData(pssngr){
      let filteredCardData = this.extractDataForPassCard(pssngr)
      filteredCardData["totalAmenitiesCompensated"] =[];
      //let amenityCodes = ["M1", "M2", "M3", "T", "H"];
      let amenityCodes = this.tabs[this.selectedTabIndex].cardsConfig[0].cardTemp.aminities //fetching amenity codes from json
      let totalAmmObj = {};
      let totalEtc= 0;
      let totalDraft= 0;
      let totalMiles= 0;
      filteredCardData.compensation.issuances.forEach(issData =>{
        let ams = issData.amenitiesCompensated || [];
        amenityCodes.forEach(filterCode => {
          let amenities = ams.filter((item)=>{
            return item.amenityCode == filterCode; // push respective amenities compensated values
          })
          let totalAmount = 0;
          if(amenities && amenities.length>0){
            let amenitiesItem = amenities[0];
             let finalAminObj ={"amenityCode":filterCode, "currencyCode" : amenitiesItem.amountCompensated.currencyCode}
              if(totalAmmObj.hasOwnProperty(amenitiesItem.amenityCode)){ 
                let amObj = totalAmmObj[amenitiesItem.amenityCode];
                totalAmount = parseFloat(amObj["amount"]) + parseFloat(amenitiesItem.amountCompensated.amount);
                finalAminObj["amount"]= Number.isInteger(totalAmount) ? totalAmount : parseFloat(totalAmount).toFixed(2);
              } else {
                finalAminObj["amount"] = Number.isInteger(amenitiesItem.amountCompensated.amount) ?  
                amenitiesItem.amountCompensated.amount : parseFloat(amenitiesItem.amountCompensated.amount).toFixed(2);
              }
              totalAmmObj[filterCode] = finalAminObj;
          }
        });
        filteredCardData["totalAmenitiesCompensated"] = totalAmmObj; //pushing the Amenities totals
        //pushing the total Miles
        totalMiles = totalMiles + issData.processedMiles
        filteredCardData["totalProcessedMiles"] = totalMiles;
        //pushing the total ETC
        totalEtc = totalEtc + issData.processedEtc.amount
        filteredCardData["totalProcessedEtc"] = {"currencyCode": issData.processedEtc.currencyCode,"amount":Number.isInteger(totalEtc) ? totalEtc : parseFloat(totalEtc).toFixed(2)};
        //pushing the total Draft
        totalDraft = totalDraft + issData.draftAmount.amount
        filteredCardData["totalDraftAmount"] = {"currencyCode": issData.draftAmount.currencyCode,"amount": Number.isInteger(totalDraft) ? totalDraft : parseFloat(totalDraft).toFixed(2) };
      })
      return filteredCardData;
    },
    toggleIcon() {
      this.showIcon = !this.showIcon;
    },
    handleSelectTab(tab, tabIndex) {
      this.ResetSelectTab();
      this.selectedTabIndex = tabIndex;
      this.selectTab(tab);
      this.updatePrevOptions(JSON.parse(JSON.stringify(this.getPrevOptions || [])));
      this.isShowSRowCards=true;
      this.isShowFRowCards=true;
    },
    selectTab(tab) {

    },
    ResetSelectTab() {
      this.selectedTabIndex = '';
      this.addPopup = false;
      this.manualAddPop = false;
      this.isAllPassengerList = false;
      this.mustrideinfopop = false;
      this.editPopup = false;
      this.mouseDetectedAllPsnrModal = false
    },
    extractData(record, tblDetail) {
      if (tblDetail[tblDetail.id][0].headers[0].isCabinWiseData) {
        return this.getCabinWiseData(record.cabinTotals, tblDetail[tblDetail.id][0].headers[0]);
      } else {
        if(tblDetail.id == "totalcustomers") {
          record.downgradeTotalCount = this.filterUpgradeDownGrade?.filter(psngr => {
                return psngr.passenger.deniedBoardingCode == 'B';
              }).length;
          record.upgradeTotalCount = this.filterUpgradeDownGrade?.filter(psngr => {
              return psngr.passenger.deniedBoardingCode == 'A';
            }).length;
        }        
        return [record];
      }
    },
    getCabinWiseData(cabins, headers) {
      if(!cabins) {return [];}
      let cabinData = {}
      let cabinWiseData = [];
      if (headers?.isCabinWiseData) {
        for (let i = 1; i < headers?.headerValues?.length; i++) {
          let filteredCabinData = cabins?.filter((item) => {
            return item?.cabinCode == headers?.headerValues[i];
          })
          cabinData[headers?.headerValues[i]] = filteredCabinData?.length > 0 ? filteredCabinData[0] : {};
        }
        cabinWiseData.push(cabinData);
      }
      return cabinWiseData;
    },
    getExistingIssuanceFlds(psngrData,mdlTblFlds,mdlTblCopyFlds){
      let issuaceDetails = mdlTblFlds.modalTemp.modalFields[1];
          let issuancLength = psngrData.compensation.issuances.length;
          if(issuancLength > 1){ 
            //AS METADATA OF ISSUANCE ARRAY CONTAINS ONE ISSUANCE FILEDS 
            //SO IF ISSUANCE GREATER THAN ONE THEN PUSH INTO SAME ISSUANCE FILEDS ARRAY WITH (TOTAL ISSUANCE LENGTH  MINUS ONE )TIMES
            psngrData.compensation.issuances.forEach((issuance, ind) =>{
              if((issuancLength-1) <= ind) return;
              let mdlFldsInfo = JSON.parse(JSON.stringify(mdlTblCopyFlds.modalTemp.modalFields[1][issuaceDetails.id][0] || []))
              //mdlFldsInfo.headers[0].deleteimg= true,
              issuaceDetails[issuaceDetails.id].push(mdlFldsInfo) 
            });
          }
          return issuaceDetails;
    },
    toggleAddPop(flag,bindData,data) {
      this.clearAlertMessages();
      this.closeIsAllPassengerList();
      data = this.getSelectedPasngr[0];
      //TO ADD EXISTING MULTIPLE ISSUANCES
      if(data.compensation && Object.keys(data.compensation).length>0 && this.tabs[this.selectedTabIndex].addTableFields[0].modalTemp.manipulateModalFieldASPerData){
        if(data.compensation.issuances && data.compensation.issuances.length >0){
          this.getExistingIssuanceFlds(data,this.tabs[this.selectedTabIndex].addTableFields[0],this.tabsObjCopy[this.selectedTabIndex].addTableFields[0]);
        }
      }
      if(bindData){ //TO SET THE TOTAL VALUES
        this.setAmmentiesTotalValues(this.tabs[this.selectedTabIndex].addTableFields[0].modalTemp, data);
      }
      this.addPopup = true
    },
    ClosePopup() {
      this.tabs[this.selectedTabIndex].addTableFields[0].modalTemp = JSON.parse(JSON.stringify(this.tabsObjCopy[this.selectedTabIndex].addTableFields[0].modalTemp || []));
      this.addPopup = false;
      this.manualAddPop = false;
      this.mustrideinfopop = false;
    },
    toggleManualAdd() {
      this.closeIsAllPassengerList();
      this.clearAlertMessages();
      this.manualAddPop = true
    },
   async mustRideInfoPop() {
      if (this.getStatusValue() == 'STOPPED') { return; }
      let isAuthorized = await this.authorizeModule({ operationId: 'addMustride', moduleId: 'report',origin:this.selectedRecord.flightOrigin })
      if (!isAuthorized) { return; }
      this.clearAlertMessages();
      this.mustrideinfopop = true;
      this.CloseCommentInfoPop();

    },
    toggleShevron() {
      this.space = !this.space;
    },
    CommentInfoPop(flag) { // closing other popup while opening comment
      this.setIsViewDetails(false);
      this.closeIsAllPassengerList();
      this.CloseEditPopup();
      this.ClosePopup();
      let apiObj = {
        "carrierCode": this.selectedRecord['carrierCode'],
        "flightOrigin": this.selectedRecord['flightOrigin'],
        "flightNumber": this.selectedRecord['flightNumber'],
        "flightDate": this.selectedRecord['flightDate'],
      }
      getFlightComments(apiObj)
        .then(res => {
          if (res.status == 200) {
            if (res.data.isSuccessful) {
              this.commentData = [];
              if(res.data.flightComments && (res.data.flightComments).length >0){
              res.data.flightComments = res.data.flightComments.sort( (a, b) => { // Sort hierarchy:  By created Date Time
                let aDate =  new Date(a.createdDateTime);
                let bDate = new Date(b.createdDateTime);
                return aDate - bDate;  // Compare first value then second
              })
            }
              res.data.flightComments?.forEach(cmt => { 
                if(this.getEmployeeId == cmt.employeeId)
                {cmt.employeeName=this.getUserName;} 
                this.commentData.push(cmt); 
              });
              this.commentspop = flag;
            } else {
              let msgArray = res.data.messages.map(m => m.message);
              this.setAlertMessages({
                alertType: "warning",
                alertMessages: msgArray
              })
            }
          }
        }).catch(er => {
          //this.$refs.uaoslcard.forEach(trgt=>trgt.CloseDeletePopup());
          this.handleError(er);
        });
    },
    handleError(er, isSHowModalError, mdlTableFields){
      let response = er.response;
      if (response.data?.messages) {
        let msgArray = this.addEditCustomerErrMSG(mdlTableFields,response.data.messages);
        if (isSHowModalError) {
          this.setModalAlertMessages({
            alertType: "warning",
            alertMessages: msgArray
          })
        } else {
          this.setAlertMessages({
            alertType: "warning",
            alertMessages: msgArray
          })
        }
      } else {
        if (isSHowModalError) {
          this.setModalAlertMessages({
            alertType: this.appInfo.errorMessageList.SERVER_ERROR.errorType,
            alertMessages: [this.appInfo.errorMessageList.SERVER_ERROR.text]
          })
        } else {
          this.setAlertMessages({
            alertType: this.appInfo.errorMessageList.SERVER_ERROR.errorType,
            alertMessages: [this.appInfo.errorMessageList.SERVER_ERROR.text]
          });
        }


      }
    },
    CloseCommentInfoPop() {
      this.commentspop = false
    },
    enableEdit(flag,bindData, data, isEditFromViewPopup=false) {
      this.clearAlertMessages();
      this.CloseCommentInfoPop();
      this.closeIsAllPassengerList();      
      this.setIsViewDetails(false); 
      if(!isEditFromViewPopup){
        //TO ADD EXISTING MULTIPLE ISSUANCES      
        if(this.tabs[this.selectedTabIndex].editTableFields[0].modalTemp.manipulateModalFieldASPerData){
          if(data.compensation.issuances && data.compensation.issuances.length >0){
            this.getExistingIssuanceFlds(data,this.tabs[this.selectedTabIndex].editTableFields[0],this.tabsObjCopy[this.selectedTabIndex].editTableFields[0]);
          }
        }
        if(bindData){//TO SET THE TOTAL VALUES 
          this.setAmmentiesTotalValues(this.tabs[this.selectedTabIndex].editTableFields[0].modalTemp, data);
        }
      }
      this.selectedModal = flag;    
      this.editPopup = true;  
    },
    CloseEditPopup() {
      this.setIsViewDetails(false);
      this.tabs[this.selectedTabIndex].editTableFields[0].modalTemp = JSON.parse(JSON.stringify(this.tabsObjCopy[this.selectedTabIndex].editTableFields[0].modalTemp || []));
      this.editPopup = false;
    },
    CloseDeletePopup(){
      this.oslDeletePop = false;
    },
    enableDelete(flag){
      this.clearAlertMessages();
      this.selectedModal = flag;
      this.oslDeletePop = true;
      this.CommentInfoPop(false);
      this.closeIsAllPassengerList();
      this.setIsViewDetails(false);
    },
    enableViewPopup(flag,bindData, data){
      this.clearAlertMessages();
      this.CloseCommentInfoPop();
      this.closeIsAllPassengerList();
      this.editPopup=false;     
      this.setIsViewDetails(false); 
      //TO ADD EXISTING MULTIPLE ISSUANCES 
      if(this.tabs[this.selectedTabIndex].editTableFields[0].modalTemp.manipulateModalFieldASPerData){
        if(data.compensation.issuances && data.compensation.issuances.length >0){
          this.getExistingIssuanceFlds(data,this.tabs[this.selectedTabIndex].editTableFields[0],this.tabsObjCopy[this.selectedTabIndex].editTableFields[0]);
        }
      }
      if(bindData){//TO SET THE TOTAL VALUES
        this.setAmmentiesTotalValues(this.tabs[this.selectedTabIndex].editTableFields[0].modalTemp, data);
      }
      this.selectedModal = flag;
      this.setIsViewDetails(true);
    },
   async enableIsAllPassengerList(){
      this.mouseDetectedAllPsnrModal = false;
      let isAuthorized = await this.authorizeModule({ operationId: 'addProcessPassenger', moduleId: 'report',origin:this.selectedRecord.flightOrigin })
      if (!isAuthorized) { return; }
      this.clearAlertMessages();
      this.setIsViewDetails(false);
      this.CloseEditPopup();
      if (this.getStatusValue() == 'STOPPED') { return; }
      this.selectedOption= '';
      this.modalSelectedSearchValue = '';
      this.isAllPassengerList = true;
      setTimeout(() =>  document.addEventListener("click",this.handleOutSideClick),100);//TO CLOSE PASSENGER POPUP ON OUSIDE MODAL CLICK
    },
    closeIsAllPassengerList(){
      this.isAllPassengerList = false;
      this.mouseDetectedAllPsnrModal = false;
    },
    toggleChevron(selType) {
      if(selType == 'PI'+this.selectedTabIndex){
        this.isShowFRowCards = !this.isShowFRowCards;
      } else{
        this.isShowSRowCards = !this.isShowSRowCards;
      }
    },
    genericHandler(eventName,selOpt) {
      if (eventName.name === "cancel"){
        this.closeIsAllPassengerList();
      }
      else if (eventName.name === "addNext") {
        this.toggleAddPop(selOpt,true);
      } else {
        this.toggleManualAdd();
      }
    },
  }
};
</script>
<style scoped>
.u-margin-right-58 {
  margin-right: 58px;
}

.up-arrow {
  margin-bottom: 20px;
  /* Adjust the space as needed */
}

.down-arrow {
  margin-bottom: 10px;
  /* Adjust the space as needed */
}

.footer-space {
  /* Add styling for the space below the footer */
  padding-bottom: 100px !important;
  /* Adjust as needed */
  /* padding-top: 20px !important; */
  background-color: #f0f0f0;

}</style>
 
 
 