<template>
    <span
      class="u-text-white u-pointer"
      @click="exportFunc" id="export_excel"
    > 
      <img
        src="@/assets/img/download_white.png"
        class="u-menuImgSml u-border-0 u-transparent u-pointer u-margin-0"
        name="Export"
        alt="export_data"
      />     
      Export   
    </span>
    <UAModal
        v-if="showExportOptionModalPopup" 
        @close="showExportOptionModalPopup=!showExportOptionModalPopup"
        :modalConfigData="exportToExcelConfig.exportOptionPopupConfig.modalFields"
        :modalBtnInfo="exportToExcelConfig.exportOptionPopupConfig.modalbtnInfo"
        tblData=[]
        @submitMdlData="handleModalOkBtn"
    />
</template>

<script>
import { mapActions, mapMutations, mapState } from 'vuex';
import { exportPageDataToExcelFile } from "../helpers/flightReportExportToExcel";
import UAModal from "../components/UAModal.vue";
export default {
    name: 'UAExport',
    props: [],
    components:{
        UAModal
    },
    data(){
        return {
            showExportOptionModalPopup: false
        }
    },
    async created(){
        await this.getExportDetails('flightMangementExcelReportInfo');
    },
    computed: {
        ...mapState({
            selectedRecord: state => state.ovsiDefaultModule.selectedRecord,
            searchOVSIData: state=> state.ovsiDefaultModule.searchOVSIData,
            exportToExcelConfig: state=> state.exportModule.exportToExcelConfig,
            applicationInfoDetails: state=> state.ovsiDefaultModule.applicationInfoDetails,
            entityDisplayDetails: (state) => state.ovsiDefaultModule.entityDisplayDetails
        })
    },
    methods: {
        ...mapMutations(["setDisableExport"]),
        ...mapActions(["getExportDetails"]),
        exportFunc(){
            this.setDisableExport(false);
            this.exportToExcelConfig.exportOptionPopupConfig.modalFields.forEach(element => {
                if(element.fieldType = "UACheckbox") {
                    element.checkedItems = [];
                    element.checkedItems.push(this.entityDisplayDetails.id);
                }                    
            });
            this.showExportOptionModalPopup=!this.showExportOptionModalPopup
        },
        handleModalOkBtn(exportOptions){
            exportOptions.currPageId = this.entityDisplayDetails.id;
            exportPageDataToExcelFile(exportOptions, this.searchOVSIData, this.exportToExcelConfig, this.selectedRecord, this.applicationInfoDetails);
        }
    }

}
</script>
