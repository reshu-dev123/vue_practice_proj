<template>
  <div :class="['u-card u-margin-left-14 u-row u-white u-section u-cardView ',cardCssClass]"
    style="width:97%">
    <div :class="['u-row u-top-border-radius', cssClass]" v-if="label">
      <h6 :class="['u-text-0 u-section-1 u-padding-small u-margin-top-0', labelCss]">
        <label><a v-if="icon" class="u-padding-right-4"><img :src="getImageUrl(icon)" /></a><a>{{ label }}</a>
        <a v-if="secondaryLabel" class="u-right">{{ secondaryLabel }}</a>
        </label>
        <label>
        <a v-if="btnText"  class="u-right">
        <UAButton :id ="id?id+'_tgl_btn':'_tgl_btn'" :class="btnCssClass" @click="$emit('toggleIcon')" >{{ btnText }}<img :src="getImageUrl(icon1)" /></UAButton></a>
        </label>
      </h6>
    </div>
    <div v-if="reportCommentsInfo" class=" u-row u-padding-small" :id ="'cmt_'+id">
      <label class="u-col u-msmall u-fnt-bld">{{ reportCommentsInfo.employeeName }}</label>
      <label class="u-col u-small">{{ reportCommentsInfo.employeeId }}</label>
      <label v-if="!isEditClicked" class="u-col u-panel-xsmall">{{ reportCommentsInfo.commentText }}</label>
      <div v-if="isEditClicked" class="u-row">
        <UATextarea cssClass="u-minheight-60 u-min-width u-max-width" :id="'edit_comment_text_'+id"
        @update:modelValue="
                  updateEditFields($event)" 
        :modelValue="reportCommentsInfo.commentText" >
              </UATextarea>
        </div>
        <template v-for="(cmtField, cmtIndex) in addCustomerCommentsInfo" :key="cmtIndex">
      <label :class="['u-small u-text-3 u-panel-xsmall',this.getEmployeeId == reportCommentsInfo.employeeId?'u-col l8 u-left':'u-right']">
        {{ combineDataFields(cmtField,reportCommentsInfo) }}</label>
        </template>
      <div v-if="this.getEmployeeId == reportCommentsInfo.employeeId">
      <div v-if="!isEditClicked" class="u-right l4">
        <span class="u-tooltip tip-edit-bottom-buttons" :data-tooltip="'Edit'">
        <img src="@/assets/img/edit.png" alt="edit_comment_img" class="u-menuImgSml u-border-0 u-transparent"
        :id="'edit_comment_icon_'+id"  @click="enableEdit(data, dkey)" />
       </span>  
          <!-- <span class="u-tooltip tip-bottom-buttons" :data-tooltip="''">
          <img src="@/assets/img/more_vert.png" alt class="u-menuImgSml u-border-0 u-transparent"
         />
          </span>  -->
      </div>
      <div v-else class="u-right">
        <span class="u-tooltip tip-edit-bottom-buttons" :data-tooltip="'Cancel'">
          <img src="@/assets/img/reset.png" alt class="u-menuImgSml u-border-0 u-transparent"
          :id="'reset_edited_comment_'+id" @click="cancelUpdateComment()" />
        </span>
        <span class="u-tooltip tip-update-bottom-buttons" :data-tooltip="'Update'">
        <img src="@/assets/img/save.png" alt class="u-menuImgSml u-border-0 u-transparent"
        :id="'save_updated_comment'+id"  @click="updateComment()" />
        </span>
      </div>
      </div>
    </div>
    <div class="u-row u-center" v-if="fields">
      <UATable id="hubs_tbl" :fields="fields" :data="records" imgpath="poi.png" @navigateScreen="genericHandler" />
    </div>
    <div class="u-row u-center u-padding-small u-printClass" v-if="chartSections">
      <UAChart  :height="chartSections.height" :width="chartSections.width" :chartId="'ovsi_chart_'+id"
                :chartData="chartData" :chartOptions="chartOptions" :chartType="chartSections.chartType"
                :plugins="chartPlugins"/>
    </div>
    <div :class="['u-row']" v-if="cardTable && cardTable.cardFields && cardTable.cardFields.length > 0">
      <template v-for="(cardData, cardIndex) in cardTable.cardFields" :key="cardIndex">
        <div :class="[cardData.styles.cardDivCss]">
                    <component :is="cardData.ComponentType" :tblHeaders="cardData[cardData.id][0].headers[0]" :tableData="tableData"
            :tableFields="cardData[cardData.id][0].tableFields" :sectionHeader="cardData[cardData.id][0].sectionHeader"
            :tableBorderCSS="cardData.styles.tableBorderCSS" @toggleEdit="toggleEdit()" isActionDisplay=true @deletePsngr="deletePsngr" 
            @viewDetails="$emit('viewDetails')" :actionId="label.replaceAll(' ', '_').toLowerCase()" />
        </div>
      </template>
    </div>
    <div v-if="data" class="u-row u-center" style="cursor:auto">
      <h2 :class="[' u-text-nyblue u-break-content',getDynamicFontSize(data)]"><b>{{ data }}</b></h2>
      <div class="u-row u-margin-bottom" v-if="actions">
        <span>    
          <template v-for="(action, actionIndex) in actions" :key="actionIndex">
            <UAButton :class="action.cssClass" @click="genericHandler(action, data)" :id="text.replaceAll(' ', '_').toLowerCase()" >{{ text }}<img
                :src="getImageUrl(action.icon)" /></UAButton>
          </template>
        </span>
      </div>
    </div>
  </div>
</template>

<script>
import { mapState, mapGetters, mapActions, mapMutations } from "vuex";
import { getImageUrl, mapDateToOtherFormat,getFieldData,getJPathvalue } from '../helpers/utilities.js';
import UATable from './UATable.vue';
import UAOvsiTableColLayout from './UAOvsiTableColLayout.vue';
import UAConfirmModal from './UAConfirmModal.vue'
import UAButton from './UAButton.vue';
import UATextarea from "@/components/UATextarea.vue";
import UAChart from "./UAChart.vue";
export default {
  name: 'UAOSLCard',
  components: { UATable, UAOvsiTableColLayout, UAConfirmModal, UAButton,UATextarea,UAChart },
  props: ['label', 'secondaryLabel', 'cssClass', 'data', 'link', 'fields', 'records', 'labelCss',
    'tableData', 'name', 'uid', 'reportCommentsInfo', 'date', 'text', 'actions', 'cardTable','cardCssClass',
    'icon','icon1','chartData','chartOptions','chartSections','addCustomerCommentsInfo','btnText','btnCssClass','chartPlugins',"id"],
  emits:["navigateScreen","update_Comment","enableEdit","deletePsngr","viewDetails","toggleIcon"],
  data(){
    return{
      isEditClicked:false
    }
  },
  computed: {
    ...mapState({
      selectedRecord: state => state.ovsiDefaultModule.selectedRecord,
      sections: (state) => state.ovsiDefaultModule.entityDisplayDetails.Layouts[0].InnerLayout.sections,
    }),
    ...mapGetters(['getEmployeeId'])
  },
  methods: {
    ...mapMutations(["setSelectedMenuId"]),
    getDynamicFontSize(data) {
      let dtSz = data.length;
      if (dtSz > 4 && dtSz <13)
        return 'u-xxxlarge';
      if (dtSz >= 13 && dtSz <=16)
        return 'u-xxlarge';
      if (dtSz > 16 && dtSz <= 19)
        return 'fnt-size-30';
      if (dtSz > 16 && dtSz <= 19)
        return 'fnt-size-30';
      if (dtSz > 19)
        return 'u-xlarge'
      return 'u-jumbo lf mf sf'

    },
    combineDataFields(field, data) {
      let temp = [];
      field.combineFields.forEach(z => {
        let subF = { ...field, ...z }
        if (z.name == "Date") {
          temp.push(mapDateToOtherFormat(subF, data));
        }
        if (z.name == "Time") {
          //temp.push(getFieldData(subF, data));
          let options = subF.mapTimeFormat;
          if(options.timeZone == 'local'){
            options.timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
          }
          temp.push(new Date(getJPathvalue(subF.path,data)).toLocaleTimeString({},options))
        }
      })
      return temp.join(',');
    },
    enableEdit() {
      this.isEditClicked=true;
    },
    toggleEdit() {
      this.$emit('enableEdit');
    },
    deletePsngr() {
      this.$emit('deletePsngr');
    },
    async genericHandler(actionBtnInfo, data, dataIndex) {
      let { events } = actionBtnInfo;
      this.selectedDataIndex = dataIndex;
      if (events.name == "navigateToOtherScreen") {
        this.$emit('navigateScreen', actionBtnInfo, data);
        this.setSelectedMenuId(actionBtnInfo.navigationInfo.navigateToID);
      }
    },
    getImageUrl(params) {
      return getImageUrl(params);
    },
    updateEditFields(event){
      this.modelValue=event
    },
    updateComment() {
      this.$emit("update_Comment",this.modelValue)
      this.isEditClicked=false;
    },
    cancelUpdateComment(){
      this.isEditClicked=false;
    }
  },
}
</script>

<style></style>