<template>
    <div>
  <span class="u-text-white u-pointer" @click="copyLink" :id="`copy_link_${selectedMenuId}`">
    <img 
                    src="@/assets/img/link.png"
                    alt
                    class="u-menuImgSml u-border-0 u-transparent u-margin-0 u-margin-right-2px"
                    :title="`Copy link for ${selectedMenuId} screen`"
                  />URL{{formURL}}
  </span>
  <span class="tooltiptext_copy_url" v-if="isCopied">Link Copied!</span>
</div>
</template>

<script>
import { mapState } from 'vuex';
import { copyToClipBoard } from "../helpers/utilities";
import UAButton from './UAButton.vue';
export default {
    name: 'UACopyURL',
    data(){
        return {
            isCopied:false
        }
    },
    props: ['disableQuery'],
    components: {
        UAButton
    },
    computed: {
        ...mapState({
            selectedRecord: state => state.ovsiDefaultModule.selectedRecord,
            selectedMenuId: state=>state.menuModule.selectedMenuId
        }),
        formURL(){
            let query= this.disableQuery?'':`?fltnum=${this.selectedRecord['flightNumber']}&fltOrigin=${this.selectedRecord['flightOrigin']}&fltDt=${this.selectedRecord['flightDate']}`;
            this.$router.push(`${this.selectedMenuId}${this.selectedRecord?query:''}`);
        }
    },
    beforeUnmount(){
        this.$router.push('/');
    },
    methods: {
        copyLink(){
      let query= this.disableQuery?'':`?fltnum=${this.selectedRecord['flightNumber']}&fltOrigin=${this.selectedRecord['flightOrigin']}&fltDt=${this.selectedRecord['flightDate']}`;
      let link = `${window.location.origin}/${this.selectedMenuId}${this.selectedRecord?query:''}`;
      //this.$router.push(`${this.selectedMenuId}${query}`)
      copyToClipBoard(link)
      this.isCopied=true;
      setTimeout(() => {
        this.isCopied=false;//to close title popup in 1 sec
      }, 1000);
    },
    }

}
</script>

<style>
.tooltip {
    position: fixed;
    /*display: inline-block;
    border-bottom: 1px dotted black; */
  }
  .tooltiptext_copy_url {
    width: 120px;
    background-color: rgb(255, 255, 255);
    color: #0c0c0c;
    text-align: center;
    border-radius: 6px;
    padding: 5px 0;
  
    /* Position the tooltip */
    position: absolute;
    z-index: 1;
    top: 94px;
    right: 10px;
  }
</style>