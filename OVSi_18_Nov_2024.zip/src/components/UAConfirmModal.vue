<template>
  <div class="u-modal u-col u-overlay" :style="[deletewithcard?'padding-top:0px':'','display: block']">
    <UAAlertMessage v-once/>
       <div class="u-round u-modal-confirm-content">
         <div class="u-row">
           <div :class="['u-col l11 m11 s11 u-col u-medium u-fnt-bld u-ht-15 u-left-align']">
             <label :class="['u-ls-ws u-panel-xsmall u-section-1']">
                {{title}}
             </label>
          </div>
           <div class="u-col l1 m1 s1">
                 <UAButton
                   @click="$emit('close')"
                   cssClass=" u-transparent u-medium u-primary-inv-border u-fnt-bld u-right u-pointer"
                 >
                  X
                 </UAButton>
           </div>
        </div>
       <div class="u-row">
           <label :class="['u-ls-ws1 u-panel-xsmall u-section-1']">
             Are you sure want to delete this customer?
           </label>
       </div>
       <div class="u-row">
           <div class="u-col l12 m12 s12 u-padding-left-14">
                   <UAOSLCardConfirmation :label="label" :secondaryLabel="secondaryLabel" details=true
                   :cssClass="cardTable.cssClass" 
                   :labelCss="cardTable.textCssclass"
                   :cardTable="cardTable" 
                   :tableData="tableData"  
                   @linkClicked="handleLinkClicked(card.event)"
                   />       
           </div>
       </div>
 
         <div class="u-row u-pad-0 u-section-1">
           <div class="u-col l12 m12 s12">
             <div class="u-row-padding u-pad-0 u-center">
               <div class="u-col l4 m4 s4">
                 <UAButton
                 @click="$emit('close')"
                   cssClass="u-button u-round u-secondary-cst u-col"
                 >
                  Cancel
                 </UAButton>
               </div>
               <div class="u-col l8 m8 s8">
                 <UAButton cssClass="u-red u-button u-round u-col" 
                 @click="$emit('deleteCard')"
                   > Delete Customer
                 </UAButton>
               </div>
             </div>
           </div>
         </div>
       </div>
   </div>
   
 </template>
 <script>
 import { mapState,mapMutations, mapGetters } from 'vuex';
 import UAButton from "@/components/UAButton.vue";
 import UAOSLCardConfirmation from "@/components/UAOSLCardConfirmation.vue";
import UAAlertMessage from './UAAlertMessage.vue';
 export default {
     name: "UAConfirmModal",
      components: {
       UAButton,
       UAOSLCardConfirmation,
       UAAlertMessage
     },
     computed: {
     ...mapState({
       cardsConfig: state => state.ovsiDefaultModule.cardsConfig,
     }),},
 
     data() {
       return {
         dialogVisible: false,
         resolvPromise: null,
         rejectPromise: null,
         message: null,
         okButtonText: null,
         cancelButtonText: null,
       };
       
     },
     props: ['title','deletewithcard','cardTable','tableData','secondaryLabel','label'],
 
     methods: {
       ok() {
         this.dialogVisible = false;
       },
       cancel() {
         this.dialogVisible = false;
       },
     },
   }
 </script>
 <style>
 </style>
 
 