<template>
  <div class="
       u-display-container u-fnt-bld  u-small  u-padding-small-1 u-small "
    >
   
    <input
      class="'u-display-container u-text-1 no-outline"
      v-bind="$attrs"
      @input="updateInput($event)"
      v-model="modelValue"
      :disabled="isDisabled"
      :id="id"
      :placeholder="isFloatLabel ? '' : placeholder"
    />
  </div>
</template>
<script>
import { mapGetters} from "vuex";
export default {
  name: "UALabel",
  inheritAttrs: false,
  data() {
    return {
      searchValue: "",
      errmsg: "",
    };
  },
  props: [
    "modelValue",
    "id",
    "isDisabled",
    "labelInfo",
    "isFloatLabel",
    "isMandatory",
    "placeholder",
    "showLabel",
    "cssClass",
    "cssLabel",
    "dataType",
    "onChangeFieldsToTrigger",
    "errorMessage",
    "filtersErrorTooltip",
    "currInputFieldInfo",
    "errorOnTop",
    "modalError"
  ],
  computed: {
    floatClass() {
      return this.modelValue != '' ? 'u-floatFly-fix' : 'u-float';
    },
    ...mapGetters(["getPatternMatching" ]),
  },


  methods: {

    updateInput(event) { 
        this.searchValue = event.target.value;
         this.$emit("update:modelValue", this.searchValue);
         if(this.dataType && this.modelValue){
           this.patternValidation( event, this.dataType);
          }else{
            this.errmsg = "" ;
            this.currInputFieldInfo ? this.currInputFieldInfo.isError =  false :"";
          }
         if(this.onChangeFieldsToTrigger != undefined && this.onChangeFieldsToTrigger.length >0){          
            this.$emit("callApiOnDateChange", this.searchValue);
        }
    }
,
patternValidation(event,selectedDataType) {
      let res = this.getPatternMatching(event,selectedDataType);
     let hasNumber = /\d/;
      if(hasNumber.test(res)){  
        this.currInputFieldInfo ? this.currInputFieldInfo.isError =  true :"";
        if(res=='1')
        this.errmsg = "max "+res+" character is allowed" ;
        else
        this.errmsg = "max "+res+" characters are allowed" ;
        return;
      }
      else{
      if(!res) {
        this.errmsg =this.errorMessage;
        this.currInputFieldInfo ? this.currInputFieldInfo.isError =  true :"";        
        return;
      } 
      else {
        this.errmsg = "" ;
        this.currInputFieldInfo ? this.currInputFieldInfo.isError =  false :"";        
      }
    }
    },
  },
};
</script>
<style scoped>
input {
  border-top-style: hidden;
  border-right-style: hidden;
  border-left-style: hidden;
  border-bottom-style: hidden;
  background-color: #ffffff;
}
.no-outline:focus {
  outline: none;
}

.u-tooltip:before{
  background:#cc0000;
}
.u-tooltip.tip-top-buttons:after{
  border-color: #cc0000 transparent transparent transparent;
}
.u-tooltip.tip-bottom-buttons:after{
  border-color: transparent transparent #cc0000 transparent;
}

.u-tooltip.tip-bottom:after{
  border-color: transparent transparent #cc0000 transparent;
}

.u-tooltip.tip-bottom-search:after {
  border-color: transparent transparent #cc0000 transparent;
}
.u-tooltip{
  display:block;
}
</style>