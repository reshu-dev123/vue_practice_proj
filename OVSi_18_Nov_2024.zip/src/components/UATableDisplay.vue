<template>
  <div v-if="isInlineLoading" class="u-col l12 m12 s12">
    <div class="u-center u-fnt-bld">
      <span>{{ loadingMessage }}</span>
    </div>
  </div>
  <div
    v-if="
      !isInlineLoading && inlineTableFields && !displayHeader?.inlineheaderText
    "
    class="u-row"
  >
    <div class="u-col u-center u-small u-fnt-bld u-bg-color-ltylw">
      <template v-for="(inTblfld, ind) in inlineTableFields.fields" :key="ind">
        <label class="u-ls-ws">{{ inTblfld.label + ":     " }} </label>
        <label :class="['u-ls-ws', inTblfld.textCSSClass]">
          {{
            getJPathValue(
              inTblfld.path,
              inlinetableFieldsData?.length > 0 && inlinetableFieldsData[0]
            ) + "     "
          }}
        </label>
      </template>
    </div>
  </div>
  <div
    v-if="!isInlineLoading"
    :class="[
      'u-container u-tiny  u-centered  u-padding',tableCssClass,
      headerFields ? 'u-padding-top-4' : '',
    ]"
  >
    <div class="u-row" v-if="headerFields">
      <div class="u-col u-flex">
        <template v-for="(hField, hKey) in headerFields" :key="hKey">
          <div
            :class="['u-rtbl-hc u-padding-msmall', hField.cssClass]"
            :style="[hField.styleHeader]"
          >
            <label
              class="u-small u-block u-break-content u-fnt-bld u-tu u-center"
            >
              {{ hField.name }}
            </label>
          </div>
        </template>
      </div>
    </div>
    <div :class="['u-row',(tableData && tableData.length>0 && !hideScroll) && 'contentScroll']"  @scroll="onScroll">
      <div class="u-th-fixed">
        <div id="tblhd" :class="['u-rtbl-th u-tbl-hd u-flex',borderCssClass]">
          <template v-for="(rField, rKey) in tableFields" :key="rKey">
            <div
              :class="['u-rtbl-hc u-padding-msmall', rField.cssClass]"
              :style="[rField.styleHeader]"
            >
              <span
                @click="(rField.isSortable  && rField.sortingOrder) ? sortTblData(rField) : ''"
                :class="[rField.tooltipHeader?'':'u-tooltip tip-bottom-buttons-header']"
                :data-tooltip="rField.label"
              >
                <label :class="[rField.tooltipHeader ? 'u-medium': ' u-tu','u-small lf mf sf u-block u-break-content']">
                  {{ rField.name }}
                </label>
              </span>
              <img  class="u-border-0 " style="width:17px;padding:4px" @click="sortTblData(rField)" v-if="rField.sortingOrder==='asc'" src="@/assets/img/arrow_up.png"/>
              <img  class="u-border-0 " style="width:17px;padding:4px" @click="sortTblData(rField)" v-if="rField.sortingOrder==='dsc'" src="@/assets/img/arrow_down.png"/>
             
            </div>
          </template>
        </div>
      </div>
      <div class="u-innerTable-freeze" v-if="!isLoading && tableData">
        <template v-for="(data, dKey) in tableData" :key="dKey">
         <template v-if="data">
          <div :id="generateId(data,dKey)" tabindex="-1"
            :class="['u-col u-flex',cardRowCss]" 
          >
            <template v-for="(rField, rKey) in tableFields" :key="rKey">
              <div
                :class="[
                  'u-rtbl-cell u-white u-small lf mf sf u-padding-xsmall u-cell-middle',
                  rField.textCSSClass,borderCssClass
                ]"
                v-if="rField.isDisplay"
                :style="rField?.attributes?.style"
              >
                <template v-if="rField.name == 'Mileage Plus' && !rField.getDataForDowngrade">
                  <div v-if="data.passenger.loyaltyProfiles.length>0">
                    <div v-if="data.passenger.loyaltyProfiles[0].memberTierLevel && data.passenger.loyaltyProfiles[0].memberTierLevel != (null || 'MP')">
                      <span>
                        <img :src="getMileagePlusImg(data)" :title="mileagePlusLevel" class="u-margin-right-2px u-Mileage-Imgclass"/>
                      </span>
                      <label  :class="['u-small lf mf sf u-break-content']">
                        {{  getFieldData(rField, data)  }}
                      </label>
                    </div>
                    <div v-else-if="data.passenger.loyaltyProfiles[0].starEliteLevel 
                    && data.passenger.loyaltyProfiles[0].starEliteLevel != null && data.passenger.loyaltyProfiles[0].memberTierLevel == null ">
                      <span>
                        <img :src="getStarMileagePlusImg(data)" :title="mileagePlusLevel" class="u-margin-right-2px u-Mileage-Imgclass"/>
                      </span>
                      <label  :class="['u-small lf mf sf u-break-content']">
                        {{ combineSecondaryFieldPath(rField, data) }}
                      </label>
                    </div>
                    <div v-else>
                      <label
                        :class="['u-small lf mf sf u-block u-break-content']">
                        {{ getFieldData(rField, data)}}
                      </label>
                    </div>
                  </div>
                </template>
                <template v-else-if="!rField.denyTableRowNumByIndex && rField.name == 'Row'">
                  {{ dKey+1}}
                </template>
                <template v-else-if="rField.name === 'Status' && rField.showColoredBtn">
                  <button v-if="getJPathValue(rField.path,data)" :id="generateId(data,dKey)+`_`+getStatusValue(rField,data).replaceAll(' ','').toLowerCase()" :class="[getOvslStatusColor(getStatusValue(rField,data)),'u-width-80 u-sans-serif u-padding-5 u-break-content']">{{getStatusValue(rField,data) }}</button>
                </template>
                <template v-else-if="rField?.displayModalFlds">
                   <component 
                   :is="rField.modalFields.ComponentType"
                   :tableData="flow4"
                   :tableFields="getFieldByIdWrapper(rField.modalFields,rField.modalFields.tableValues)"
                   :tblHeaders="getFieldByIdWrapper(rField.modalFields,rField.modalFields.headerValues)"/>
                </template>
                <template v-else-if="rField?.displayDtRange">
                   <UATableColLayout  
                   :tableData="flow4"
                   :tableFields="rField.modalFields.tableFields"
                   :tblHeaders="rField.modalFields.headers[0]"/>
                </template>
                <template v-else-if="rField?.displayTableBlind">
                   <UAOvsiTableColLayout  
                   :tblHeaders="rField.modalFields.totalFields[0].headers[0]" 
                   :tableFields="rField.modalFields.totalFields[0].tableFields"
                   :tableData="flow4" 
                   />
                </template>
                <template v-else-if="rField.name == 'Bid details'">
                  <img v-if="data.compensation?.passengerOffers"
                  @click="$emit('setShowModalPopup', data)"
                    src="@/assets/img/view.png"
                    alt :id="generateId(data,dKey)+`_bid_details`"
                    class="u-menuImgSml u-border-0 u-transparent"
                    v-bind:title="rField.name"
                  />
                </template>                
                <template v-else-if="rField.name === 'PBT'">
                    <div class="u-flex-center u-ht-40">
                        <span class="tooltip2" @mouseenter="setTitleInfoPop($event,true,dKey)"  @mouseleave="setTitleInfoPop($event,false,dKey)" >
                            <img v-if="data.isPbtOverCapacity" 
                                src="@/assets/img/error.png" alt :id="dKey+`_`+data?.sortKey+`_oversold`"
                                class="u-menuImgSml u-border-0 u-transparent printHide"
                               
                                 />
                            <img v-else src="@/assets/img/check_circle.png" alt :id="dKey+`_`+data?.sortKey+`_undersold`"
                                class="u-menuImgSml u-border-0 u-transparent printHide" 
                               
                                />
                            <span
                            :style="popupStyle" :class="['tooltiptext u-pbt-width l m s']" :id="dKey+`_`+data?.sortKey+`_infopopup`" v-if="titleInfopop && (selectedDataIndex == dKey)">
                                <UAInfoPop 
                                
                                :tableCss="['u-white']" 
                                :headerCSS="[displayHeader1.cssClass,data.isPbtOverCapacity ?'errorimg':'u-left-align u-padding-left-10 u-margin-top-6']"
                                :secondaryHeaderCSS="['u-right-align u-padding-right-10',displayHeader1.cssClass,data.isPbtOverCapacity ?'':'u-margin-top-6']"
                                :Header="displayHeader1.headerText"
                                :secondaryHeader="data.isPbtOverCapacity? displayHeader1.headerText2:displayHeader1.headerText2"
                                :tableFields="innerFields1.tableFields"
                                :tableHeader="innerFields1.headers[0]"
                                :tableData="getCabinWiseData(data.cabins)"
                                :infoCsslass="['u-ht-30 u-flex',data.isPbtOverCapacity ?'u-red':'u-bg-5-inv']" />
                                <!-- <UATableColLayout :tableData="getCabinWiseData(data.cabins)"

                                 :tableFields="innerFields1.tableFields"
                                  :tblHeaders="innerFields1.headers[0]"/> -->
                            </span>
                        </span>
                    </div>
                </template>
                <template v-else-if="rField.type == 'action'">
                    <div ref="opt">
                          <template v-for="(action, actionIndex) in rField.actions" :key="actionIndex">
                              <img v-if="!action.showBasedOnStatus && action.image" :src="getImageUrlM(action.image)" :id="generateId(data, dKey)+`_`+action.id"
                              :class="action.cssClass" @click="genericHandler(action, data, dKey)" v-bind="action.attributes"/>
                              <img v-if="action.showBasedOnStatus && getActionImageUrlM(action,data)" :src="getImageUrlM(action.image)" :id="generateId(data, dKey)+`_`+action.id"
                              :class="action.cssClass" @click="genericHandler(action, data, dKey)" v-bind="action.attributes"/>
                              <UAButton v-if="action.fieldType == 'UAButton'" :id="generateId(data, dKey)+`_`+action.id"
                              :cssClass="[action.cssClass,disableActionBtn && 'u-disabled']" @click="genericHandler(action, data,dKey)" v-bind="action.attributes">
                              {{ action.label }}
                              </UAButton>
                          </template>
                        <div class="logoutMenu u-padding-left-6" v-if="(this.selectedPopIndex == dKey) && logoutTab">
                           <div class="no-border u-pointer-event  u-align-center" >
                           <template v-for="(option, index) in rField.actions[0].events.buttons" :key="index">
                            <div class="u-flex u-padding-xsmall" @click="genericHandler(option, data, dKey)">
                            <img :src="getImageUrl(option.img)" :id="generateId(data, dKey)+`_`+option.id" class="u-logo u-inlineImgSml u-pointer"/>
                              <label class="u-flex u-padding-right-8 u-padding-left-6 u-pointer" >{{ option.name }}</label>
                            </div>
                            </template>
                          </div>
                          </div>
                     </div>
                </template>
                <template v-else-if="rField.inlineField == 'data' && rField.mapDateFormat">
                  <label :class="['u-small lf mf sf u-block u-break-content']">
                    {{mapDateToOtherFormat(rField,data)}}
                  </label>
                </template>
                <template v-else-if="rField?.handleMultipleCurrencies" >
                  <div class="u-innerTable-freeze">
                    <template v-for="(currData, cKey) in getMultipleCurrencyData(rField,data)" :key="cKey">
                      <div class="u-col u-flex" >
                          <div :class="['u-rtbl-cell u-white u-small lf mf sf u-padding-top-4 u-padding-bottom-4 u-cell-middle u-primary-inv-border',
                              rField.textCSSClass]">
                            <label
                              class="u-small lf mf sf u-block u-break-content"
                              v-if="rField.inlineField == 'data'"
                            > 
                              {{ combineFields(rField, currData) }}
                            </label>
                          </div>
                      </div>
                    </template>
                  </div>
                </template>
                <label
                  :class="['u-small lf mf sf u-block u-break-content']"
                  v-else-if="rField.inlineField == 'data'"
                >
                  {{
                    rField.name == 'Flight'?String(getFieldData(rField, data)).padStart(4,'0'):getFieldData(rField, data)
                  }}
                </label>
                <label
                  :class="['u-small lf mf sf u-block u-break-content']"
                  v-else-if="rField.inlineField == 'label'"
                >
                  {{ rField.labelText }}
                  <UATableColLayout  v-if="rField?.extratable"
                   :tableData="tableData"
                   :tableFields="rField.extratable.tableFields"
                   :tblHeaders="rField.extratable.headers[0]"/>
                </label>
                <template v-if="rField.inlineField == 'field'">
                  <component v-if="rField.fieldType == 'UAToggleSwitch'"
                  :is="rField.fieldType"
                  :cssClass="rField.fieldsCssClass"
                  v-bind="
                    rField.inlineField == 'field' ? '' : rField.attributes
                  "
                  :text="getJPathValue(rField.path, data)"
                  :id="rField.id"
                  @changeView="changeView(data, rField)"
                  :isLoopOnce="rField.isLoopOnce"
                  v-model="rField.model"
                  :activeToggleName="rField.activeToggleName"
                  :inactiveToggleName="rField.inactiveToggleName"
                  :currInputFieldInfo="rField"
                  :selectedKey="rField?.selectedKey"
                  :selectedLabel="rField?.selectedLabel"
                  :dataLength="rField?.dataLength"
                  :errorOnTop="rField?.errorOnTop"
                  />
                  <component v-else 
                  :is="rField.fieldType"
                  :cssClass="rField.fieldsCssClass"
                  v-bind="
                    rField.inlineField == 'field' ? '' : rField.attributes
                  "
                  :text="getJPathValue(rField.path, data)"
                  :id="rField.id"
                  @changeView="changeView(data, rField)"
                  :isLoopOnce="rField.isLoopOnce"
                  :currInputFieldInfo="rField"
                  :selectedKey="rField?.selectedKey"
                  :selectedLabel="rField?.selectedLabel"
                  :dataLength="rField?.dataLength"
                  :errorOnTop="rField?.errorOnTop"
                  :modelValue="modelValue"
                  :selectOptions="[data]"
                  @radioOptionSelectedfromChild="$emit('radioOptionSelectedfromChild',data)"
                  />
                </template>
              </div>
            </template>
          </div>

          <div
            class="u-col u-border-bottom u-padding-7"
            v-if="tableText && data.isShow"
            :style="[
              (dKey + 1) % 2 == 0 ? {} : { 'background-color': '#F6F6F6' },
            ]"
          >
            <template v-for="(tField, tKey) in tableText" :key="tKey">
              <div
                class="u-small u-padding-xsmall u-cell-middle"
                v-if="
                  getJPathValue(tField.path, data) &&
                  getJPathValue(tField.path, data).length > 0
                "
              >
                <label
                  class="u-small u-fnt-bld"
                  v-if="
                    tField.inlineField == 'data' && tField?.isBasic != undefined
                  "
                >
                  {{
                    tField.id == "cancellationdiversiondataerrors" &&
                    getJPathValue("status", data) &&
                    getJPathValue("status", data).toString().trim().length >
                      0
                      ? getJPathValue(tField.path, data)
                      : tField.id != "cancellationdiversiondataerrors"
                      ? getJPathValue(tField.path, data)
                      : ""
                  }}
                </label>

                <label
                  class="u-small u-text-red u-fnt-bld"
                  v-if="
                    tField.inlineField == 'data' && tField?.isBasic == undefined
                  "
                >
                  {{
                    tField.id == "cancellationdiversiondataerrors" &&
                    getJPathValue("status", data) &&
                    getJPathValue("status", data).toString().trim().length >
                      0
                      ? getJPathValue(tField.path, data)
                      : tField.id != "cancellationdiversiondataerrors"
                      ? getJPathValue(tField.path, data)
                      : ""
                  }}
                </label>
              </div>

              <div
                class="u-small u-padding-xsmall u-cell-middle"
                v-if="
                  getJPathValue(tField.path, data) == undefined &&
                  tField?.status != undefined
                "
              >
                <label class="u-small u-fnt-bld" v-if="tField?.concateMessage"
                  >{{ tField.concateMessage }}
                </label>
                <label
                  class="u-small u-text-red u-fnt-bld"
                  v-if="tField?.status"
                  >{{ tField.status }}
                </label>
              </div>
            </template>
          </div>

          <div
            class="u-col u-border-bottom u-flex"
            v-if="InlinetableText"
            :style="[
              (dKey + 1) % 2 == 0 ? {} : { 'background-color': '#F6F6F6' },
            ]"
          >
            <template v-for="(iField, iKey) in InlinetableText" :key="iKey">
              <div
                :class="[
                  'u-rtbl-cell u-small u-padding-xsmall u-cell-middle u-text-red',
                  iField.textCSSClass,
                ]"
                :style="iField?.attributes?.style"
              >
                <label
                  class="u-small u-block u-break-content"
                  v-if="
                    iField.inlineField == 'data' && iField?.isPath == undefined
                  "
                >
                  {{ getJPathValue(iField.path, data) }}</label
                >
                <label
                  class="u-small u-block u-break-content"
                  v-else-if="
                    iField.inlineField == 'data' && iField?.isPath != undefined
                  "
                >
                  {{ iField?.isPath }}</label
                >
              </div>
            </template>
          </div>
          
         </template>
        </template>
        <template v-if="tableData && tableData.length == 0">
          <div class="u-center">
            <span class="u-center u-small u-fnt-bld"> No data found ! </span>
          </div>
        </template>
      </div>
      <div class="u-center" v-else>
        <span v-if="isLoading" class="u-center u-small u-fnt-bld"> Loading . . . </span>
        <span v-else class="u-center u-small u-fnt-bld"> No data found!</span>
      </div>
      <template v-if="isMoreDataLoading">
        <div class="u-col u-padding-16 u-center u-white u-text-1 u-ht-40 "  >
         <div class="nb-spinner u-center" style=" left:50%;"></div> 
        </div>
      </template>  
    </div>
  </div>
</template>
<script>
import { mapState, mapGetters, mapActions, mapMutations } from "vuex";
import UAButton from "@/components/UAButton.vue";
import UAModalDisplay from "@/components/UAModalDisplay.vue";
import UAConfirmModal from "@/components/UAConfirmModal.vue";
import UAInfoPop from "./UAInfoPop.vue";
import UATableColLayout from "./UATableColLayout.vue";
import { getDateTimePart,getSortedDataByField } from "../helpers/utilities";
import UAOvsiTableColLayout from "./UAOvsiTableColLayout"
import UAToggleSwitch from "./UAToggleSwitch.vue";
import UARadioButton from './UARadioButton.vue';

export default {
  name: "UATableDisplay",
  inheritAttrs: false,
  components: {
    UAButton,
    UAConfirmModal,
    UAModalDisplay,
    UAInfoPop,
    UATableColLayout,
    UAOvsiTableColLayout,
    UAToggleSwitch,
    UARadioButton

  },
  inheritAttrs: false,
  emits: ["changeView","navigateScreen","update","setShowModalPopup","deleteFieldRow","getMoreItems","radioOptionSelectedfromChild","handleConfirmOk","addFieldsModalPopup"],
  props: [
    "tableData",
    "tableFields",
    "inlinetableFieldsData",
    "cssClass",
    "borderCssClass",
    "cardRowCss",
    "tableCssClass",
    "hideScroll",
    "isInfinitScrollRequired",
    "modelValue",
    "disableActionBtn"
  ],
  data() {
    return {
      logoutTab: false,
      infopop: false,
      selectedDataIndex: -1,
      selectedPopIndex: -1,
      popupFlag:-1,
      popupStyle: {
        top: '0px',
        left: '0px'
      },
      titleInfopop: false,
      flow4: [
        {blindbid_1_start: "0", blindbid_1_end: "1,000", blindbid_1_etc: "$300",
        blindbid_2_start: "0", blindbid_2_end: "1,000", blindbid_2_etc: "$300",
        blindbid_3_start: "0", blindbid_3_end: "1,000", blindbid_3_etc: "$300",
        blindbid_4_start: "0", blindbid_4_end: "1,000", blindbid_4_etc: "$300",
        start_dt:"01-Jan-2022",end_dt:"31-Mar-2023",start_time:"00:00",end_time:"15:00" ,
        start_value : "+1",end_value: "+3",currency:"Euro",min_curr:"€102.27",max_curr:"€2,556.63"
        ,mil_usd:"$0.02",cf_usd:"$0.04",intiation_starttime:"12 hours",intiation_stoptime:"1 hour",
        capacity:"-10%",baseline_bid_ma: "0.60", baseline_bid_mb: "0.80", baseline_bid_mc: "1.00",
      },
      ],
      mileagePlusLevel:'',
    };
  },
 unmounted() {
    document.removeEventListener("click", () => {
      this.logoutTab = false;
    });
  },
  
mounted() {
document.addEventListener("click", (e) => {
      if( this.logoutTab && this.$refs){
        if( this.$refs.opt && this.$refs.opt.length > 0  && this.$refs.opt[this.selectedPopIndex] && !this.$refs.opt[this.selectedPopIndex].contains(e.target)){
          this.logoutTab = false;
        }
      }
    });
},
  computed: {
    ...mapState({
      InnerRTFHeader: (state) => state.ovsiDefaultModule.InnerRTFHeader,
      isInlineLoading: (state) => state.ovsiDefaultModule.isInlineLoading,
      isLoading: (state) => state.ovsiDefaultModule.isLoading,
      loadingMessage: (state) => state.ovsiDefaultModule.loadingMessage,
      inlineTableFields: (state) => state.ovsiDefaultModule.inlineTableFields,
      headerFields: (state) => state.ovsiDefaultModule.headerFields,
      displayHeader: (state) => state.ovsiDefaultModule.displayHeader,
      dataCondition: (state) => state.ovsiDefaultModule.dataCondition,
      tableText: (state) => state.ovsiDefaultModule.tableText,
      modalButtons: (state) => state.ovsiDefaultModule.modalButtons,
      addTableFields: (state) => state.ovsiDefaultModule.addTableFields,
      InlinetableText: (state) => state.ovsiDefaultModule.InlinetableText,
      addEditObject: (state) => state.ovsiDefaultModule.addEditObject,
      selectedInputValues: (state) =>
        state.ovsiDefaultModule.selectedInputValues,
      displayHeader1:(state) => state.ovsiDefaultModule.displayHeader1,
      innerFields1:(state) => state.ovsiDefaultModule.innerFields1,
      standardTblFlds:(state) => state.ovsiDefaultModule.standardTblFlds,
      apiResponse: (state)=> state.ovsiDefaultModule.apiResponse,
      actionId: (state) => state.ovsiDefaultModule.actionId,
      isMoreDataLoading: (state) => state.ovsiDefaultModule.isMoreDataLoading,
      isShow: (state) => state.ovsiDefaultModule.isShow,
    }),
    ...mapGetters(["getOVSIFields", "getJPathValue", "getOVSIEntityId","getImageUrl",'getOvslStatusColor']),
  },
  methods: {
    ...mapActions(["getOVSIData", "verifyAdvanceSectionData"]),
    ...mapMutations(["setSelectedMenuId"]),
    getMultipleCurrencyData(field,data){
      let currData={}
      let defaultCurrValue=[]
      if(data){
        if(field.combineStructure){
          field.combineStructure.forEach(strctr => {
            currData[strctr.id] =strctr.defaultValue;
          })
            defaultCurrValue.push(currData)
          }
          if(field.name=='ETC'){
            currData = data?.etc.length>0 ? data?.etc:defaultCurrValue
          }
          if(field.name=='Drafts'){
            currData = data?.draft.length>0 ? data?.draft:defaultCurrValue
          }
          else{
            currData;
          }
        } 
        return currData;
    },
    setFocus(selectedObj){
      document.getElementById('selOpt'+selectedObj.pnr+selectedObj.lastName+", "+selectedObj.firstName).focus();
    },
    generateId(data,dKey){
      if(data && data?.pnr && data?.psnrName){
        return 'selOpt'+data?.pnr+data?.psnrName;
      } 
      if(this.getOVSIEntityId =='overSaleOverView'){
        return `${dKey}_${data?.flightDate.replaceAll('-','')}_${data?.carrierCode}_${data?.flightOrigin}_${data?.flightNumber}`;
      } else if(this.getOVSIEntityId =='flight_Management'){
        return `${dKey}_${data?.sortKey}`;
      } else if(this.getOVSIEntityId =='history'){
        return `${dKey+1}_${data?.flight?.sortKey}_${data?.eventType}_${data?.createdBy}_${data?.createdChannel}`; 
      } else if(this.getOVSIEntityId =='volunteerLists'){
        return `${dKey+1}_${data?.passenger?.sortKey}`;
      } else if(this.getOVSIEntityId =='downgradeIDBHlists'){
        return `${dKey+1}_${data?.firstName}_${data?.lastName}_${data?.pnr}`;
      } else {
        return `record_${dKey}`;
      }
    },
    sortTblData(fieldToSort){
      this.tableFields.forEach(fldHeader => {
        if(fldHeader.isSortable && fldHeader.sortingOrder) {
          if(fldHeader.sortKey == fieldToSort.sortKey) {
            fldHeader.sortingOrder = fldHeader.sortingOrder == 'asc' ? 'dsc' : 'asc';
          } else {
            fldHeader.sortingOrder = 'asc';
          } 
        }        
      })
      getSortedDataByField(this.tableData, fieldToSort);
    },
    onScroll(e){
      if(this.isInfinitScrollRequired && !this.isMoreDataLoading){
        if((e.target.offsetHeight + e.target.scrollTop) >= e.target.scrollHeight) {
          this.$emit('getMoreItems');
        }
      }
    },
    getFieldByIdWrapper(tblMetaData,fldsToRtrn){
      let fields = this.standardTblFlds.filter( field => tblMetaData.fieldIdsToBind.includes(field.id));
      let tableInfoTemp = JSON.parse(JSON.stringify(tblMetaData));
      tableInfoTemp.totalFields = fields;
      let Headers = tableInfoTemp.totalFields[0].headers[0];
      let tblFlds = tableInfoTemp.totalFields[0].tableFields;
      if(fldsToRtrn == 'rtrnHeaders'){
        return Headers;
      } else if(fldsToRtrn == 'rtrnTblFlds'){
        return tblFlds; 
      } else {
        return tableInfoTemp;
      }
    },
    combineSecondaryFieldPath(field,data){
      let fieldValue ='';
      let arrV= this.getData(field.path,data);
      let lastPathVal = this.getJPathValue(field.combineSecondaryPath[field.combineSecondaryPath.length - 1],arrV?arrV[0]:{});
      fieldValue = field.combineSecondaryPath.map(path=>this.getJPathValue(path,arrV?arrV[0]:{})).join((lastPathVal && lastPathVal.length>0) ? field.combinePrefix : '').toString();
      if(fieldValue.trim().length === 0){
       return field.defaultValue;
      }
      return fieldValue;
    },
    combineFields(field,item){
      let FloatObj = {};
      let fieldValue ='';
      let lastPathVal = this.getJPathValue(field.combinepath[field.combinepath.length - 1],item);
      if(field.isFloatValue){
        field.combinepath.forEach(path=>{
          if(path == field.combinepath[0]){
            let amnt = this.getJPathValue(path,item) || field.defaultValue            
            let amntValue = Number.isInteger(amnt) ? amnt : parseFloat(amnt).toFixed(2)
            FloatObj["amount"] =  amntValue;
          } else {
            let currCode = this.getJPathValue(path,item)
            FloatObj["currencyCode"] =  currCode;
          }
        })
         fieldValue = field.combinepath.map(path=>this.getJPathValue(path,FloatObj)).join(field.combinePrefix||'').toString();
      } else{
         fieldValue = field.combinepath.map(path=>this.getJPathValue(path,item)).join((lastPathVal && lastPathVal.length>0) ? field.combinePrefix : '').toString();
      }
      if(fieldValue.trim().length === 0){
       return field.defaultValue;
      }
      return fieldValue;
    },
    getFieldData(field, data){
      if(field.inlineField == 'data' && field.type == 'concat'){
       return this.combineFields(field,data);
      } else if(field.inlineField == 'data' && field.dataType == 'array'){
          let arrV= this.getData(field.path,data);
         return this.combineFields(field,arrV?arrV[0]:{});
       }else if(field.inlineField == 'data' && field.formatDate){
        return getDateTimePart(this.getJPathValue(field.path,data), field.dateFormat);
      } else if(field.inlineField == 'data' && field.name != 'Bid details' && !field.showColoredBtn){
        return this.getJPathValue(field.path,data)
      }
    },
    getData(path,data){
      return this.getJPathValue(path,data);
    },
    mapDateToOtherFormat(rField,data){
      let date = this.getFieldData(rField, data);
      if(date){
       // return  new Date(date).toLocaleString('en-US', {  month: 'short' });
       const tokens= new Date(date).toLocaleDateString({},rField.mapDateFormat).split(' ');
       return `${tokens[1].toString().substring(0,2)}-${tokens[0]}-${tokens[2]}`;
      }
      return "";

    },
    setTitleInfoPop(e,flag,dataIndex){
      this.selectedDataIndex = flag?dataIndex:-1;
      this.titleInfopop = flag;
      this.setPosition(e);     
    },
    setPosition(event){ 
      let element = document.getElementById('tblhd');
      let position = element.getBoundingClientRect();
      this.popupStyle = {
        top:  event.srcElement.offsetTop, 
        left: event.srcElement.offsetLeft,
      };
      let yDiff = event.screenY - event.clientY;
      yDiff = yDiff < 0 ? (yDiff * -1) : yDiff
      if (event.clientY <= 415 ) {
        this.popupStyle.top = position.top + 'px';
      } 
      else if (event.clientY > 415 && event.clientY <= 620 && this.isShow){
        this.popupStyle.top = position.top + 40 + 'px';
      }else if (event.clientY > 415 && event.clientY <= 620 && !this.isShow){
        this.popupStyle.top = position.top + 80 + 'px';
      }
      else{
        if(!this.isShow){
          this.popupStyle.top = (position.top + yDiff + 115) + 'px';
        } else {
          this.popupStyle.top = (position.top + yDiff + 90) + 'px';
        }
      }       
    },
    getStatusValue(rField,record){
      return this.getJPathValue(rField.path,record).toUpperCase();
      
    },
    getCabinWiseData(cabins){
      //TO GET DATA AS PER CABIN [{'O': {O CABIN DATA}, 'J': {J CABIN DATA}, 'Y': {Y CABIN DATA}}]
          let cabinData ={}
          let cabinWiseData = [];
          if(this.innerFields1?.headers[0]?.isCabinWiseData){                
              for(let i=1; i< this.innerFields1.headers[0].headerValues?.length; i++){     
                  let filteredCabinData = cabins?.filter((item) => {      
                        return item?.cabinCode == this.innerFields1.headers[0].headerValues[i];
                  })                    
                  cabinData[this.innerFields1.headers[0].headerValues[i]] = filteredCabinData?.length>0 ? filteredCabinData[0] : {};                
              }
              cabinWiseData.push(cabinData);    
          }
          return cabinWiseData;
    },
    getImageUrlM(img){
      return this.getImageUrl(img);
    },
    getActionImageUrlM(fld,data){
      let showBasedOnStatus = false;
      if(data.oversaleStatus == 'Stopped' && fld.events.name=='initiate'){
        showBasedOnStatus = true;
      }
      if((data.oversaleStatus == 'Initiated'|| data.oversaleStatus == 'Volunteers Added') && fld.events.name=='stop'){
        showBasedOnStatus =true;
      }
      return showBasedOnStatus;
    },
    getMileagePlusImg(data){
      if(data.passenger.loyaltyProfiles[0].memberTierLevel=='1K'){ // 1K
        this.mileagePlusLevel ='1K';
        return this.getImageUrl('mileage_plus_1k.png');
      }
      if(data.passenger.loyaltyProfiles[0].memberTierLevel=='GS'){ //Global Services
        this.mileagePlusLevel ='Global Services';
        return this.getImageUrl('mileage_plus_GS.png');
      }
      if(data.passenger.loyaltyProfiles[0].memberTierLevel=='PL'){ //Platinum
        this.mileagePlusLevel ='Platinum';
        return this.getImageUrl('mileage_plus_P.png');
      }
      if(data.passenger.loyaltyProfiles[0].memberTierLevel=='GL'){ //Premier Gold
        this.mileagePlusLevel ='Premier Gold';
        return this.getImageUrl('mileage_plus_G.png');
      }
      if(data.passenger.loyaltyProfiles[0].memberTierLevel=='SL'){ //Premier Silver
        this.mileagePlusLevel ='Premier Silver';
        return this.getImageUrl('mileage_plus_S.png');
      }
    },
    getStarMileagePlusImg(data){
      if(data.passenger.loyaltyProfiles[0].starEliteLevel=='*G'){ //Star Alliance Gold
        this.mileagePlusLevel ='Star Alliance Gold';
        return this.getImageUrl('mileage_plus_StarG.png');
      }
      if(data.passenger.loyaltyProfiles[0].starEliteLevel=='*S'){ //Star Alliance Silver
        this.mileagePlusLevel ='Star Alliance Silver';
        return this.getImageUrl('mileage_plus_StarS.png');
      }
      if(data.passenger.loyaltyProfiles[0].starEliteLevel=='*'){ //Star Alliance Member
        this.mileagePlusLevel ='Star Alliance Member';
        return this.getImageUrl('mileage_plus_Star.png');
      }
    },
    async genericHandler(actionBtnInfo, data,dataIndex){
        let {events} = actionBtnInfo;
        this.selectedDataIndex = dataIndex;
        if(events.name == "EditDelete"){
          this.logoutTab=!this.logoutTab;
          this.logoutTab ? this.selectedPopIndex = dataIndex: -1;
        } else if(events.name == "navigateToOtherScreen"){
            this.$emit('navigateScreen', actionBtnInfo, data);
            //this.setSelectedMenuId(actionBtnInfo.navigationInfo.navigateToID);
        } else  if(events.name == "edit"){
          this.logoutTab=!this.logoutTab
          this.$emit('setShowModalPopup', data);
        } else if(events.name == "delete"){
          let confirmObj = {events,data}
          this.$emit('handleConfirmOk', confirmObj);
          this.logoutTab=!this.logoutTab
        } else if(events.needConfirmBox){
          let confirmObj = {events,data}
          this.$emit('handleConfirmOk', confirmObj);
        }
        else if(events.name == "add"){
          this.$emit('addFieldsModalPopup', data);
        }
        return;        
         
    },
    changeView(data, fieldInfo) {
      if (fieldInfo?.verifyModel) {
        this.Verify(data);
      } else {
        this.$emit("changeView", data, fieldInfo);
      }
    },

    Verify(data) {
      let inParamObj = this.createInputObj(
        data,
        this.addEditObject.insert_field
      );
      let inpObj = {
        action: this.inlineTableFields.verifyeMacroName,
        actionId: "ActionType",
        inputObject: inParamObj,
      };
    },

    createInputObj(editedField, macroFields) {
      let inParamObj = {};
      macroFields.forEach((eField) => {
        if (editedField.hasOwnProperty(eField.path)) {
          if (eField.fieldType == "UADateTimePicker") {
            inParamObj[eField.id] = getDateTimePart(
              editedField[eField.path],
              eField.dateFormat
            );
          } else {
            inParamObj[eField.id] = editedField[eField.path].toString().trim();
          }
        } else {
          let curretnValue = "";
          if (eField.path == "customerID" || eField.path == "statusind") {
            curretnValue = eField.model;
          } else {
            curretnValue = this.getJPathValue(
              eField.path,
              this.selectedInlineData
            );
          }

          inParamObj[eField.id] =
            curretnValue != undefined ? curretnValue.toString().trim() : "";
        }
      });

      return inParamObj;
    },
  },
};
</script>

<style  scoped>
  .u-rtbl-cell:last-child {
    border-right: 0 !important;
  }
  
  button {
      display: inline-block;
      padding: 5px 15px;
      font-size: 10px;
      text-align: center;
      text-decoration: none;
      outline: none;
      color: #000;
      background-color: #f0f0f0;
      border: none;
      border-radius: 15px;
      font-family: 'Times New Roman', Times, serif;
  }
  
.tooltip2 {
    position: relative;
    display: inline-block;
}

.tooltip2 .tooltiptext {
    visibility: visible;
    background-color: #fff;
    text-align: center;
    border-radius: 6px;
    /* Position the tooltip */
    position: fixed;
    z-index: 1;
     top:0px;
    /* bottom: 7vh; */
    transform: translate(0%, 0%);
}

.tooltip2:hover .tooltiptext {
    visibility: visible;
}
.logoutMenu {
  background: white;
    /* width: 21rem; */
    position: absolute;
    box-shadow: 3px 3px 3px 3px #ccc;
    /* right: -1px; */
    top: 3.7rem;
    z-index: 10;
    /* padding: 0.25rem 1.5rem; */
    border-radius: 3px 3px 3px 3px;
    border: 1px solid #ccc;
    color: black;
    text-align: left;
    box-shadow: 2px #ccc;
    border-color: 2px 1px 3px 2px #ccc;
    transform: translate(-110%, -135%);
}
.logoutMenu::before {
  content: " ";
    position: absolute;
    top: 6px;
    right: -5%;
    width: 20px;
    box-shadow: 6px -2px 0px 1px #cccccc;
    height: 20px;
    background: white;
    transform: rotate(45deg);
    z-index: -1;
}


 
</style>
