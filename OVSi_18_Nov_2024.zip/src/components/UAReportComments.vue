<template>
  <div class="u-row u-overlay" style="display: block">
    <div class="u-modal-comment-container" style="display: block" ref="repCmntsRef" @mouseleave="mouseLeaveHandler()" @mouseover="mouseOverHandler()">
      <form class="u-modal-add-content " style="height: 74vh">
        <div class="u-round">
          <div class="u-row u-th-fixed">
            <div :class="['u-col l11 m11 s11',modalCssClass]">
          <label :class="['u-ls-ws',modaltextCSSClass]">
            {{ `${modalHeaderText} (${commentData.length})` }}
          </label>
        </div>
            <div class="u-col l1 m1 s1">
                  <UAButton
                  id="close_report_comments"
                  @click.prevent="$emit('closeComment')"
                    cssClass=" u-transparent u-medium u-primary-inv-border u-fnt-bld u-right u-pad-0 u-pointer"
                  >
                  <img src="../assets/img/close_grey.png" alt="Close icon" class="" id="close_comments_icon"/>
                  </UAButton>
                </div>
            </div>
            <div class="u-row contentScroll" style="height: 70vh;">
                <div :class="['u-row u-container ',blockCssClass]"  >
                  <template v-if="commentData.length>0">
                  <div v-for="(comment,cKey) in commentData" :key="cKey" :class="this.getEmployeeId == comment.employeeId?'u-left-pad-100':' u-right-pad-100'">
                  <UAOSLCard @update_Comment="updateComment($event,comment)" :addCustomerCommentsInfo="addCustomerCommentsInfo"
                  :cardCssClass="this.getEmployeeId == comment.employeeId?'':' u-bg-1'" :id="comment.commentId"
                  :reportCommentsInfo="comment"/>
                </div>
                </template>
                <div v-else>
                  <h6>{{ headers.text2 }}</h6>
                </div>
          </div>
        </div>
          </div>
      </form>
      <footer :class="['u-row u-border-top u-padding-6 u-th-fixed']">
        <div class="u-row">
        <div v-if="modalFields" :class="['u-col u-padding-bottom-7', divCssClass]">
                <div :class="[headers.headerCss]">
                  <label class="u-small">
                    {{ headers.headerValues }}
                  </label>
                </div>
                <div class="u-row">
                  <UATextarea cssClass=" u-fnt-itlc u-minheight-60 u-min-width u-max-width"
                  @update:modelValue="updateEditFields($event)" placeholder="Enter text here"
                  id="add_comment_text"  :modelValue="modelValue">
                    </UATextarea>
                </div>
              </div>
      <div class="u-col u-padding-top-7 u-border-top">
      <template v-for="(hField,hKey) in footerFields" :key="hKey">
      <UAButton @click="genericHandler(hField.events)" :id="'report_comments_'+hField.id"
      :cssClass="[hField.fieldsCssClass,disableIfNoText(hField.id)]">{{hField.name}}
      </UAButton>
      </template>
    </div>
  </div>
      </footer>
    </div>
  </div>  
</template>
<script>
import UATextbox from "@/components/UATextbox.vue";
import UAButton from "@/components/UAButton.vue";
import UADropDown from "@/components/UADropDown.vue";
import UATableColLayout from "@/components/UATableColLayout.vue";
import UATableDisplayLayout from "@/components/UATableDisplayLayout.vue";
import UATextarea from "@/components/UATextarea.vue";
import UAOSLCard from "@/components/UAOSLCard.vue";
import { mapGetters, mapState,mapMutations,mapActions } from "vuex"; 

export default {
  name: "UAReportComments",
  components: {
    UATextbox,
    UAButton,
    UADropDown,
    UATableColLayout,
    UATableDisplayLayout,
    UATextarea,
    UAOSLCard
  },
  props: ["modalCssClass","modaltextCSSClass","modalHeaderText","blockCssClass",
"modalFields","divCssClass","headers","footerFields","commentData","addCustomerCommentsInfo"],
  emits: ["closeComment","addComment","update_comment"],
  data() {
    return {
      searchFiltersOptions: {
        pathParam: "",
        data: "",
        docType: "",
      },
      modelValue:"",
      mouseVisitedOnModal:false,//TO Verify THE mouse FOCUS OR MOUSE OVER ON MODAL DISPLAY at least one time 
      mouseLeaveDetected:false
    };
  },
  mounted() {
    setTimeout(() =>  document.addEventListener("click",this.handleOutSideClick),100) ;
  },
  computed: {
    ...mapState({
      addTableFields: state => state.ovsiDefaultModule.addTableFields,
      commentsHeader: state => state.ovsiDefaultModule.commentsHeader,
      commentFields:(state) => state.ovsiDefaultModule.commentFields,
      innerFields1:(state) => state.ovsiDefaultModule.innerFields1,
      selectedRecord: state => state.ovsiDefaultModule.selectedRecord,
    }),
    currentDate() {
   // Get current date and time
let currentDate = new Date();

// Array of month names
const monthNames = [
 'Jan', 'Feb', 'Mar', 'Apr', 'May', 'June',
 'July', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
];

// Format date
let day = currentDate.getDate().toString().padStart(2, '0');
let month = monthNames[currentDate.getMonth()];
let year = currentDate.getFullYear();

// Format time
let hours = currentDate.getHours().toString().padStart(2, '0');
let minutes = currentDate.getMinutes().toString().padStart(2, '0');

// Display formatted date and time
let formattedDateTime = `${day}-${month}-${year} ${hours}:${minutes}`;
return formattedDateTime;
  },
    ...mapGetters (["getJPathValue","getOVSIFields","getEmployeeId"]),
  },
  methods: {
    ...mapMutations(["setAlertMessages"]),
    mouseLeaveHandler(){
        this.mouseLeaveDetected = true;
      },
      mouseOverHandler(){
        this.mouseLeaveDetected = false;
        this.mouseVisitedOnModal = true;
      },
      handleOutSideClick(e){
        if((this.mouseLeaveDetected && this.mouseVisitedOnModal) || (!this.mouseLeaveDetected && !this.mouseVisitedOnModal)){//IF AT LEAST ONCE THE MOUSE OVER THE MODAL DISPLAY AND THEN ONLY DETECT THE MOUSE LEAVE
          if(this.$refs?.repCmntsRef && !this.$refs?.repCmntsRef?.contains(e.target)){
            this.$emit("closeComment");       
          } 
        }
      },
    updateEditFields(event){
      this.modelValue=event
    },
    disableIfNoText(id){
      if(id == 'add' && this.modelValue.trim().length==0){
        return 'u-disabled';
      }
      return '';
    },
    genericHandler(events){
      if(events.name == 'add'){
        this.$emit('addComment',this.modelValue.trim())
        this.modelValue=""
      }
      else{
        this.$emit('closeComment',events)
      }
      
    },
    updateComment(event,reportCommentsInfo){
      this.$emit('update_comment',{event,reportCommentsInfo})
    }
  },
};



</script>

<style scoped>
.u-modal-comment-container{
    z-index: 3;
    display: none;
    position: fixed;
    left: 70%;
    top: 0;
    width: 30%;
    height: 100vh;
    overflow: auto;
    background-color:#fff
}
.u-modal-add-content{
    margin: auto;
    background-color: #fff;
    position: relative;
    padding: 0;
    outline: 0;
    padding: 8px;
    border-radius: 10px;
}
.u-left-pad-100{
  padding-left: 100px;
}
.u-right-pad-100{
  padding-right: 100px;
}
</style>