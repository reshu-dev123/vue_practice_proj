<template>
  <div class="u-row" v-if="intiateFlightPop">
            <template v-for="(btn,btnIndex) in adddEditDeactivatedFlightButtons" :key="btnIndex">
            <UAModalDisplay v-if="btn.modalConfigs"
              @close="setIntiateFlightPop(false)" 
              @add="intiateFlight($event,btn)" 
              :modalTable="btn.modalConfigs" 
              :footerFields="btn.buttons"
              :tableData="[]"/>
          </template>         
      </div>
     <div class="u-row u-bg-1" v-if="getActiveFlagForInitiation">
      <h3 class="u-row" :class="displayHeader.cssClass">{{displayHeader.NoFLightsMessage}}</h3>
     </div>
  <template v-else>  
    <div class="u-row">
      <div class="u-col l10"><h3 v-if="displayHeader" :class="displayHeader.cssClass">{{displayHeader.headerText}}</h3></div>
    </div>
    <UAModalDisplay v-if="showModalPopup" @close="ClosePopup()"
      @update="editOversaleLimit"
      :modalTable="editModalDisplayTableFields[0].modalTemp"
      :record="modalData"
      :tableData="cabinWiseData"
      :footerFields="modalButtons[0].editButtons"
      @bindDependentValuesOnCHange="handleDependedFieldsOnChange($event, editModalDisplayTableFields[0].modalTemp)"
    />
    <UATableDisplay       
      :tableData="searchOVSIData" 
      :tableFields="getOVSIFields"  
      @navigateScreen="navigateScreen"    
      @setShowModalPopup="setShowModalPopup"
      @getMoreItems="loadMoreItems"
      :isInfinitScrollRequired="true"
      @handleConfirmOk="handleConfirmOkFunc"
    />
    <UAConfirmBox ref="uaconfirmbox"  v-if="showConfrmBox"/>
    <div class="u-row">
      <div class="u-col l10"></div>
      <div class="u-col l2 u-section-1 u-flex-center u-text-block u-padding u-right u-margin-top-0" v-if="!isLoading && apiResponse.nextPage">
        <UAButton @click="loadMoreItems()" type="button"
          cssClass="u-button u-round u-secondary-1-pur u-col ">Load More Items...</UAButton>
      </div>
    </div>
  </template>
</template>

<script>
import { mapState, mapGetters, mapMutations, mapActions} from 'vuex';

import UATableDisplay from "./UATableDisplay.vue";
import UAButton from './UAButton.vue';
import UAModalDisplay from './UAModalDisplay.vue';
import { createGetInputObj, getDateDiff,validatInputParams,getAmtAndCurrencyCode,getAPIFormattedDate } from "../helpers/utilities";
import {initiateFlight,deactiveFlight} from '../services/flightService';
import UAPagination from './UAPagination.vue';
import UAConfirmBox from './UAConfirmBox.vue';
export default {
  name: "UAFlightManagement",
  data() {
      return {
          adddEditDeactivatedFlightButtons: [],
          showModalPopup:false,
          modalData:[],
          cabinWiseData:[],
          editModalDisplayTableFields:[],
          showConfrmBox:false
      };
  },   
  async created() { 
        this.adddEditDeactivatedFlightButtons=JSON.parse(JSON.stringify(this.deactivatedFlightButtons));        
  },
  async mounted(){
    this.editModalDisplayTableFields = JSON.parse(JSON.stringify(this.addTableFields));
    if(this.intiateFlightPop && !this.isFlightMgmtEnabled){
     this.setModalAlertMessages({ alertType: this.erMsg.errorType, alertMessages: [this.erMsg.text] });
     this.adddEditDeactivatedFlightButtons.forEach(btn=>{
      btn.buttons.forEach(b=>b.attributes.disabled=true)
      btn.modalConfigs.modalFields.forEach(mField=>{
        mField.flightdetails.forEach(fltDtl=>{
          fltDtl.tableFields.forEach(tF=>{
            console.log("tF",tF)
            tF.subFields.forEach(sF=>{
              
              sF.attributes.disabled=true;
            
            })
          })
        })
      })
     })
    }
  },
  props: [],
  computed: {
    ...mapState({
      displayHeader: (state)=>state.ovsiDefaultModule.displayHeader,
      searchOVSIData: (state)=>state.ovsiDefaultModule.searchOVSIData,
      deactivatedFlightButtons: state=>state.ovsiDefaultModule.entityDisplayDetails.Layouts[0].deactivatedFlightButtons,
      mainViewId: state => state.ovsiDefaultModule.mainViewId,
      erMsg: (state) => state.ovsiDefaultModule.applicationInfoDetails.errorMessageList.PERMISSION_DENIED,
      selectedInputValues: state => state.ovsiDefaultModule.selectedInputValues,
      prevNavigateViews: state => state.ovsiDefaultModule.prevNavigateViews,
      isNavigatedEvent: state => state.ovsiDefaultModule.isNavigatedEvent,
      actionId: (state) => state.ovsiDefaultModule.actionId,
      showSerachFilter: (state) => state.ovsiDefaultModule.showSerachFilter,
      isLoading: (state) => state.ovsiDefaultModule.isLoading,
      addTableFields: (state) => state.ovsiDefaultModule.addTableFields,
      modalButtons: (state) => state.ovsiDefaultModule.modalButtons,
      apiResponse: (state)=> state.ovsiDefaultModule.apiResponse,
      intiateFlightPop: (state)=> state.ovsiDefaultModule.intiateFlightPop,
      channel: (state) => state.userModule.channel
    }),
     ...mapGetters(["getOVSIFields", "getJPathValue", "getOVSIEntityId", "getMenuItems","getEmployeeId","getOVSIEntityId","isFlightMgmtEnabled"]),
     getActiveFlagForInitiation(){
      // if(this.searchOVSIData.length == 1){
      //   return this.searchOVSIData[0].oversaleStatus?.toString().toUpperCase() == 'DEACTIVATED';
      // }
      return (this.searchOVSIData.length==0) && !this.isLoading;
      //return this.searchOVSIData.length==0
    }
  },
  components: {
    UATableDisplay,
    UAButton,
    UAModalDisplay,
    UAPagination,
    UAConfirmBox
},
  methods:{
    ...mapActions(["getEntityDisplayDetailsAction", "getOVSIData","updatePrevOptions","authorizeModule","raiseServerError"]),
    ...mapMutations(["setIsNavigatedEvent",
         "setIsNavigateToInnerOtherView",
         "setPrevNavigateViews",
         "updatePrevNavigateViews",
         "setSelectedMenuId",
         "setModalAlertMessages",
         "setAlertMessages",
         "clearAlertMessages","setSelectedRecord", "resetPrevNavigateViews", "setIsMoreDataLoading","setIntiateFlightPop","setSelectedMenuId"]),
    async navigateScreen(actionBtnInfo, data){ // navigating to report
      //update reportInlinefilter with default options when flight navigation with new flight data
      let isAuthorized = await this.authorizeModule({operationId: 'ua_get_flight_report',moduleId: 'report',origin: data.flightOrigin})
      if(!isAuthorized){return; }
      this.setSelectedMenuId(actionBtnInfo.navigationInfo.navigateToID);
      this.clearAlertMessages();
      let defaultOptions = {"type":"All","cabin":"All","compensation":"All","compensation_1": "All","pass_class":"All"};
      this.updatePrevOptions(JSON.parse(JSON.stringify(defaultOptions)));
      this.setSelectedRecord(data);
        let {events} = actionBtnInfo;
        if(events.name == "navigateToOtherScreen"){
            this.setIsNavigatedEvent(true);
            this.setIsNavigateToInnerOtherView(true);
            const prevItems = this.prevNavigateViews.filter(
              (item) => item.id == this.getOVSIEntityId
              );
            let prevMainObjToReset = false;
            if(prevItems.length > 0){
              const preItem = prevItems[prevItems.length-1];
              if(preItem.mainFilterParams && prevItems.length == 1){
                prevMainObjToReset = true;
                this.resetPrevNavigateViews();
              }              
            }
            if (
                this.mainViewId == this.getOVSIEntityId &&
                Object.keys(this.selectedInputValues).length > 0 &&
                (this.prevNavigateViews.length === 0 || prevMainObjToReset)
            ) {
                //if current component is from main menu click which we started navigation first/origin
                this.setPrevNavigateViews({
                  id: this.getOVSIEntityId,
                  searchFilterInputParams: JSON.parse(JSON.stringify(this.selectedInputValues.inputObject)),
                  bindSearchFilterParams: true,
                  mainFilterParams: true
                });
            } else if(this.mainViewId != this.getOVSIEntityId && 
              this.prevNavigateViews.length >= 1 && !prevMainObjToReset) {
                this.updatePrevNavigateViews({entityId:this.getOVSIEntityId ,searchParams:this.selectedInputValues.inputObject})
            }
            let inputHeaderParamObj;
            if (actionBtnInfo.navigationInfo.headerMacroParams) {
              inputHeaderParamObj = createGetInputObj(
                actionBtnInfo.navigationInfo.headerMacroParams,
                data
              );
            }
            this.setPrevNavigateViews({
                id: actionBtnInfo.navigationInfo.navigateToID,
                searchFilterInputParams: {},//inputParamObj,
                headerMacroParams: inputHeaderParamObj,
                showNavMenus: true
            });
            await this.redirectToSpecificMenu(actionBtnInfo.navigationInfo.navigateToID,data);
        }
    },
    async redirectToSpecificMenu(id,data){
          await this.getEntityDisplayDetailsAction(id).then(()=>{
            this.setSelectedMenuId(id);
          });
    },
    //MODIFY THE DEPENDENT FIELD ON CHANGE OF CURRENT FIELD
    handleDependedFieldsOnChange(inputFieldDetails, currModalInfo) {
      try {
        if (inputFieldDetails.inputFieldInfo.currField.onChangeFieldsToTrigger
          && inputFieldDetails.inputFieldInfo.currField.onChangeFieldsToTrigger.length > 0) {
          currModalInfo.modalFields.forEach(modalData => {
            if(inputFieldDetails.inputFieldInfo.currField.sectionIdForOnChangeFields &&
              inputFieldDetails.inputFieldInfo.currField.sectionIdForOnChangeFields.includes(modalData.id)){
              let mdlTblFields= modalData[modalData.id][0];
              mdlTblFields.tableFields.forEach(fieldItem => {
                if(fieldItem.isValuesDependOnOtherField && inputFieldDetails.inputFieldInfo.currField.disableField && 
                  inputFieldDetails.inputFieldInfo.currField.disableField.includes(fieldItem.id)) {
                  if(inputFieldDetails.inputFieldInfo.currField.model == ("" || 0)){
                    fieldItem.attributes.disabled = true;
                    fieldItem.model=0;
                  } else {
                    fieldItem.attributes.disabled = false;
                  }
                }
              });              
            }           
          });
        }
      } catch (err) {
        console.error(err)
      }
    },
    ClosePopup(){
      this.showModalPopup =false;
    },
   async setShowModalPopup(currRowData){ // open popup for EditOversale flight
    this.ClosePopup();
    this.clearAlertMessages();
     let isAuthorized = await this.authorizeModule({operationId: 'editInitiateFlight',moduleId: this.getOVSIEntityId,origin: currRowData.flightOrigin,isModalErr:true})
      this.editModalDisplayTableFields = JSON.parse(JSON.stringify(this.addTableFields));
      this.modalData=currRowData;
      this.cabinWiseData=this.getCabinCodeWiseData(currRowData.cabins);
      this.editModalDisplayTableFields[0].modalTemp.modalFields.forEach((modalFlds) => {
        modalFlds[modalFlds.id][0].tableFields.forEach((inHeader) => {
          if (this.cabinWiseData[0][modalFlds.cabinCode] &&  this.cabinWiseData[0][modalFlds.cabinCode].length == 0) {
            inHeader.attributes.disabled = true;
            modalFlds.EmptyCabinFound = true;
            modalFlds.disableSection=true;
          } else if(inHeader.initialDisableBasedOnOtherFieldPathValue
           && this.getJPathValue(inHeader.initialDisableBasedOnOtherFieldPathValue ,this.cabinWiseData[0][modalFlds.cabinCode][0]) == 0 ){
            inHeader.attributes.disabled = true;
          }
          if (this.modalData.oversaleStatus == ('Finalized' || 'FINALIZED' ) ) {
            modalFlds.disableSection=true;
          }
         
        });
      });
      this.showModalPopup =true;
    },
    getCabinCodeWiseData(cabins){
      let filteredCabinData ={};
          this.addTableFields[0].modalTemp.modalFields.forEach((modalData )=>{
          if(modalData.cabinCode){      
              let cabinData = cabins.filter((item) => {
                  if (item.cabinCode == modalData.cabinCode)
                  return item;
                })
              filteredCabinData[modalData.cabinCode] = cabinData;
           }
        })
        return [filteredCabinData] ;
    },
  async loadMoreItems(){
      if(!this.apiResponse.nextPage || this.searchOVSIData.length == 0) return;
      this.setIsMoreDataLoading(true);
      const finalObj = {
          inputObject: {
            ...this.selectedInputValues.inputObject
          },
          actionId: this.actionId,
      };
      if(this.apiResponse.nextPage) //if token present then pass token in paload to get next data
        finalObj.inputObject.page = this.apiResponse.nextPage.toString();
      setTimeout(async() => {
        await this.getOVSIData(finalObj);
        this.setIsMoreDataLoading(false);
      }, 500);
    },
    async loadPageData(){
      if(this.prevNavigateViews.length > 0){
          const prevItems = this.prevNavigateViews.filter(
              (item) => item.id == this.getOVSIEntityId
              );
          const preItem = prevItems[prevItems.length-1];
          const finalObj = {
              inputObject: preItem.searchFilterInputParams,
              actionId: this.actionId,
          };
          await this.getOVSIData(finalObj);
        } else if (Object.keys(this.selectedInputValues).length > 0) {
          const finalObj = {
              inputObject: this.selectedInputValues.inputObject,
              actionId: this.actionId,
          };
          await this.getOVSIData(finalObj);
        }
    },
  async editOversaleLimit(tableFields){
    this.clearAlertMessages();
    let errFound = [];
    let header= {};
      tableFields.modalFields.forEach(modal => {
        let modalTableFields = modal[modal.id][0];
        if(modal?.headerText){
            header["headerText"]=modal.headerText
            header["headerPrefix"]=`${modal?.headerPrefix}`
          }
        let err = validatInputParams(modalTableFields.tableFields,header);
        if (err) {
          errFound = [...errFound, ...err];
        }
      });
      if (errFound.length > 0) {
        let alertInfo = {
          alertType: "error",
          alertMessages: [...errFound],
        };
        this.setModalAlertMessages(alertInfo);
        return;
      }
       let uiObj = {};
       let tempObj = [];
       tableFields.modalFields.forEach(modal => {
        let mf = modal[modal.id][0];
        if(modal.EmptyCabinFound){
          return; 
        }
        let cabObj = {cabinCode : modal.cabinCode,};
        let headers = mf.headers[0];
         if (headers.tableRootPath && !uiObj.hasOwnProperty(headers.tableRootPath))
          uiObj[headers.tableRootPath] = tempObj;
         mf.tableFields.forEach(f => {
          if(f.model=="") return;
          cabObj[f.updtPath] = {};
            if (f.updtPath) {
                if (f.combineStructure) {
                  let currObj = {};
                  let amt = f.model.toString().trim();
                  let amtCode = getAmtAndCurrencyCode(amt);
                  f.combineStructure.forEach(strctr => {
                    if(strctr.target == 'model') {
                      currObj[strctr.id] = amtCode[strctr.id] || strctr.defaultValue;
                    } else {
                      currObj[strctr.id] = strctr.defaultValue;
                    }                    
                  })
                  headers.tableRootPath ? cabObj[f.updtPath] = currObj : uiObj[f.updtPath] = currObj;
                } else {
                  headers.tableRootPath ? cabObj[f.updtPath] = f.model : uiObj[f.updtPath] = f.model;
                }
              }
         });
         uiObj[headers.tableRootPath].push(cabObj);
       })
       uiObj["carrierCode"] = this.modalData.carrierCode;
       uiObj["flightOrigin"] = this.modalData['flightOrigin'];
       uiObj["flightNumber"] = this.modalData['flightNumber'];
       uiObj["flightDate"] = this.modalData['flightDate'];
       uiObj["employeeId"] = this.getEmployeeId;
       uiObj["station"] = this.modalData['flightOrigin'];
       uiObj["flightDestination"] = this.modalData['flightDestination'];
       uiObj["channel"] = this.channel;
       let isAuthorized = await this.authorizeModule({operationId: 'editInitiateFlight',moduleId: this.getOVSIEntityId,origin: uiObj.flightOrigin,isModalErr:true})
        if(!isAuthorized){return; }
       await initiateFlight(uiObj).then(async(response)=>{
         if(response.status == 200){
           if(response.data.isSuccessful){
             this.setAlertMessages({
               alertType: "success",
               alertMessages: [`Flight ${response.data.flight.flightNumber} Updated Successfully`]
             })
             this.ClosePopup();
             this.loadPageData();
           }else{
             let msgArray = this.createEditOVersaleErrMSG(tableFields,response.data.messages);
             this.setModalAlertMessages({
               alertType: "warning",
               alertMessages: msgArray
             })
           }
         }
       }).catch(er=>{
         let response = er.response;
         try{
         let msgArray = this.createEditOVersaleErrMSG(tableFields,response.data.messages);
         this.setModalAlertMessages({
           alertType: "warning",
           alertMessages: msgArray
         })
        }catch(err){
          this.raiseServerError({er,isModalEr:true});
        }
       }).finally(()=>{
       });
     },
     createEditOVersaleErrMSG( tblFields,errmessages){
      let errorMsgs = errmessages.map( errmsgobj => {
          let errmsg=errmsgobj.message;
          tblFields.modalFields.forEach(modal => {
            let modalTableFields = modal[modal.id][0];
            modalTableFields.tableFields.forEach(tblFld =>{
              if(tblFld.compareFieldNameInErrMSG && errmsg.includes(tblFld.compareFieldNameInErrMSG)) {
                errmsg= errmsg.replace(tblFld.compareFieldNameInErrMSG, tblFld.label);//REPLACE UI FIELD NAME IN API ERROR MESSAGE        
              }
            }); 
          });             
          return errmsg;
        });
        return errorMsgs;
     },
     createOVSReportErrMSG(ovsRptModalConfig,errmessages){
      let tblFields = ovsRptModalConfig.modalFields[0].flightdetails[0].tableFields;
      let errorMsgs = errmessages.map( errmsgobj => {
          let errmsg=errmsgobj.message;
          tblFields.forEach(tblFld =>{
            tblFld?.subFields?.forEach((subField) => {
              if(subField.compareFieldNameInErrMSG && errmsg.includes(subField.compareFieldNameInErrMSG)) {
                errmsg= errmsg.replace(subField.compareFieldNameInErrMSG, subField.label);//REPLACE UI FIELD NAME IN API ERROR MESSAGE        
              }
            });   
          });          
          return errmsg;
        });
        return errorMsgs;
     },
    createOVSReport(btn){
      this.adddEditDeactivatedFlightButtons=JSON.parse(JSON.stringify(this.deactivatedFlightButtons));
      this.clearAlertMessages();
       this.intiateFlightPop=true;
      //this.navigateScreen(btn,this.searchOVSIData[0]);
    },
   async intiateFlight(modalConfig,btn){
    this.clearAlertMessages();
      let apiObj= {channel:this.channel,employeeId:this.getEmployeeId}; 
      let errFound=[];
      let err = validatInputParams(modalConfig.modalFields[0].flightdetails[0].tableFields);
        if (err) {
          errFound = [...errFound, ...err];
        }
       if(errFound.length > 0) {
        let alertInfo = {
          alertType: "error",
          alertMessages: [...errFound],
        };
        this.setModalAlertMessages(alertInfo);
        return;
      }
      modalConfig.modalFields[0].flightdetails[0].tableFields.forEach(tf=>{
        tf.subFields.forEach(sf=>{
          if(sf.model){
          if(sf.fieldType == 'UADatePicker')
            apiObj[sf.path]=getAPIFormattedDate(sf.model);
          else
            apiObj[sf.path]=sf.model;
          if(sf.id == 'origin')
          apiObj["station"]=sf.model;
          }
        })
      });
    let isAuthorized = await this.authorizeModule({operationId: 'initiateflight',moduleId: this.getOVSIEntityId ,isModalErr:true,origin: apiObj.flightOrigin});
    if(!isAuthorized){ this.setModalAlertMessages({ alertType: this.erMsg.errorType, alertMessages: [this.erMsg.text] }); return; }
     await initiateFlight(apiObj).then(async(response)=>{
        if(response.status == 200){
          if(response.data.isSuccessful){
            let updatedData=response.data.flight;
            await this.navigateScreen(btn,updatedData);
            this.setModalAlertMessages({
              alertType: "success",
              alertMessages: [`Flight ${response.data.flight.flightNumber} Initiated Successfully`]
            })
          }else{
            let msgArray = this.createOVSReportErrMSG(modalConfig,response.data.messages);
            this.setModalAlertMessages({
              alertType: "warning",
              alertMessages: msgArray
            })
          }
        }
      }).catch(er=>{
        try{
        let response = er.response;
        let msgArray = this.createOVSReportErrMSG(modalConfig,response.data.messages);
        this.setModalAlertMessages({
          alertType: "warning",
          alertMessages: msgArray
        })
      }catch(err){
        this.raiseServerError({er,isModalEr:true});
      }
      })
    },
    getConfirmMsg(eventInfo, data){
      let msgtxt = '';
      if(eventInfo.needConfirmBox){
        if(eventInfo.confirmBoxInfo.combineMessageInfo){
          eventInfo.confirmBoxInfo.combineMessageInfo.forEach(cnfmsg => {
            if(cnfmsg.isText){
              msgtxt = msgtxt + cnfmsg.text;
            } else {
              msgtxt = msgtxt + this.getJPathValue(cnfmsg.path, data);
            }            
          })
        }
      }
      return msgtxt;
    },
    handleConfirmOkFunc(confrmInfoObj){
      this.showConfrmBox =true;
      let {events, data} = confrmInfoObj;
      setTimeout(() => {   
        this.$refs.uaconfirmbox
          .dialogOpen({
            title: `${events.confirmBoxInfo.title}` ,
            message: `${this.getConfirmMsg(events, data)}`,
            okButtonText: "Yes",
            cancelButtonText: "No",
          })
          .then(async (ok) => {
            if(events.name == "stop"){
              this.stopOversaleApi(data);
            } else if(events.name == "initiate"){
              this.reInitiateAbrtFlight(data);
            }
          })
          .catch((er) => {});
      }, 50);
    },
    async stopOversaleApi(data) {
      let isAuthorized = await this.authorizeModule({ operationId: 'deactivateflight', moduleId: this.getOVSIEntityId, origin:data.flightOrigin })
      if (!isAuthorized) { return; }
      let apiObj = {
        "carrierCode": data.carrierCode,
        "flightOrigin": data.flightOrigin,
        "flightNumber": data.flightNumber,
        "flightDate": data.flightDate,
        "employeeId": this.getEmployeeId,
        "station": data.flightOrigin,
        "channel": this.channel,
      }
      deactiveFlight(apiObj).then(res => {
        if (res.status == 200) {
          if (res.data.isSuccessful) {
            this.setAlertMessages({
              alertType: "success",
              alertMessages: [`Flight  ${data.flightNumber} Stopped Successfully`]
            });
            this.loadPageData();
          } else {
            let msgArray = res.data.messages.map(m => m.message);
            this.setAlertMessages({
              alertType: "warning",
              alertMessages: msgArray
            })
          }
        }

      }).catch(er => {
        this.setAlertMessages({ alertType: 'warning', alertMessages: [`Stop Oversale Failed for Flight ${data.flightNumber}`] })
      })
    },
    async reInitiateAbrtFlight(data) {
      let isAuthorized = await this.authorizeModule({ operationId: 'initiateflight', moduleId: this.getOVSIEntityId, origin:data.flightOrigin })
      if (!isAuthorized) { return; }
      let apiObj = {
        "carrierCode": data.carrierCode,
        "flightOrigin": data.flightOrigin,
        "flightDestination":data.flightDestination,
        "flightNumber": data.flightNumber,
        "flightDate": data.flightDate,
        "employeeId": this.getEmployeeId,
        "station": data.flightOrigin,
        "channel": this.channel,
      }
      initiateFlight(apiObj).then(res => {
        if (res.status == 200) {
          if (res.data.isSuccessful) {
            this.setAlertMessages({
              alertType: "success",
              alertMessages: [`Flight  ${data.flightNumber} Initiated Successfully`]
            });
            this.loadPageData();
          } else {
            let msgArray = res.data.messages.map(m => m.message);
            this.setAlertMessages({
              alertType: "warning",
              alertMessages: msgArray
            })
          }
        }

      }).catch(er => {
        let response = er.response;
        try{
        let msgArray = response.data.messages.map(m => m.message);
        this.setAlertMessages({ 
          alertType: 'warning', 
          alertMessages: msgArray 
        })
      }catch(err){
        this.raiseServerError({er});
      }
      })
    }
  }
};
</script>

