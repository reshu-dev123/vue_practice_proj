<template>
  <div class="u-modal u-col" style="display: block" >
    <div class="u-round u-modal-Message">
      <div class="u-row">
        <div class="u-col l12 m12 s12">
          <div class="u-lineHeight-popup">
            <div :class="['u-col l12 m12 s12', alertCssClass]">
            <div class="u-col l11 m11 s11">
            <label class=" u-fnt-bld">{{ title }}</label>
            </div>
            <div class="u-col l1 m1 s1 u-right">
              <UAButton
                  @click="ok()"
                  cssClass="u-medium u-primary-inv-border u-fnt-bld u-round u-right"
                >
                  X
                </UAButton>
            </div>
          </div>

          
          <div v-if="spantag!=undefined"  class="u-col">
            <ul>
              <span class="u-border-0 u-text-red u-left u-fnt-bld" style="padding: 0px; white-space: break-spaces"
                v-for="(alert, index) in modalMessages" :key="index">
                {{ alert }}
              </span>
            </ul>
          </div>
          <div v-else class="u-col">
            <ul>
              <li class="u-border-0 u-text-red u-left u-fnt-bld" style="padding: 0px; white-space: break-spaces"
                v-for="(alert, index) in modalMessages" :key="index">
                {{ alert }}
              </li>
            </ul>
          </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</template>
<script>
import UAButton from "@/components/UAButton.vue";
import { mapState,mapMutations } from "vuex";
export default {
  name: "UAModalMessage",
  components: {
    UAButton
  },
  data() {
    return {
      okButtonText: null,
    };
  },
  computed: {
    ...mapState({
      modalType: (state) => state.messageModal.modalType,
      title: (state) => state.messageModal.title,
      modalMessages: (state) => state.messageModal.modalMessages,
      spantag: (state) => state.messageModal.spantag,
      showModalMessage: (state) => state.messageModal.showModalMessage,
      alertCssClass(state) {
      switch (state.messageModal.modalType.toLowerCase()) {
        case "error":
          return "errorAlert u-padding-small u-row  u-card u-center u-text-white u-round";
        case "warning":
          return "warningAlert u-padding-small u-row  u-card u-center u-text-white u-round";
        case "success":
          return "successAlert u-padding-small u-row  u-card u-center u-text-white u-round";
        case "information":
          return "infoAlert u-padding-small u-row  u-card u-center u-text-white u-round";
        default:
          return "u-padding-small u-row  u-card u-center u-text-white u-round";
      }
    },
    })
  },
  methods: {
    ...mapMutations(["clearModalMessages"]),
    ok() {
      this.clearModalMessages();
    }
  },
}
</script>

<style lang="scss">
.errorAlert {
  background-color: #f10f0f;
}
.warningAlert {
  background-color: #ff8800;
}
.successAlert {
  background-color: #007e33;
}
.infoAlert {
  background-color: #0099cc;
}
</style>


