<template>
  <div>
    <div class="label-margin">
      <label v-if="label" :for="label">
        {{ label }}
      </label>
    </div>
    <div>
      <input
        :type="type"
        :id="id"
        @input="updateInput"
        v-bind="$attrs"
        :class="cssClass"
        :value="modelValue"
      />
    </div>
  </div>
</template>

<style>
input {
  margin-left: 20px;
}
</style>

<script>
export default {
  name: "UAInput",
  data() {
    return {
      searchValue: "",
    };
  },
  props: ["label", "modelValue", "type", "cssClass", "id"],
  methods: {
    updateInput(event) {
      this.searchValue = event.target.value;

      this.$emit("update:modelValue", this.searchValue);
    },
  },
};
</script>
<style scoped>
.label-margin {
  margin: 10px 0px 10px 0px;
}
</style>