<template>
  <div :class="[
              'u-row',             
              {'u-disabled':isLoading}
            ]"  v-if="!isVisible">
    <div class="u-margin-bottom">
      <form
        @submit.prevent="getFiltersData(showSerachFilter)"
        class="u-row"
        v-show="computedScrollIsShow"
      >
        <div class="u-row-padding u-pad-0">
          <div class="u-col l12 ">
          <div
            v-for="(filter, index) in showSerachFilter"
            :class="['u-col', filter.colCssClass]"
            :key="index"
          >
            <template v-if="filter.isDisplay">
              <component v-if="filter.fieldType == 'UADateRangePicker'"
                :is="filter.fieldType"
                :id="filter.id"
                :isDisabled="filter.attributes.disabled"
                v-bind="filter.attributes"
                v-model:startDate="filter.model.startDate"
                v-model:endDate="filter.model.endDate"
                :options="filter.source"
                :labelInfo="filter.label"
                :isFloatLabel="filter.isFloatLabel"
                :showLabel="true"
                :selectOptions="getSourceOptions(filter, index)"
                :sourceType="filter.sourceType"
                :isMandatory="filter.attributes.required"
                :placeholder="filter.attributes.placeholder"
                :cssClass="filter.cssClass"
                :dataType="filter.dataType"
                :labelClass="filter.labelClass"
                ref="dateRangePickerCom"
                :errorMessage="filter.errorMessage"
                :filtersErrorTooltip="filter.filtersErrorTooltip"
                @update:startDate="
                  updateSearchFields($event, filter, filter.attributes.id)
                "
                @update:endDate="
                  updateSearchFields($event, filter, filter.attributes.id)
                "
                @radioOptionSelectedfromChild="handleRadioButton"
                :dateFieldInfo="filter"
              >
              </component>
              <component v-else-if="filter.modalDependentField == 'UAMultiSelect2'"
                :is="filter.fieldType"
                :isDisabled="filter.attributes.disabled"
                v-bind="filter.attributes"
                v-model="filter.model"
                :labelInfo="filter.label"
                :isFloatLabel="filter.isFloatLabel"
                :showLabel="true"
                :isMandatory="filter.attributes.required"
                :placeholder="filter.attributes.placeholder"
                :cssClass="filter.cssClass"
                :dataType="filter.dataType"
                :labelClass="filter.labelClass"
                :modelValue="filter.model"
                :errorMessage="filter.errorMessage"
                :filtersErrorTooltip="filter.filtersErrorTooltip"
                @update:modelValue="
                  updateSearchFields($event, filter, filter.attributes.id,'from event')
                "
                :currInputFieldInfo="filter"
                @click="openStationPopup(filter)"
              >
              </component>
              <component v-else
                :is="filter.fieldType"
                :isDisabled="filter.attributes.disabled"
                v-bind="filter.attributes"
                v-model="filter.model"
                :options="filter.source"
                :labelInfo="filter.label"
                :isFloatLabel="filter.isFloatLabel"
                :showLabel="true"
                :selectOptions="getSourceOptions(filter, index)"
                :sourceType="filter.sourceType"
                :isMandatory="filter.attributes.required"
                :placeholder="filter.attributes.placeholder"
                :cssClass="filter.cssClass"
                cssMargin="u-break-content u-line-height-15"
                :dataType="filter.dataType"
                :labelClass="filter.labelClass"
                :modelValue="filter.model"
                :errorMessage="filter.errorMessage"
                :filtersErrorTooltip="filter.filtersErrorTooltip"
                @update:modelValue="
                  updateSearchFields($event, filter, filter.attributes.id)
                "
                @radioOptionSelectedfromChild="handleRadioButton"
                :currInputFieldInfo="filter"
                :selectedKey="filter.selectedKey"
                :selectedLabel="filter?.selectedLabel"
                :dataLength="filter?.dataLength"
                :errorOnTop="filter.errorOnTop"
                :isModalvalueSwap="filter.isModalvalueSwap"
              >
              </component>
            </template>
          </div>
          <div  v-if="resetSearchVisible " :class="[
              'u-col l1-7 m4 s12 u-panel-msmall u-pad-0 u-flex-center' ,
              isRequiredCustomAlignButtons ? 'u-left' : 'u-right',
              {'u-disabled':isLoading}
            ]">
            <div class="u-padding-xsmall" v-if="showSerachFilter.length > 0" >
              <UAButton
                type="button"
                @click="resetFilters()"
                cssClass="u-button u-round u-secondary-1-pur u-col u-wd-5rem"
                id="button_reset"
                >Reset
              </UAButton>
            </div>
            <div class="u-padding-xsmall" 
            v-if="showSerachFilter.length > 0">
              <UAButton
                :cssClass="['u-button u-round u-primary-1-pur u-col u-wd-5rem u-padding-8', {'u-disabled':!isValidInputFilterParams} ]"
                :id="filterSubmitButtonText"
              >
                {{ filterSubmitButtonText }}
              </UAButton>
            </div>
          </div>            
          </div>          
        </div>        
      </form>
    </div>

    <div class="u-center u-small u-col" style="margin: -1rem">
      <UAButton 
        :disabled="this.isVisible"
        @click="setIsShow(!isShow)"
        id="toggle_search_chevron"
        cssClass="u-button u-round-xlarge u-bg-2 u-border-top u-right u-pad-0 u-border"
      >
      <span>
          <img v-if="isShow" src="@/assets/img/arrow-down.png" 
          alt = "chevron-down"
          class="u-menuImgSml u-border-0 u-transform-chevron u-transparent printHide" />
          <img v-else src="@/assets/img/arrow-down.png" 
          alt = "chevron-down"
          class="u-menuImgSml u-border-0  u-transparent printHide" />
       </span>
      </UAButton>
    </div>
  </div>
</template>
<script>
import UATextbox from "@/components/UATextbox.vue";
import UAButton from "@/components/UAButton.vue";
import UARadioButton from "@/components/UARadioButton.vue";
import UADatePicker from "@/components/UADatePicker.vue";
import UASelect from "@/components/UASelect.vue";
import { mapState, mapGetters, mapActions, mapMutations } from "vuex";
import { getDateTimePart, validatInputParams, getDefaultDate } from "@/helpers/utilities";
import UAMultiSelect2 from './UAMultiSelect2.vue';
import UADateRangePicker from "./UADateRangePicker.vue";
import UADropDown from './UADropDown.vue';
import UATime from "@/components/UATime.vue";
export default {
  name: "UAOVSISearchFilters",
  components: {
    UATextbox,
    UAButton,
    UARadioButton,
    UADatePicker,
    UASelect,
    UAMultiSelect2,
    UADateRangePicker,
    UADropDown,
    UATime
  },
  props: ["rtfFilters"],
  data() {
    return {
      dynamicMacroName: "", // will used based on selected cancel code
      dynamicMacroFields: [],
      beginDtIndex: 0,
      endDtIndex: 1,
      prevItem:{}
    };
  },
  created(){
    this.setSelectedInputValues({});
    if (this.prevNavigateViews.length == 0 ){
      this.resetToDefaultState();
    } else if(this.prevNavigateViews.length > 0 ){
      const prevItems = this.prevNavigateViews.filter(
        (item) => item.id == this.getOVSIEntityId
      ); 
      if(prevItems.length > 0){
        const preItem = prevItems[prevItems.length-1];
        if(preItem.bindSearchFilterParams){//to reset the previous field values
          this.resetToDefaultStateWithPrevValues(preItem.searchFilterInputParams,preItem?.searchFilterModel);
        } else {
          this.resetToDefaultState()
        }   
      }
    }
    this.setAddFilterItemSetOnSrch(Object.assign({},this.addFilterItem));
  },
  async mounted() {
    const prevItems = this.prevNavigateViews.filter((item) => item.id == this.getOVSIEntityId);
    this.prevItem=prevItems[0]
    prevItems.forEach((item)=>{
      if(item?.navToFltMngm){
        this.setIsShow(false);
    }
    }) 
    if(this.isHeaderSrchClicked){
      this.setHeaderSearchFilterData();
      this.setIsHeaderSrchClicked(false);
    }
    this.entityDisplayDetails.fetchDefault? await this.getFiltersData(this.showSerachFilter):'';
  },
  emits: ["resetDefaultData",'openMultiSelectPopup'],
  computed: {
    computedScrollIsShow(){
      if(this.isShow && !this.isScrollDown)
        return true;
      if(!this.isShow && this.isScrollDown)
        return true;
      if(this.isShow && this.isScrollDown)
        return false;
      if(!this.isShow && !this.isScrollDown)
        return false;
      
    },
    ...mapState({
      headerFilterData: (state) => state.ovsiDefaultModule.headerFilterData,
      isHeaderSrchClicked: (state) => state.ovsiDefaultModule.isHeaderSrchClicked,
      isNavigatedEvent: (state) => state.ovsiDefaultModule.isNavigatedEvent,
      navigatedEventFilterData: (state) =>
        state.ovsiDefaultModule.navigatedEventFilterData,
      action: (state) => state.ovsiDefaultModule.action,
      actionId: (state) => state.ovsiDefaultModule.actionId,
      entityDisplayDetails: (state) =>
        state.ovsiDefaultModule.entityDisplayDetails,
      searchFilterMacro: (state) => state.ovsiDefaultModule.searchFilterMacro,
      defaultSearchParams: (state) =>state.ovsiDefaultModule.entityDisplayDetails.defaultSearchParams,
      isVisible: (state) => state.ovsiDefaultModule.isVisible,
      addFilterItem: (state) => state.ovsiDefaultModule.addFilterItem,
      grpAccess: (state) => state.ovsiDefaultModule.grpAccess,
      dbType: (state) => state.ovsiDefaultModule.dbType,

      filterSubmitButtonText: (state) =>
        state.ovsiDefaultModule.filterSubmitButtonText,
      resetSearchVisible: (state) => state.ovsiDefaultModule.resetSearchVisible,
      isRequiredCustomAlignButtons: (state) =>
        state.ovsiDefaultModule.isRequiredCustomAlignButtons,
      showSerachFilter: (state) => state.ovsiDefaultModule.showSerachFilter,

      selectedInputValues: (state) =>
        state.ovsiDefaultModule.selectedInputValues,
      searchType: (state) => state.ovsiDefaultModule.searchType,
      isLoading: (state) => state.ovsiDefaultModule.isLoading,
      dateValidationMessage: (state) => state.ovsiDefaultModule.dateValidationMessage,
      secondarysearchFilterMacro:  (state) => state.ovsiDefaultModule.secondarysearchFilterMacro,
      prevNavigateViews: state => state.ovsiDefaultModule.prevNavigateViews,
      filterConfig: state => state.ovsiDefaultModule.filterConfig,
      showMultiSelectPop: (state) => state.ovsiDefaultModule.showMultiSelectPop,
      isShow: (state) => state.ovsiDefaultModule.isShow,
      isScrollDown: (state) => state.ovsiDefaultModule.isScrollDown,
      isSelectedAllHubs: (state) => state.ovsiDefaultModule.isSelectedAllHubs,
      isValidInputFilterParams(){//VERIFY ALL INPUT FIELDS TO MAKE SURE FIELDS ARE VALID WITH NO ERROR
        let errFound = validatInputParams(JSON.parse(JSON.stringify(this.showSerachFilter)));
        return errFound ? false : true;
      }
    }),
    ...mapGetters(["getJPathValue", "getUserName", "getOVSIEntityId","getUserStation"]),
  },
  
  methods: {
    ...mapActions(["getOVSIData", "clearAlertMessages"]),
    ...mapMutations([
      "reSetSearchOVSIData",
      "setInvalidDateError",
      "setIsLoading",
      "setSelectedInputValues",
      "setSelectedDataId",
      "setVisibleFilter",
      "publishRadioBtnValue",
      "setaddFilterItem",
      "resetaddFilterItem",
      "setAlertMessages",
      "setshowSerachFilter",
      "resetShowSerachFilter",
      "resetSelectedDataIds",
      "getSelectedUFDataId",
      "resetPagination",
      "setShowMultiSelectPop",
      "setIsHeaderSrchClicked",
      "setIsShow",
      "setSelectedAllHubs",
      "clearCache",
      "setAddFilterItemSetOnSrch",
      "setApplyFilterClicked"
    ]),
    openStationPopup(filter){
      this.setShowMultiSelectPop(!this.showMultiSelectPop);
      let modalData = filter.multiselectModalValue;
      this.$emit('openMultiSelectPopup',{"showpopup":this.showMultiSelectPop, modalData },filter)
    },

    createInputObj(editedField, inlineData, macroFields) {
      let inParamObj = {};
      try {
        let flightData = inlineData;
        macroFields.forEach((eField) => {
          if (editedField.hasOwnProperty(eField.path)) {
            if (eField.fieldType == "UADateTimePicker") {
              inParamObj[eField.id] = getDateTimePart(
                editedField[eField.path],
                eField.dateFormat
              );
            }else if(eField.fieldType == "UADateRangePicker"){
              inParamObj['SearchStartDate'] = editedField[eField.path][eField.model.startDate];
              inParamObj['SearchEndDate'] = editedField[eField.path][eField.model.endDate];
            }
          } else {
            if (eField.id == "par_username" || eField.id == "username" || eField.id == "empid") {
              inParamObj[eField.id] = this.getUserName;
            } else {
              if (flightData.hasOwnProperty(eField.path)) {
                inParamObj[eField.id] = this.getJPathValue(
                  eField.path,
                  flightData
                ).toString();
              } else {
                inParamObj[eField.id] = eField.model;
              }
            }
          }
        });
      } catch (err) {}
      return inParamObj;
    },
    handleRadioButton(selectedOption, index) {
      this.dynamicMacroName = selectedOption.macroName;
     
      this.dynamicMacroFields = selectedOption.macroFields;
      this.publishRadioBtnValue(selectedOption.id);
      this.reSetSearchOVSIData();
    },

    // Use if individual record has to be retrieve from backend.
    // Else for atomic entities - filter records on UI
    async getFiltersData(filters) {
      this.clearAlertMessages();
      this.clearCache();
      this.resetPagination();
      this.reSetSearchOVSIData();
      let errFound = validatInputParams(JSON.parse(JSON.stringify(filters)));
      if (errFound) {
        let alertInfo = {
          alertType: "error",
          alertMessages: ["Errors in the Search fields!", ...errFound],
        };
        this.setAlertMessages(alertInfo);
        return;
      }
      let stationModelValue=''  // To get Multiselect model value on search to use it on navigation return
      filters.forEach(filterItem =>{
        if(filterItem.modalDependentField == "UAMultiSelect2"){
          stationModelValue = filterItem.multiselectModalValue;
          if(filterItem.multiselectModalValue.showHubTable) 
            this.setSelectedAllHubs(true);
          else 
            this.setSelectedAllHubs(false);
        }
      })
      this.setIsLoading(true);
      let filteredFileds = JSON.parse(JSON.stringify(this.addFilterItem));
      if(this.defaultSearchParams){ // setting default params not present in filter but set from metadata
        this.defaultSearchParams.forEach(defaultF=> {
          if(defaultF.id == 'show_hubs'){
            if(this.isSelectedAllHubs)//PASS showhubs param true only when the user selects "All stations" or "All hubs".
              filteredFileds[defaultF.path]=defaultF.model
            else 
              filteredFileds[defaultF.path] = false;
          } else 
            filteredFileds[defaultF.path]=defaultF.model
        });
      }
      delete filteredFileds?.volunteerStatuses;
      const iObj=filteredFileds;
      const finalObj = {
        inputObject: iObj,
        action: this.dynamicMacroName
          ? this.dynamicMacroName
          : this.searchFilterMacro, // default If cnxlCode = NO
        actionId: this.actionId,
        multiSelectModel: stationModelValue,
      };
      this.setSelectedInputValues(finalObj);
      this.setAddFilterItemSetOnSrch(Object.assign({},this.addFilterItem));
      await this.getOVSIData(finalObj);
      this.$emit("resetDefaultData", true);
      this.setApplyFilterClicked(false);
    },
    setMultiSelectModal(modalVal, dataObjForAll,filterObj){
      this.addFilterItem[filterObj.path] = modalVal.selectedOptions;
      this.updateSearchFields(modalVal.selectedModelText, filterObj, filterObj.attributes.id);
      filterObj.multiselectModalValue = dataObjForAll;
    },
    updateSearchFields(eVal, filter, modalPath, dd) {
      if (filter?.fieldType == "UADatePicker") {
        this.addFilterItem[modalPath] = getDateTimePart(
          filter?.model,
          "yyyy-mm-dd"
        );
      } else if (filter?.fieldType == "UADateRangePicker") {
        for(let [key,value] of Object.entries(filter.model)){
          this.addFilterItem[filter.attributes.id[key]] =value
        }
        // this.addFilterItem['SearchStartDate'] = filter.model.startDate;
        // this.addFilterItem['SearchEndDate'] = filter.model.endDate;
      }  else if (filter?.modalDependentField == "UAMultiSelect2") {
          //this.addFilterItem[modalPath] = eVal.selectedOptions;
          filter.model = eVal;
      } else {
        if (filter?.isModalvalueSwap != undefined) {
          let currenteval = ''
          if (eVal != undefined) {
            let filterObj = filter.source.filter((item) => {
              return item.name == eVal;
            });
            if (filterObj.length > 0) {
              currenteval = filterObj[0].id;
            } else {
              currenteval = '';
            }
          } 
          this.addFilterItem[modalPath] = currenteval;
          filter.model = eVal;        
        } else {
          this.addFilterItem[modalPath] = eVal;
          filter.model = eVal;
        }        
      }
      this.setaddFilterItem(this.addFilterItem);
    },
    setHeaderSearchFilterData(){
      this.showSerachFilter.forEach((inHeader) => {
        if (inHeader.fieldType) {
          if(inHeader.fieldType == "UADateRangePicker") {
            let fltItemData = this.headerFilterData;
              let dtKeys = Object.keys(inHeader.attributes.id);
              if(this.headerFilterData.hasOwnProperty(inHeader.attributes.id[dtKeys[0]])){
                inHeader.model[dtKeys[0]] = fltItemData[inHeader.attributes.id[dtKeys[0]]]
              }
              if(this.headerFilterData.hasOwnProperty(inHeader.attributes.id[dtKeys[1]])){
                inHeader.model[dtKeys[1]] = fltItemData[inHeader.attributes.id[dtKeys[1]]]
              }
            this.updateSearchFields(inHeader.model, inHeader, inHeader.attributes.id);
          } else {
            if(this.headerFilterData.hasOwnProperty(inHeader.attributes.id)){
              let fltItemData = this.headerFilterData[inHeader.attributes.id];
              if(inHeader.fieldType == "UADatePicker"){
                inHeader.model = getDefaultDate(fltItemData);
              } 
              else {
                inHeader.model = fltItemData;
              }
              this.updateSearchFields(inHeader.model, inHeader, inHeader.attributes.id);
            }
          }
        }
      });
    },
    resetToDefaultState() {
      this.setaddFilterItem({});
      this.resetPagination();
      this.showSerachFilter.forEach((inHeader) => {
        if (inHeader.fieldType) {
          inHeader.isError= false;
            if(inHeader.defaultSelectedValue && inHeader.defaultSelectedValue != "") {
              if(inHeader.fieldType == "UADatePicker"){
                inHeader.model = getDefaultDate(inHeader.defaultSelectedValue);
              } else if(inHeader.fieldType == "UADateRangePicker"){
                inHeader.model =  { 
                  "startDate": getDefaultDate(inHeader.defaultSelectedValue),
                  "endDate": getDefaultDate(inHeader.defaultSelectedValue)
                };
              } 
              else if(inHeader.modalDependentField == "UAMultiSelect2"){
               /* inHeader.model = inHeader.defaultSelectedValue.selectedModelText;
                this.addFilterItem[inHeader.path] = inHeader.defaultSelectedValue.selectedOptions;
                if(inHeader.model == inHeader.defaultSelectedValue.selectedModelText){
                  this.setSelectedAllHubs(true);
                } */
                let selectedOptions=[this.getUserStation];
                inHeader.model = this.getUserStation;
                inHeader.multiselectModalValue = {
                  "selectedModelText": this.getUserStation,
                  "selectedOptions": selectedOptions
                }
                this.addFilterItem[inHeader.path] = selectedOptions; 
                this.setSelectedAllHubs(false); // default  will be local  
              } 
              else {
                inHeader.model = inHeader.defaultSelectedValue;
              }
                this.updateSearchFields(inHeader.model, inHeader, inHeader.attributes.id);
            } else {
              if(inHeader.fieldType == "UADateRangePicker"){
                inHeader.model =  { "startDate": getDefaultDate(),"endDate": getDefaultDate()};
                this.updateSearchFields(inHeader.model, inHeader, inHeader.attributes.id);
              } else {
                inHeader.model = "";
              }             
            }
        }
      });
      
    },
    //THIS IS FOR RETURNING BACK TO MAIN PAGE. 
    //SHOW/SET THE PREVIOUS MODEL VALUE TO FIELDS WHICH IS USED WHILE FILTERED THE RECORDS FIRST TIME.
    resetToDefaultStateWithPrevValues(prevInpObj,prevObjModel) {
      this.setaddFilterItem({});
      this.resetPagination();
      this.showSerachFilter.forEach((inHeader) => {
        if(inHeader.fieldType) {
          inHeader.isError= false;
          if(inHeader.defaultSelectedValue && inHeader.defaultSelectedValue != "") {
            if(inHeader.fieldType == "UADatePicker"){
              inHeader.model = prevInpObj.hasOwnProperty(inHeader.attributes.id) 
                ? this.getJPathValue(inHeader.attributes.id, prevInpObj) 
                : getDefaultDate(inHeader.defaultSelectedValue);
            } else if(inHeader.fieldType == "UADateRangePicker"){
              inHeader.model =  { 
                "startDate": prevInpObj.hasOwnProperty(inHeader.attributes.id["startDate"]) 
                  ? this.getJPathValue(inHeader.attributes.id["startDate"], prevInpObj) : getDefaultDate(inHeader.defaultSelectedValue),
                "endDate": prevInpObj.hasOwnProperty(inHeader.attributes.id["endDate"]) 
                  ? this.getJPathValue(inHeader.attributes.id["endDate"], prevInpObj) : getDefaultDate(inHeader.defaultSelectedValue)
              };
            } 
            else if(inHeader.modalDependentField == "UAMultiSelect2"){
              let selectedOptions= prevInpObj.stations || [this.getUserStation];
              inHeader.model =prevObjModel.selectedModelText || this.getUserStation;
              inHeader.multiselectModalValue.selectedModelText= prevObjModel.selectedModelText || this.getUserStation;
              inHeader.multiselectModalValue.groupId= prevObjModel.groupId || '';
              inHeader.multiselectModalValue.selectedOptions= (selectedOptions == 'all' ? prevObjModel.selectedOptions : selectedOptions);
              inHeader.multiselectModalValue.showHubTable = prevObjModel.showHubTable;
              this.addFilterItem[inHeader.path] = selectedOptions;
              let cnt = 0
              selectedOptions.forEach(optItem => {
                inHeader.defaultSelectedValue.selectedOptions.forEach(hubItem => {
                  if (optItem == hubItem) {
                    cnt++;
                  }
                })
              })
              if(selectedOptions == 'all' || cnt == inHeader.defaultSelectedValue.selectedOptions.length){
                this.setSelectedAllHubs(true);
              } else{
                this.setSelectedAllHubs(false); // default  will be local  
              }
            } 
            else {
              inHeader.model = prevInpObj.hasOwnProperty(inHeader.attributes.id) 
              ? this.getJPathValue(inHeader.attributes.id, prevInpObj) : inHeader.defaultSelectedValue;
            }
              this.updateSearchFields(inHeader.model, inHeader, inHeader.attributes.id);
          } else {
            if(inHeader.fieldType == "UADateRangePicker"){
              inHeader.model =  { 
                "startDate": prevInpObj.hasOwnProperty(inHeader.attributes.id["startDate"]) 
                  ? this.getJPathValue(inHeader.attributes.id["startDate"], prevInpObj) : getDefaultDate(),
                "endDate": prevInpObj.hasOwnProperty(inHeader.attributes.id["endDate"]) 
                  ? this.getJPathValue(inHeader.attributes.id["endDate"], prevInpObj) : getDefaultDate()
              };
              this.updateSearchFields(inHeader.model, inHeader, inHeader.attributes.id);
            } else {
              inHeader.model = prevInpObj.hasOwnProperty(inHeader.attributes.id) 
                  ? this.getJPathValue(inHeader.attributes.id, prevInpObj) : "";
              this.updateSearchFields(inHeader.model, inHeader, inHeader.attributes.id);
            }             
          }
        }
      });
    },
    resetFilters() {
      this.clearAlertMessages();
      this.resetaddFilterItem();
      this.reSetSearchOVSIData();
      this.clearCache();
      this.resetShowSerachFilter(JSON.parse(JSON.stringify(this.rtfFilters)));
      this.resetToDefaultState();
      this.$emit("resetDefaultData", false);
      this.entityDisplayDetails.fetchDefault?this.getFiltersData(this.showSerachFilter):'';
      if(this.$refs.dateRangePickerCom) this.$refs.dateRangePickerCom[0].resetDataRange();
    },
    getSourceOptions(entityItem, index) {
      switch (entityItem.sourceType) {
        case "api":
          return entityItem.source;
        case "inLine":
          return entityItem.source;
        default:
          return "";
      }
    },
  },
};
</script>