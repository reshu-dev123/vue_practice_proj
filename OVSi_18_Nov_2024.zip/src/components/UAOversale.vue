<template>
    <!--Sub Tabs Tabs -->
    <UATab v-if="!isEnlargePopup" :tabFields="tabs" :selectedTabInd="selectedTabIndex" @selectedTab="handleSelectTab" headerSticky=true 
    :cssClass="(isLoading || isCostLoading || isDBdetailsLoading) && 'u-disabled'" />
    <!-- cards -->
    <div id="OVSi_loading" v-if="isLoading" class="u-row u-center u-fnt-bld u-msmall u-section-1"> Loading... </div>
    <div v-else class="u-row" >
        <div class="u-row" v-if="selectedTabIndex == 0">
            <div v-if="!isEnlargePopup" class="u-col l3 m3 s12">
                <template v-for="(card, cardIndex) in sections[0].cardsConfig" :key="cardIndex">
                    <UAOSLCard :label="card.label" :icon="card.icon" cardCssClass="u-round-10px" :cssClass="['u-card-radius', card.cssClass]" 
                    :data="card.id == 'seats'?getCabinValues(searchOVSIData[card.path]):getValue(searchOVSIData,card)"
                        :text="card.link" :actions="card.actions" :id="card.id"
                        :labelCss="['u-text-black u-medium lf mf sf']" @navigateScreen="navigateScreen" />
                </template>
                <UAOSLCard :fields="sections[0].hubsCard.hubsFields" :records="searchOVSIData['totalOverBookedPerStation']" v-if="isSelectedAllHubs" cardCssClass="u-round-10px"
                label="Hubs" :icon="sections[0].hubsCard.icon" :labelCss="['u-text-black u-fnt-bld']" :cssClass="['u-card-radius']" :id="sections[0].hubsCard.id"
                    :class="[sections[0].hubsCard.hubsFields.cssClass]" :actions="sections[0].hubsCard.hubsFields.actions"
                    @navigateScreen="navigateScreen" />
            </div>
            <div :class="[!isEnlargePopup ?'u-col l9 m9 s12':'u-col l12 m12 s12 u-section u-print']">
                <UAOSLCard :icon="sections[0].chartConfigs.icon" :label="sections[0].chartConfigs.label" :labelCss="sections[0].chartConfigs.textCSSClass" :id="sections[0].chartConfigs.id"
                :btnText="!isEnlargePopup ? sections[0].chartConfigs.secondaryLabel : ' '"  :icon1="!isEnlargePopup ? sections[0].chartConfigs.icon1 : sections[0].chartConfigs.closeIcon " 
                @toggleIcon="enlargeScreen" :btnCssClass="sections[0].chartConfigs.btnCssClass"
                :cssClass="['u-card-radius']" cardCssClass="u-round-10px" :chartData="getChartDatahub()" :chartOptions="lineChartOptions" :chartSections="sections[0].chartConfigs"
                :chartPlugins="lineChartPlugins"/>
            </div>
        </div>
        <div class="u-row" v-if="selectedTabIndex == 1">
            <div v-if="isCostLoading" class="u-row u-center u-fnt-bld u-msmall u-section-1"> Loading... </div>
            <div v-else>
            <!-- Filter -->
                <div class="u-row">
                    <span class="u-col l9 m10 s12">
                        <label class="u-padding-left-16 u-small u-fnt-bld u-col l6 m6 s6">{{ sections[1].headerText }}</label>
                    </span>
                </div>
                <div class="u-col l9 m10 s12">
                    <template v-for="(filter, filterIndex) in sections[1].filters" :key="filterIndex">
                        <component :is="filter.componentType" :cssClass="filter.cssClass" :cellCss="filter.cellCss" v-model="filter.model" :id="filter.id"
                        :direction="filter.direction" :selectOptions="filter.radioItems" @radioOptionSelectedfromChild="(e)=>handleRadioOption(sections[1].filters,e)"
                         />
                    </template>
                </div>
                <!-- cards -->
                <div class="u-row u-margin-top-20">
                    <template v-for="(crdData,crdIndex) in sections[1].cardData" :key="crdIndex">
                    <div class="u-col l3 m6 s12 u-padding">
                        <UACards :data="[crdData]" :crdData="ovsiCstDataByVolType" />
                    </div>
                    </template>
                </div>
                <!-- Tables -->
                <div class="u-row u-margin-top-14">
                    <UATableDisplay :tableData="ovsiCstDataByVolType?.flightInfo?.flightInfo" :tableFields="sections[1].tableMetaData"
                    :rowCssClass="['u-white']" :headerCssClass="['u-bg-5-inv']" @navigateScreen="navigateToReportScreen" />
                </div>
            </div>
        </div>
        <div class="u-row" v-if="selectedTabIndex == 2">
            <div v-if="isDBdetailsLoading" class="u-row u-center u-fnt-bld u-msmall u-section-1"> Loading... </div>
            <div v-else>
            <!-- Filter -->
            <div class="u-row">
                <!-- <div class="u-row">
                    <span class="u-col l9 m10 s12">
                        <label class="u-padding-left-16 u-small u-fnt-bld u-col l6 m6 s6">{{ sections[2].headerText }}</label>
                    </span>
                </div> -->
                <div class="u-col l12 m12 s12">
                    <template v-for="(filter, filterIndex) in sections[2].chartConfigs.filters" :key="filterIndex">
                        <div v-if="filter.shoTop" :class="filter.cssClass">
                        <label class="u-padding-left-16 u-small u-fnt-bld u-col">{{ filter.headerText }}</label>
                        <component :is="filter.componentType" :cellCss="filter.cellCss" :id="filter.id"
                        :direction="filter.direction" :selectOptions="filter.radioItems" v-model="filter.model"
                        :options="filter.source" @radioOptionSelectedfromChild="(e)=>handleRadioOptionDB(sections[2].chartConfigs.filters,e)"
                        />
                        </div>
                    </template>
                </div>
            </div>
            <!-- charts -->
            <div class="u-row">
                <template v-for="(chart, chartIndex) in sections[2].chartConfigs.charts" :key="chartIndex">
                    <div :class="chart.cssClass" >
                    <UAOSLCard v-if="generatedChartData[chart.path] && Object.keys(generatedChartData[chart.path]).length>0"
                :chartSections="chart" 
                :id="chart.id"
                cardCssClass="u-round-10px"
               :chartData="generatedChartData[chart.path]"
                :chartOptions="getChartOptionWithCustomPlugin(chart)"
                :cssClass="chart.cssClass"/>
            </div>
                </template>

            </div>
            <div class="u-row u-border-top-2px">
                <div class="u-col l12 u-margin-top">
                        <template v-for="(filter, filterIndex) in sections[2].chartConfigs.filters" :key="filterIndex">
                            <div v-if="!filter.shoTop" :class="filter.cssClass">
                            <label :class="['u-col',filter.headerCss]">{{ filter.headerText }}</label>
                            <component :is="filter.componentType" :id="filter.id"
                            @updateOption="(e)=>handleDropdown(e,filter)" :selectedKey="filter.selectedKey" :cssClass="filter.cellCss"
                            :direction="filter.direction" :selectOptions="filter.radioItems" v-model="filter.model"
                            :options="filter.source" @radioOptionSelectedfromChild="(e)=>handleRadioOptionDB(sections[2].chartConfigs.filters,e)"/>
                            </div>
                        </template>
                </div>
            </div>
            <!-- Table supports multi tabs: supports progress bars  UAOSLTableGraph-->
            <div class="u-row" v-if="dbDetailsReponse">
                <component :is="sections[2].tableMetaData.componentType" :filters="sections[2].chartConfigs.filters"
                :chartResponse="dbDetailsReponse" :charts="sections[2].tableMetaData.charts" :boardingTypes="sections[2].chartConfigs.deniedBoardingTypes" 
                :selectedViewOption="selectedViewAs" :tblHeaders="sections[2].tableMetaData.tableHeaders" :boardingType="selectedBoardingType" :spendFltrModel="selectedSpendFltrModel"/>
                </div>
            </div>
        </div>
    </div>
</template>

<script>
import UAButton from "./UAButton.vue";
import UAOSLCard from './UAOSLCard.vue';
import UATab from "./UATab.vue";
import UATableDisplay from "./UATableDisplay.vue";
import { mapActions, mapMutations, mapState, mapGetters } from 'vuex';
import UACards from "./UACards.vue";
import UACheckbox from './UACheckbox.vue';
import UAOSLTableGraph from "./UAOSLTableGraph.vue";
import {  createHash ,getImageUrl, getCombinedCabinValues,createGetInputObj,getRandomColor } from "../helpers/utilities";
import UARadioButton from './UARadioButton.vue';
import UADropDown from "./UADropDown.vue";
import UAUIPagination from './UAUIPagination.vue';
import { getoverviewbycost ,getoverviewbydb} from '../services/oversaleService';
export default {
    name: "UAOversale",
    data() {
        return {
            startPage:1,
            endpage:1,
            isDisabled: false,
            isEnlargePopup: false,
            selectedButton:'',
            selectedViewAs: {},
            selectedBoardingType: 'All',
            selectedSpendFltrModel:{},
            oversaleCostData:{},
            lineChartPlugins: [{
                id: 'verticalLiner',
                afterInit: (chart, args, opts) => {
                    chart.verticalLiner = {}
                },
                afterEvent: (chart, args, options) => {
                    const {inChartArea} = args
                    chart.verticalLiner = {draw: inChartArea}
                },
                beforeTooltipDraw: (chart, args, options) => {
                    const {draw} = chart.verticalLiner
                    if (!draw) return
                    const {ctx} = chart
                    const {top, bottom} = chart.chartArea
                    const {tooltip} = args
                    const x = tooltip?.caretX
                    if (!x) return
                    ctx.save()                    
                    ctx.beginPath()
                    ctx.moveTo(x, top)
                    ctx.lineTo(x, bottom)
                    ctx.stroke()                    
                    ctx.restore()
                }
            }],
            lineChartOptions: {
                responsive: true,
                maintainAspectRatio: false,
                fill: true,
                interaction: {
                    intersect: true
                },
                events: ['click','mousemove'],
                scales:{
                    x:{
                        title:{
                            display:true,
                            text:"Hour",
                            color:'#000',
                            font: {
                                size: 18
                            }
                        },
                        grid:{
                            display: false,
                        },
                    },
                    y:{
                        min: 0,
                        title:{
                            display:true,
                            text:"Flights",
                            color:'#000',
                            font: {
                                size: 18
                            }
                        },
                        grid:{
                            drawBorder: false,
                        }
                    },
                    
                },
                plugins: {
                    legend: {
                        display: false,
                       
                    },
                    tooltip: {
                        enabled: false,
                        position: 'nearest',
                        external: this.externalTooltipHandlerhub,
                       
                    },
                    
                    
                },
                onHover:(event,chartElement) =>{
                    event.native.target.style.cursor = chartElement[0] ? 'pointer' : 'default';
                },
                
            },
            pi: [
                {
                    labels: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'P', 'S'],
                    datasets: [
                        {
                            label: 'Denied boarding count by type',
                            backgroundColor: ['#208500', '#0fd702','#00b1a8', '#69b3e7', '#6244bb', '#ff4fde', '#900030', '#f46335', '#edb72b', '#3d85be'],
                            data: []
                        }
                    ]
                },
                {
                    labels: ['Type A', 'Type B', 'Type C', 'Type D', 'Type E', 'Type F', 'Type G', 'Type P', 'Type S'],
                    datasets: [
                        {
                            label: 'Denied boarding spend by type',
                            backgroundColor: ['#208500', '#0fd702','#00b1a8', '#69b3e7', '#6244bb', '#ff4fde', '#900030', '#f46335', '#edb72b', '#3d85be'],
                            data: [22, 15, 5, 10, 16, 7, 15, 4, 6]
                        }
                    ]
                }
            ],
            dbDetailsReponse:{},
            dbChartData :[
                {
                    labels: ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'P', 'S'],
                    datasets: [
                        {
                            label: 'Denied Boarding Count',
                            backgroundColor: ['#208500', '#0fd702','#00b1a8', '#69b3e7', '#6244bb', '#ff4fde', '#900030', '#f46335', '#edb72b', '#3d85be'],
                            data: []
                        }
                    ]
                },
                {
                    labels:  ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'P', 'S'],
                    datasets: [
                        {
                            label: 'Value',
                            backgroundColor: ['#208500', '#0fd702','#00b1a8', '#69b3e7', '#6244bb', '#ff4fde', '#900030', '#f46335', '#edb72b', '#3d85be'],
                            data: []
                        }
                    ]
                }
            ],
            ovsiCstDataByVolType: {},
            isCostLoading : false,
            isDBdetailsLoading : false,
            generatedChartData:{"boardingCount":{"labels":["A","B","C","D","E","F","G","P","S"],"datasets":[{"label":"Denied Boarding Count","backgroundColor":["#208500","#0fd702","#00b1a8","#69b3e7","#6244bb","#ff4fde","#900030","#f46335","#edb72b","#3d85be"],"data":[0,0,0,0,0,0,0,0,0]}]},"spendData":{"labels":["A","B","C","D","E","F","G","P","S"],"datasets":[{"label":"Miles","backgroundColor":["#208500","#0fd702","#00b1a8","#69b3e7","#6244bb","#ff4fde","#900030","#f46335","#edb72b","#3d85be"],"data":[0,0,0,0,0,0,0,0,0]}]}},
        }
    },
        components: {
        UAButton,
        UAOSLCard,
        UATab,
        UATableDisplay,
        UACards,
        UACheckbox,
        UAOSLTableGraph,
        UARadioButton,
        UADropDown,
        UAUIPagination
    },
    async created() {
        this.loadPageData();
        this.setIsShow(true);
    },
    mounted() {
        this.selectTab()
    },
    computed: {
        ...mapState({
            searchOVSIData: (state)=>state.ovsiDefaultModule.searchOVSIData,
            isSelectedAllHubs: (state) => state.ovsiDefaultModule.isSelectedAllHubs,
            chartConfig: (state) => state.ovsiDefaultModule.chartConfig,
            sections: (state) => state.ovsiDefaultModule.entityDisplayDetails.Layouts[0].InnerLayout.sections,
            mainViewId: state => state.ovsiDefaultModule.mainViewId,
            selectedInputValues: state => state.ovsiDefaultModule.selectedInputValues,
            prevNavigateViews: state => state.ovsiDefaultModule.prevNavigateViews,
            isNavigatedEvent: state => state.ovsiDefaultModule.isNavigatedEvent,
            actionId: (state) => state.ovsiDefaultModule.actionId,
            showSerachFilter: (state) => state.ovsiDefaultModule.showSerachFilter,
            currentPage: (state) => state.ovsiDefaultModule.currentPage,
            isLoading: (state) => state.ovsiDefaultModule.isLoading,
            selectedRecord: (state) => state.ovsiDefaultModule.selectedRecord,
            tabs: (state)=>state.ovsiDefaultModule.entityDisplayDetails.Layouts[0].tabs,
            chartConfigsNav:(state) => state.ovsiDefaultModule.entityDisplayDetails.Layouts[0].InnerLayout.sections[0].chartConfigs,
            addFilterItemSetOnSrch: (state) => state.ovsiDefaultModule.addFilterItemSetOnSrch,
            oversaleCostDfltSrchParams: (state) =>state.ovsiDefaultModule.entityDisplayDetails.oversaleCostDfltSrchParams,
            selectedTabIndex : (state) => state.ovsiDefaultModule.currentSelTabIndex,
            applyFilterClicked : (state) => state.ovsiDefaultModule.applyFilterClicked
        }),
        ...mapGetters(["getOVSIEntityId","getCachePaths"])
    },
    methods: {
        ...mapActions(["getEntityDisplayDetailsAction", "getFlights", "getOVSIData","updatePrevOptions","authorizeModule","handleError","getFromCache",'addIntoCache',"unAuthorizedHandler"]),
        ...mapMutations(["setIsNavigatedEvent","setIsShow",
            "setIsNavigateToInnerOtherView", "setSelectedMenuId","setCurrentSelTabIndex",
            "setPrevNavigateViews","setSelectedRecord","setAlertMessages","setIsLoading","clearAlertMessages","resetPrevNavigateViews"]),
            getChartOptionWithCustomPlugin(chart){
                if(chart.id == 'boarding_spend_by_type'){
                    chart.chartOptions.plugins.tooltip['callbacks']={
                        label: function(context) {
                            let label = '';
                            if (context.parsed.y !== (null || 0 )) {
                                label += `${context.dataset.label}${': '}${Number.isInteger(context.parsed.y)?context.parsed.y:context.parsed.y.toFixed(2)}`;
                            }
                            return label;
                        }
                }
                chart.chartOptions.scales.y.title.text= `${chart.dynamicText} (${this.getSpendByFromModel()?.model})`;
            }
                return chart.chartOptions;
            },
            resetGeneratedData(){
                this.generatedChartData={"boardingCount":{"labels":["A","B","C","D","E","F","G","P","S"],"datasets":[{"label":"Denied Boarding Count","backgroundColor":["#208500","#0fd702","#00b1a8","#69b3e7","#6244bb","#ff4fde","#900030","#f46335","#edb72b","#3d85be"],"data":[0,0,0,0,0,0,0,0,0]}]},"spendData":{"labels":["A","B","C","D","E","F","G","P","S"],"datasets":[{"label":"Miles","backgroundColor":["#208500","#0fd702","#00b1a8","#69b3e7","#6244bb","#ff4fde","#900030","#f46335","#edb72b","#3d85be"],"data":[0,0,0,0,0,0,0,0,0]}]}};
            },
    setCostDataFrSlVlType(filterItem){ // from cost tab Data by VolStatus
        this.ovsiCstDataByVolType={};
        if(this.oversaleCostData && Object.keys(this.oversaleCostData).length>0){
            let milesData = this.oversaleCostData.totalMileVolTypes
            milesData = this.oversaleCostData.totalMileVolTypes.filter(item=>{
                return filterItem[0].model == item.volStatus
            })
            this.ovsiCstDataByVolType["totalMileVolTypes"] = milesData[0]
            let fltCntData = this.oversaleCostData.totalFlightCounts
            fltCntData = this.oversaleCostData.totalFlightCounts.filter(item=>{
                return filterItem[0].model == item.volStatus
            })
            this.ovsiCstDataByVolType["totalFlightCounts"] = fltCntData[0]
            let etcData = this.oversaleCostData.totalEtc
            etcData = this.oversaleCostData.totalEtc.filter(item=>{
                return filterItem[0].model == item.volStatus
            })
            this.ovsiCstDataByVolType["totalEtc"] = etcData[0]
            let draftData = this.oversaleCostData.totalDraft
            draftData = this.oversaleCostData.totalDraft.filter(item=>{
                return filterItem[0].model == item.volStatus
            })
            this.ovsiCstDataByVolType["totalDraft"] = draftData[0]
            let fltInfoData = this.oversaleCostData.flightInfo
            fltInfoData = this.oversaleCostData.flightInfo.filter(item=>{
                return filterItem[0].model == item.volStatus
            })
            this.ovsiCstDataByVolType["flightInfo"] = fltInfoData[0]
        }
    },
    handleRadioOption(inlineFilters,selectedOption){ // from cost tab
        this.setCostDataFrSlVlType(inlineFilters) //Cost tab Data by VolStatus
    },
    getValue(searchOVSIData,card){
        let defV = card.defaultValue || '';
        return searchOVSIData[card.path]||defV;
    },
    generateKey(operationId,obj){
        return operationId+createHash(obj.inputObject,this.getCachePaths).toString();
    },
    generateForMiles(denyTypes,spendMiles,selectedVol){
            let typeWiseMiles= [];
            denyTypes.forEach(type=>{
                let milesCount = spendMiles?.filter(spM=>spM.dbType == type.code);
                if(milesCount && milesCount.length>0){
                    typeWiseMiles.push(milesCount[0].totalMiles)
                }else{
                    typeWiseMiles.push(0)
                }
            })
            let milesChart = JSON.parse(JSON.stringify(this.dbChartData[0]));
            milesChart.datasets[0].label = 'Miles'
            milesChart.datasets[0].data = typeWiseMiles;
            return milesChart;
    },
    generateSpendData(dbDetailsReponse) {
            let deniedBoardingTypes = this.sections[2].chartConfigs.deniedBoardingTypes;
            let charts = this.sections[2].chartConfigs.charts;
            let selectedVol = this.getVolStatusFromModel();
            let spendObj = this.getSpendByFromModel();
            this.resetGeneratedData();
            charts.forEach((chart, index) => {
                let chartDetails = this.dbChartData[index];
                if (chart.id == 'boarding_spend_by_type') {
                    let dbSpendByTypeForSlOpt = dbDetailsReponse[spendObj.path]?.filter(dbcont => dbcont.volStatus.toLowerCase() == selectedVol.toLowerCase())[0];
                        if(spendObj.path=='dbTotalMilesByVolTypes'){
                            chartDetails=  this.generateForMiles(deniedBoardingTypes,dbSpendByTypeForSlOpt?.dbTotalMilesByTypes)
                        }else{
                            chartDetails.datasets = this.generateDataSetsForDBSpendByType(deniedBoardingTypes, dbSpendByTypeForSlOpt?.dbSpendByType, spendObj) || [{ label: 'USD', data: [] }];
                        }
                        this.generatedChartData.spendData=chartDetails;
                } else {
                    let dbCountByTypeFrSlOpt = dbDetailsReponse.dbCountByVolTypes?.filter(dbcont => dbcont.volStatus.toLowerCase() == selectedVol)[0]?.dbPaxCountByType || [];
                    let typeWiseCOunt = [];
                    deniedBoardingTypes.forEach(type => {
                        let cntRes = dbCountByTypeFrSlOpt?.filter(item => type.code == item.dbType);
                        if (cntRes && cntRes.length > 0)
                            typeWiseCOunt.push(cntRes[0].count);//FOR dbCountByType count                
                        else
                            typeWiseCOunt.push(0);
                    });
                    chartDetails.datasets[0].data = typeWiseCOunt;
                    this.generatedChartData.boardingCount=chartDetails
                }

            })
        },
    async getOVSIDataDBDetails(selectedOption) {
            if (this.selectedTabIndex != 2) { return; } // if not selected DB tab ignore the fun call
            let operationId='ua_getoverviewbydb';
            let isAuthorized = await this.authorizeModule({ operationId, moduleId: 'overSaleOverView' })
            if (!isAuthorized) { return; }
            this.dbDetailsReponse = {};
            let filteredFields = JSON.parse(JSON.stringify(this.addFilterItemSetOnSrch));
            delete filteredFields.showHubs;
            this.sections[2].chartConfigs.filters.forEach(f=>{
                filteredFields[f.path]= f.defaultModel;
            });
            let apiObj = {
                inputObject: filteredFields
            }
            // cahceing reponse
            let key = this.generateKey(operationId,apiObj);
            let data = await this.getFromCache(key);
            if(data){
                this.dbDetailsReponse = data;
                return;
            }
            this.isDBdetailsLoading = true;
            await getoverviewbydb(apiObj).then(res => {
                if (res.status == 200) {
                    if (res.data.isSuccessful) {
                        this.addIntoCache({key,data: res.data})
                        this.dbDetailsReponse = res.data;
                        this.generateSpendData(res.data);
                    } else {
                        let msgArray = res.data.messages.map(m => m.message);
                        this.setAlertMessages({
                            alertType: "warning",
                            alertMessages: msgArray
                        })
                    }
                }
            }).catch(er => {
                console.error(er);
                this.handleError(er);
            }).finally(() => this.isDBdetailsLoading = false)
        },
        radioOptionAutoSelection(selectedOption){ // changing view as type for DB tab
            let radiobtnfil=this.sections[2].chartConfigs.filters.filter(f=>f.id=='view_as')[0]
            let dateRange=this.showSerachFilter.filter(range=>range.id=='dateRange')[0]
            let defaultOption='';
            let diableOptions=[]
            let startDate=new Date(dateRange.model.startDate)
            let endDate=new Date(dateRange.model.endDate)
            const diffTime = Math.abs(endDate - startDate);
            const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24))+1;
            if (diffDays <7) {
                defaultOption = 'days';
                diableOptions.push('months','weeks')//weeks and months should disable
            } else if (diffDays < 30 && diffDays>=7) {
                defaultOption = 'weeks';
                diableOptions.push('months') //months should disable
                if(diffDays>14){ //days should disable
                    diableOptions.push('days')
                }
            } else if(diffDays>=30) {
                defaultOption = 'months';
                diableOptions.push('days')//days should disable
                if(diffDays>90){ 
                    diableOptions.push('weeks')//weeks should disable
                }
            }
            radiobtnfil.radioItems.forEach(e=>{
                    if(diableOptions.length>0){ 
                        diableOptions.includes(e.compKeyPath)?e.isDisable=true:e.isDisable=false
                    }
                    if(selectedOption){
                        e.compKeyPath==selectedOption.compKeyPath?radiobtnfil.model = e.id:''
                        defaultOption='';
                        this.selectedViewAs=selectedOption;
                    }
                    if(defaultOption){
                        if(e.compKeyPath==defaultOption){
                            e.defaultChecked=true; radiobtnfil.model = e.id;
                            this.selectedViewAs=e;
                        }else
                            e.defaultChecked=false
                        selectedOption=''
                    }
                }
                )
        },
     handleSearchClickOrReste(){ // onvoking by reference
        this.radioOptionAutoSelection();
        this.getoversaleByCostDatacc();
        this.getOVSIDataDBDetails();
     },   
    async getoversaleByCostDatacc(){
        if(this.selectedTabIndex !=1){return;} // if not selected cost tab ignore the fun call
        let operationId = 'ua_getoverviewbycost'
        let filteredFields = JSON.parse(JSON.stringify(this.addFilterItemSetOnSrch));
        delete filteredFields.showHubs;
        this.sections[1].filters.forEach(f=>{
            filteredFields[f.path]=f.defaultModel;
        });
        let apiObj = {
            inputObject: filteredFields
        }
        // auth
     let isAuthorized = await this.authorizeModule({operationId,  moduleId: 'overSaleOverView' })
       if (!isAuthorized) { return; }
       this.oversaleCostData = {};
       // cahceing reponse
       let key = this.generateKey(operationId,apiObj);
            let data = await this.getFromCache(key);
            if(data){
                this.oversaleCostData = data;
                this.setCostDataFrSlVlType(this.sections[1].filters); //Cost tab Data by VolStatus
                return;
            }
      this.isCostLoading = true;
      await getoverviewbycost(apiObj).then(res => {
        if (res.status == 200) {
          if (res.data.isSuccessful) {
            this.oversaleCostData = res.data;
            this.addIntoCache({key,data: res.data})
          } else {
            let msgArray = res.data.messages.map(m => m.message);
            this.setAlertMessages({
              alertType: "warning",
              alertMessages: msgArray
            })
          }
        }
      }).catch(er => {
        console.error(er);
        this.handleError(er)
      }).finally(()=>{
        this.isCostLoading = false;
        this.setCostDataFrSlVlType(this.sections[1].filters); //Cost tab Data by VolStatus
    })
    },
    async loadPageData(){
        if(this.applyFilterClicked) return;//NO NEED TO CALL THE API ON APPLY FILTER
            if(this.prevNavigateViews.length > 0){
                const prevItems = this.prevNavigateViews.filter(
                    (item) => item.id == this.getOVSIEntityId
                    );
                const preItem = prevItems[prevItems.length-1];
                const finalObj = {
                    inputObject: preItem.searchFilterInputParams,
                    actionId: this.actionId,
                };
                await this.getOVSIData(finalObj);
            } else if (Object.keys(this.selectedInputValues).length > 0) {
                const finalObj = {
                    inputObject: this.selectedInputValues.inputObject,
                    actionId: this.actionId,
                };
                await this.getOVSIData(finalObj);
            }
        },
        handleDropdown(e,field){
            field.model=e;
            this.selectedBoardingType=e;
        },
        handleRadioOptionDB(inlineFilters,selectedOption){ // on inline filter change it trigger from DB  tab
        if(selectedOption.name == 'viewAs'){
            this.radioOptionAutoSelection(selectedOption);
        }
        this.generateSpendData(this.dbDetailsReponse);
        },
        getVolStatusFromModel(){
            let filters = this.sections[2].chartConfigs.filters;
            let selectedVol = filters.filter(f=>f.id=='vol_status').map(f=>f.model)[0];
          return  selectedVol.length>1?'all':selectedVol[0].toLowerCase();
        },
        getBordingTypeFromModel(){
            let filters = this.sections[2].chartConfigs.filters;
            let selectedVol = filters.filter(f=>f.id=='boarding_type_chart').map(f=>f.model)[0];
          return  selectedVol[0];
        },
        getSpendByFromModel(){
            let filters = this.sections[2].chartConfigs.filters;
            let model= filters.filter(f=>f.id=='spend_by').map(f=>f.model)[0];
            if(model == 'ETC') return {model,path:'dbEtcSpendByVolTypes'};
            if(model == 'Miles') return {model,path:'dbTotalMilesByVolTypes'};
            if(model == 'Draft') return {model,path:'dbDraftSpendByVolTypes'};
        },
        getDbDetailsDeniedCHartData(chartDataIndex,id,deniedBoardingTypes){
            let chartDetails = this.dbChartData[chartDataIndex];
            let typeWiseCOunt= [];
            let selectedVol = this.getVolStatusFromModel();
            
            if(id == 'boarding_spend_by_type'){
                let dbSpendByTypeForSlOpt = this.dbDetailsReponse.dbSpendByVolType?.filter(dbcont=>dbcont.volStatus.toLowerCase()==selectedVol)[0]?.dbSpendByType;
                chartDetails.datasets= this.generateDataSetsForDBSpendByType(deniedBoardingTypes,dbSpendByTypeForSlOpt) || [{label:'USD',data:[]}];
                return chartDetails;
            }
            let dbCountByTypeFrSlOpt = this.dbDetailsReponse.dbCountByVolType?.filter(dbcont=>dbcont.volStatus.toLowerCase()==selectedVol)[0]?.dbPaxCountByType
            deniedBoardingTypes.forEach(type => {
                let  cntRes = dbCountByTypeFrSlOpt?.filter(item => type.code == item.dbType);
                if(cntRes && cntRes.length > 0)
                    typeWiseCOunt.push(cntRes[0].count);//FOR dbCountByType count                
                else
                    typeWiseCOunt.push(0);
            });
            chartDetails.datasets[0].data = typeWiseCOunt;
            return chartDetails;
            
        },
        generateDataSetsForDBSpendByType(types,dbSpendByType) {
            let currList = []; // find all currency present in payload
            let datasets = [];
            dbSpendByType?.forEach(spendType => {
                spendType.spend.forEach(amt => !currList.includes(amt.currencyCode) ? currList.push(amt.currencyCode) : '');
            })
            currList.forEach(curr => {
                let dataset = { label: curr, 
                   backgroundColor: [getRandomColor(curr)]
                  // backgroundColor: types.map(type=>type.typeBackColor)
                };
                let data = [];
                types.forEach(type => {
                    let currentSpendTypeObj = dbSpendByType?.filter(spendType => spendType.dbType == type.code);
                    if (currentSpendTypeObj.length > 0) { // if found 
                        let currObject = currentSpendTypeObj[0].spend.filter(sp => sp.currencyCode == curr);
                        if (currObject.length > 0)
                            data.push(currObject[0].amount);
                        else
                            data.push(0);
                    } else
                        data.push(0);
                })
                dataset.data = data;
                datasets.push(dataset);
            });
            if(datasets.length == 0){ // if no API data
                datasets.push({"label":"Denied Boarding Spend","backgroundColor":["#208500","#0fd702","#00b1a8","#69b3e7","#6244bb","#ff4fde","#900030","#f46335","#edb72b","#3d85be"],"data":[]})
            }
            return datasets;
        },
        
        getChartDatahub() {
            let datasetArr = [];
            let hoursData = [ 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23];
            let hubwiseCountData=[];
            let dsObj = {
                //label: hb.hub,
                backgroundColor: 'rgba(182, 189, 197, 0.5)',
                borderColor: "#002244",
                //tension: 0.2,
                //data: [0, 0, 0, 0, 2, 1, 3, 6, 8, 3, 0, 0, 0, 7, 3, 2, 1, 0, 4, 0], //Y -Axis
                clip: { left: 5, top: true, right: -2, bottom: 0 },
                pointBorderColor: '#002244',
                pointBackgroundColor:'#002244',
                borderWidth:1.5,
                showLine: true, // working
                //spanGaps: 2,
                mode: true,
            }
            let dataArr = [];
            hoursData.forEach((hour) => { // check for each hour 
                let hourWiseInfo = []
                let flightDeptData = this.searchOVSIData.flightDepartureCounts
                let flightsPerHour= []
                Object.keys(flightDeptData||[]).filter((item)=>{
                    if(hour)
                    flightsPerHour= this.searchOVSIData.flightDepartureCounts[hour.toString()]; // get the flight count for current hour
                })
                let totalCount=0
                if(flightsPerHour && flightsPerHour.length>0){
                    flightsPerHour.forEach((flt)=>{ 
                        if(flt.station == 'Total')
                         totalCount =  flt.count ||0;// set the total count if found for current hour
                        else
                         hourWiseInfo.push({ 'station' : flt.station , 'count' : flt.count}); // push all station in current hour to hourWiseInfo
                    });
                }
                hubwiseCountData.push({'hr': hour, extraInfo : hourWiseInfo }) //setting stations per hour
                dataArr.push(totalCount)  // setting total count               
                datasetArr.push(dsObj);
            });
            //dsObj.label = JSON.stringify({text:'OVERSOLD Flights', hubInfo: JSON.stringify(hubwiseCountData)});
            dsObj.label = JSON.stringify({text:'Oversold Flights', hubInfo: hubwiseCountData});
            dsObj.data = dataArr;
            return {
                labels: hoursData, //X-AXIS
                datasets : [dsObj]
                //datasets : datasetArr
            };
        },
        enlargeScreen(){
        this.isEnlargePopup = !this.isEnlargePopup;
        },
        getCabinValues(cabins){
            return getCombinedCabinValues(cabins);
        },
        async navigateScreen(actionBtnInfo, data) {
            this.setSelectedRecord(data);
            let { events } = actionBtnInfo;
            this.setSelectedMenuId(actionBtnInfo.navigationInfo.navigateToID);
            if (events.name == "navigateToOtherScreen") {
                this.setIsNavigatedEvent(true);
                this.setIsNavigateToInnerOtherView(true);
                const prevItems = this.prevNavigateViews.filter(
                    (item) => item.id == this.getOVSIEntityId
                );
                let prevMainObjToReset = false;
                if(prevItems.length > 0){
                    const preItem = prevItems[prevItems.length-1];
                    if(preItem.mainFilterParams && prevItems.length == 1){
                        prevMainObjToReset = true;
                        this.resetPrevNavigateViews();
                    }              
                }
                if (
                    this.mainViewId == this.getOVSIEntityId &&
                    Object.keys(this.selectedInputValues).length > 0 &&
                    (this.prevNavigateViews.length === 0 || prevMainObjToReset)
                ) {
                    //if current component is from main menu click
                    this.setPrevNavigateViews({
                        id: this.getOVSIEntityId,
                        searchFilterInputParams: JSON.parse(JSON.stringify(this.selectedInputValues.inputObject)),
                        bindSearchFilterParams: true,
                        mainFilterParams: true,
                        searchFilterModel: JSON.parse(JSON.stringify(this.selectedInputValues.multiSelectModel))
                    });
                }
                let inputHeaderParamObj={};
                let seachFilterObj =  actionBtnInfo.navigationInfo.headerMacroParams
                // currently binding only Date Range since multiple station The API currently not support
                let searchFilterModelData = JSON.parse(JSON.stringify(this.selectedInputValues.inputObject));
                seachFilterObj.forEach((field)=>{
                    if(field.fieldType == "UADateRangePicker"){
                        inputHeaderParamObj['SearchStartDate']=searchFilterModelData.startDate;
                        inputHeaderParamObj['SearchEndDate']=searchFilterModelData.endDate;
                    }
                    if(field.attributes.name=='Origin'){
                        inputHeaderParamObj['FlightOrigin']=data.hub
                    }
                })
                this.setPrevNavigateViews({
                    id: actionBtnInfo.navigationInfo.navigateToID,
                    searchFilterInputParams: inputHeaderParamObj,//inputParamObj,
                    headerMacroParams: inputHeaderParamObj,
                    showNavMenus: false,
                    navToFltMngm:true,
                    bindSearchFilterParams:true
                    });
                
                await this.redirectToSpecificMenu(actionBtnInfo.navigationInfo.navigateToID);
            }
        },
        async navigateToReportScreen(actionBtnInfo, data){ // navigating to report
        //update reportInlinefilter with default options when flight navigation with new flight data
        //   let isAuthorized = await this.authorizeModule({operationId: 'ua_get_flight_report',moduleId: 'report',origin: data.flightOrigin})
        //   console.log(' authorizeModule : navigateScreen to report ua_get_flight_report ',isAuthorized);
        //   if(!isAuthorized){return; }
        this.setSelectedMenuId(actionBtnInfo.navigationInfo.navigateToID);
        this.clearAlertMessages();
        let defaultOptions = {"type":"All","cabin":"All","compensation":"All","compensation_1": "All","pass_class":"All"};
        this.updatePrevOptions(defaultOptions);
        this.setSelectedRecord(data);
            let {events} = actionBtnInfo;
            if(events.name == "navigateToOtherScreen"){
                this.setIsNavigatedEvent(true);
                this.setIsNavigateToInnerOtherView(true);
                const prevItems = this.prevNavigateViews.filter(
                (item) => item.id == this.getOVSIEntityId
                );
                let prevMainObjToReset = false;
                if(prevItems.length > 0){
                const preItem = prevItems[prevItems.length-1];
                if(preItem.mainFilterParams && prevItems.length == 1){
                    prevMainObjToReset = true;
                    this.resetPrevNavigateViews();
                }              
                }
                if (
                    this.mainViewId == this.getOVSIEntityId &&
                    Object.keys(this.selectedInputValues).length > 0 &&
                    (this.prevNavigateViews.length === 0 || prevMainObjToReset)
                ) {
                    //if current component is from main menu click
                    this.setPrevNavigateViews({
                    id: this.getOVSIEntityId,
                        searchFilterInputParams: JSON.parse(JSON.stringify(this.selectedInputValues.inputObject)),
                        bindSearchFilterParams: true,
                        mainFilterParams: true,
                        searchFilterModel: JSON.parse(JSON.stringify(this.selectedInputValues.multiSelectModel))
                    });
                }
                let inputHeaderParamObj;
                if (actionBtnInfo.navigationInfo.headerMacroParams) {
                inputHeaderParamObj = createGetInputObj(
                    actionBtnInfo.navigationInfo.headerMacroParams,
                    data
                );
                }
                this.setPrevNavigateViews({
                    id: actionBtnInfo.navigationInfo.navigateToID,
                    searchFilterInputParams: {},//inputParamObj,
                    headerMacroParams: inputHeaderParamObj,
                    showNavMenus: true
                });
                this.redirectToSpecificMenu(actionBtnInfo.navigationInfo.navigateToID,data);
            }
        },
        async redirectToSpecificMenu(id) {
            await this.getEntityDisplayDetailsAction(id).then(() => {
                this.setSelectedMenuId(id);
            })
        },
        handleSelectTab(tab, tabIndex) {
        this.setCurrentSelTabIndex(tabIndex);
        if(this.isLoading){return;}
        setTimeout(() =>
           this.selectTab(tab),
         1 * 1);
       
        },
        selectTab(tab) {
            if(this.selectedTabIndex == 1){
                this.getoversaleByCostDatacc() //calling Api on click of selected tab
            }
            if(this.selectedTabIndex == 2){
                this.radioOptionAutoSelection();
                this.getOVSIDataDBDetails() //calling Api on click of selected tab
            }
        },
        getOrCreateTooltip(chart) {
            let tooltipEl = chart.canvas.parentNode.querySelector('div');
                if (!tooltipEl) {
                tooltipEl = document.createElement('div');
                tooltipEl.style.background = 'white';
                tooltipEl.style.borderRadius = '3px';
                //tooltipEl.style.color = 'white';
                //tooltipEl.style.opacity = 1;
                //tooltipEl.style.pointerEvents = 'none';
                tooltipEl.style.position = 'absolute';
                tooltipEl.style.transform = 'translate(0%, 0)';
                tooltipEl.style.transition = 'all .1s ease';
                const table = document.createElement('table');
                table.style.margin = '0px';
                tooltipEl.appendChild(table);
                chart.canvas.parentNode.appendChild(tooltipEl);
            }
            return tooltipEl;
        },
        async linkClick(sTime,eTime){
            this.setIsNavigatedEvent(true)
            this.setIsNavigateToInnerOtherView(true)
            const prevItems = this.prevNavigateViews.filter(
                (item) => item.id == this.getOVSIEntityId
            );
            let prevMainObjToReset = false;
            if(prevItems.length > 0){
                const preItem = prevItems[prevItems.length-1];
                if(preItem.mainFilterParams && prevItems.length == 1){
                    prevMainObjToReset = true;
                    this.resetPrevNavigateViews();
                }              
            }
            if (
                    this.mainViewId == this.getOVSIEntityId &&
                    Object.keys(this.selectedInputValues).length > 0 &&
                    (this.prevNavigateViews.length === 0 || prevMainObjToReset)
                ) {
                    //if current component is from main menu click
                    this.setPrevNavigateViews({
                        id: this.getOVSIEntityId,
                        searchFilterInputParams: JSON.parse(JSON.stringify(this.selectedInputValues.inputObject)),
                        bindSearchFilterParams: true,
                        mainFilterParams: true,
                        searchFilterModel: JSON.parse(JSON.stringify(this.selectedInputValues.multiSelectModel)) 
                    });
                }
                let inputHeaderParamObj={}
                let seachFilterObj=this.chartConfigsNav.lineChartOptions.headerMacroParams
                let searchFilterModelData = JSON.parse(JSON.stringify(this.selectedInputValues.inputObject));
                seachFilterObj.forEach((field)=>{
                    if(field.attributes.name=='Start Time'){
                        inputHeaderParamObj['startTime']=sTime
                    }
                    if(field.attributes.name=='End Time'){
                        inputHeaderParamObj['endTime']=eTime
                    }
                    if(field.attributes.name == "Date Range"){
                        inputHeaderParamObj['SearchStartDate']=searchFilterModelData.startDate;
                        inputHeaderParamObj['SearchEndDate']=searchFilterModelData.endDate;
                    }
                    
                })
                this.setPrevNavigateViews({
                    id: 'flight_Management',
                    searchFilterInputParams: inputHeaderParamObj,
                    showNavMenus: false,
                    headerMacroParams: inputHeaderParamObj,
                    bindSearchFilterParams: true,
                    navToFltMngm:true
                })
                
                await this.redirectToSpecificMenu('flight_Management');
        },
        externalTooltipHandlerhub(context) {
            // Tooltip Element
            const { chart, tooltip } = context;
            const tooltipEl = this.getOrCreateTooltip(chart);
            // Hide if no tooltip
            if (tooltip.opacity === 0) {
                tooltipEl.style.opacity = 0;
                tooltipEl.innerHTML = '<div><table><table></div>';
                return;
            }
           
            // Set Text
            if (tooltip.body) {
                //const titleLines = tooltip.title || [];
                const bodyLines = tooltip.body.map(b => b.lines);
                const tableHead = document.createElement('thead');
                const tableBody = document.createElement('tbody');
                let xPoint = tooltip.dataPoints[0].parsed.x;
                let frmxPoint = (xPoint.length == 1 ? '0'+ xPoint : xPoint)  + ':00' ;
                let toxPoint = ((xPoint + 1).length == 1 ? ('0'+(xPoint + 1) ) : xPoint + 1) + ':00';
                    
                bodyLines.forEach((body, i) => {
                
                    let bodyText = body[0];
                    let bodyTextPart =  body[0].split(':');
                    let totlCnt = bodyText.substring(bodyText.lastIndexOf(':')+1);
                    let titleTextObj = JSON.parse(bodyText.substring(0,bodyText.lastIndexOf(':')));

                    let timeData = frmxPoint + ' - ' + toxPoint;

                    let trheadInnerHtml = `<tr style='border:0'> 
                        <th style='width:30px;text-align: center;  position: sticky; top: 2px; z-index: 2; box-shadow: 1px -14px 6px 0px white; background-color: white;'> <label style="font-size:18px;font-weight: bold;"> ${totlCnt} </label> </th> 
                        <th style = 'position: sticky; top: 2px; z-index: 2; box-shadow: 1px -14px 6px 0px white; background-color: white;''> <label style="font-size: 14px;"> ${titleTextObj.text} </label> </br>
                            <label style="opacity:0.5;font-size: 14px;"> ${timeData} </label>
                        </th> 
                    </tr>`;
                    tableHead.innerHTML = trheadInnerHtml;

                    let bodyDetailsObj = titleTextObj.hubInfo.filter(hbHour => hbHour.hr == xPoint && hbHour.extraInfo.length > 0);
                    
                    let trbodyInnerHtml ='';
                    if(bodyDetailsObj.length > 0){
                        bodyDetailsObj[0].extraInfo.forEach((item) => {
                            trbodyInnerHtml += `<tr style='border:0;'> 
                                <td style='width:30px;text-align: center;' class='u-pad-0'> <label style="font-size:12px;"> ${item.count} </label> </td> 
                                <td class='u-pad-0'> <label style="font-size: 12px;"> ${item.station} </label> 
                                </td> 
                            </tr>`;
                        });
                    }
                    tableBody.innerHTML = trbodyInnerHtml;
                });
                const footerLiness = tooltip.footer || [];

                const tableFooter = document.createElement('tfoot');
                let footerText = this.chartConfig.tooltip.footer.text;              
                const tr = document.createElement('tr');
                tr.style.borderWidth = 0;
                const td = document.createElement('td');
                td.style.borderWidth = 1;
                const lnk = document.createElement('a')
                lnk.setAttribute('href', '#');
                lnk.addEventListener('click', ()=> this.linkClick(frmxPoint,toxPoint));
                lnk.style.pointerEvents = 'auto';
                lnk.appendChild(document.createTextNode(footerText));
                lnk.style.color = '#6244bb';
                lnk.style.fontSize = "12px"
                let imgPath = "arrow_right_alt.png"
                const img = document.createElement('img');
                img.src = getImageUrl(imgPath);
                img.alt="->";
                img.style.height='20px';
                lnk.appendChild(img);
                td.appendChild(lnk); // Add link 
                const tdEmpty = document.createElement('td');
                tr.appendChild(tdEmpty);
                tr.appendChild(td);
                tableFooter.appendChild(tr);
                // let trFooterInnerHtml = `<tr> 
                //         <td class='u-pad-0'></td>
                //         <td style='text-align: center;font-size:12px;' class='u-pad-0'> 
                //             <button href='#' onclick='${this.linkClick}' style="color:blue;"> 
                //                 ${footerText} <img src=${getImageUrl(imgPath)} alt='->'/>
                //              </button> </td> 
                //         </td> 
                //     </tr>`;
                // tableFooter.innerHTML = trFooterInnerHtml;
                //});

                const tableRoot = tooltipEl.querySelector('table');

                // Remove old children
                while (tableRoot.firstChild) {
                    tableRoot.firstChild.remove();
                }

                // Add new children
                tableRoot.appendChild(tableHead);
                tableRoot.appendChild(tableBody);
                tableRoot.appendChild(tableFooter);
                
            }
            const { offsetLeft: positionX, offsetTop: positionY } = chart.canvas;
            const { height, width } = tooltipEl.getBoundingClientRect();
            // Display, position, and set styles for font
            const tableHeader = tooltipEl.querySelector('thead');
            const tableBody = tooltipEl.querySelector('tbody');
            const tableFooter = tooltipEl.querySelector('tfoot');
            // Display, position, and set styles for font
            const heightOfChart  = chart.canvas.height;
            tooltipEl.style.opacity = 1;
            const caretY = tooltip.caretY;
            const caretX = tooltip.caretX;
            
            // Final coordinates
            let top = positionY  + caretY-height;
            let left = positionX  + caretX;
            if(left < window.innerWidth/2 ){
                left = positionX + caretX
            }
            else{
                left = positionX  + caretX-width
            }
            if(caretY <= chart.canvas.height/2 + positionY || caretY < height) {
                top = positionY + window.pageYOffset + caretY;
            }
            else{
                top = positionY + window.pageYOffset + caretY-height;
            }
            // if(height > positionY){
            //         tooltipEl.style.maxHeight ='290px';
            //         tooltipEl.style.display = 'block';
            //         tooltipEl.style.overflow = 'scroll';
            // }
            // else{
            //         tooltipE1.style.height = '';
            //         tooltipEl.style.display = '';
            //         tooltipE1.style.overflow = '';
            //     }
             if( (heightOfChart) < (top + height)){
                tableBody.style.maxHeight =`${(heightOfChart - top)-tableHeader.offsetHeight - tableFooter.offsetHeight -1.5* positionY}px`;
                tableBody.style.display = 'block';
                tableBody.style.overflow = 'scroll';
                tableBody.style.width ='355%';
             }       
            else{
                tableBody.style.maxHeight ='';
                tableBody.style.display = '';
                tableBody.style.overflow = '';
                tableBody.style.width = '';
            }
            tooltipEl.style.top = `${top}px`;
            tooltipEl.style.left = `${left}px`;
            tooltipEl.style.font = tooltip.options.bodyFont.string;
            tooltipEl.style.padding = tooltip.options.padding + 'px ' + tooltip.options.padding + 'px';
            
        },
        externalTooltipHandler(context) {
            // Tooltip Element
            
            const { chart, tooltip } = context;
            const tooltipEl = this.getOrCreateTooltip(chart);
            // Hide if no tooltip
            if (tooltip.opacity === 0) {
                tooltipEl.style.opacity = 0;
                return;
            }
           
            // Set Text
            if (tooltip.body) {
                //const titleLines = tooltip.title || [];
                const bodyLines = tooltip.body.map(b => b.lines);
                const tableHead = document.createElement('thead');
                const tableBody = document.createElement('tbody');
                
                bodyLines.forEach((body, i) => {
                                       
                    let bodyTextPart =  body[0].split(':'); 

                    let xPoint = tooltip.dataPoints[0].parsed.x;
                    let frmxPoint = (xPoint.length == 1 ? '0'+ xPoint : xPoint)  + ':00' ;
                    let toxPoint = ((xPoint + 1).length == 1 ? ('0'+(xPoint + 1) ) : xPoint + 1) + ':00';
                    
                    let timeData = frmxPoint + ' - ' + toxPoint;
                    
                   
                    let trInnerHtml = `<tr style='border:0'> 
                        <td style='width:30px;'> <h2 style="font-weight: bold;"> ${bodyTextPart[1]} </h2> </td> 
                        <td> <label style="font-size: 20px;"> ${bodyTextPart[0]} </label> </br>
                            <label style="opacity:0.5;font-size: 20px;"> ${timeData} </label>
                        </td> 
                    </tr>`;

                    tableBody.innerHTML = trInnerHtml;
                });
                const footerLiness = tooltip.footer || [];

                const tableFooter = document.createElement('tfoot');
                let footerText = this.chartConfig.tooltip.footer.text;
                //footerLiness.forEach(footer => {
                    const tr = document.createElement('tr');
                tr.style.borderWidth = 0;
                const td = document.createElement('td');
                td.style.borderWidth = 1;
                const lnk = document.createElement('a')
                lnk.setAttribute('href', '#');
                lnk.addEventListener('click', ()=> this.linkClick(frmxPoint,toxPoint));
                lnk.style.pointerEvents = 'auto';
                lnk.appendChild(document.createTextNode(footerText));
                lnk.style.color = '#6244bb';
                lnk.style.fontSize = "12px"
                let imgPath = "arrow_right_alt.png"
                const img = document.createElement('img');
                img.src = getImageUrl(imgPath);
                img.alt="->";
                lnk.appendChild(img);
                td.appendChild(lnk); // Add link 
                //td.colSpan=2;
                const tdEmpty = document.createElement('td');
                tr.appendChild(tdEmpty);
                tr.appendChild(td);
                tableFooter.appendChild(tr);
                //});

                const tableRoot = tooltipEl.querySelector('table');

                // Remove old children
                while (tableRoot.firstChild) {
                    tableRoot.firstChild.remove();
                }

                // Add new children
                tableRoot.appendChild(tableHead);
                tableRoot.appendChild(tableBody);
                tableRoot.appendChild(tableFooter);
                
            }
            const { offsetLeft: positionX, offsetTop: positionY } = chart.canvas;
            
            // Display, position, and set styles for font
            tooltipEl.style.opacity = 1;
            tooltipEl.style.left = positionX + tooltip.caretX + 'px';
            tooltipEl.style.top = positionY + tooltip.caretY + 'px';
            tooltipEl.style.font = tooltip.options.bodyFont.string;
            tooltipEl.style.padding = tooltip.options.padding + 'px ' + tooltip.options.padding + 'px';
        }
    },
};
</script>

<style scoped>
/* Style the tab */
.tab {
    overflow: hidden;
    border-bottom: 2px solid #a0a5ab;
    background-color: #F6F6F6;
    margin: 14px !important;
    border-top-left-radius: 9px;
    border-top-right-radius: 9px;
}

/* Style the buttons inside the tab */
.tab button {
    background-color: inherit;
    float: left;
    border: none;
    outline: none;
    cursor: pointer;
    padding: 14px 16px;
    transition: 0.3s;
    font-size: 17px;
    color: #002244 !important;

}

/* Change background color of buttons on hover */
.tab button:hover {
    background-color: #ddd;
}

.tab button.active {
    /* background-color: #ccc; */
    border-bottom: 3px solid #0c2340;

}

/* Create an active/current tablink class */


/* Style the tab content */
.tabcontent {
    display: none;
    padding: 6px 12px;
    border: 1px solid #ccc;
    border-top: none;
}
</style>
