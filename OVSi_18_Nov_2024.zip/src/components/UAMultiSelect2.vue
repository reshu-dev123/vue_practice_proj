<template>
  <div class="u-modl  u-text-3 u-tiny " style="display: flex" v-show="isMultiSelectPop">
    <form class="u-modal-content-2">
      <div class="u-row u-margin-top-1">
        <div class="u-row u-cnt-scrl-stnpopup">
          <div class="u-row u-border-bottom u-flex-start u-th-fixed u-white">
            <h4 class=" u-col l1-1 m2 s2 u-bold u-text-1 u-msmall u-fnt-bld">Stations ({{ this.selectedOptions.length }})
            </h4>
            <div class="u-col l10 m9 s9 u-flex u-pad-left-1 u-margin-7 u-inline-flex">
              <input type="text" class="u-left-search u-tu" v-model="searchKeyword" placeholder="Enter the Search Keyword">
              <div class="u-right-search">
                <img src="../assets/img/search2.png" alt="search icon" class="u-img-width" id="search_stations"/>
              </div>
            </div>
            <div class="u-col l1 m1 s1">
              <UAButton id="close_stations" cssClass="u-transparent u-right u-pad-0 u-large u-pointer" @click.prevent="toggle">
                <img src="../assets/img/close_grey.png" alt="Close icon" class="" id="close_stations_icon"/>
              </UAButton>
            </div>
          </div>
          <div class="u-row u-text-1 u-tiny u-flex" style="min-height:72vh !important;">
            <div class="u-col l1-1 m2 s2">
              <div class="u-small u-padding u-fnt-500">Groupings</div>
              <UARadioButton @radioOptionSelectedfromChild="handleRadioOption" v-model="selectedButton" id="groups"
                :cssClass="['u-row',!isShowAllHubs && !isShowAllStations && 'u-disabled']" :selectOptions="computedGroups" />
              <div class="u-text-1 u-small u-pad-left-1 u-margin-top u-fnt-500">Hubs</div>
              <UACheckbox :checkedProps="hubCheckProps" @selectedItem="handleCheckBoxSelectedHubs"
                :cssClass="['u-row u-margin-top-1',!isShowAllHubs && 'u-disabled']" cellfontCss="u-tiny" cellCss="u-tiny" :options="filteredHubs" />
            </div>
            <div class="u-col l11 m10 s10 u-border-left" >
              <div Class="u-padding u-text-1 u-small u-fnt-500">Stations</div>
              <UACheckbox :isDynamicRowCol='true' v-model="selectedButtons" @selectedItem="handleCheckBoxSelected"
              :cssClass="['u-row',allstationDisable()]" :enabledIndexs="enabledIndexes"
                cellfontCss="u-tiny" cellCss="u-tiny" :checkedProps="stationCheckedProps" :options="filteredStations" />
            </div>
          </div>
        </div>
        <div class="u-row  u-border-top u-th-fixed" :class="[((!isShowAllHubs && !isShowAllStations) || isShowOnlyLocalStations)?'u-disabled':'',this.selectedOptions.length>0 ? '' : 'u-disabled']">
          <UAButton cssClass="u-col l2-1 u-right u-primary-cst u-margin-10 u-round-small u-small lf mf sf u-pointer" id="apply_filter"
            @click.prevent="applyFilter">Apply filter{{ `(s)` }}</UAButton>
          <UAButton cssClass="u-col l1 m1 s1 u-right u-secondary-cst u-margin-10 u-round-small u-small lf mf sf u-pointer"
            @click.prevent="clear" id="clear_stations">Clear</UAButton>
        </div>
      </div>
    </form>
  </div>
</template>

<script>
import UATextbox from "@/components/UATextbox.vue";
import UACheckbox from '@/components/UACheckbox.vue';
import UARadioButton from '@/components/UARadioButton.vue';
import UAButton from '@/components/UAButton.vue';
import UAInput from './UAInput.vue';
import { mapMutations, mapState, mapGetters } from 'vuex';
export default {
  name: 'UAMultiSelect2',
  props: ['modelValue', 'label', 'filterField', 'isMultiSelectPop'],
  components: {
    UACheckbox,
    UARadioButton,
    UAButton,
    UAInput,
    UATextbox
  },
  data() {
    return {
      groups: [{ "id": "stations", "label": "All Stations", "name": 'radio', "defaultChecked": false, direction: true, "cssClass": "u-margin-left-14" },
      { "id": "hubs", "label": "All Hubs", "name": 'radio', direction: true, "defaultChecked": false, "cssClass": "u-margin-left-14" }],
     
      hubs: [],
      stationCheckedProps: [],
      hubCheckProps: [],
      isShown: false,
      selectedButtons: '',
      selectedGroupDataId: '',
      selectedOptions: [],
      selectedButton: '',
      selectedOptionsBackups: [],
      searchKeyword: "",
      enabledIndexes:[],

    }
  },
  created() {
    this.hubs = this.getAllHubs.map(h => h.toUpperCase());
    this.groups.forEach(gr=>{
      if(gr.id== 'stations' && !this.isShowAllStations){
        gr.isDisable=true;
      }
      if(gr.id== 'hubs'  && !this.isShowAllHubs){
        gr.isDisable=true;
      }
    })
    this.setEnabledIndex();
  },
  computed: {
    ...mapGetters(['getAllHubs','getLocalStation']),
    ...mapState({
      showMultiSelectPop: (state) => state.ovsiDefaultModule.showMultiSelectPop,
      currentRoleInfo: (state) => state.userModule.currentRoleInfo,
      stationList: (state)=> state.ovsiDefaultModule.stationData.stations
    }),
    isShowAllHubs() {
      let ovsRole = this.currentRoleInfo.accessInfo.overSaleOverView;
      return ovsRole.enabled && (ovsRole.stations.includes("Hubs")|| ovsRole.allStation);
    },
    isShowAllStations() {
      let ovsRole = this.currentRoleInfo.accessInfo.overSaleOverView;
      return ovsRole.enabled && ovsRole.allStation;
    },
    isShowOnlyLocalStations() {
      let ovsRole = this.currentRoleInfo.accessInfo.overSaleOverView;
      return ovsRole.enabled && ovsRole.stations.length==1 && ovsRole.stations.includes("Local Stations");
    },
    computedGroups() {
      return this.groups;
    },
    filteredStations() {
      let keyword = this.searchKeyword.toLowerCase();

      let filetredStations = this.stationList.filter(word =>
        word.toLowerCase().includes(keyword))
      return filetredStations;
    },
    filteredHubs() {
      let keyword = this.searchKeyword.toLowerCase();
      return this.hubs.filter(word =>
        word.toLowerCase().includes(keyword))
    }

  },
  mounted() {
    if (this.isMultiSelectPop) {
      this.selectedOptionsBackups = this.modelValue;
      if (this.modelValue.selectedOptions && this.modelValue.selectedOptions.length > 0) {
        let groupType = this.groups.filter(item => item.id == this.modelValue.groupId)[0];
        this.selectedOptions = this.modelValue.selectedOptions;
        if (groupType) {
          this.selectedGroupDataId = groupType.id;
          if (groupType.id == 'hubs' && this.modelValue.selectedOptions.length == this.hubCheckProps.length) {
            // this.stationCheckedProps = this.modelValue.selectedOptions;    
            this.selectedButton = groupType.id;
            this.hubCheckProps = this.selectedOptions
            this.stationCheckedProps = []
            this.setRadioOption(groupType.id);
          }
          else {
            if (this.modelValue.selectedOptions.length == this.stationList.length+this.hubs.length) {
              this.selectedButton = groupType.id;
              this.stationCheckedProps = this.stationList;
              this.hubCheckProps = this.hubs
              this.setRadioOption(groupType.id);
            }
            else {
              this.hubCheckProps = [];
              this.stationCheckedProps = [];
              for (let i = 0; i < this.selectedOptions.length; i++) {
                if (this.hubs.includes(this.selectedOptions[i])) {
                  this.hubCheckProps.push(this.selectedOptions[i]);
                }
                if (this.stationList.includes(this.selectedOptions[i])) {
                  this.stationCheckedProps.push(this.selectedOptions[i]);
                }
              }
              if (this.hubCheckProps.length == this.hubs.length) {
                this.setRadioOption('hubs');
              }
            }
          }

        }
        else {
          this.hubCheckProps = [];
          this.stationCheckedProps = [];
          for (let i = 0; i < this.selectedOptions.length; i++) {
            if (this.hubs.includes(this.selectedOptions[i])) {
              this.hubCheckProps.push(this.selectedOptions[i]);
            }
            if (this.stationList.includes(this.selectedOptions[i])) {
              this.stationCheckedProps.push(this.selectedOptions[i]);
            }
          }
        }
      }
    }
  },
  methods: {
    ...mapMutations(['setSelectedAllHubs', "setShowMultiSelectPop","setApplyFilterClicked"]),
    setEnabledIndex(){
      if(!this.isShowAllStations)
      if(this.isShowOnlyLocalStations || this.isShowAllHubs){
         this.stationList.forEach((st,i)=>{
          if(this.getLocalStation == st)
          this.enabledIndexes.push(i);
        })
      }
    },
    allstationDisable(){
      let cssCl= 'u-disabled';
      if(!this.isShowAllStations){
        let ovsRole = this.currentRoleInfo.accessInfo.overSaleOverView;
        if(ovsRole.stations.length ==1){ // disable all stations if only one is enabled from list
            return cssCl;
        }
      }
      return '';
    },
    getDisabledIndex(){
      if(this.isShowAllStations){
        return []
      }
      if(this.isShowAllHubs){
        return [];
      }
      if(this.isShowOnlyLocalStations){
        return this.stationList.filter(st=>st!=this.getLocalStation).map((st,i)=>i);
      }
    },
    handleCheckBoxSelectedHubs(listSelected, item, isNotEmpty) { //only for Hubs
      this.hubCheckProps = listSelected
      this.selectedOptions = Array.from(new Set(this.hubCheckProps.concat(this.stationCheckedProps))) // remove duplicates after concatination
      this.groups[0].defaultChecked = false;
      // this.selectedOptions=  this.selectedOptions.concat(this.stationCheckedProps)
      if (this.hubCheckProps.length == this.hubs.length && this.stationCheckedProps.length != this.stationList.length) {
        this.groups[1].defaultChecked = true;
        this.selectedButton = this.groups[1].id;
      }
      else if (this.selectedOptions.length == (this.stationList.length + this.hubs.length)) {
        this.groups[0].defaultChecked = true;
        this.groups[1].defaultChecked = false;
        this.selectedButton = this.groups[0].id;
      }
      else {
        this.groups[0].defaultChecked = false;
        this.groups[1].defaultChecked = false;
        this.selectedButton = '';
      }

    },
    handleCheckBoxSelected(listSelected, item, isNotEmpty) { //only for station
      this.stationCheckedProps = listSelected
      this.selectedOptions =  Array.from(new Set(this.stationCheckedProps.concat(this.hubCheckProps))) // remove duplicates after concatination
      if (this.selectedOptions.length == this.stationList.length+this.hubs.length) {
        this.groups[0].defaultChecked = true;
        this.groups[1].defaultChecked = false;
        this.selectedButton = this.groups[0].id
      }
      else if (this.hubCheckProps.length == this.hubs.length && this.stationCheckedProps.length != this.stationList.length) {
        this.groups[0].defaultChecked = false;
        this.groups[1].defaultChecked = true;
        this.selectedButton = this.groups[1].id;
      }
      else {
        this.groups[0].defaultChecked = false;
        this.groups[1].defaultChecked = false;
        this.selectedButton = '';
      }
    },
    isEqualArray(arr1, arr2) {
      return arr1.length === arr2.length && arr1.every((el, index) => el === arr2[index]);
    },
    toggle() {
      this.setShowMultiSelectPop(!this.showMultiSelectPop);

    },
    handleRadioOption(option, index) {
      this.resetSelectedOptions();
      this.selectedGroupDataId = option.id;
      this.selectedButton = option.id;
      if (option.id == 'stations') {
        this.stationCheckedProps = JSON.parse(JSON.stringify(this.stationList));
        this.hubCheckProps = JSON.parse(JSON.stringify(this.hubs));
        this.selectedOptions = this.hubCheckProps.concat(this.stationCheckedProps);
      } else {
        this.hubCheckProps = JSON.parse(JSON.stringify(this.hubs));
        this.selectedOptions = this.hubCheckProps
      }
      this.setRadioOption(option.id);
    },
    setRadioOption(optionId) {
      this.groups.forEach(item => {
        if (item.id == optionId) {
          item.defaultChecked = true;
        } else {
          item.defaultChecked = false;
        }
      });
    },
    resetSelectedOptions() {
      this.groups.forEach(grp => grp.defaultChecked = false);
      this.stationCheckedProps = [];
      this.hubCheckProps = [];
      this.selectedOptions = [];
      this.selectedGroupDataId = '';
      this.selectedButton = "";
    },
    applyFilter() {
      //this.setSelectedAllHubs(false);
      let showHubTable = false;
      let isSelectedAll = '';
      let selectedAll='';
      let groupType = this.groups.filter(item => item.id == this.selectedGroupDataId)[0];
      let selectedModelOptions = '';
      let cnt = 0
      this.selectedOptions.forEach(optItem => {
        this.hubs.forEach(hubItem => {
          if (optItem == hubItem) {
            cnt++;
          }
        })
      })
      if (groupType) {
        if (groupType.id == 'hubs' && this.selectedOptions.length == this.hubCheckProps.length && cnt == this.hubs.length) {
          //this.setSelectedAllHubs(true);
          showHubTable = true;
          selectedModelOptions = `${groupType.label} (${this.selectedOptions.length})`
        }
        else {
          if (this.selectedOptions.length == this.stationList.length + this.hubs.length) {
            //this.setSelectedAllHubs(true);
            showHubTable = true;
            selectedModelOptions = `${groupType.label} (${this.selectedOptions.length})`
            isSelectedAll = ["all"];
            selectedAll = this.selectedOptions;
          }
          else {
            if (this.selectedOptions.length > 3) {
              if (cnt == this.hubs.length) {
                //this.setSelectedAllHubs(true);
                showHubTable = true;
              }
              let optArr =  this.selectedOptions.sort().slice(0, 3);
              selectedModelOptions = `${optArr} ... (${this.selectedOptions.length})`;
            } else {
              selectedModelOptions = this.selectedOptions.sort().toString();
            }
          }
        }
      }
      else {
        if (this.selectedOptions.length > 3) {
          if (cnt == this.hubs.length) {
            //this.setSelectedAllHubs(true); 
          }
          let optArr = this.selectedOptions.sort().slice(0, 3);
          selectedModelOptions = `${optArr} ... (${this.selectedOptions.length})`;
        } else {
          selectedModelOptions = this.selectedOptions.sort().toString();
        }
      }
      let dataObj = {
        "selectedModelText": selectedModelOptions,
        "groupId": groupType ? groupType.id : '',
        "selectedOptions": isSelectedAll || this.selectedOptions
      };
      let dataObjForAll = {
        "selectedModelText": selectedModelOptions,
        "groupId": groupType ? groupType.id : '',
        "selectedOptions": selectedAll || this.selectedOptions,
        "showHubTable": showHubTable
      };
      this.$emit('update:modelValue', dataObj);
      this.filterField.model = dataObj;
      this.$emit("setMultiselectModalValue", dataObj,dataObjForAll, this.filterField);
      this.setShowMultiSelectPop(false);
      this.setApplyFilterClicked(true);
    },
    clear() {
      this.resetSelectedOptions();
      //this.$emit('update:modelValue','');
    }
  }
}
</script>

<style>
.button {
  color: white;
  background-color: royalblue;
  margin: 10px;
}
.u-cnt-scrl-stnpopup{
height: 60vh;
overflow-y: scroll;
}
</style>