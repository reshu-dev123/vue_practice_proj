<template>
  <div class="u-col u-pad-0">
    <input 
      type='search'
      :placeholder='placeholder'
      :value='searchKeyword'
      @input='$emit("update:searchKeyword", $event.target.value)'
      :class="['u-input u-border u-round l3 m3 s3', cssClass,!searchKeyword?'searchinput':'']"
      aria-label="search Keyword"
      :id="id"
      />
  </div>
</template>
<script>
export default {
  name: "UAConfigSearchKeyword",
  props: ['searchKeyword','placeholder','cssClass','id']
};
</script>
<style> 
.searchinput {
  background-position: 100%;
  background-image: url('.././assets/img/search2.png');
  background-repeat: no-repeat;
}
</style>

