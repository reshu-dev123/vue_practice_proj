<template>
  <div :class="[cssClass,$attrs.disabled && 'u-disabled']">
    <div class="u-row u-radiobtn u-msmall">
      {{ placeholder }} <span class="u-text-red" v-if="isMandatory">*</span>
    </div>
    <div :class="[direction? 'radio-button-group-item radio-button-group-lft':'radio-button-group-lft u-display-inline']">
      <div
        v-for="(option, index) in selectOptions"
        :key="index"
        :class="['radio-button-group-item', option.cssClass]"
      >
        <label :for="option.id+'_'+id" :class="[option.tool? 'u-tooltip-2 tip-bottom-2':'']" :data-tooltip="option.tool">
          <input
            class="u-border-4 u-radiobtn u-radioalign u-radio-mark"
            :class="!option.isDisable?'u-pointer':'u-disabled'"
            type="radio"
            :id="option.id+'_'+id"
            :name="option.name"
            v-bind="$attrs"
            :disabled="option.isDisable"
            :checked="modelValue?modelValue.toString() == option.id.toString() : option.defaultChecked"
            @change="onchangeEvenet(option, option?.tabSequence != undefined ?
             option.tabSequence:index,modelValue)"            
          />
          {{ option.label }}
        </label>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: "UARadioButton",
  props: [
    "selectOptions",
    "placeholder",
    "cssClass",
    "modelValue",
    "id",
    "isMandatory",
    "isDisabled",
    "direction"
  ],
  emits:["radioOptionSelectedfromChild","update:modelValue"], 
  methods: {
    onchangeEvenet(option,index) {       
      let obj = {'selectedValue':option.id,"componentValue":option.ComponentType,'selectedIndex':index}
      this.$emit("update:modelValue", option.id);
      this.$emit("radioOptionSelectedfromChild",option, index);
      //this.$emit("disableOtherRadioButtons", this.selectOptions, index, modelValue);
    },
    getRandomNumber(modelValue){
      Math.random()
    }
  },
};
</script>
<style scoped>
 .u-radio-mark { 
  accent-color: #002244;  
 }
</style>