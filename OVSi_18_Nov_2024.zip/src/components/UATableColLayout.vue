<template>
  <div
    :class="['u-small u-round u-border-grey u-centered u-white',tblHeaders.blockCss]"
  >
  <div :class="['u-row',tblHeaders.tableHeaderTextCss]" v-if="tblHeaders.tableHeaderText">
    <label :class="['u-col',tblHeaders.subHeaderCss]">{{tblHeaders.tableHeaderText }} {{value}}</label>
    <div v-if="chevronImg">   
        <span @click="toggleChevron"   >          
          <img v-if="isShowChevron" src="@/assets/img/down_arrow_1.png" 
          alt = "chevron-down"
          class="u-menuImgSml u-border-0 u-transform-chevron u-transparent printHide" />
          <img v-else src="@/assets/img/down_arrow_1.png" 
          alt = "chevron-down"
          class="u-menuImgSml u-border-0  u-transparent printHide" /> 
        </span>          
    </div>
  </div>
    <div class="u-row" v-if="showHeader && tblHeaders.chevronImg? isShowChevron : !tblHeaders.chevronImg">
      <div :class="['u-col l12 m12 s12 u-center',tblHeaders.css]" >
        <template v-for="(header, tKey) in tblHeaders.headerValues" :key="tKey">
          <div
            :class="['u-col', tblHeaders.cssClass]"
          >
            <div
              v-if="dropDownOption && tKey == 0"
              :class="[
                'u-col',
               dropDownOption
                  ? 'u-left-align l9 m9 s9 '
                  : 'u-center l12 m12 s12',
              ]"
            >
              <div class="u-col l6 m6 s6 u-left-align">
                <label class="u-padding-xsmall">{{ dropDownOption.label }}</label>
              </div>
              <div class="u-col l6 m6 s6 u-cell-top">
                <component
                  :is="dropDownOption.fieldType"
                  :cssClass="['u-bg-1', dropDownOption.cssClass]"
                  v-model="dropDownOption.model"
                  v-bind="dropDownOption.attributes"
                  :options="getSourceOptions(dropDownOption)"
                  :value="selectedDnlnStn"
                  firstOption="Select"
                  @update-option="
                    getSelectedDNLNStnData($event, dropDownOption, 'model')
                  "
                >
                </component>
              </div>
            </div>
            <div
              :class="[
                dropDownOption && tKey == 0
                  ? ' u-col u-left l4 m4 s4'
                  : '', tblHeaders?.subLabelCss
              ]"
            >
              <label>{{ header || " " }}</label>
            </div>
          </div>
        </template>
      </div>
    </div>
    <div :class="['u-row',tblHeaders.dataBlockCss]" v-if="tblHeaders.chevronImg? isShowChevron : !tblHeaders.chevronImg">
      <template v-for="(tblField, rKey) in tableFields" :key="rKey">
        <div :class="[tblField?.subFields ? 'u-col l12 m12 s12' : '']">
          <template
            v-for="(subField, tKey) in getTableFields(tblField)"
            :key="tKey"
          >
            <div
              :class="[
                'u-col',
                tblHeaders.cssClass,
                subField.cssClass,
              ]"
            >
              <div
                v-for="(inlineFields, inKey) in subField.displayInlineFields"
                :key="inKey"
                :class="[inlineFields.cssClass]"
              >
                <label v-if="inlineFields.inlineField == 'label'">{{
                  subField.label
                }}</label>
                <label v-if="inlineFields.inlineField == 'modelData'">{{
                  subField.model
                }}</label>
                <label v-if="inlineFields.inlineField == 'data'">{{
                  getTableDataForField(subField.path, subField.cabin,subField)
                }}</label>
                <span :class="subField.isRedNotrequired == undefined ? 'u-padding u-text-red': ''"
                  v-if="
                    inlineFields.inlineField == 'data' &&
                    subField?.addtionalPath
                  "
                >
                  {{
                    getTableDataForField(
                      subField?.addtionalPath,
                      subField.cabin
                    )
                  }}</span
                >
                <!-- <div v-if="inlineFields.inlineField == 'field' && subField.setIsDDLLoading" class="nb-spinner"></div> -->
                <template v-if="subField.fieldType == 'UADateRangePicker'">
                <component 
                :is="subField.fieldType"
                :isDisabled="subField.attributes.disabled"
                v-bind="subField.attributes"
                v-model:startDate="subField.model.startDate"
                v-model:endDate="subField.model.endDate"              
              ></component>
               </template>
               <template v-else>
                <component 
                  :is="subField.fieldType"
                  v-if="!subField.setIsDDLLoading && inlineFields.inlineField == 'field'"
                  :cssClass="[subField.fieldsCssClass ]"                  
                  :cssCalendar="subField.cssCalendar"
                  v-model="subField.model"
                  :checkedProps="subField.checkedProps"
                  v-bind="subField.attributes"
                  :selectedKey="subField.selectedKey"
                  :dataType="subField.dataType"
                  :modalError="subField?.modalError"
                  :errorMessage="subField.errorMessage"
                  :filtersErrorTooltip="subField.filtersErrorTooltip"
                  :id ="subField.id"
                  :options="
                    subField.fieldType == 'UADropDown' ||
                    subField.fieldType == 'UACheckbox'
                      ? getSourceOptions(subField)
                      : []
                  "
                  :firstOption="subField.model"
                  :selectOptions="
                    subField.fieldType == 'UASelect' ||
                    subField.fieldType == 'UARadioButton'
                      ? getSourceOptions(subField)
                      : []
                  "
                  :onChangeFieldsToTrigger="subField.onChangeFieldsToTrigger"
                  @update:modelValue="
                    updateEditFields($event, subField, 'model')
                  "
                  @update-option="
                    updateOption($event, subField, 'model', subField.path)
                  "
                  @callApiOnDateChange="getValuesToBind($event, subField)"
                  @toggleChanged="(e)=>$emit('toggleChanged',{value:e,subField})"
                  :isDisabled="subField?.attributes?.disabled || isViewDetails || isCaseIdNotEmpty(subField,tableData)"
                  :currInputFieldInfo="subField"
                  :text="subField.label"
                   @changeView="changeView(subField)"
                   :dataLength="subField?.dataLength"
                   :isDynamicRowCol="subField.fieldType == 'UACheckbox'?subField.isDynamicRowCol:false"
                   @selectedItem="(items)=>subField.model=items"
                   :cellCss ="subField.fieldsCssClass"
                >
                </component>
              </template>
              </div>
            </div>
          </template>
        </div>
      </template>
       <div v-if="deleteimg" :class="[tblHeaders.deleteimageClass]">
           <img src="@/assets/img/delete.png" @click="deleteRow"  class="deleteRow"/>

          </div>
    </div>
  </div>
</template>

<script>
import { mapGetters,  mapState } from "vuex";
import UADateTimePicker from "@/components/UADateTimePicker.vue";
import UATextbox from "@/components/UATextbox.vue";
import UADropDown from "@/components/UADropDown.vue";
import UASelect from "@/components/UASelect.vue";
import UADatePicker from "@/components/UADatePicker.vue";
import UATextarea from "@/components/UATextarea.vue";
import UADateRangePicker from "@/components/UADateRangePicker.vue";
import UAToggleSwitch from '@/components/UAToggleSwitch.vue';
import UACheckbox from '@/components/UACheckbox.vue';
import UARadioButton from '@/components/UARadioButton.vue';
export default {
  name: "UATableColLayout",
  components: {
    UADateTimePicker,
    UATextbox,
    UADropDown,
    UASelect,
    UADatePicker,
    UATextarea,
    UADateRangePicker,
    UAToggleSwitch,
    UACheckbox,
    UARadioButton
  },
  data() {
    return {
      isShowChevron: true
    };
  },
  props: [
    "tblHeaders",
    "tableData",
    "tableFields",
    "dropDownOption",
    "dnlnStns",
    "selectedDnlnStn",
    "value", // contains index+1 ued for case_id tracking
    "deleteimg",
    "chevronImg"
  ],
  emits:["getDynamicValuesOnChange", "setSelectedDnlnStn","changeView","delete",'toggleChanged'],
  computed: {
     ...mapState({
        isDDLLoading: (state) => state.ovsiDefaultModule.isDDLLoading,
        ddlLoadingMessage: (state) => state.ovsiDefaultModule.ddlLoadingMessage,
         isViewDetails: (state) => state.ovsiDefaultModule.isViewDetails,
     }),
    showHeader() {      
      return (
        this.tblHeaders.headerValues &&
        this.tblHeaders.headerValues.length > 0 &&
        this.tblHeaders.headerValues.filter((hf) => hf != "").length > 0
      );
    },
    ...mapGetters(["getJPathValue"]),
  },
  methods: {   
     changeView(subField){ 
      this.$emit("changeView",subField);
    },
    isCaseIdNotEmpty(subField,tableData){
      let caseIdToDisable = false;
      if(subField.label=='Case ID'){
          tableData[0]?.compensation?.issuances?.forEach(issData =>{
            if(issData.id == this.value){
            caseIdToDisable = (issData?.itmcReferenceNumber && issData?.itmcReferenceNumber.length>0);
            }
          })
      }
      return caseIdToDisable;
    },
    async getValuesToBind(selectedValue, currField) {
      try {
        this.$emit(
          "getDynamicValuesOnChange",
          {selectedValue,
          currField,
          inlineTableData:this.tableData}
        );
      } catch (err) {
        console.error(" getValuesToBind ",err)
      }
    },
    getTableFields(tblFlds) {
      let arrField = [];
      if (tblFlds.hasOwnProperty("subFields")) {
        return tblFlds.subFields;
      } else {
        //AVOID HIDDEN FIELDS 
        if(tblFlds.fieldType !== "Hidden") arrField.push(tblFlds);
        return arrField;
      }
    },
    getTableDataForField(tblFldsPath, cabin,fields) {
      let fieldData = "";
      if(fields.isAminities && fields.isEdit ){
        let  ams = this.getJPathValue(tblFldsPath, this.tableData[0]) || [];
        let aminities = ams.filter(am=>am[fields.filterPath] == fields.filterValue) || [];
        return aminities.length>0?fields.combinepath.map(path=>this.getJPathValue(path,aminities[0])).join(fields.combinePrefix||'').toString():fields.defaultValue;
      }
      
      if (this.tableData.length > 0) {
        fieldData = this.getJPathValue(tblFldsPath, this.tableData[0][cabin]);
        if(!cabin){
        fieldData = this.getJPathValue(tblFldsPath, this.tableData[0]);
        }
        if(fields.dataType && fields.dataType.toString() == "array"){
          fieldData =this.combineFields(fields,fieldData[0]);
        }
        if(fields.dataType && fields.dataType.toString() == "object"){
          fieldData =this.combineFields(fields,fieldData);
        }
        if(fields.dataType && fields.dataType.toString() == "nestiarray"){
          fieldData =this.combineFields(fields,fieldData[0]?fieldData[0][fields.subpath][0]:{});
        }
      }
      if(fieldData === 0){
        return fieldData;
      }
      if(!fieldData && fields && fields.defaultValue){
        fieldData = fields.defaultValue;
      }
      return fieldData;
    },
    combineFields(field,item){
      return field.combinepath.map(path=>this.getJPathValue(path,item)).join(field.combinePrefix||'').toString();
    },
    getSourceOptions(entityItem) {
      switch (entityItem.sourceType) {
        case "api":
          return entityItem.source;
        case "inLine":
          return entityItem.source;
        case "custom":
          return this.dnlnStns;
        default:
          return "";
      }
    },
    getSelectedDNLNStnData(selectedItem, modal, path) {
      modal.model = selectedItem;
      this.$emit("setSelectedDnlnStn", selectedItem);
    },
    updateOption(eVal, modal, path, modalPath) {
      modal[path] = eVal;
    },
    updateEditFields(eVal, fieldItem) {
      fieldItem.model = eVal;
    },
    toggleChevron() {
      this.isShowChevron = !this.isShowChevron;
    },
    deleteRow(){
      this.$emit('delete');
    }
  },
};
</script>

<style>
.deleteRow{
  margin-left: 10px;
  margin-top:18px;
  height: 22px;
  width: 18px;
  cursor: pointer;
}
.u-width-0{
  width: 0 !important;
}
</style>