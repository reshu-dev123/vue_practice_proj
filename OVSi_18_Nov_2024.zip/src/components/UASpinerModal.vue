<template>
  <div class="u-modal u-col" style="display: block;z-index:4" v-if="isGeneratingPDF || isGeneratingExcel">
    <div class="u-round u-modal-content-1 u-top-25per">
      <div class="u-row u-pad-left-1 u-pad-right-1">
        <div class="u-col l12 m12 s12">
          <div class="u-col l12 m12 s12 ">
            <div class="u-lineHeight-popup u-pad-0">
              <h5 class="u-padding-16 u-fnt-bld u-flex-center">{{ isGeneratingPDF?generatingPDFMsg: generatingExcelMsg }}</h5>
              <!-- <div class="nb-spinner"></div> -->
            </div>
          </div>
        </div>
      </div>

    </div>
  </div>
</template>
<script>
import { mapState } from 'vuex';
export default {
  name: "UASpinerModal",
  data() {
    return {
      dialogVisible: false
    };
  },
  computed: {
    ...mapState({
      isGeneratingPDF: (state) => state.ovsiDefaultModule.isGeneratingPDF,
      generatingPDFMsg: (state) => state.ovsiDefaultModule.generatingPDFMsg,
      isGeneratingExcel: (state) => state.ovsiDefaultModule.isGeneratingExcel,
      generatingExcelMsg: (state) => state.ovsiDefaultModule.generatingExcelMsg,
    }),
  }
}
</script>
<style></style>

