<template>
    <div class="u-row u-display-flex">
        <div class="u-col u-section">
        <template v-for="(header, headerInd) in tblHeaders" :key="headerInd">
            <label v-if="getDbTypeDetails.length > 1 && headerInd==0" class="u-col l2 m2 s2 u-padding-left-16 u-fnt-bld">{{ header.text }}</label>
            <label v-if="headerInd!=0" :class="['u-col u-padding-left-16 u-fnt-bld', getDbTypeDetails.length > 1 ? 'l5 m5 s5' : 'l6 m6 s6']">{{ header.text }}{{header.id == 'average_comp_by_cust_or_miles'?` (${getSpendByFromModel().model})`:''}}</label>
        </template>
        <label v-if="getDbTypeDetails.length ==0" class="u-col u-center u-fnt-bld  u-padding-top-7 " >No Data Found</label>
        </div>
        <template v-for="(dbTypeInfo, dbtypeInd) in getDbTypeDetails" :key="dbtypeInd">
            <div class="u-col l2 m2 s2 u-padding-left-16" v-if="getDbTypeDetails.length > 1">Type {{ dbTypeInfo.dbType }}</div>
            <template v-for="(chart, chartIndex) in charts" :key="chartIndex+dbtypeInd">
                <div :class="['u-col u-tbl-bar', getDbTypeDetails.length > 1 ? 'l5 m5 s5' : 'l6 m6 s6']">
                    <!-- UAChart -->
                    <component :is="chart.componentType" :width="chart.width" :height="chart.height" :chartId="chart.id+'_type_'+dbTypeInfo.dbType"
                        :chartData="getDbDetailsLineChartData(chartIndex, dbTypeInfo.dbType,chart)"
                        :chartOptions="getChartOptionWithCustomPlugin(chart)" :chartType="chart.chartType" />
                </div>
            </template>
        </template>
    </div>
</template>
    
<script>
import UAChart from "./UAChart.vue";
import {getRandomColor} from './../helpers/utilities';
export default {
    name: "UAOSLTableGraph",
    props:['chartResponse','charts','selectedViewOption','boardingTypes',"tblHeaders","filters",'spendFltrModel','boardingType'],
    components: {
        UAChart,
    },
    computed:{
        getDbTypeDetails(){
            let dbTypeinfo = [];
            let dyTypes = this.boardingTypes;
             dyTypes = this.boardingType != 'All' ? [{code:this.boardingType}] : dyTypes;
             let selectedVolOpt = this.getVolStatusFromModel(); // get selected vol status
             let spendObj = this.getSpendByFromModel();
             let avgPaxCountByTypePerFlightForSlOpt= this.chartResponse?.avgPaxCountByVolTypes?.filter(pxCnt=>pxCnt.volStatus.toLowerCase()==selectedVolOpt)[0]?.avgPaxCountByTypePerFlight;
             let avgCompByTypePerPassengertForSlOpt= this.chartResponse[spendObj.path]?.filter(avgCompTy=>avgCompTy.volStatus.toLowerCase()==selectedVolOpt)[0];
                 avgCompByTypePerPassengertForSlOpt= spendObj.model == 'Miles'?avgCompByTypePerPassengertForSlOpt?.avgMilesByTypePerPassenger:avgCompByTypePerPassengertForSlOpt?.avgCompByTypePerPassenger
             
            dyTypes.forEach(type => {
                let avgCompByType =avgCompByTypePerPassengertForSlOpt?.filter(resItem => resItem.dbType == type.code)[0];
                let size = avgCompByType?avgCompByType[spendObj.model == 'Miles'?this.getDbMilesPathForSlBtn():this.getDbPeriodPathForSlBtn()].length:1;
                let dheight= size*50;
                dbTypeinfo.push({ dbType: type.code, 
                    avgPaxCountDataByTypeFound : avgPaxCountByTypePerFlightForSlOpt?.filter(resItem => resItem.dbType == type.code).length>0, 
                    avgPgnrCompByTypeFound: avgCompByTypePerPassengertForSlOpt?.filter(resItem => resItem.dbType == type.code).length>0,
                    height: dheight
                })
            })
            //IGNORE RECORD IF BOTH DB TYPE DATA NOT AVAILABLE
            return dbTypeinfo.filter(item => (item.avgPaxCountDataByTypeFound || item.avgPgnrCompByTypeFound)); 
        }        
    },
    methods: {
        getChartOptionWithCustomPlugin(chart){
                if (chart.id == 'avg_comp_per_cust'){
                    chart.chartOptions.plugins.tooltip['callbacks']={
                        label: function(context) {
                            let label = '';
                            if (context.parsed.x !== (null || 0)) {
                                label += `${context.dataset.label}${': '}${Number.isInteger(context.parsed.x)?context.parsed.x:context.parsed.x.toFixed(2)}`;
                            }
                            return label;
                        }
                }
            }
                return chart.chartOptions;
            },
        getDbPeriodPathForSlBtn(){
            let pathForDbPeriods='';
            if(this.selectedViewOption.compKeyPath == 'days')
                 pathForDbPeriods= 'avgCompByDay'
             else if(this.selectedViewOption.compKeyPath == 'months')
                 pathForDbPeriods= 'avgCompByMonth'
            else
              pathForDbPeriods= 'avgCompByWeek'
            return pathForDbPeriods;
        },
        getDbMilesPathForSlBtn(){
            let pathForDbPeriods='';
            if(this.selectedViewOption.compKeyPath == 'days')
                 pathForDbPeriods= 'avgMilesByDay'
             else if(this.selectedViewOption.compKeyPath == 'months')
                 pathForDbPeriods= 'avgMilesByMonth'
            else
              pathForDbPeriods= 'avgMilesByWeek'
            return pathForDbPeriods;
        },
        getVolStatusFromModel(){
            let selectedVol = this.filters.filter(f=>f.id=='vol_status').map(f=>f.model)[0];
        return selectedVol.length>1?'all':selectedVol[0].toLowerCase();
        },
        getSpendByFromModel(){
            let model= this.filters.filter(f=>f.id=='spend_by').map(f=>f.model)[0];
            if(model == 'ETC') return {model,path:'avgEtcCompByVolTypes'};
            if(model == 'Miles') return {model,path:'avgMilesByVolTypes'};
            if(model == 'Draft') return {model,path:'avgDraftCompByVolTypes'};
        },
        getBoardingTypeColor(type){
           return this.boardingTypes.filter(bType=>bType.code==type)[0].typeBackColor;
        },
        getDbDetailsLineChartData(chartDataIndex, currDbType,chart) {
            let chartDetails = JSON.parse(JSON.stringify(chart.chartDataTemplate));
            let selectedVolOpt = this.getVolStatusFromModel();
            let avgPaxCount = [];
            let dayMonWeekLabel = [];
            let cntRes = [];
            let multiCurrenciesData= [];
            if (chartDataIndex == 0) { //FOR count/flight
                let avgPaxCountByTypePerFlightForSlOpt= this.chartResponse.avgPaxCountByVolTypes?.filter(pxCnt=>pxCnt.volStatus.toLowerCase()==selectedVolOpt)[0]?.avgPaxCountByTypePerFlight;
                cntRes = avgPaxCountByTypePerFlightForSlOpt || [];
                cntRes = cntRes.filter(item => item.dbType == currDbType); //FILTER RECORDS AS PER SELECTED TAB TYPE
                cntRes.forEach(paxCntItem => {
                    if (this.selectedViewOption.compKeyPath == 'days')
                        paxCntItem.avgPaxCountByDay.forEach((count) => { avgPaxCount.push(count.avgPaxCount); dayMonWeekLabel.push(count.day) });
                    else if (this.selectedViewOption.compKeyPath == 'months')
                        paxCntItem.avgPaxCountByMonth.forEach((count) => { avgPaxCount.push(count.avgPaxCount); dayMonWeekLabel.push(count.month) });
                    else // week
                        paxCntItem.avgPaxCountByWeek.forEach((count) => { avgPaxCount.push(count.avgPaxCount); dayMonWeekLabel.push(count.week) });
                    chartDetails.datasets[0].backgroundColor.push(this.getBoardingTypeColor(paxCntItem.dbType));
                });
                chartDetails.labels = dayMonWeekLabel;
                chartDetails.datasets[0].data = avgPaxCount;
                return chartDetails;
            }//FOR dbCountByType count
            else { // For AVG COMPE PER CUSTOMER BY SELECTED VOl_STa
                
                return this.generateAvgCompByVolType(this.chartResponse,selectedVolOpt,chartDataIndex,currDbType,chart);
            }
            
        },
        generateAvgCompByVolType(dbDetailsReponse,selectedVolOpt,chartDataIndex,currDbType,chart){
            let spendObj = this.getSpendByFromModel();
            let chartDetails = JSON.parse(JSON.stringify(chart.chartDataTemplate));

            let avgData= dbDetailsReponse[spendObj.path]?.filter(avgCompTy=>avgCompTy.volStatus.toLowerCase()==selectedVolOpt)[0];
            if(spendObj.model == 'Miles'){
                avgData = avgData?.avgMilesByTypePerPassenger||[];
                avgData = avgData.filter(av=>av.dbType==currDbType);
                avgData=avgData||[];
                if (avgData.length == 0) {
                    return chartDetails;
                }
                if (this.selectedViewOption.compKeyPath == 'days') {
                    return this.generateDataSetsForCompByMiles(currDbType, avgData[0].avgMilesByDay, 'day');
                } else if (this.selectedViewOption.compKeyPath == 'months') {
                    return this.generateDataSetsForCompByMiles(currDbType, avgData[0].avgMilesByMonth, 'month');
                } else { // week
                    return this.generateDataSetsForCompByMiles(currDbType, avgData[0].avgMilesByWeek, 'week');
                }
            }else{
                avgData = avgData?.avgCompByTypePerPassenger||[];
                avgData = avgData.filter(item => item.dbType == currDbType); //FILTER RECORDS AS PER SELECTED TAB TYPE
                if (avgData.length == 0) {
                    return chartDetails;
                }
                else if (this.selectedViewOption.compKeyPath == 'days') {
                    return this.generateDataSetsForCompByCustomer(currDbType, avgData[0].avgCompByDay, 'day');
                } else if (this.selectedViewOption.compKeyPath == 'months') {
                    return this.generateDataSetsForCompByCustomer(currDbType, avgData[0].avgCompByMonth, 'month');
                } else { // week
                    return this.generateDataSetsForCompByCustomer(currDbType, avgData[0].avgCompByWeek, 'week');
                }
            }
            
        },
        generateDataSetsForCompByMiles(type, avgMiles,labelPath) {
            let datasets = [];
            let mainLables = [];
            let data = [];
            avgMiles.forEach(avgC => {
                mainLables.push(avgC[labelPath]);
                data.push(avgC.avgMiles);
            });
            let dataset = { label: 'Miles', data,
                     backgroundColor: [this.getBoardingTypeColor(type)]
                    }
                    datasets.push(dataset);
            return { labels: mainLables, datasets };
        },
        generateDataSetsForCompByCustomer(type, avgCompsBy,labelPath) {
            let datasets = [];
            let mainLables = [];
            let currList = [];
            avgCompsBy.forEach(avgC => {
                mainLables.push(avgC[labelPath]);
                avgC.avgComp.forEach(amt =>{ 
                    if(!currList.includes(amt.currencyCode))
                        currList.push(amt.currencyCode);
                })
            });
            currList.forEach(curr => {
                let dataset = { label: curr, data: [],
                     backgroundColor: [getRandomColor(curr)]
                    }
                mainLables.forEach(lbl => {
                    let currDay = avgCompsBy.filter(avg => avg[labelPath] == lbl);
                    if (currDay.length > 0) {
                        let foundForCurrAmt = currDay[0].avgComp.filter(amt => amt.currencyCode == curr);
                        if (foundForCurrAmt.length > 0)
                            dataset.data.push(foundForCurrAmt[0].amount)
                        else
                            dataset.data.push(0)
                    }
                })
                datasets.push(dataset);
            })


            return { labels: mainLables, datasets };
        }
    },

}
</script>
    
<style ></style>