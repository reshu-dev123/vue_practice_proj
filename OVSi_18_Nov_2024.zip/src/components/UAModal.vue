<template>
  <div class="u-modal u-overlay u-col" style="display: block">
    <form
     ref="modalConfirmCompRef" @mouseleave="mouseLeaveHandler()" @mouseover="mouseOverHandler()"
      @submit.prevent="submitData()"
      class="u-modal-content-1 u-border" 
    >
      <div class="u-round">
        <header class="u-row">
          <div
            class="u-col u-pad-left-1"
            v-for="(modal, index) in modalConfData"
            :key="index"
          >
            <div v-if="modal.header">
              <div class="u-col l10 m6 s6">
                <h5 class="u-fnt-bld">{{ modal.header }}</h5>
              </div>
              <div class="u-col l2 m6 s6">
                <UAButton
                  @click="$emit('close')"
                  cssClass="u-button u-large  u-right"
                >
                  X
                </UAButton>
              </div>
            </div>
            <div class="u-col">
              <h6>{{ modal.field }}</h6>
            </div>
          </div>
        </header>

        <div class="u-row u-pad-left-1 u-pad-right-1 u-padding-16">
          <div
            class="u-col l6 m6 s6"
            v-for="(modal, index) in modalConfData"
            :key="index"
          >
            <div class="u-col l10 m10 s10 u-padding-16"  style="height:60px;">
              <span class="u-fnt-bld">
                {{ modal.label }}
              </span>
              <div v-if="modal.fieldType" class="u-lineHeight-popup">
                <component
                  v-if="modal.fieldType == 'UADropDown'"
                  :is="modal.fieldType"
                  :id="modal.id"
                  :labelInfo="modal.label"
                  :cssClass="modal.cssClass"
                  :options="getSourceOptions(modal, 1)"
                  @update-option="updateOption($event, modal, 'model', modal.path)"
                  v-bind="modal.attributes"
                  :firstOption="modal.model"
                ></component>

                <component
                  :is="modal.fieldType"
                  v-if="modal.fieldType != 'UADropDown'"
                  :labelInfo="modal.label"
                  :id="modal.id"
                  :cssClass="modal.cssClass"
                  :options="getSourceOptions(modal, 1)"
                  v-model="modal.model"
                  :dataType="modal.dataType"
                  v-bind="modal.attributes"
                  :modelValue="modal.model"
                  @input="updateEditItem(modal.path)"
                  :errorMessage="modal.errorMessage"
                  :currInputFieldInfo="modal"
                  :filtersErrorTooltip="modal.filtersErrorTooltip"
                  :modalError="modal.modalError"
                  :dataLength="modal?.dataLength"
                  :optionsType="modal.optionsType"
                  :checkedProps="modal.checkedItems"
                  @selectedItem="selectedCheckedItems($event,modal)" 
                ></component>
              </div>
              <div v-else>
                <span>{{ getJPathValue(modal.path, modalData) }}</span>
              </div>
            </div>
          </div>
        </div>

      <footer class="u-container  u-padding-16">
        <div class="u-row u-pad-0 u-section-1">
          <div class="u-col l12 m12 s12">
            <div class="u-row-padding u-pad-0 u-right">
              <div class="u-col l6 m6 s6">
                <UAButton
                id="_modal_cancel"
                  @click="$emit('close')"
                  cssClass="u-button u-round u-secondary-cst u-col"
                >
                {{modalBtnInfo.cancelBtnText}}
                </UAButton>
              </div>
              <div class="u-col l6 m6 s6">
                <UAButton id="_modal_ok" :cssClass="['u-button u-round u-primary-cst u-col',disableExport && 'u-disabled']"
                  > {{modalBtnInfo.okBtnText}}
                </UAButton>
              </div>
            </div>
          </div>
        </div>
       </footer>
      </div>
    </form>
  </div>
</template>
<script>
import UATextbox from "@/components/UATextbox.vue";
import UAButton from "@/components/UAButton.vue";
import UADropDown from "@/components/UADropDown.vue";
import UACheckbox from "@/components/UACheckbox.vue";
import { mapGetters, mapState,mapMutations } from "vuex";
import { validatInputParams } from "@/helpers/utilities.js";

export default {
  name: "UAModal",
  components: {
    UATextbox,
    UAButton,
    UADropDown,
    UACheckbox
  },
  props: ["modalConfigData", "tblData", "modalBtnInfo"],
  emits: ["close", "submitMdlData"],
  data() {
    return {
      modalConfData: JSON.parse(JSON.stringify(this.modalConfigData)),
      modalData: JSON.parse(JSON.stringify(this.tblData)),
      addEditItem:{},
      checkedItems:[],
      mouseVisitedOnModal:false,//TO Verify THE mouse FOCUS OR MOUSE OVER ON MODAL DISPLAY at least one time 
      mouseLeaveDetected:false
    };
  },
  mounted() {
    setTimeout(() =>  document.addEventListener("click",this.handleOutSideClick),100) ;
  },
  computed: {
    ...mapState({
      displayHeader: state => state.ovsiDefaultModule.displayHeader,
      disableExport: state => state.ovsiDefaultModule.disableExport,
    }),
    ...mapGetters (["getJPathValue","getOVSIFields"]),
  },
  methods: {
    ...mapMutations(["setAlertMessages"]),
     mouseLeaveHandler(){
        this.mouseLeaveDetected = true;
      },
      mouseOverHandler(){
        this.mouseLeaveDetected = false;
        this.mouseVisitedOnModal = true;
      },
      handleOutSideClick(e){
        if((this.mouseLeaveDetected && this.mouseVisitedOnModal) || (!this.mouseLeaveDetected && !this.mouseVisitedOnModal)){//IF AT LEAST ONCE THE MOUSE OVER THE MODAL DISPLAY AND THEN ONLY DETECT THE MOUSE LEAVE
          if(this.$refs?.modalConfirmCompRef && !this.$refs?.modalConfirmCompRef?.contains(e.target)){
            this.$emit("close");       
          } 
        }
      },
    selectedCheckedItems(selectedItems, modal){//Checkbox checked items
      modal.checkedItems = selectedItems;
      this.addEditItem[modal.path] = selectedItems
    },
    //override update option by passing event
    updateOption(eVal, modal, path, modalPath) {
      modal[path] = eVal;
      this.updateEditItem(modalPath);
    },
    updateEditItem(modelKeyPath) {

      this.addEditItem[modelKeyPath] = event.target.value;

    },
    getSourceOptions(entityItem, index) {
      switch (entityItem.sourceType) {
        case "api":
          return entityItem.source;
        case "inLine":
          return entityItem.source;
        default:
          return "";
      }
    },
    submitData(type) {
      if(this.modalBtnInfo.submitType == "exportOptions"){
        if (this.addEditItem.exportOption.length == 0) {
          return; 
        }
        this.$emit("submitMdlData",this.addEditItem);
        this.$emit("close");
        return;
      }
      let errFound = validatInputParams(this.modalConfData);        
      if (errFound) {
        let alertInfo = {
          alertType: "error",
          alertMessages: ["Errors in the Modal fields!", ...errFound],
        };
        this.setAlertMessages(alertInfo);  
        return ;        
      }
      const saveData = Object.assign(this.tblData, this.addEditItem);
      this.$emit("submitMdlData", saveData);
      this.$emit("close");
    },
  },
};
</script>
<style>
</style>

