<template>
  <div class="u-modal u-col u-overlay" style="display: block" v-if="dialogVisible">
      <div class="u-round u-modal-confirm-content" ref="confirmModalComRef" @mouseleave="mouseLeaveHandler()" @mouseover="mouseOverHandler()">
       
        <div class="u-row u-pad-left-1 u-pad-right-1">
            <div class="u-col l12 m12 s12 " >             
              <div  class="u-lineHeight-popup">
                 <h5 class=" u-fnt-bld">{{ title }}</h5>
                 <span class="u-padding-16">{{ message }}</span>
              </div>
            </div>
      </div>
      <div class="u-row u-pad-left-1 u-pad-right-1 u-pad-btm-15" v-if="commentFields && commentFields.length>0">
        <template v-for="(cmtfld,cmtind) in commentFields" :key="cmtind">
            <component :is="cmtfld.fieldType" :class="cmtfld.cssClass"
            @update:modelValue="updateEditFields($event,cmtfld,'model')" :placeholder="cmtfld.name"
            v-model="cmtfld.model">
            </component>
          </template>
      </div>
        <div class="u-row u-pad-0 u-section-1">
          <div class="u-col l12 m12 s12 u-pad-left-8px u-pad-right-8">
            <div class="u-row-padding u-pad-0 u-center">
              <div class="u-col l6 m6 s6" v-if="cancelButtonText">
                <UAButton
                  @click="cancel()"
                  cssClass="u-button u-round u-secondary-1-pur u-col"
                >
                  {{cancelButtonText}}
                </UAButton>
              </div>
              <div class="u-col l6 m6 s6">
                <UAButton cssClass="u-button u-round u-primary-1-pur u-col" 
                  @click="ok()"
                  > {{okButtonText}}
                </UAButton>
              </div>
            </div>
          </div>
        </div>
      </div>
  </div>
</template>
<script>
import UAButton from "@/components/UAButton.vue";
import UATextarea from "@/components/UATextarea.vue";
export default {
    name: "UAConfirmBox",
     components: {
      UAButton,
      UATextarea
    },
    props:["commentFields"],
    data() {
      return {
        dialogVisible: false,
        dialogCmtTxt: false,
        resolvPromise: null,
        rejectPromise: null,
        message: null,
        title: null,
        okButtonText: null,
        cancelButtonText: null,
        mouseVisitedOnModal:false,//TO Verify THE mouse FOCUS OR MOUSE OVER ON MODAL DISPLAY at least one time 
        mouseLeaveDetected:false,
      };
    },
    mounted() {
      setTimeout(() =>  document.addEventListener("click",this.handleOutSideClick),100) ;
    },
    unmounted() {
      document.removeEventListener("click",this.handleOutSideClick);
    },
    methods: {
      mouseLeaveHandler(){
        this.mouseLeaveDetected = true;
      },
      mouseOverHandler(){
        this.mouseLeaveDetected = false;
        this.mouseVisitedOnModal = true;
      },
      handleOutSideClick(e){
        if(this.dialogVisible){
          if((this.mouseLeaveDetected && this.mouseVisitedOnModal) || (!this.mouseLeaveDetected && !this.mouseVisitedOnModal)){//IF AT LEAST ONCE THE MOUSE OVER THE MODAL DISPLAY AND THEN ONLY DETECT THE MOUSE LEAVE
            if(this.$refs?.confirmModalComRef && !this.$refs?.confirmModalComRef?.contains(e.target)){
              this.dialogVisible = false;    
              this.mouseVisitedOnModal = false;
            } 
          }
        }
      },
      dialogOpen(opts = {}) {      
        this.dialogVisible = true;
        this.title = opts.title;
        this.message = opts.message;
        this.okButtonText = opts.okButtonText;
        this.cancelButtonText = opts.cancelButtonText;
        return new Promise((resolve, reject) => {
          this.resolvPromise = resolve;
          this.rejectPromise = reject;
        });
      },
      ok() {
        this.resolvPromise(true);
        this.dialogVisible = false;
        this.mouseVisitedOnModal = false;
      },
      cancel() {
        this.rejectPromise(false);
        this.dialogVisible = false;
        this.mouseVisitedOnModal = false;
      },
      updateEditFields(eVal, fieldItem) {
        fieldItem.model = eVal;
      },
    },
  }
</script>
<style>
</style>

