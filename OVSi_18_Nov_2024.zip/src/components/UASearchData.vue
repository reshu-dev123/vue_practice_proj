<template>
  <div class="u-row" v-if="!isLoading">
    <div :style="isShow ? 'u-row' : 'height:20px'">
      <form @submit.prevent="getRTFFiltersData(searchRTFFilters)" class="u-row" v-show="isShow">
        <div class="u-row-padding">
          <div :class="['u-col',filter.colCssClass]" v-for="(filter, index) in searchRTFFilters" :key="index">
              <component v-if="filter.fieldType == 'UADateRangePicker'"
                :is="filter.fieldType"
                :isDisabled="filter.attributes.disabled"
                v-bind="filter.attributes"
                v-model:startDate="filter.model.startDate"
                v-model:endDate="filter.model.endDate"
                :options="filter.source"
                :labelInfo="filter.label"
                :isFloatLabel="filter.isFloatLabel"
                :showLabel="true"
                :selectOptions="getSourceOptions(filter, index)"
                :sourceType="filter.sourceType"
                :isMandatory="filter.attributes.required"
                :placeholder="filter.attributes.placeholder"
                :cssClass="filter.cssClass"
                :dataType="filter.dataType"
                :labelClass="filter.labelClass"
                :widthCssClass="filter.widthCssClass"
                ref="dateRangePickerCom"
                :errorMessage="filter.errorMessage"
                :filtersErrorTooltip="filter.filtersErrorTooltip"
                @update:startDate="
                  updateSearchFields($event, filter, filter.attributes.id)
                "
                @update:endDate="
                  updateSearchFields($event, filter, filter.attributes.id)
                "
                :currInputFieldInfo="filter"
                :selectedKey="filter.selectedKey"
                :selectedLabel="filter?.selectedLabel"
                :dataLength="filter?.dataLength"
                :errorOnTop="filter.errorOnTop"
                :isModalvalueSwap="filter.isModalvalueSwap"
                :dateFieldInfo="filter"
              >
              </component>
              <component v-else :is="filter.fieldType" :isDisabled="filter.attributes.disabled" v-bind="filter.attributes"
                v-model="filter.model" :options="filter.source" :labelInfo="filter.label"
                :isFloatLabel="filter.isFloatLabel" :showLabel="true" :selectOptions="getSourceOptions(filter, index)"
                :sourceType="filter.sourceType" :isMandatory="filter.attributes.required"
                :placeholder="filter.attributes.placeholder" :cssClass="filter.cssClass" :dataType="filter.dataType"
                :modelValue="filter.model" @update:modelValue="
                  updateSearchFields($event, filter, filter.attributes.id)
                  " :errorMessage="filter.errorMessage" :currInputFieldInfo="filter"
                :filtersErrorTooltip="filter.filtersErrorTooltip" :selectedKey="filter.selectedKey"
                :cssMargin="['u-break-content u-line-height-15',filter.attributes.cssMargin]" :dataLength="filter?.dataLength"
                :dropDownCss="filter.dropDownCssClass"
                >
              </component>
          </div>
          <div :class="['u-col l1-7 m4 s10 u-section-1 u-pad-0 u-right',this.inlineFilterConfig.showSearchButton && 'u-flex']" v-if="searchRTFFilters.length > 0 ">
            <div :class="['u-col l8 m6 s6',!this.inlineFilterConfig.showSearchButton && 'u-right u-padding-top']" v-if="this.inlineFilterConfig.showResetButton">
              <UAButton type="button" @click="resetFilters()" id="Reset" cssClass="u-button u-round u-secondary-1-pur u-col u-width-90 u-msmall lf mf">Reset
              </UAButton>
            </div>
            <div class="u-col l8 m6 s6" v-if="this.inlineFilterConfig.showSearchButton">
              <UAButton id="search" :cssClass="['u-button u-round u-primary-1-pur u-col u-padding-8 u-width-90 u-msmall lf mf', {'u-disabled':!isValidInputFilterParams}]">
                Search
              </UAButton>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>
</template>
<script>
import UATextbox from "@/components/UATextbox.vue";
import UAButton from "@/components/UAButton.vue";
import UARadioButton from "@/components/UARadioButton.vue";
import UADatePicker from "@/components/UADatePicker.vue";
import UASelect from "@/components/UASelect.vue";
import UADateRangePicker from "./UADateRangePicker.vue";
import { mapState, mapGetters, mapActions, mapMutations } from "vuex";
import { getDateTimePart, validatInputParams, getDefaultDate } from "@/helpers/utilities";
import UATime from "@/components/UATime.vue";
export default {
  name: "UASearchData",
  components: {
    UATextbox,
    UAButton,
    UARadioButton,
    UADatePicker,
    UASelect,
    UADateRangePicker,
    UATime
  },
  props: ["inlineFilterConfig"],
  emits: ["checkUFTableDataFound", "resetDefaultData"],
  data() {
    return {
      searchRTFFilters: JSON.parse(JSON.stringify(this.inlineFilterConfig.filters)),
      isShow: true,
      addEditItem: {},
      selectedOptions :{}
    };
  },

  async created() {
    //await this.bindDropdownList();
    this.resetToDefaultState();
  },

  computed: {
    ...mapState({
      isLoading: (state) => state.ovsiDefaultModule.isLoading,
      action: (state) => state.ovsiDefaultModule.action,
      actionId: (state) => state.ovsiDefaultModule.actionId,
      searchFilterMacro: (state) => state.ovsiDefaultModule.searchFilterMacro,
      secondaryFilterMacroFields: (state) =>
        state.ovsiDefaultModule.secondaryFilterMacroFields,
      dynamiceMacroName: (state) => state.ovsiDefaultModule.dynamiceMacroName,
      showSerachFilter: (state) => state.ovsiDefaultModule.showSerachFilter,
      isHeaderSrchClicked: (state) => state.ovsiDefaultModule.isHeaderSrchClicked,
      headerFilterData: (state) => state.ovsiDefaultModule.headerFilterData,
      entityDisplayDetails: (state) =>
        state.ovsiDefaultModule.entityDisplayDetails,
      tabPrevOptions(){
        return this.getPrevOptions;
      },
      isValidInputFilterParams(){//VERIFY ALL INPUT FIELDS TO MAKE SURE FIELDS ARE VALID WITH NO ERROR
        let errFound = validatInputParams(JSON.parse(JSON.stringify(this.searchRTFFilters)));
        return errFound ? false : true;
      }
    }),
    ...mapGetters(["getUserName","getPrevOptions"]),
  },
  methods: {
    ...mapActions(["clearAlertMessages","getEntityDisplayDetailsAction","updatePrevOptions"]),
    ...mapMutations([
      "setIsLoading",
      "setAlertMessages",
      "setFilterInputData",
      "setSelectedMenuId",
      "resetEntityDetails",
      "setheaderFilterData",
    ]),
    reassignFilterFields(){
      this.searchRTFFilters = JSON.parse(JSON.stringify(this.inlineFilterConfig.filters));
    },
    // Use if individual record has to be retrieve from backend.
    // Else for atomic entities - filter records on UI
    async getRTFFiltersData() {
      this.clearAlertMessages();
      if (Object.keys(this.addEditItem).length > 0) {
        let errFound = validatInputParams(this.searchRTFFilters);
        if (errFound) {
          let alertInfo = {
            alertType: "error",
            alertMessages: ["Errors in the Search fields!", ...errFound],
          };
          this.setAlertMessages(alertInfo);
          return;
        }
        if(this.isHeaderSrchClicked){
          this.resetEntityDetails();
          this.navigateScreen();
        } else{
          this.setFilterInputData(JSON.parse(JSON.stringify(this.addEditItem)));
        }       
      }
    },
    async navigateScreen(){
      this.setheaderFilterData(this.addEditItem);
      this.redirectToSpecificMenu('flight_Management');
    },
    redirectToSpecificMenu(id) {
      this.getEntityDisplayDetailsAction(id).then(() => {
      this.setSelectedMenuId(id);
      })
    },
    resetFilters() {
      this.addEditItem = {};
      this.clearAlertMessages();
      let defaultOptions;
      if(this.tabPrevOptions){
         defaultOptions = {"type":"All","cabin":"All","compensation":"All",
      "compensation_1": this.tabPrevOptions["compensation_1"]?this.tabPrevOptions["compensation_1"]:'All',
         "pass_class": this.tabPrevOptions["pass_class"]?this.tabPrevOptions["pass_class"] :'All' };
      }else{
         defaultOptions = {"type":"All","cabin":"All","compensation":"All","compensation_1" : 'All',"pass_class" :'All' };
      }
      this.updatePrevOptions(JSON.parse(JSON.stringify(defaultOptions)));
      this.searchRTFFilters = JSON.parse(JSON.stringify(this.inlineFilterConfig.filters));            
      if(this.$refs.dateRangePickerCom && this.$refs.dateRangePickerCom.length > 0){
        this.$refs.dateRangePickerCom.forEach(dtPickr => dtPickr.resetDataRange());//Reset the All DateRangePicker component
      }
      this.resetToDefaultState();
      if(!this.isHeaderSrchClicked){//NO NEED TO FETCH RECORDS ON RESET WHEN GLOBAL SEARCH ACTIVATED
        this.entityDisplayDetails.fetchDefault ? this.getRTFFiltersData(this.searchRTFFilters) : '';
      }
    },
    getSourceOptions(entityItem, index) {
      switch (entityItem.sourceType) {
        case "api":
          return entityItem.source;
        case "inLine":
          return entityItem.source;
        default:
        return entityItem.source;
      }
    },
    updateSearchFields(eVal, filter, modalPath) {
      if (filter?.fieldType == "UADatePicker") {
        this.addEditItem[modalPath] = getDateTimePart(
          filter?.model,
          "yyyy-mm-dd"
        );
      } else if (filter?.fieldType == "UADateRangePicker") {
        for(let [key,value] of Object.entries(filter.model)){
          this.addEditItem[filter.attributes.id[key]] = value;
        } 
      } else {
             if(filter?.id == 'type'){
              filter.model = this.tabPrevOptions["type"],
              filter.defaultSelectedValue = this.tabPrevOptions["type"]
            } else if(filter?.id == 'cabin'){
              
              if(this.tabPrevOptions["cabin"] !=null)
              {
                if(this.tabPrevOptions["cabin"].toLowerCase() != 'all'){
                  filter.model = this.tabPrevOptions["cabin"]?.toLowerCase()?.substring(0,1);
                }else{
                  filter.model = "All"
                }
              }else{
                filter.model = "All"
              }
             //filter.model = this.tabPrevOptions["cabin"],
             filter.defaultSelectedValue = this.tabPrevOptions["cabin"]
            } else if(filter?.id == 'compensation'){
              filter.model = this.tabPrevOptions["compensation"],
              filter.defaultSelectedValue = this.tabPrevOptions["compensation"]
            } else if(filter?.id == 'compensation_1'){
              filter.model = this.tabPrevOptions["compensation_1"],
              filter.defaultSelectedValue = this.tabPrevOptions["compensation_1"]
            } else if(filter?.id == 'pass_class'){
              filter.model = this.tabPrevOptions["pass_class"],
              filter.defaultSelectedValue = this.tabPrevOptions["pass_class"]
            } 
        this.addEditItem[modalPath] = eVal;
      }
      if(this.inlineFilterConfig.onchangeFilter){
        this.setFilterInputData(JSON.parse(JSON.stringify(this.addEditItem)));
      }
    },
    resetToDefaultState() {
      this.searchRTFFilters.forEach((inHeader) => {
        if (inHeader.fieldType) {
          inHeader.isError= false;
            if(inHeader.defaultSelectedValue && inHeader.defaultSelectedValue != "") {
              if(inHeader.fieldType == "UADatePicker"){
                inHeader.model = getDefaultDate(inHeader.defaultSelectedValue);
              } else if(inHeader.fieldType == "UADateRangePicker"){
                inHeader.model =  { 
                  "startDate": getDefaultDate(inHeader.defaultSelectedValue),
                  "endDate": getDefaultDate(inHeader.defaultSelectedValue)
                };
              } else {
                inHeader.model = inHeader.defaultSelectedValue;
              }
              this.updateSearchFields(inHeader.model, inHeader, inHeader.attributes.id);
            } else {
              if(inHeader.fieldType == "UADateRangePicker"){
                inHeader.model =  { "startDate": "","endDate":""};
                this.updateSearchFields(inHeader.model, inHeader, inHeader.attributes.id);
              } else {
                inHeader.model = "";
              }             
            }
        }
      });      
    },
  },
};
</script>

