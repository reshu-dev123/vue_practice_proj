package com.polymorphism;

public class TestOveride {

	public static void main(String[] args) {
		/*MethodOverriding1 obj1 = new MethodOverriding1();
		obj1.test();*/
		MethodOverriding2 obj2 = new MethodOverriding2();
		obj2.test("deepa",20);
		

	}

}
