package com.polymorphism;

public class MethodOverriding1 {
	
	void test(int a,String b) {
		System.out.println("override 1");
	}

	

}
