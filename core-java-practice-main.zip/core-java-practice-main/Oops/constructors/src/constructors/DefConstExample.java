package constructors;

public class DefConstExample {
	int roll_no;
	String name;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	DefConstExample obj= new DefConstExample();//calling constructor
	System.out.println(obj.roll_no+" "+obj.name);
		
	}

}
