package constructors;

public class ParametrizedConst {
	
	public  ParametrizedConst(int a,String b) {
		System.out.println("This is a parametrized constructor");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
	ParametrizedConst obj=new ParametrizedConst(10,"reshma");
	
	}

}
