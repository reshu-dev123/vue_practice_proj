package constructors;

public class NoArgConst {
	
	public NoArgConst() {
		System.out.println("This is no argument constructor");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		NoArgConst obj=new NoArgConst();//automatically called after obj creation
		
	}

}
