package constructors;

public class NoArg1 {
	
	public NoArg1() {
		System.out.println("i am noarg constr");
	}

	public static void main(String[] args) {
		NoArg1 obj = new NoArg1();

	}

}
