package constructors;

public class Para1 {
	
	public Para1(int a,String b) {
		System.out.println("i am para constr");
	}

	public static void main(String[] args) {
	Para1 obj = new Para1( 20,"taara");

	}

}
