package com.inheritance;

public class Cat extends Animal {
	

	void sleep() {
		System.out.println("i am cat");
	}

}
