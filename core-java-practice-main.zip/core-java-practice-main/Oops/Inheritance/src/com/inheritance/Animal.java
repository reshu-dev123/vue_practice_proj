package com.inheritance;

public class Animal {
	
	void run() {
		System.out.println("i am parentclass");
	}

	 

	}


