package com.inheritance;

public class Dog extends Animal{

	void eat() {
		System.out.println("i am childclass");
	}

	

}
