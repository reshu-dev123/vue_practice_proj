package com.inheritance;

public class Test{

public static void main(String[] args) {
   Cat c = new Cat();
   c.sleep();//cat method
  // c.eat();//dog  method
   c.run();// parent class
System.out.println();
	
}
}