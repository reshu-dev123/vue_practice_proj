package com.abstraction;


	public class Scooter extends Vehicle{
		
		void start()
		{
			System.out.println("has 3 tyres");
		}

	}


