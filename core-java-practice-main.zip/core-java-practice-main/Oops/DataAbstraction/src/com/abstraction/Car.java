package com.abstraction;

public class Car extends Vehicle{
	
	void start()
	{
		System.out.println("has 4 tyres");
	}

}
