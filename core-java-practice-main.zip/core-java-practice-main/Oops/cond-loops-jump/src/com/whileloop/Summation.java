package com.whileloop;

public class Summation {

	public static void main(String[] args) {//0+1+.........10=??
		int i =1,sum=0;
		
		while(i<=10) {
			sum=sum+i;//sum=0+1=1
			
			i++;//
		}
			System.out.println("summation:"+sum);//1
		}

	}



