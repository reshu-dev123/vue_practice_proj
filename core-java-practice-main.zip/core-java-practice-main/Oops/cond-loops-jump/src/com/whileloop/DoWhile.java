package com.whileloop;

public class DoWhile {

	public static void main(String[] args) {
		int i=1,n=100;
		do {
			System.out.println("\n"+i);
			i++;
		}
while(i<=n) ;
	
	}
}
